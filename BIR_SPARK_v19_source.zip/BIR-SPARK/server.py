import os
import re
import json
import time
import sqlite3
import threading
import webbrowser
import shutil
import subprocess
import sys
import socket
import ipaddress
import ntpath
import mimetypes

from datetime import datetime, date, timedelta
from html import escape as html_escape
from urllib.parse import urlparse, parse_qs
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED

# ============================================================
# CONFIG
# ============================================================

# Scan sources, displayed labels and media types are loaded ONLY from SQLite.
# Source IDs of existing historical scans (D/H/DJ/HJ) are preserved.
SCAN_LABELS = {}
SCAN_SOURCES = {}
SOURCE_KINDS = {}
LEGACY_HISTORY_TYPES = set()
LEGACY_C_PATH = ""
PORT = int(os.getenv("ATM_PY_PORT", "8080"))
MAX_WORKERS = 10

IMAGE_EXTENSIONS = {".jpg", ".jpeg"}
TXT_EXTENSIONS = {".txt", ".jrn"}  # Explorer-in "JRN File" göstərdiyi fayllar .jrn-dir
VIDEO_EXTENSIONS = {
    ".mp4", ".avi", ".mov", ".mkv", ".wmv", ".mpeg", ".mpg",
    ".m4v", ".3gp", ".webm", ".ts", ".mts", ".m2ts"
}
DATE_PATTERN = re.compile(r"^\d{8}$")

# ============================================================
# PATHS
# ============================================================

def file_url_to_unc(url):
    parsed = urlparse(url)
    host = parsed.netloc
    path = parsed.path.replace("/", "\\").strip("\\")
    return os.path.normpath("\\\\" + host + "\\" + path)


ROOT_PATH = ""  # no hard-coded scan path; config_folders is the authority
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "atm_history.db")
os.chdir(BASE_DIR)

# ============================================================
# DATABASE / HISTORY
# ============================================================

def db_connect():
    con = sqlite3.connect(DB_PATH, timeout=30)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    con = db_connect()
    cur = con.cursor()
    cur.execute("PRAGMA journal_mode=WAL")
    cur.execute("PRAGMA foreign_keys=ON")

    cur.execute("""
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            started_at TEXT NOT NULL,
            finished_at TEXT,
            status TEXT NOT NULL,
            selected_date TEXT NOT NULL,
            yesterday TEXT NOT NULL,
            total_atm INTEGER DEFAULT 0,
            checked INTEGER DEFAULT 0,
            excellent INTEGER DEFAULT 0,
            normal INTEGER DEFAULT 0,
            problem INTEGER DEFAULT 0,
            total_images INTEGER DEFAULT 0,
            total_videos INTEGER DEFAULT 0,
            total_media INTEGER DEFAULT 0,
            duration_seconds REAL DEFAULT 0,
            error TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS scan_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id INTEGER NOT NULL,
            atm TEXT NOT NULL,
            category TEXT NOT NULL,
            reason TEXT,
            yesterday_folder TEXT,
            yesterday_state TEXT,
            last_valid_backup TEXT,
            last_valid_backup_raw TEXT,
            latest_date_folder TEXT,
            latest_date_folder_raw TEXT,
            delay_days INTEGER,
            images INTEGER DEFAULT 0,
            videos INTEGER DEFAULT 0,
            total INTEGER DEFAULT 0,
            last_media_time TEXT,
            FOREIGN KEY(scan_id) REFERENCES scans(id) ON DELETE CASCADE,
            UNIQUE(scan_id, atm)
        )
    """)

    # Existing database is never recreated or cleared. Old scans belong to D Scan.
    existing_columns = {
        row[1] for row in cur.execute("PRAGMA table_info(scans)").fetchall()
    }
    if "scan_type" not in existing_columns:
        cur.execute("ALTER TABLE scans ADD COLUMN scan_type TEXT NOT NULL DEFAULT 'D'")
    if "source_path" not in existing_columns:
        cur.execute("ALTER TABLE scans ADD COLUMN source_path TEXT")
    cur.execute("UPDATE scans SET scan_type = 'D' WHERE scan_type IS NULL OR scan_type = ''")
    # Never backfill historical source paths with the *current* IP: it may differ.
    # Existing historical source_path values are preserved exactly as saved.
    # Non-destructive migration: keep existing records, add TXT columns.
    result_cols = {x[1] for x in cur.execute("PRAGMA table_info(scan_results)")}
    if "txt" not in result_cols:
        cur.execute("ALTER TABLE scan_results ADD COLUMN txt INTEGER NOT NULL DEFAULT 0")
    if "latest_journal_filename" not in result_cols:
        cur.execute("ALTER TABLE scan_results ADD COLUMN latest_journal_filename TEXT NOT NULL DEFAULT ''")
    scan_cols = {x[1] for x in cur.execute("PRAGMA table_info(scans)")}
    if "total_txt" not in scan_cols:
        cur.execute("ALTER TABLE scans ADD COLUMN total_txt INTEGER NOT NULL DEFAULT 0")

    # Source configuration stored in three separate relational tables.
    cur.execute("""CREATE TABLE IF NOT EXISTS config_ips (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        address TEXT NOT NULL UNIQUE
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS config_disks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ip_id INTEGER NOT NULL REFERENCES config_ips(id) ON DELETE CASCADE,
        letter TEXT NOT NULL CHECK(length(letter)=1),
        UNIQUE(ip_id,letter)
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS config_folders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        disk_id INTEGER NOT NULL REFERENCES config_disks(id) ON DELETE CASCADE,
        name TEXT NOT NULL,
        scan_type TEXT UNIQUE,
        UNIQUE(disk_id,name)
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS config_meta (
        id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL DEFAULT 1
    )""")
    cur.execute("INSERT OR IGNORE INTO config_meta(id,revision) VALUES(1,1)")
    # No hard-coded IP, disk or folder is seeded by Python.
    # Existing configuration is retained. Configure any new source in the UI.
    folder_cols={row[1] for row in cur.execute("PRAGMA table_info(config_folders)")}
    if "media_kind" not in folder_cols:
        cur.execute("ALTER TABLE config_folders ADD COLUMN media_kind TEXT NOT NULL DEFAULT 'MEDIA'")
        cur.execute("UPDATE config_folders SET media_kind='TXT' WHERE scan_type IN ('DJ','HJ')")
    # Legacy folders with no scan ID become a stable source derived from their DB id.
    cur.execute("UPDATE config_folders SET scan_type='F' || id WHERE scan_type IS NULL OR scan_type=''")

    cur.execute("CREATE INDEX IF NOT EXISTS idx_scans_type_id ON scans(scan_type, id)")

    cur.execute("CREATE INDEX IF NOT EXISTS idx_scan_results_scan ON scan_results(scan_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_scan_results_atm ON scan_results(atm)")

    # ATM inventory / coordinate management. Real passwords are NEVER stored here.
    # password_env only stores the environment variable NAME, e.g. PASSWORD3.
    cur.execute("""CREATE TABLE IF NOT EXISTS atms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        atm_id TEXT NOT NULL UNIQUE COLLATE NOCASE,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        password_env TEXT,
        status INTEGER NOT NULL DEFAULT 1 CHECK(status IN (0,1)),
        is_deleted INTEGER NOT NULL DEFAULT 0 CHECK(is_deleted IN (0,1)),
        deleted_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        last_connection_at TEXT,
        last_connection_ok INTEGER CHECK(last_connection_ok IN (0,1) OR last_connection_ok IS NULL),
        last_connection_error TEXT
    )""")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_atms_deleted_status ON atms(is_deleted,status)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_atms_atm_id ON atms(atm_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_atms_password_env ON atms(password_env)")

    # Last operational action shown on the ATM map. Existing DBs are migrated in-place.
    atm_cols = {row[1] for row in cur.execute("PRAGMA table_info(atms)").fetchall()}
    if "last_action_type" not in atm_cols:
        cur.execute("ALTER TABLE atms ADD COLUMN last_action_type TEXT")
    if "last_action_at" not in atm_cols:
        cur.execute("ALTER TABLE atms ADD COLUMN last_action_at TEXT")
    if "last_action_ok" not in atm_cols:
        cur.execute("ALTER TABLE atms ADD COLUMN last_action_ok INTEGER")
    if "last_action_detail" not in atm_cols:
        cur.execute("ALTER TABLE atms ADD COLUMN last_action_detail TEXT")

    cur.execute("""CREATE TABLE IF NOT EXISTS atm_activity_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        atm_id TEXT NOT NULL COLLATE NOCASE,
        action_type TEXT NOT NULL,
        action_label TEXT NOT NULL,
        source_module TEXT NOT NULL,
        started_at TEXT NOT NULL,
        finished_at TEXT,
        success INTEGER CHECK(success IN (0,1) OR success IS NULL),
        detail TEXT
    )""")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_atm_activity_atm_id ON atm_activity_log(atm_id, id DESC)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_atm_activity_started ON atm_activity_log(started_at DESC)")

    # Selected ATM disk reports. Existing DB is migrated in-place; no history is deleted.
    cur.execute("""CREATE TABLE IF NOT EXISTS disk_report_runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        started_at TEXT NOT NULL,
        finished_at TEXT,
        status TEXT NOT NULL,
        selected_count INTEGER NOT NULL DEFAULT 0,
        checked_count INTEGER NOT NULL DEFAULT 0,
        success_count INTEGER NOT NULL DEFAULT 0,
        partial_count INTEGER NOT NULL DEFAULT 0,
        failed_count INTEGER NOT NULL DEFAULT 0,
        duration_seconds REAL NOT NULL DEFAULT 0,
        error TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS disk_report_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id INTEGER NOT NULL REFERENCES disk_report_runs(id) ON DELETE CASCADE,
        atm_id TEXT NOT NULL COLLATE NOCASE,
        access_status TEXT NOT NULL,
        connection_ok INTEGER NOT NULL DEFAULT 0,
        password_env TEXT,
        c_total_bytes INTEGER, c_used_bytes INTEGER, c_free_bytes INTEGER, c_used_percent REAL,
        d_total_bytes INTEGER, d_used_bytes INTEGER, d_free_bytes INTEGER, d_used_percent REAL,
        checked_at TEXT NOT NULL,
        error TEXT,
        UNIQUE(run_id, atm_id)
    )""")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_disk_report_runs_started ON disk_report_runs(id DESC)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_disk_report_results_run ON disk_report_results(run_id, atm_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_disk_report_results_atm ON disk_report_results(atm_id, id DESC)")

    # VIDEOARCHIVE Scan (toplu son şəkil yoxlaması)
    cur.execute("""CREATE TABLE IF NOT EXISTS va_scan_runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        started_at TEXT NOT NULL,
        finished_at TEXT,
        status TEXT NOT NULL,
        scope TEXT,
        selected_count INTEGER NOT NULL DEFAULT 0,
        checked_count INTEGER NOT NULL DEFAULT 0,
        active_count INTEGER NOT NULL DEFAULT 0,
        late_count INTEGER NOT NULL DEFAULT 0,
        problem_count INTEGER NOT NULL DEFAULT 0,
        nophoto_count INTEGER NOT NULL DEFAULT 0,
        failed_count INTEGER NOT NULL DEFAULT 0,
        duration_seconds REAL NOT NULL DEFAULT 0,
        error TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS va_scan_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id INTEGER NOT NULL REFERENCES va_scan_runs(id) ON DELETE CASCADE,
        atm_id TEXT NOT NULL COLLATE NOCASE,
        name TEXT, region TEXT,
        category TEXT NOT NULL,
        connection_ok INTEGER NOT NULL DEFAULT 0,
        password_env TEXT,
        archive_path TEXT,
        folder_count INTEGER,
        latest_folder TEXT,
        media_folder TEXT,
        last_image_at TEXT,
        last_image_name TEXT,
        image_count INTEGER,
        video_count INTEGER,
        last_video_at TEXT,
        days_since INTEGER,
        checked_at TEXT NOT NULL,
        duration_seconds REAL,
        error TEXT,
        UNIQUE(run_id, atm_id)
    )""")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_va_results_run ON va_scan_results(run_id, last_image_at DESC)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_va_results_atm ON va_scan_results(atm_id, id DESC)")
    # E$\Video (ikinci mənbə) üçün paralel sütunlar — mövcud bazaya əlavə edilir
    _va_cols = {row[1] for row in cur.execute("PRAGMA table_info(va_scan_results)")}
    for _c, _t in (("video_archive_path", "TEXT"), ("video_category", "TEXT"),
                   ("video_folder_count", "INTEGER"), ("video_latest_folder", "TEXT"),
                   ("video_media_folder", "TEXT"), ("video_last_image_at", "TEXT"),
                   ("video_last_image_name", "TEXT"), ("video_image_count", "INTEGER"),
                   ("video_video_count", "INTEGER"), ("video_days_since", "INTEGER"),
                   ("video_error", "TEXT")):
        if _c not in _va_cols:
            cur.execute(f"ALTER TABLE va_scan_results ADD COLUMN {_c} {_t}")

    # Cached latest disk report fields make the map fast and keep the latest result visible.
    atm_cols = {row[1] for row in cur.execute("PRAGMA table_info(atms)").fetchall()}
    for col, ddl in (
        ("last_disk_report_at", "TEXT"),
        ("last_disk_report_status", "TEXT"),
        ("last_disk_report_run_id", "INTEGER"),
        ("last_disk_c_percent", "REAL"),
        ("last_disk_d_percent", "REAL"),
        ("last_disk_report_error", "TEXT"),
    ):
        if col not in atm_cols:
            cur.execute(f"ALTER TABLE atms ADD COLUMN {col} {ddl}")

    # ATM Info: metadata (Excel master) + son yigilan metrik kesi (xerite/siyahi ucun suretli)
    atm_cols = {row[1] for row in cur.execute("PRAGMA table_info(atms)").fetchall()}
    for col, ddl in (
        ("name", "TEXT"), ("atype", "TEXT"), ("rim", "TEXT"), ("region", "TEXT"),
        ("sys_address", "TEXT"), ("phys_address", "TEXT"),
        ("windows_type", "TEXT"),
        ("last_info_at", "TEXT"), ("last_info_ok", "INTEGER"), ("last_info_method", "TEXT"),
        ("last_cpu_percent", "REAL"), ("last_ram_percent", "REAL"),
        ("last_os_name", "TEXT"), ("last_hostname", "TEXT"), ("last_info_error", "TEXT"),
    ):
        if col not in atm_cols:
            cur.execute(f"ALTER TABLE atms ADD COLUMN {col} {ddl}")

    # ATM Info: her qosulmanin tam neticesi (tarixce / report)
    cur.execute("""CREATE TABLE IF NOT EXISTS atm_info_snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        atm_id TEXT NOT NULL COLLATE NOCASE,
        collected_at TEXT NOT NULL,
        method TEXT,
        password_env TEXT,
        online INTEGER NOT NULL DEFAULT 0,
        cpu_percent REAL, cpu_name TEXT, cpu_cores INTEGER,
        ram_total_bytes INTEGER, ram_used_bytes INTEGER, ram_free_bytes INTEGER, ram_percent REAL,
        os_name TEXT, os_version TEXT, os_build TEXT, os_architecture TEXT,
        hostname TEXT, uptime_seconds INTEGER, boot_time TEXT,
        disk_count INTEGER, disks_json TEXT, raw_json TEXT,
        latency_ms INTEGER, error TEXT
    )""")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_atm_info_snap_atm ON atm_info_snapshots(atm_id, id DESC)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_atm_info_snap_at ON atm_info_snapshots(collected_at DESC)")

    cur.execute("""
        UPDATE va_scan_runs
        SET status='INTERRUPTED', finished_at=COALESCE(finished_at, ?)
        WHERE status='RUNNING'
    """, (datetime.now().isoformat(timespec="seconds"),))
    # If the app was stopped during a report, preserve it as interrupted history.
    cur.execute("""
        UPDATE disk_report_runs
        SET status='INTERRUPTED', finished_at=COALESCE(finished_at, ?)
        WHERE status='RUNNING'
    """, (datetime.now().isoformat(timespec="seconds"),))

    # Əgər proqram əvvəl scan gedərkən bağlanıbsa, həmin scan tarixçədə qalsın.
    now = datetime.now().isoformat(timespec="seconds")
    cur.execute("""
        UPDATE scans
        SET status = 'INTERRUPTED',
            finished_at = COALESCE(finished_at, ?)
        WHERE status = 'RUNNING'
    """, (now,))

    # ========================================================
    # AGENT MONITOR: ATM-in içindəki agent (exe) push ilə məlumat göndərir.
    # Hər ATM üçün ən son hesabat agent_reports-da saxlanılır (UNIQUE upsert).
    # Tarixçə/trend üçün agent_report_log saxlanılır (ATM başına 200 sətir limiti).
    # ========================================================
    cur.execute("""
        CREATE TABLE IF NOT EXISTS agent_reports (
            atm_id TEXT PRIMARY KEY COLLATE NOCASE,
            hostname TEXT,
            os_name TEXT,
            os_version TEXT,
            os_build TEXT,
            os_architecture TEXT,
            cpu_name TEXT,
            cpu_percent REAL,
            cpu_cores INTEGER,
            cpu_logical INTEGER,
            ram_total_bytes INTEGER,
            ram_used_bytes INTEGER,
            ram_free_bytes INTEGER,
            ram_percent REAL,
            disk_total_bytes INTEGER,
            disk_used_bytes INTEGER,
            disk_free_bytes INTEGER,
            disk_count INTEGER,
            uptime_seconds INTEGER,
            boot_time TEXT,
            agent_version TEXT,
            source_ip TEXT,
            collected_at TEXT,
            received_at TEXT NOT NULL,
            payload TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS agent_report_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            atm_id TEXT NOT NULL COLLATE NOCASE,
            cpu_percent REAL,
            ram_percent REAL,
            disk_used_bytes INTEGER,
            disk_total_bytes INTEGER,
            source_ip TEXT,
            received_at TEXT NOT NULL
        )
    """)
    cur.execute("CREATE INDEX IF NOT EXISTS idx_agent_log_atm ON agent_report_log(atm_id, id DESC)")

    # ---- MÜQAYİSƏ (eyniləşdirmə) — ATM ↔ server backup ----
    cur.execute("""CREATE TABLE IF NOT EXISTS cmp_runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        started_at TEXT NOT NULL, finished_at TEXT, status TEXT NOT NULL,
        scope TEXT, selected_count INTEGER NOT NULL DEFAULT 0,
        checked_count INTEGER NOT NULL DEFAULT 0, ok_count INTEGER NOT NULL DEFAULT 0,
        diff_count INTEGER NOT NULL DEFAULT 0, failed_count INTEGER NOT NULL DEFAULT 0,
        atm_files INTEGER NOT NULL DEFAULT 0, missing_files INTEGER NOT NULL DEFAULT 0,
        srv_img_files INTEGER NOT NULL DEFAULT 0, srv_jrn_files INTEGER NOT NULL DEFAULT 0,
        duration_seconds REAL NOT NULL DEFAULT 0, error TEXT)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS cmp_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id INTEGER NOT NULL REFERENCES cmp_runs(id) ON DELETE CASCADE,
        atm_id TEXT NOT NULL COLLATE NOCASE, name TEXT, region TEXT,
        category TEXT NOT NULL, connection_ok INTEGER NOT NULL DEFAULT 0, password_env TEXT,
        img_total INTEGER, img_backed INTEGER, img_missing INTEGER,
        jrn_total INTEGER, jrn_backed INTEGER, jrn_missing INTEGER,
        missing_json TEXT, checked_at TEXT NOT NULL, duration_seconds REAL, error TEXT,
        UNIQUE(run_id, atm_id))""")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_cmp_results_run ON cmp_results(run_id, id)")

    # ---- ATM JURNAL SCAN — C$\JOURNAL + C$\Mobilpay\LOG (sonuncu tarix) ----
    cur.execute("""CREATE TABLE IF NOT EXISTS ajscan_runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        started_at TEXT NOT NULL, finished_at TEXT, status TEXT NOT NULL,
        scope TEXT, selected_count INTEGER NOT NULL DEFAULT 0,
        checked_count INTEGER NOT NULL DEFAULT 0, ok_count INTEGER NOT NULL DEFAULT 0,
        empty_count INTEGER NOT NULL DEFAULT 0, failed_count INTEGER NOT NULL DEFAULT 0,
        duration_seconds REAL NOT NULL DEFAULT 0, error TEXT)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS ajscan_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id INTEGER NOT NULL REFERENCES ajscan_runs(id) ON DELETE CASCADE,
        atm_id TEXT NOT NULL COLLATE NOCASE, name TEXT, region TEXT,
        category TEXT NOT NULL, connection_ok INTEGER NOT NULL DEFAULT 0, password_env TEXT,
        j_date TEXT, j_files INTEGER, j_bytes INTEGER, j_last TEXT, j_error TEXT,
        m_date TEXT, m_files INTEGER, m_bytes INTEGER, m_last TEXT, m_error TEXT,
        checked_at TEXT NOT NULL, duration_seconds REAL, error TEXT,
        UNIQUE(run_id, atm_id))""")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_ajscan_results_run ON ajscan_results(run_id, id)")

    # ---- ATM Monitoring Agent — per-ATM gizli açar (HMAC autentifikasiya) ----
    cur.execute("""CREATE TABLE IF NOT EXISTS agent_tokens (
        atm_id TEXT PRIMARY KEY COLLATE NOCASE,
        secret TEXT NOT NULL,
        enabled INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        rotated_at TEXT,
        last_seen TEXT,
        last_ip TEXT,
        agent_version TEXT,
        note TEXT)""")

    # ---- XƏBƏRDARLIQLAR (Alerts) — avtomatik şəkil/jurnal/backup yoxlaması ----
    cur.execute("""CREATE TABLE IF NOT EXISTS alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        atm_id TEXT NOT NULL COLLATE NOCASE,
        kind TEXT NOT NULL,
        severity TEXT NOT NULL DEFAULT 'problem',
        status TEXT NOT NULL DEFAULT 'active',
        message TEXT,
        details TEXT,
        first_seen TEXT NOT NULL,
        last_seen TEXT NOT NULL,
        resolved_at TEXT,
        UNIQUE(atm_id, kind))""")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status, last_seen DESC)")
    cur.execute("""CREATE TABLE IF NOT EXISTS alert_config (
        id INTEGER PRIMARY KEY CHECK (id=1),
        enabled INTEGER NOT NULL DEFAULT 0,
        interval_minutes INTEGER NOT NULL DEFAULT 180,
        image_max_days INTEGER NOT NULL DEFAULT 2,
        journal_max_days INTEGER NOT NULL DEFAULT 2,
        check_images INTEGER NOT NULL DEFAULT 1,
        check_journals INTEGER NOT NULL DEFAULT 1,
        check_server INTEGER NOT NULL DEFAULT 0,
        mail_on INTEGER NOT NULL DEFAULT 0,
        updated_at TEXT)""")
    cur.execute("INSERT OR IGNORE INTO alert_config(id,updated_at) VALUES(1, ?)",
                (datetime.now().isoformat(timespec="seconds"),))

    # ---- BİLDİRİŞLƏR / Hesabat qutusu — bütün yaradılan Excel-lər ----
    cur.execute("""CREATE TABLE IF NOT EXISTS report_files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        module TEXT NOT NULL,
        title TEXT,
        filename TEXT NOT NULL,
        path TEXT NOT NULL,
        size_bytes INTEGER,
        summary TEXT,
        created_at TEXT NOT NULL)""")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_report_files ON report_files(id DESC)")

    # ---- Server (77) backup xəbərdarlıq config ----
    cur.execute("""CREATE TABLE IF NOT EXISTS srvalert_config (
        id INTEGER PRIMARY KEY CHECK (id=1),
        enabled INTEGER NOT NULL DEFAULT 0,
        interval_minutes INTEGER NOT NULL DEFAULT 180,
        max_days INTEGER NOT NULL DEFAULT 2,
        mail_on INTEGER NOT NULL DEFAULT 0,
        updated_at TEXT)""")
    cur.execute("INSERT OR IGNORE INTO srvalert_config(id,updated_at) VALUES(1, ?)",
                (datetime.now().isoformat(timespec="seconds"),))

    # ---- Sadə ATM Agent (müvəqqəti) — CPU/RAM/C/D disk/IP, /agent ----
    cur.execute("""CREATE TABLE IF NOT EXISTS simple_agent (
        atm_id TEXT PRIMARY KEY COLLATE NOCASE,
        hostname TEXT, ip TEXT,
        cpu_percent REAL, ram_percent REAL, ram_total_bytes INTEGER, ram_used_bytes INTEGER,
        c_total_bytes INTEGER, c_free_bytes INTEGER, c_percent REAL,
        d_total_bytes INTEGER, d_free_bytes INTEGER, d_percent REAL,
        source_ip TEXT, interval_minutes INTEGER, collected_at TEXT, received_at TEXT NOT NULL)""")

    con.commit()
    con.close()


# ============================================================
# AGENT MONITOR — push rejimli hesabat qəbulu və oxunması
# ============================================================
AGENT_LOCK = threading.RLock()
AGENT_LOG_LIMIT = 200          # ATM başına saxlanan maksimum tarixçə sətri
AGENT_MAX_DISKS = 64           # sui-istifadəyə qarşı limit


def _num(value, default=None):
    try:
        if value is None or value == "":
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _int(value, default=None):
    f = _num(value, None)
    return int(f) if f is not None else default


def _text(value, limit=256):
    if value is None:
        return ""
    s = str(value).strip()
    return s[:limit]


def agent_report_ingest(data, source_ip):
    """Agent-dən gələn JSON hesabatını yoxlayıb bazaya yazır (upsert)."""
    if not isinstance(data, dict):
        raise ValueError("JSON obyekt gözlənilir.")

    atm_id = _text(data.get("atm_id"), 64)
    if not atm_id:
        raise ValueError("atm_id boş ola bilməz.")
    if not re.match(r"^[A-Za-z0-9_\-]{1,64}$", atm_id):
        raise ValueError("atm_id yalnız hərf, rəqəm, '-' və '_' ola bilər.")

    # Diskləri normallaşdır və ümumi yaddaşı hesabla
    raw_disks = data.get("disks") or []
    if not isinstance(raw_disks, list):
        raw_disks = []
    disks = []
    disk_total = disk_used = disk_free = 0
    for d in raw_disks[:AGENT_MAX_DISKS]:
        if not isinstance(d, dict):
            continue
        tb = _int(d.get("total_bytes"), 0) or 0
        ub = _int(d.get("used_bytes"), 0) or 0
        fb = _int(d.get("free_bytes"), 0) or 0
        pct = _num(d.get("used_percent"), None)
        if pct is None and tb > 0:
            pct = round(100.0 * ub / tb, 1)
        disks.append({
            "name": _text(d.get("name"), 32),
            "label": _text(d.get("label"), 64),
            "filesystem": _text(d.get("filesystem"), 32),
            "total_bytes": tb, "used_bytes": ub, "free_bytes": fb,
            "used_percent": pct,
        })
        disk_total += tb
        disk_used += ub
        disk_free += fb

    ram_total = _int(data.get("ram_total_bytes"), 0) or 0
    ram_used = _int(data.get("ram_used_bytes"), 0) or 0
    ram_free = _int(data.get("ram_free_bytes"), 0) or 0
    ram_percent = _num(data.get("ram_percent"), None)
    if ram_percent is None and ram_total > 0:
        ram_percent = round(100.0 * ram_used / ram_total, 1)

    arch = _text(data.get("os_architecture"), 32)
    # 64/32 bit-i standartlaşdır
    low = arch.lower()
    if "64" in low:
        arch = "64-bit"
    elif "32" in low or "x86" in low:
        arch = "32-bit"

    received_at = datetime.now().isoformat(timespec="seconds")
    record = {
        "atm_id": atm_id,
        "hostname": _text(data.get("hostname"), 128),
        "os_name": _text(data.get("os_name"), 128),
        "os_version": _text(data.get("os_version"), 64),
        "os_build": _text(data.get("os_build"), 64),
        "os_architecture": arch,
        "cpu_name": _text(data.get("cpu_name"), 128),
        "cpu_percent": _num(data.get("cpu_percent"), None),
        "cpu_cores": _int(data.get("cpu_cores"), None),
        "cpu_logical": _int(data.get("cpu_logical"), None),
        "ram_total_bytes": ram_total,
        "ram_used_bytes": ram_used,
        "ram_free_bytes": ram_free,
        "ram_percent": ram_percent,
        "disk_total_bytes": disk_total,
        "disk_used_bytes": disk_used,
        "disk_free_bytes": disk_free,
        "disk_count": len(disks),
        "uptime_seconds": _int(data.get("uptime_seconds"), None),
        "boot_time": _text(data.get("boot_time"), 64),
        "agent_version": _text(data.get("agent_version"), 32),
        "source_ip": _text(source_ip, 64),
        "collected_at": _text(data.get("collected_at"), 64),
        "received_at": received_at,
    }
    # Tam detalı (disklər daxil) payload-da saxla
    full = dict(record)
    full["disks"] = disks
    record["payload"] = json.dumps(full, ensure_ascii=False)

    cols = list(record.keys())
    placeholders = ",".join("?" for _ in cols)
    updates = ",".join(f"{c}=excluded.{c}" for c in cols if c != "atm_id")

    with AGENT_LOCK:
        con = db_connect()
        try:
            con.execute(
                f"INSERT INTO agent_reports ({','.join(cols)}) VALUES ({placeholders}) "
                f"ON CONFLICT(atm_id) DO UPDATE SET {updates}",
                [record[c] for c in cols],
            )
            con.execute(
                "INSERT INTO agent_report_log "
                "(atm_id,cpu_percent,ram_percent,disk_used_bytes,disk_total_bytes,source_ip,received_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (atm_id, record["cpu_percent"], record["ram_percent"],
                 disk_used, disk_total, record["source_ip"], received_at),
            )
            # Tarixçəni ATM başına AGENT_LOG_LIMIT sətirlə məhdudlaşdır
            con.execute(
                "DELETE FROM agent_report_log WHERE atm_id=? AND id NOT IN "
                "(SELECT id FROM agent_report_log WHERE atm_id=? ORDER BY id DESC LIMIT ?)",
                (atm_id, atm_id, AGENT_LOG_LIMIT),
            )
            con.commit()
        finally:
            con.close()
    return {"success": True, "atm_id": atm_id, "received_at": received_at}


def agent_report_list():
    """Bütün ATM-lərin ən son agent hesabatı (modul siyahısı üçün)."""
    con = db_connect()
    try:
        rows = con.execute(
            "SELECT atm_id,hostname,os_name,os_version,os_architecture,"
            "cpu_percent,cpu_cores,cpu_logical,ram_total_bytes,ram_used_bytes,ram_percent,"
            "disk_total_bytes,disk_used_bytes,disk_free_bytes,disk_count,"
            "uptime_seconds,agent_version,source_ip,collected_at,received_at "
            "FROM agent_reports ORDER BY received_at DESC"
        ).fetchall()
    finally:
        con.close()
    now = datetime.now()
    items = []
    for r in rows:
        d = dict(r)
        # Son 10 dəqiqədən köhnə hesabat = offline sayılır
        online = False
        try:
            dt = datetime.fromisoformat(d["received_at"])
            online = (now - dt).total_seconds() <= 600
        except (ValueError, TypeError):
            pass
        d["online"] = online
        items.append(d)
    return {"success": True, "count": len(items), "items": items}


def agent_report_detail(atm_id):
    """Bir ATM üçün tam hesabat (disklər daxil) + son tarixçə."""
    atm_id = _text(atm_id, 64)
    if not atm_id:
        raise ValueError("atm_id boş ola bilməz.")
    con = db_connect()
    try:
        row = con.execute(
            "SELECT payload,received_at FROM agent_reports WHERE atm_id=? COLLATE NOCASE",
            (atm_id,),
        ).fetchone()
        if not row:
            return {"success": False, "error": "Bu ATM üçün hələ hesabat yoxdur."}
        history = con.execute(
            "SELECT cpu_percent,ram_percent,disk_used_bytes,disk_total_bytes,received_at "
            "FROM agent_report_log WHERE atm_id=? COLLATE NOCASE ORDER BY id DESC LIMIT 60",
            (atm_id,),
        ).fetchall()
    finally:
        con.close()
    try:
        payload = json.loads(row["payload"])
    except (ValueError, TypeError):
        payload = {}
    return {
        "success": True,
        "report": payload,
        "history": [dict(h) for h in reversed(history)],
    }


# ============================================================
# SADƏ ATM AGENT (müvəqqəti) — CPU/RAM/C/D disk/IP, POST /agent
# ============================================================
def sagent_ingest(data, source_ip):
    if not isinstance(data, dict):
        raise ValueError("JSON obyekt gözlənilir.")
    atm_id = _text(data.get("atm_id"), 64)
    if not atm_id or not re.match(r"^[A-Za-z0-9_\-]{1,64}$", atm_id):
        raise ValueError("atm_id düzgün deyil.")

    def disk(prefix):
        d = data.get(prefix) or {}
        if not isinstance(d, dict):
            d = {}
        tb = _int(d.get("total_bytes"), 0) or 0
        fb = _int(d.get("free_bytes"), 0) or 0
        pct = _num(d.get("used_percent"), None)
        if pct is None and tb > 0:
            pct = round(100.0 * (tb - fb) / tb, 1)
        return tb, fb, pct

    ram_total = _int(data.get("ram_total_bytes"), 0) or 0
    ram_used = _int(data.get("ram_used_bytes"), 0) or 0
    ram_pct = _num(data.get("ram_percent"), None)
    if ram_pct is None and ram_total > 0:
        ram_pct = round(100.0 * ram_used / ram_total, 1)
    ct, cf, cp = disk("c")
    dt, df, dp = disk("d")
    now = datetime.now().isoformat(timespec="seconds")
    rec = (atm_id, _text(data.get("hostname"), 128), _text(data.get("ip"), 64),
           _num(data.get("cpu_percent"), None), ram_pct, ram_total, ram_used,
           ct, cf, cp, dt, df, dp, _text(source_ip, 64),
           _int(data.get("interval_minutes"), None), _text(data.get("collected_at"), 64), now)
    con = db_connect()
    try:
        con.execute("""INSERT INTO simple_agent
            (atm_id,hostname,ip,cpu_percent,ram_percent,ram_total_bytes,ram_used_bytes,
             c_total_bytes,c_free_bytes,c_percent,d_total_bytes,d_free_bytes,d_percent,
             source_ip,interval_minutes,collected_at,received_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(atm_id) DO UPDATE SET
             hostname=excluded.hostname,ip=excluded.ip,cpu_percent=excluded.cpu_percent,
             ram_percent=excluded.ram_percent,ram_total_bytes=excluded.ram_total_bytes,
             ram_used_bytes=excluded.ram_used_bytes,c_total_bytes=excluded.c_total_bytes,
             c_free_bytes=excluded.c_free_bytes,c_percent=excluded.c_percent,
             d_total_bytes=excluded.d_total_bytes,d_free_bytes=excluded.d_free_bytes,
             d_percent=excluded.d_percent,source_ip=excluded.source_ip,
             interval_minutes=excluded.interval_minutes,collected_at=excluded.collected_at,
             received_at=excluded.received_at""", rec)
        con.commit()
    finally:
        con.close()
    return {"success": True, "atm_id": atm_id}


def sagent_list():
    con = db_connect()
    try:
        rows = con.execute("SELECT * FROM simple_agent ORDER BY atm_id COLLATE NOCASE").fetchall()
        return {"success": True, "rows": [dict(r) for r in rows],
                "server_time": datetime.now().isoformat(timespec="seconds")}
    finally:
        con.close()


# ============================================================
# ATM MONITORING AGENT — per-ATM HMAC autentifikasiya + telemetry
#   Agent:  POST /api/agent/telemetry
#   Başlıqlar: X-ATM-ID, X-ATM-TS (unix saniyə), X-ATM-SIG (hex HMAC-SHA256)
#   İmza:   HMAC-SHA256(secret, f"{ts}\n{atm_id}\n{body_bytes}")
#   Təhlükəsizlik: parol/secret heç vaxt loglanmır; yalnız hex imza yoxlanılır.
# ============================================================
import hmac as _hmac
import hashlib as _hashlib

AGENT_TS_WINDOW = 300  # imza vaxtı ±5 dəqiqə (replay-ə qarşı)


def _agent_gen_secret():
    return secrets.token_hex(32) if "secrets" in globals() else os.urandom(32).hex()


def agent_token_provision(atm_id, note=""):
    """ATM üçün yeni gizli açar yaradır (varsa rotasiya edir). Açarı QAYTARIR (yalnız bir dəfə göstərilir)."""
    atm_id = _text(atm_id, 64)
    if not re.match(r"^[A-Za-z0-9_\-]{1,64}$", atm_id or ""):
        raise ValueError("atm_id yalnız hərf, rəqəm, '-' və '_' ola bilər.")
    secret = _agent_gen_secret()
    now = datetime.now().isoformat(timespec="seconds")
    con = db_connect()
    try:
        exists = con.execute("SELECT atm_id FROM agent_tokens WHERE atm_id=? COLLATE NOCASE", (atm_id,)).fetchone()
        if exists:
            con.execute("UPDATE agent_tokens SET secret=?, enabled=1, rotated_at=?, note=? WHERE atm_id=? COLLATE NOCASE",
                        (secret, now, _text(note, 256), atm_id))
        else:
            con.execute("INSERT INTO agent_tokens(atm_id,secret,enabled,created_at,note) VALUES(?,?,1,?,?)",
                        (atm_id, secret, now, _text(note, 256)))
        con.commit()
    finally:
        con.close()
    return {"success": True, "atm_id": atm_id, "secret": secret,
            "rotated": bool(exists), "note": "Bu açar yalnız indi göstərilir — agent konfiqurasiyasına yazın."}


def agent_token_list():
    con = db_connect()
    try:
        rows = con.execute("""SELECT atm_id,enabled,created_at,rotated_at,last_seen,last_ip,agent_version,note
                              FROM agent_tokens ORDER BY atm_id COLLATE NOCASE""").fetchall()
        return {"success": True, "tokens": [dict(r) for r in rows]}
    finally:
        con.close()


def agent_token_revoke(atm_id, enabled=False):
    atm_id = _text(atm_id, 64)
    con = db_connect()
    try:
        cur = con.execute("UPDATE agent_tokens SET enabled=? WHERE atm_id=? COLLATE NOCASE",
                          (1 if enabled else 0, atm_id))
        con.commit()
        if cur.rowcount == 0:
            return {"success": False, "error": "ATM tapılmadı."}
        return {"success": True, "atm_id": atm_id, "enabled": bool(enabled)}
    finally:
        con.close()


def agent_verify_signature(atm_id, ts, sig, body_bytes):
    """HMAC imzasını yoxlayır. (ok, error) qaytarır. Secret yaddaşda qalmır, loglanmır."""
    atm_id = _text(atm_id, 64)
    if not atm_id or not sig or not ts:
        return False, "İmza başlıqları natamamdır."
    try:
        ts_i = int(ts)
    except (TypeError, ValueError):
        return False, "Vaxt möhürü düzgün deyil."
    now = int(time.time())
    if abs(now - ts_i) > AGENT_TS_WINDOW:
        return False, "Vaxt möhürü köhnədir (saat fərqi və ya replay)."
    con = db_connect()
    try:
        row = con.execute("SELECT secret,enabled FROM agent_tokens WHERE atm_id=? COLLATE NOCASE", (atm_id,)).fetchone()
    finally:
        con.close()
    if not row:
        return False, "Bu ATM qeydiyyatdan keçməyib (token yoxdur)."
    if not row["enabled"]:
        return False, "Bu ATM-in agenti deaktiv edilib."
    mac = _hmac.new(row["secret"].encode("utf-8"),
                    (str(ts_i) + "\n" + atm_id + "\n").encode("utf-8") + body_bytes,
                    _hashlib.sha256).hexdigest()
    if not _hmac.compare_digest(mac, str(sig).strip().lower()):
        return False, "İmza uyğun deyil."
    return True, None


def agent_token_touch(atm_id, source_ip, agent_version):
    now = datetime.now().isoformat(timespec="seconds")
    con = db_connect()
    try:
        con.execute("UPDATE agent_tokens SET last_seen=?, last_ip=?, agent_version=? WHERE atm_id=? COLLATE NOCASE",
                    (now, _text(source_ip, 64), _text(agent_version, 32), atm_id))
        con.commit()
    finally:
        con.close()


def agent_telemetry_ingest(atm_id, body_bytes, source_ip):
    """İmza yoxlandıqdan sonra çağırılır. body tək obyekt və ya {'batch':[...]} ola bilər (offline növbə)."""
    try:
        data = json.loads(body_bytes.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise ValueError("JSON oxunmadı.")
    if isinstance(data, dict) and isinstance(data.get("batch"), list):
        items = data["batch"]
    elif isinstance(data, list):
        items = data
    elif isinstance(data, dict):
        items = [data]
    else:
        raise ValueError("JSON formatı düzgün deyil.")
    if len(items) > 500:
        raise ValueError("Bir sorğuda maksimum 500 qeyd.")
    accepted = 0
    errors = []
    agent_version = ""
    for rec in items:
        if not isinstance(rec, dict):
            continue
        # Hər qeydin atm_id-si başlıqdakı ilə üst-üstə düşməlidir (başqa ATM adından göndərilməsin)
        rec = dict(rec)
        rec["atm_id"] = atm_id
        try:
            agent_report_ingest(rec, source_ip)
            accepted += 1
            agent_version = _text(rec.get("agent_version"), 32) or agent_version
        except Exception as exc:
            errors.append(system_clean_error(exc))
    agent_token_touch(atm_id, source_ip, agent_version)
    return {"success": True, "accepted": accepted, "received": len(items),
            "errors": errors[:10]}


# ============================================================
# CONFIGURATION: IP -> disk -> folder. Historical scan paths never change.
# ============================================================
CONFIG_LOCK = threading.RLock()


def db_source_rows(con):
    return con.execute("""
        SELECT f.id AS folder_id, f.scan_type, f.name, f.media_kind,
               i.id AS ip_id, i.address, d.id AS disk_id, d.letter
        FROM config_folders f
        JOIN config_disks d ON d.id=f.disk_id
        JOIN config_ips i ON i.id=d.ip_id
        WHERE f.scan_type IS NOT NULL AND f.scan_type!=''
        ORDER BY i.address,d.letter,f.name
    """).fetchall()


def db_source_paths(con):
    return {
        r["scan_type"]: chr(92)*2 + r["address"] + chr(92) + r["letter"].lower() + "$" + chr(92) + r["name"]
        for r in db_source_rows(con)
    }


def db_source_labels(con):
    traditional={"D":"D Scan","H":"H Scan","DJ":"D Scan Jurnal","HJ":"H Scan Jurnal"}
    return {r["scan_type"]:traditional.get(r["scan_type"], r["name"]+" Scan")
            for r in db_source_rows(con)}


def db_source_kinds(con):
    return {r["scan_type"]: ("TXT" if r["scan_type"] in ("DJ", "HJ") else r["media_kind"])
            for r in db_source_rows(con)}


def refresh_source_cache():
    with CONFIG_LOCK:
        con=db_connect()
        try:
            paths=db_source_paths(con)
            labels=db_source_labels(con)
            kinds=db_source_kinds(con)
        finally:
            con.close()
        with SCAN_LOCK:
            SCAN_SOURCES.clear(); SCAN_SOURCES.update(paths)
            SCAN_LABELS.clear(); SCAN_LABELS.update(labels)
            SOURCE_KINDS.clear(); SOURCE_KINDS.update(kinds)
            # Don't discard an in-flight scan or its result; old history also remains in DB.
            for scan_type in labels:
                if scan_type not in SCAN_STATES:
                    SCAN_STATES[scan_type]=new_scan_state(scan_type)
            for scan_type,state in SCAN_STATES.items():
                if not state["running"]:
                    state["source_path"]=SCAN_SOURCES.get(scan_type,"")


def is_journal_source(scan_type):
    return scan_type in ("DJ", "HJ") or SOURCE_KINDS.get(scan_type) == "TXT"


def config_snapshot():
    con = db_connect()
    try:
        ips = [dict(r) for r in con.execute("SELECT * FROM config_ips ORDER BY address")]
        disks = [dict(r) for r in con.execute("SELECT * FROM config_disks ORDER BY ip_id,letter")]
        folders = [dict(r) for r in con.execute("SELECT * FROM config_folders ORDER BY disk_id,name")]
        rev = con.execute("SELECT revision FROM config_meta WHERE id=1").fetchone()[0]
        history_types=[r[0] for r in con.execute(
            "SELECT DISTINCT scan_type FROM scans WHERE scan_type IS NOT NULL ORDER BY scan_type")]
        return {"success":True,"ips":ips,"disks":disks,"folders":folders,
                "paths":db_source_paths(con),"revision":rev,
                "scan_labels":db_source_labels(con),"source_kinds":db_source_kinds(con),
                "history_types":history_types,
                "normal_tolerance":{k: normal_tolerance_days(k) for k in db_source_labels(con)}}
    finally:
        con.close()


def config_save(data):
    entity = str(data.get("entity", ""))
    record_id = int(data.get("id") or 0)
    with CONFIG_LOCK:
        con = db_connect()
        con.execute("PRAGMA foreign_keys=ON")
        try:
            con.execute("BEGIN IMMEDIATE")
            if entity == "ip":
                address = str(data.get("address", "")).strip()
                try:
                    ipaddress.ip_address(address)
                except ValueError:
                    raise ValueError("Düzgün IP ünvanı daxil et.")
                if record_id:
                    cur = con.execute("UPDATE config_ips SET address=? WHERE id=?",(address,record_id))
                else:
                    cur = con.execute("INSERT INTO config_ips(address) VALUES(?)",(address,))
            elif entity == "disk":
                ip_id = int(data.get("ip_id") or 0)
                letter = str(data.get("letter", "")).strip().upper().replace(":", "")
                if not re.fullmatch(r"[A-Z]",letter):
                    raise ValueError("Disk hərfi A-Z aralığında olmalıdır (məsələn H).")
                if not con.execute("SELECT 1 FROM config_ips WHERE id=?",(ip_id,)).fetchone():
                    raise ValueError("IP seçilməyib.")
                if record_id:
                    cur = con.execute("UPDATE config_disks SET ip_id=?,letter=? WHERE id=?",(ip_id,letter,record_id))
                else:
                    cur = con.execute("INSERT INTO config_disks(ip_id,letter) VALUES(?,?)",(ip_id,letter))
            elif entity == "folder":
                ip_id = int(data.get("ip_id") or 0)
                disk_id = int(data.get("disk_id") or 0)
                folder = str(data.get("name", "")).strip().strip("\\/")
                requested_type = str(data.get("scan_type") or "").strip().upper()
                if requested_type and requested_type not in ("D","H","DJ","HJ"):
                    raise ValueError("Köhnə scan təyinatı düzgün deyil.")
                media_kind = str(data.get("media_kind") or "MEDIA").strip().upper()
                if media_kind not in ("MEDIA", "TXT"):
                    raise ValueError("Fayl növü MEDIA və ya TXT olmalıdır.")
                if not re.fullmatch(r"[A-Za-z0-9_ .-]{1,120}",folder) or folder in (".","..") or ".." in folder:
                    raise ValueError("Folder adı yalnız bir qovluq adı olmalıdır (məsələn JOURNAL_FILES).")
                if not con.execute("SELECT 1 FROM config_disks WHERE id=? AND ip_id=?",(disk_id,ip_id)).fetchone():
                    raise ValueError("Seçilən disk həmin IP-yə aid deyil.")
                current=None
                if record_id:
                    current=con.execute("SELECT scan_type FROM config_folders WHERE id=?",(record_id,)).fetchone()
                    if not current:
                        raise ValueError("Redaktə üçün folder tapılmadı.")
                # Existing legacy scan identity survives editing unless explicitly reassigned.
                scan_type=requested_type or (current[0] if current else None)
                if requested_type:
                    other=con.execute("SELECT id FROM config_folders WHERE scan_type=? AND id<>?",(requested_type,record_id)).fetchone()
                    if other:
                        con.execute("UPDATE config_folders SET scan_type='F' || id WHERE id=?",(other[0],))
                if record_id:
                    if not scan_type: scan_type="F"+str(record_id)
                    cur=con.execute("UPDATE config_folders SET disk_id=?,name=?,scan_type=?,media_kind=? WHERE id=?",
                                    (disk_id,folder,scan_type,media_kind,record_id))
                else:
                    # Use an id-based stable source for every new folder.
                    cur=con.execute("INSERT INTO config_folders(disk_id,name,scan_type,media_kind) VALUES(?,?,?,?)",
                                    (disk_id,folder,requested_type or None,media_kind))
                    if not requested_type:
                        con.execute("UPDATE config_folders SET scan_type='F' || id WHERE id=?",(cur.lastrowid,))
            else:
                raise ValueError("Naməlum konfiqurasiya obyekti.")
            if record_id and cur.rowcount == 0:
                raise ValueError("Redaktə üçün qeyd tapılmadı.")
            con.execute("UPDATE config_meta SET revision=revision+1 WHERE id=1")
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()
        refresh_source_cache()
    return config_snapshot()


def config_delete(data):
    entity = str(data.get("entity", ""))
    record_id = int(data.get("id") or 0)
    tables={"ip":"config_ips","disk":"config_disks","folder":"config_folders"}
    if entity not in tables or record_id <= 0:
        raise ValueError("Silinəcək qeyd düzgün deyil.")
    with CONFIG_LOCK:
        con=db_connect()
        con.execute("PRAGMA foreign_keys=ON")
        try:
            con.execute("BEGIN IMMEDIATE")
            # Deleting an IP/disk deletes its child config only, not scan history.
            con.execute("DELETE FROM "+tables[entity]+" WHERE id=?",(record_id,))
            con.execute("UPDATE config_meta SET revision=revision+1 WHERE id=1")
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()
        refresh_source_cache()
    return config_snapshot()


def create_scan_record(selected_date, yesterday, scan_type, source_path):
    started_at = datetime.now().isoformat(timespec="seconds")
    con = db_connect()
    cur = con.cursor()
    cur.execute("""
        INSERT INTO scans (
            started_at, status, selected_date, yesterday, scan_type, source_path
        ) VALUES (?, 'RUNNING', ?, ?, ?, ?)
    """, (
        started_at,
        selected_date.strftime("%Y-%m-%d"),
        yesterday.strftime("%Y-%m-%d"),
        scan_type,
        source_path
    ))
    scan_id = cur.lastrowid
    con.commit()
    con.close()
    return scan_id, started_at


def persist_result_and_summary(scan_id, result, summary, total_atm):
    con = db_connect()
    cur = con.cursor()

    cur.execute("""
        INSERT OR REPLACE INTO scan_results (
            scan_id, atm, category, reason,
            yesterday_folder, yesterday_state,
            last_valid_backup, last_valid_backup_raw,
            latest_date_folder, latest_date_folder_raw,
            delay_days, images, videos, txt, total, last_media_time,
            latest_journal_filename
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        scan_id,
        result.get("atm"),
        result.get("category"),
        result.get("reason"),
        result.get("yesterday_folder"),
        result.get("yesterday_state"),
        result.get("last_valid_backup"),
        result.get("last_valid_backup_raw"),
        result.get("latest_date_folder"),
        result.get("latest_date_folder_raw"),
        result.get("delay_days"),
        result.get("images", 0),
        result.get("videos", 0),
        result.get("txt", 0),
        result.get("total", 0),
        result.get("last_media_time"),
        result.get("latest_journal_filename", "")
    ))

    cur.execute("""
        UPDATE scans
        SET total_atm = ?, checked = ?, excellent = ?, normal = ?, problem = ?,
            total_images = ?, total_videos = ?, total_txt = ?, total_media = ?
        WHERE id = ?
    """, (
        total_atm,
        summary["checked"],
        summary["excellent"],
        summary["normal"],
        summary["problem"],
        summary["total_images"],
        summary["total_videos"],
        summary["total_txt"],
        summary["total_media"],
        scan_id
    ))

    con.commit()
    con.close()


def finalize_scan_record(scan_id, started_at, summary, total_atm, status="COMPLETED", error=None):
    finished_at = datetime.now().isoformat(timespec="seconds")
    try:
        start_dt = datetime.fromisoformat(started_at)
        finish_dt = datetime.fromisoformat(finished_at)
        duration = round((finish_dt - start_dt).total_seconds(), 2)
    except Exception:
        duration = 0

    con = db_connect()
    cur = con.cursor()
    cur.execute("""
        UPDATE scans
        SET finished_at = ?, status = ?, total_atm = ?, checked = ?,
            excellent = ?, normal = ?, problem = ?,
            total_images = ?, total_videos = ?, total_txt = ?, total_media = ?,
            duration_seconds = ?, error = ?
        WHERE id = ?
    """, (
        finished_at,
        status,
        total_atm,
        summary.get("checked", 0),
        summary.get("excellent", 0),
        summary.get("normal", 0),
        summary.get("problem", 0),
        summary.get("total_images", 0),
        summary.get("total_videos", 0),
        summary.get("total_txt", 0),
        summary.get("total_media", 0),
        duration,
        error,
        scan_id
    ))
    con.commit()
    con.close()
    # Scan bitdikdə Excel yarat və Bildirişlər qutusuna yaz
    if status == "COMPLETED":
        try:
            data, fn = scan_excel(scan_id)
            con2 = db_connect()
            try:
                row = con2.execute("SELECT scan_type FROM scans WHERE id=?", (scan_id,)).fetchone()
            finally:
                con2.close()
            label = SCAN_LABELS.get((row["scan_type"] if row else "D"), "Scan")
            report_register("scan", label + " scan", data, fn,
                            "Problem: %d · ATM: %d" % (summary.get("problem", 0), total_atm))
        except Exception:
            pass


def get_history(limit=500, scan_type="D"):
    con = db_connect()
    cur = con.cursor()
    cur.execute("""
        SELECT * FROM scans
        WHERE scan_type = ?
        ORDER BY id DESC
        LIMIT ?
    """, (scan_type, limit))
    rows = [dict(row) for row in cur.fetchall()]
    con.close()
    return rows


def get_scan_detail(scan_id):
    con = db_connect()
    cur = con.cursor()

    cur.execute("SELECT * FROM scans WHERE id = ?", (scan_id,))
    scan = cur.fetchone()
    if not scan:
        con.close()
        return None

    cur.execute("""
        SELECT * FROM scan_results
        WHERE scan_id = ?
        ORDER BY
            CASE category
                WHEN 'PROBLEM' THEN 1
                WHEN 'NORMAL' THEN 2
                WHEN 'EXCELLENT' THEN 3
                ELSE 9
            END,
            atm
    """, (scan_id,))
    results = [dict(row) for row in cur.fetchall()]
    con.close()

    return {
        "scan": dict(scan),
        "results": results
    }


def scan_excel(scan_id):
    """D/H/Jurnal scan nəticəsini .xlsx kimi qaytarır: (bytes, fayl_adı)."""
    from xlsx_lite import Workbook
    detail = get_scan_detail(scan_id)
    if not detail:
        raise FileNotFoundError("Scan tapılmadı.")
    scan, results = detail["scan"], detail["results"]
    st = scan.get("scan_type") or "D"
    label = SCAN_LABELS.get(st, st)
    cat_az = {"EXCELLENT": "ƏLA", "NORMAL": "NORMAL", "PROBLEM": "PROBLEM"}
    cat_fill = {"EXCELLENT": "green", "NORMAL": "yellow", "PROBLEM": "red"}
    wb = Workbook()
    s = wb.add_sheet("Xülasə", [("Göstərici", 40), ("Dəyər", 30)], autofilter=False)
    s.add_row([label + " — scan hesabatı", "#" + str(scan.get("id"))], bold=True, fill="title")
    s.add_row(["Mənbə", scan.get("source_path") or ""])
    s.add_row(["Başlama", str(scan.get("started_at") or "")])
    s.add_row(["Bitmə", str(scan.get("finished_at") or "")])
    s.add_row(["Status", scan.get("status") or ""])
    s.add_row(["Seçilmiş tarix (limit)", str(scan.get("selected_date") or "")])
    s.add_row(["Ümumi ATM", int(scan.get("total_atm") or 0)])
    s.add_row(["Yoxlanılıb", int(scan.get("checked") or 0)])
    s.add_row(["ƏLA", int(scan.get("excellent") or 0)], fill="green")
    s.add_row(["NORMAL", int(scan.get("normal") or 0)], fill="yellow")
    s.add_row(["PROBLEM", int(scan.get("problem") or 0)], fill="red")
    if scan.get("duration_seconds"):
        s.add_row(["Müddət (dəqiqə)", round(float(scan["duration_seconds"]) / 60.0, 1)])

    cols = [("№", 6), ("ATM", 14), ("Kateqoriya", 12), ("Son etibarlı backup", 20),
            ("Ən son tarix folderi", 20), ("Gecikmə (gün)", 13),
            ("Şəkil", 9), ("Video", 9), ("Mətn/jurnal", 12), ("Cəmi", 10),
            ("Son media vaxtı", 20), ("Səbəb / qeyd", 60)]

    def add_rows(sheet, rows):
        for i, r in enumerate(rows, 1):
            sheet.add_row([
                i, r.get("atm", ""), cat_az.get(r.get("category"), r.get("category") or ""),
                r.get("last_valid_backup") or "", r.get("latest_date_folder") or "",
                r.get("delay_days"), r.get("images") or 0, r.get("videos") or 0,
                r.get("txt") or 0, r.get("total") or 0,
                r.get("last_media_time") or "", r.get("reason") or "",
            ], fill=cat_fill.get(r.get("category"), "none"), bold_cols=(1,))

    add_rows(wb.add_sheet("Bütün ATM-lər", cols), results)
    bad = [r for r in results if r.get("category") == "PROBLEM"]
    if bad:
        add_rows(wb.add_sheet("Yalnız PROBLEM", cols), bad)

    stamp = (scan.get("started_at") or "").replace(":", "-").replace("T", "_")[:16]
    safe = re.sub(r"[^A-Za-z0-9_-]", "_", label)
    return wb.to_bytes(), safe + "_Scan_" + str(scan.get("id")) + "_" + stamp + ".xlsx"


def compare_scans(old_id, new_id):
    old_detail = get_scan_detail(old_id)
    new_detail = get_scan_detail(new_id)

    if not old_detail or not new_detail:
        return None
    if old_detail["scan"]["scan_type"] != new_detail["scan"]["scan_type"]:
        raise ValueError("Yalnız eyni mənbənin (D Scan, H Scan və ya əvvəlki C Scan) iki nəticəsi müqayisə edilə bilər.")

    old_map = {x["atm"]: x for x in old_detail["results"]}
    new_map = {x["atm"]: x for x in new_detail["results"]}

    rank = {
        "PROBLEM": 1,
        "NORMAL": 2,
        "EXCELLENT": 3
    }

    solved = []
    new_problems = []
    improved = []
    worsened = []
    unchanged = []

    all_atms = sorted(set(old_map) | set(new_map))

    for atm in all_atms:
        old = old_map.get(atm)
        new = new_map.get(atm)

        if old and new:
            old_cat = old.get("category", "PROBLEM")
            new_cat = new.get("category", "PROBLEM")

            if old_cat == "PROBLEM" and new_cat != "PROBLEM":
                solved.append(atm)

            if old_cat != "PROBLEM" and new_cat == "PROBLEM":
                new_problems.append(atm)

            old_rank = rank.get(old_cat, 0)
            new_rank = rank.get(new_cat, 0)

            if new_rank > old_rank:
                improved.append(atm)
            elif new_rank < old_rank:
                worsened.append(atm)
            else:
                unchanged.append(atm)

        elif new and not old:
            if new.get("category") == "PROBLEM":
                new_problems.append(atm)
            else:
                improved.append(atm)

        elif old and not new:
            worsened.append(atm)

    old_scan = old_detail["scan"]
    new_scan = new_detail["scan"]

    return {
        "old_scan": old_scan,
        "new_scan": new_scan,
        "problem_delta": new_scan.get("problem", 0) - old_scan.get("problem", 0),
        "excellent_delta": new_scan.get("excellent", 0) - old_scan.get("excellent", 0),
        "normal_delta": new_scan.get("normal", 0) - old_scan.get("normal", 0),
        "solved_count": len(solved),
        "new_problem_count": len(new_problems),
        "improved_count": len(improved),
        "worsened_count": len(worsened),
        "unchanged_count": len(unchanged),
        "solved_atms": solved,
        "new_problem_atms": new_problems,
        "improved_atms": improved,
        "worsened_atms": worsened
    }

# ============================================================
# ATM ACTIVITY LOG / MAP LAST ACTION
# ============================================================
# The map uses this table as an audit-friendly operational timeline. Password values
# are never stored; only ordinary action/result text is written.
ATM_ACTIVITY_LOCK = threading.RLock()


def atm_activity_start(atm_id, action_type, action_label, source_module):
    atm_id = str(atm_id or "").strip().upper()
    if not ATM_ID_PATTERN.fullmatch(atm_id):
        return None
    now = datetime.now().isoformat(timespec="seconds")
    with ATM_ACTIVITY_LOCK:
        con = db_connect()
        try:
            cur = con.execute("""
                INSERT INTO atm_activity_log(atm_id,action_type,action_label,source_module,started_at,success)
                VALUES(?,?,?,?,?,NULL)
            """, (atm_id, str(action_type), str(action_label), str(source_module), now))
            con.commit()
            return cur.lastrowid
        finally:
            con.close()


def atm_activity_finish(activity_id, atm_id, success, detail=""):
    if not activity_id:
        return
    atm_id = str(atm_id or "").strip().upper()
    now = datetime.now().isoformat(timespec="seconds")
    clean_detail = system_clean_error(detail)[:700] if 'system_clean_error' in globals() else str(detail or '')[:700]
    with ATM_ACTIVITY_LOCK:
        con = db_connect()
        try:
            row = con.execute("SELECT action_type,action_label FROM atm_activity_log WHERE id=?", (int(activity_id),)).fetchone()
            if not row:
                return
            con.execute("""
                UPDATE atm_activity_log SET finished_at=?, success=?, detail=? WHERE id=?
            """, (now, 1 if success else 0, clean_detail, int(activity_id)))
            con.execute("""
                UPDATE atms
                SET last_action_type=?, last_action_at=?, last_action_ok=?, last_action_detail=?, updated_at=?
                WHERE atm_id=? COLLATE NOCASE
            """, (row["action_type"], now, 1 if success else 0, clean_detail, now, atm_id))
            con.commit()
        finally:
            con.close()


def atm_activity_list(atm_id, limit=8):
    atm_id = str(atm_id or "").strip().upper()
    if not ATM_ID_PATTERN.fullmatch(atm_id):
        raise ValueError("ATM ID düzgün deyil.")
    limit = max(1, min(int(limit or 8), 50))
    con = db_connect()
    try:
        rows = con.execute("""
            SELECT id,atm_id,action_type,action_label,source_module,started_at,finished_at,success,detail
            FROM atm_activity_log WHERE atm_id=? COLLATE NOCASE
            ORDER BY id DESC LIMIT ?
        """, (atm_id, limit)).fetchall()
        return {"success": True, "rows": [dict(r) for r in rows]}
    finally:
        con.close()


def atm_activity_recent(limit=15):
    """Bütün ATM-lər üzrə ən son əməliyyatlar (Home 'son görülən işlər' üçün)."""
    limit = max(1, min(int(limit or 15), 100))
    con = db_connect()
    try:
        rows = con.execute("""
            SELECT id,atm_id,action_type,action_label,source_module,started_at,finished_at,success,detail
            FROM atm_activity_log ORDER BY id DESC LIMIT ?
        """, (limit,)).fetchall()
        return {"success": True, "rows": [dict(r) for r in rows]}
    finally:
        con.close()


# ============================================================
# ATM INVENTORY / COORDINATE MANAGEMENT
# ============================================================
# The DB stores only PASSWORD slot labels (PASSWORD1, PASSWORD2, ...).
# The actual password values stay exclusively in Windows environment variables.
ATM_INVENTORY_LOCK = threading.RLock()


def atm_inventory_validate(atm_id, latitude, longitude):
    atm_id = str(atm_id or "").strip().upper()
    if not ATM_ID_PATTERN.fullmatch(atm_id):
        raise ValueError("ATM ID düzgün deyil.")
    try:
        latitude = float(latitude)
        longitude = float(longitude)
    except (TypeError, ValueError):
        raise ValueError("Latitude və Longitude rəqəm olmalıdır.")
    if not -90 <= latitude <= 90:
        raise ValueError("Latitude -90 ilə 90 arasında olmalıdır.")
    if not -180 <= longitude <= 180:
        raise ValueError("Longitude -180 ilə 180 arasında olmalıdır.")
    return atm_id, latitude, longitude


def atm_inventory_stats(con):
    row = con.execute("""
        SELECT COUNT(*) AS total,
               SUM(CASE WHEN is_deleted=0 THEN 1 ELSE 0 END) AS visible,
               SUM(CASE WHEN is_deleted=0 AND status=1 THEN 1 ELSE 0 END) AS active,
               SUM(CASE WHEN is_deleted=0 AND status=0 THEN 1 ELSE 0 END) AS inactive,
               SUM(CASE WHEN is_deleted=1 THEN 1 ELSE 0 END) AS deleted,
               SUM(CASE WHEN is_deleted=0 AND password_env IS NOT NULL AND password_env<>'' THEN 1 ELSE 0 END) AS password_found,
               SUM(CASE WHEN is_deleted=0 AND (password_env IS NULL OR password_env='') THEN 1 ELSE 0 END) AS password_missing
        FROM atms
    """).fetchone()
    return {key: int(row[key] or 0) for key in row.keys()}


def atm_inventory_list(query="", state="all"):
    query = str(query or "").strip()
    state = str(state or "all").strip().lower()
    where = []
    params = []
    if state == "active":
        where.append("is_deleted=0 AND status=1")
    elif state == "inactive":
        where.append("is_deleted=0 AND status=0")
    elif state == "deleted":
        where.append("is_deleted=1")
    elif state in ("visible", "normal"):
        where.append("is_deleted=0")
    elif state != "all":
        raise ValueError("Status filteri düzgün deyil.")
    if query:
        where.append("(atm_id LIKE ? OR COALESCE(password_env,'') LIKE ?)")
        pattern = "%" + query + "%"
        params.extend([pattern, pattern])
    sql = "SELECT * FROM atms"
    if where:
        sql += " WHERE " + " AND ".join("(" + x + ")" for x in where)
    sql += " ORDER BY atm_id COLLATE NOCASE"
    con = db_connect()
    try:
        rows = [dict(r) for r in con.execute(sql, params).fetchall()]
        return {"success": True, "rows": rows, "stats": atm_inventory_stats(con)}
    finally:
        con.close()


def atm_inventory_save(data):
    record_id = int(data.get("id") or 0)
    atm_id, latitude, longitude = atm_inventory_validate(
        data.get("atm_id"), data.get("latitude"), data.get("longitude")
    )
    status = 1 if bool(data.get("status", True)) else 0
    def _m(key, lim=160):
        v = data.get(key)
        return (str(v).strip()[:lim] or None) if v is not None and str(v).strip() else None
    meta = {k: _m(k) for k in ("name", "atype", "rim", "region", "sys_address", "phys_address")}
    now = datetime.now().isoformat(timespec="seconds")
    with ATM_INVENTORY_LOCK:
        con = db_connect()
        try:
            con.execute("BEGIN IMMEDIATE")
            if record_id:
                old = con.execute("SELECT atm_id FROM atms WHERE id=?", (record_id,)).fetchone()
                if not old:
                    raise ValueError("ATM tapılmadı.")
                changed_id = str(old["atm_id"]).casefold() != atm_id.casefold()
                if changed_id:
                    con.execute("""
                        UPDATE atms
                        SET atm_id=?, latitude=?, longitude=?, status=?,
                            password_env=NULL, last_connection_at=NULL,
                            last_connection_ok=NULL, last_connection_error=NULL,
                            updated_at=?
                        WHERE id=?
                    """, (atm_id, latitude, longitude, status, now, record_id))
                else:
                    con.execute("""
                        UPDATE atms SET latitude=?, longitude=?, status=?, updated_at=? WHERE id=?
                    """, (latitude, longitude, status, now, record_id))
                con.execute("""UPDATE atms SET name=?,atype=?,rim=?,region=?,sys_address=?,phys_address=?,updated_at=? WHERE id=?""",
                            (meta["name"], meta["atype"], meta["rim"], meta["region"], meta["sys_address"], meta["phys_address"], now, record_id))
            else:
                cur = con.execute("""
                    INSERT INTO atms(atm_id,latitude,longitude,password_env,status,is_deleted,deleted_at,
                                     created_at,updated_at,last_connection_at,last_connection_ok,last_connection_error,
                                     name,atype,rim,region,sys_address,phys_address)
                    VALUES(?,?,?,NULL,?,0,NULL,?,?,NULL,NULL,NULL,?,?,?,?,?,?)
                """, (atm_id, latitude, longitude, status, now, now,
                      meta["name"], meta["atype"], meta["rim"], meta["region"], meta["sys_address"], meta["phys_address"]))
                record_id = cur.lastrowid
            con.commit()
            row = con.execute("SELECT * FROM atms WHERE id=?", (record_id,)).fetchone()
            return {"success": True, "row": dict(row)}
        except sqlite3.IntegrityError as exc:
            con.rollback()
            if "UNIQUE" in str(exc).upper():
                raise ValueError("Bu ATM ID artıq bazada mövcuddur.")
            raise
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()


def atm_inventory_soft_delete(record_id):
    record_id = int(record_id or 0)
    if record_id <= 0:
        raise ValueError("ATM seçilməyib.")
    now = datetime.now().isoformat(timespec="seconds")
    with ATM_INVENTORY_LOCK:
        con = db_connect()
        try:
            cur = con.execute("""
                UPDATE atms SET is_deleted=1, status=0, deleted_at=?, updated_at=?
                WHERE id=? AND is_deleted=0
            """, (now, now, record_id))
            if cur.rowcount == 0:
                raise ValueError("ATM tapılmadı və ya artıq silinib.")
            con.commit()
            return {"success": True}
        finally:
            con.close()


def atm_inventory_restore(record_id):
    record_id = int(record_id or 0)
    if record_id <= 0:
        raise ValueError("ATM seçilməyib.")
    now = datetime.now().isoformat(timespec="seconds")
    with ATM_INVENTORY_LOCK:
        con = db_connect()
        try:
            cur = con.execute("""
                UPDATE atms SET is_deleted=0, status=1, deleted_at=NULL, updated_at=?
                WHERE id=? AND is_deleted=1
            """, (now, record_id))
            if cur.rowcount == 0:
                raise ValueError("Silinmiş ATM tapılmadı.")
            con.commit()
            return {"success": True}
        finally:
            con.close()


def atm_inventory_clear_sessions(target):
    # The user explicitly pressed "Qoşulma". Clear this target's SMB sessions so
    # Windows error 1219 does not hide which PASSWORD slot is actually correct.
    for share in (rf"\\{target}\IPC$", rf"\\{target}\C$", rf"\\{target}\ADMIN$", rf"\\{target}"):
        try:
            subprocess.run(["net", "use", share, "/delete", "/y"], capture_output=True,
                           text=True, errors="replace", timeout=5,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except Exception:
            pass


def atm_inventory_probe_password(atm, preferred_env=None, password_timeout=12):
    passwords = get_restart_passwords()
    if not passwords:
        return None, "PASSWORD environment dəyişənləri tapılmadı."
    preferred_slot = None
    m = re.fullmatch(r"PASSWORD(\d+)", str(preferred_env or "").upper())
    if m:
        preferred_slot = int(m.group(1))
    ordered = list(passwords)
    if preferred_slot is not None:
        ordered.sort(key=lambda item: 0 if item[0] == preferred_slot else 1)

    targets = [atm]
    try:
        resolved = socket.gethostbyname(atm)
        if resolved and resolved.casefold() != atm.casefold():
            targets.append(resolved)
    except Exception:
        pass

    last_error = "Uyğun PASSWORD slotu tapılmadı."
    for target in targets:
        # Offline ATM-lərdə hər PASSWORD üçün ayrıca timeout gözləməmək üçün əvvəl TCP 445 yoxlanır.
        try:
            with socket.create_connection((target, 445), timeout=3):
                pass
        except OSError as exc:
            last_error = f"TCP 445 əlçatan deyil: {exc}"
            continue
        atm_inventory_clear_sessions(target)
        share = rf"\\{target}\IPC$"
        for slot, password in ordered:
            try:
                proc = subprocess.run(
                    ["net", "use", share, "/user:administrator", password],
                    capture_output=True, text=True, errors="replace", timeout=password_timeout,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
                )
            except subprocess.TimeoutExpired:
                last_error = f"PASSWORD{slot}: qoşulma {password_timeout} saniyədə cavab vermədi."
                continue
            except Exception as exc:
                last_error = system_clean_error(exc)
                continue
            output = (proc.stdout or "") + "\n" + (proc.stderr or "")
            if proc.returncode == 0:
                # Do not leave a credential session open just for discovery.
                try:
                    subprocess.run(["net", "use", share, "/delete", "/y"], capture_output=True,
                                   text=True, errors="replace", timeout=5,
                                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                except Exception:
                    pass
                return slot, None
            code = extract_windows_error_code(output)
            last_error = system_clean_error(friendly_error(code, output))
            # Network/lockout errors are not fixed by trying more passwords.
            if code in (53, 67, 64, 51, 121, 1231, 1909):
                break
        # if hostname was blocked by an existing SMB identity, try resolved IP alias
    return None, last_error


# ============================================================
# ATM INVENTORY - BULK PASSWORD DISCOVERY
# ============================================================
# Toplu yoxlama hər aktiv/silinməmiş ATM üçün PASSWORD1, PASSWORD2, ...
# slotlarını YENİDƏN sıfırdan yoxlayır. Əvvəldən bazada saxlanan password_env
# prioritet kimi istifadə edilmir. Real parol heç vaxt DB/UI/log-a yazılmır.
ATM_BULK_LOCK = threading.RLock()
ATM_BULK_CANCEL = threading.Event()
ATM_BULK_MAX_WORKERS = 10
ATM_BULK_STATE = {
    "running": False, "finished": False, "cancel_requested": False,
    "started_at": None, "finished_at": None, "total": 0, "processed": 0,
    "success_count": 0, "failed_count": 0, "percent": 0.0,
    "current_atm": "", "logs": [], "recent": [], "error": None,
}


def atm_bulk_log(message):
    line = datetime.now().strftime("%H:%M:%S") + "  " + str(message)
    with ATM_BULK_LOCK:
        ATM_BULK_STATE["logs"].append(line)
        ATM_BULK_STATE["logs"] = ATM_BULK_STATE["logs"][-120:]


def atm_bulk_snapshot():
    with ATM_BULK_LOCK:
        state = dict(ATM_BULK_STATE)
        state["logs"] = list(ATM_BULK_STATE["logs"])
        state["recent"] = [dict(x) for x in ATM_BULK_STATE["recent"]]
        return state


def atm_bulk_persist_result(record_id, atm, slot, error):
    now = datetime.now().isoformat(timespec="seconds")
    con = db_connect()
    try:
        if slot is not None:
            env_name = f"PASSWORD{slot}"
            # Slotdan Windows növü avtomatik təyin olunur (əl ilə dəyişdirilə bilər).
            win_type = WIN_TYPE_BY_SLOT.get(slot)
            con.execute("""
                UPDATE atms SET password_env=?,
                                windows_type=COALESCE(windows_type, ?),
                                last_connection_at=?, last_connection_ok=1,
                                last_connection_error=NULL, updated_at=?
                WHERE id=? AND is_deleted=0
            """, (env_name, win_type, now, now, record_id))
            con.commit()
            return True, env_name, None
        clean_error = str(error or "Uyğun PASSWORD slotu tapılmadı.")[:700]
        # Köhnə PASSWORD etiketi saxlanılır; uğursuz recheck ayrıca last_connection_ok=0 ilə görünür.
        con.execute("""
            UPDATE atms SET last_connection_at=?, last_connection_ok=0,
                            last_connection_error=?, updated_at=?
            WHERE id=? AND is_deleted=0
        """, (now, clean_error, now, record_id))
        con.commit()
        return False, None, clean_error
    finally:
        con.close()


# ============================================================
# WINDOWS XƏRİTƏSİ (idarəetmə):  bankomatId · PASSWORD slotu · Windows növü
# ============================================================
def atm_winmap_list(state="visible"):
    """Hər ATM üçün password_env, əl ilə təyin olunmuş windows_type və
    slotdan çıxarılan təxmini növü qaytarır (idarəetmə ekranı üçün)."""
    where = "is_deleted=0" if state != "all" else "1=1"
    con = db_connect()
    con.row_factory = sqlite3.Row
    try:
        rows = con.execute(
            f"""SELECT id, atm_id, name, region, password_env, windows_type,
                       last_connection_ok, last_info_ok
                FROM atms WHERE {where} ORDER BY atm_id COLLATE NOCASE""").fetchall()
    finally:
        con.close()
    out = []
    for r in rows:
        d = dict(r)
        d["derived_type"] = windows_type_for_env(d.get("password_env"))
        d["effective_type"] = (d.get("windows_type") or d["derived_type"])
        out.append(d)
    return {"success": True, "rows": out,
            "win_types": [{"code": k, "label": v} for k, v in WIN_TYPE_LABELS.items()],
            "slot_map": WIN_TYPE_BY_SLOT}


def atm_winmap_save(data):
    """Tək ATM üçün windows_type-ı (və istəyə görə password_env) əl ilə yeniləyir."""
    atm = str((data or {}).get("atm_id") or "").strip()
    if not atm:
        return {"success": False, "error": "ATM ID boşdur."}
    win_type = str(data.get("windows_type") or "").strip().upper()
    if win_type and win_type not in WIN_TYPE_LABELS:
        return {"success": False, "error": "Windows növü yanlışdır (XP/WIN7/WIN10)."}
    env = data.get("password_env")
    now = datetime.now().isoformat(timespec="seconds")
    con = db_connect()
    try:
        exists = con.execute("SELECT 1 FROM atms WHERE atm_id=? COLLATE NOCASE", (atm,)).fetchone()
        if not exists:
            return {"success": False, "error": "ATM bazada tapılmadı: " + atm}
        if env is not None:
            env = str(env).strip().upper() or None
            if env is not None and not re.fullmatch(r"PASSWORD\d+", env):
                return {"success": False, "error": "password_env formatı PASSWORD<N> olmalıdır."}
            con.execute("UPDATE atms SET password_env=?, windows_type=?, updated_at=? WHERE atm_id=? COLLATE NOCASE",
                        (env, win_type or None, now, atm))
        else:
            con.execute("UPDATE atms SET windows_type=?, updated_at=? WHERE atm_id=? COLLATE NOCASE",
                        (win_type or None, now, atm))
        con.commit()
    finally:
        con.close()
    return {"success": True, "atm_id": atm, "windows_type": win_type or None}


def atm_bulk_check_one(item):
    if ATM_BULK_CANCEL.is_set():
        return None
    record_id = int(item["id"])
    atm = str(item["atm_id"])
    with ATM_BULK_LOCK:
        ATM_BULK_STATE["current_atm"] = atm
    # preferred_env=None: toplu əməliyyatda bazadakı köhnə slotdan başlamırıq,
    # bütün environment slotlarını PASSWORD nömrə sırası ilə yenidən yoxlayırıq.
    slot, error = atm_inventory_probe_password(atm, None, password_timeout=7)
    ok, env_name, clean_error = atm_bulk_persist_result(record_id, atm, slot, error)
    result = {"id": record_id, "atm_id": atm, "success": ok,
              "password_env": env_name, "error": clean_error}
    with ATM_BULK_LOCK:
        ATM_BULK_STATE["processed"] += 1
        if ok:
            ATM_BULK_STATE["success_count"] += 1
        else:
            ATM_BULK_STATE["failed_count"] += 1
        total = max(1, int(ATM_BULK_STATE["total"] or 0))
        ATM_BULK_STATE["percent"] = round(ATM_BULK_STATE["processed"] * 100.0 / total, 1)
        ATM_BULK_STATE["recent"].append(result)
        ATM_BULK_STATE["recent"] = ATM_BULK_STATE["recent"][-50:]
    atm_bulk_log(f"{atm}: " + ((env_name + " UĞURLU") if ok else ("XƏTA — " + str(clean_error))))
    return result


def atm_bulk_worker(rows):
    try:
        atm_bulk_log(f"Toplu qoşulma başladı. Aktiv ATM: {len(rows)}. Worker: {ATM_BULK_MAX_WORKERS}.")
        atm_bulk_log("Hər ATM üçün PASSWORD slotları yenidən PASSWORD nömrə sırası ilə yoxlanılır.")
        executor = ThreadPoolExecutor(max_workers=ATM_BULK_MAX_WORKERS)
        futures = []
        try:
            for row in rows:
                if ATM_BULK_CANCEL.is_set():
                    break
                futures.append(executor.submit(atm_bulk_check_one, dict(row)))
            pending = set(futures)
            while pending:
                if ATM_BULK_CANCEL.is_set():
                    for f in pending:
                        f.cancel()
                    break
                done, pending = wait(pending, timeout=0.4, return_when=FIRST_COMPLETED)
                for f in done:
                    try:
                        f.result()
                    except Exception as exc:
                        atm_bulk_log("Worker xətası: " + system_clean_error(exc))
                        with ATM_BULK_LOCK:
                            ATM_BULK_STATE["processed"] += 1
                            ATM_BULK_STATE["failed_count"] += 1
                            total = max(1, int(ATM_BULK_STATE["total"] or 0))
                            ATM_BULK_STATE["percent"] = round(ATM_BULK_STATE["processed"] * 100.0 / total, 1)
        finally:
            executor.shutdown(wait=not ATM_BULK_CANCEL.is_set(), cancel_futures=ATM_BULK_CANCEL.is_set())
        with ATM_BULK_LOCK:
            cancelled = ATM_BULK_CANCEL.is_set()
            ATM_BULK_STATE["running"] = False
            ATM_BULK_STATE["finished"] = True
            ATM_BULK_STATE["cancel_requested"] = cancelled
            ATM_BULK_STATE["finished_at"] = datetime.now().isoformat(timespec="seconds")
            ATM_BULK_STATE["current_atm"] = ""
        atm_bulk_log("Toplu qoşulma dayandırıldı." if cancelled else "Toplu qoşulma tamamlandı.")
    except Exception as exc:
        error = system_clean_error(exc)
        with ATM_BULK_LOCK:
            ATM_BULK_STATE.update({"running": False, "finished": True, "error": error,
                                   "finished_at": datetime.now().isoformat(timespec="seconds")})
        atm_bulk_log("TOPLU XƏTA: " + error)


def atm_inventory_bulk_start(atm_ids=None):
    """
    atm_ids verilməyibsə bütün aktiv ATM-lər üzrə işləyir.
    Verilibsə (toplu qoşulma pəncərəsindən seçilən siyahı) yalnız həmin ATM-lər
    yoxlanılır — hər ATM üçün uyğun PASSWORD slotu tapılıb bazaya (password_env +
    windows_type) yazılır.
    """
    with ATM_BULK_LOCK:
        if ATM_BULK_STATE["running"]:
            return False, "Toplu qoşulma artıq işləyir."
    con = db_connect()
    try:
        if atm_ids:
            wanted = [str(a).strip() for a in atm_ids if str(a).strip()]
            if not wanted:
                return False, "Seçilmiş ATM yoxdur."
            placeholders = ",".join("?" * len(wanted))
            rows = con.execute(f"""
                SELECT id, atm_id FROM atms
                WHERE is_deleted=0 AND atm_id IN ({placeholders}) COLLATE NOCASE
                ORDER BY atm_id COLLATE NOCASE
            """, wanted).fetchall()
        else:
            rows = con.execute("""
                SELECT id, atm_id FROM atms
                WHERE is_deleted=0 AND status=1
                ORDER BY atm_id COLLATE NOCASE
            """).fetchall()
    finally:
        con.close()
    if not rows:
        return False, "Uyğun ATM tapılmadı."
    ATM_BULK_CANCEL.clear()
    now = datetime.now().isoformat(timespec="seconds")
    with ATM_BULK_LOCK:
        ATM_BULK_STATE.update({
            "running": True, "finished": False, "cancel_requested": False,
            "started_at": now, "finished_at": None, "total": len(rows), "processed": 0,
            "success_count": 0, "failed_count": 0, "percent": 0.0,
            "current_atm": "", "logs": [], "recent": [], "error": None,
        })
    threading.Thread(target=atm_bulk_worker, args=(rows,), daemon=True).start()
    return True, None


def atm_inventory_bulk_cancel():
    with ATM_BULK_LOCK:
        if not ATM_BULK_STATE["running"]:
            return False, "Aktiv toplu qoşulma yoxdur."
        ATM_BULK_STATE["cancel_requested"] = True
    ATM_BULK_CANCEL.set()
    atm_bulk_log("STOP sorğusu qəbul edildi; növbədəki ATM-lər dayandırılır.")
    return True, None


def atm_inventory_connect(record_id):
    with ATM_BULK_LOCK:
        if ATM_BULK_STATE["running"]:
            raise ValueError("Toplu qoşulma davam edir. Bitəndən sonra tək ATM yoxla.")
    record_id = int(record_id or 0)
    con = db_connect()
    try:
        row = con.execute("SELECT * FROM atms WHERE id=?", (record_id,)).fetchone()
    finally:
        con.close()
    if not row:
        raise ValueError("ATM tapılmadı.")
    if int(row["is_deleted"] or 0):
        raise ValueError("Silinmiş ATM üçün qoşulma yoxlaması aparılmır.")
    atm = str(row["atm_id"])
    slot, error = atm_inventory_probe_password(atm, row["password_env"])
    now = datetime.now().isoformat(timespec="seconds")
    con = db_connect()
    try:
        if slot is not None:
            env_name = f"PASSWORD{slot}"
            con.execute("""
                UPDATE atms SET password_env=?, last_connection_at=?, last_connection_ok=1,
                                last_connection_error=NULL, updated_at=? WHERE id=?
            """, (env_name, now, now, record_id))
            con.commit()
            row = con.execute("SELECT * FROM atms WHERE id=?", (record_id,)).fetchone()
            return {"success": True, "password_env": env_name, "row": dict(row)}
        con.execute("""
            UPDATE atms SET last_connection_at=?, last_connection_ok=0,
                            last_connection_error=?, updated_at=? WHERE id=?
        """, (now, str(error or "Qoşulma alınmadı.")[:700], now, record_id))
        con.commit()
        return {"success": False, "error": error or "Uyğun PASSWORD slotu tapılmadı."}
    finally:
        con.close()


# ============================================================
# SELECTED ATM DISK REPORT (C:/D:) + HISTORY
# ============================================================
# This module is intentionally independent from System Monitor state. It uses SMB 445
# only for disk capacity and stores report history in SQLite. Real passwords are never
# stored in DB/UI/logs; only PASSWORD<n> environment labels may be persisted.
DISK_REPORT_LOCK = threading.RLock()
DISK_REPORT_CANCEL = threading.Event()
DISK_REPORT_MAX_WORKERS = 8
DISK_REPORT_STATE = {
    "running": False, "finished": False, "cancel_requested": False,
    "run_id": None, "started_at": None, "finished_at": None,
    "total": 0, "processed": 0, "success_count": 0, "partial_count": 0,
    "failed_count": 0, "percent": 0.0, "current_atm": "",
    "logs": [], "completed_results": [], "error": None,
}


def disk_report_log(message):
    line = datetime.now().strftime("%H:%M:%S") + "  " + str(message)
    with DISK_REPORT_LOCK:
        DISK_REPORT_STATE["logs"].append(line)
        DISK_REPORT_STATE["logs"] = DISK_REPORT_STATE["logs"][-180:]


def disk_report_snapshot(since=0):
    with DISK_REPORT_LOCK:
        completed = DISK_REPORT_STATE["completed_results"]
        try:
            since = max(0, min(int(since), len(completed)))
        except Exception:
            since = 0
        return {
            "running": DISK_REPORT_STATE["running"],
            "finished": DISK_REPORT_STATE["finished"],
            "cancel_requested": DISK_REPORT_STATE["cancel_requested"],
            "run_id": DISK_REPORT_STATE["run_id"],
            "started_at": DISK_REPORT_STATE["started_at"],
            "finished_at": DISK_REPORT_STATE["finished_at"],
            "total": DISK_REPORT_STATE["total"],
            "processed": DISK_REPORT_STATE["processed"],
            "success_count": DISK_REPORT_STATE["success_count"],
            "partial_count": DISK_REPORT_STATE["partial_count"],
            "failed_count": DISK_REPORT_STATE["failed_count"],
            "percent": DISK_REPORT_STATE["percent"],
            "current_atm": DISK_REPORT_STATE["current_atm"],
            "logs": list(DISK_REPORT_STATE["logs"]),
            "new_results": [dict(x) for x in completed[since:]],
            "next_index": len(completed),
            "error": DISK_REPORT_STATE["error"],
        }


def _disk_report_passwords(preferred_env=None):
    items = list(get_restart_passwords())
    preferred_slot = None
    m = re.fullmatch(r"PASSWORD(\d+)", str(preferred_env or "").upper())
    if m:
        preferred_slot = int(m.group(1))
    if preferred_slot is not None:
        items.sort(key=lambda pair: (0 if pair[0] == preferred_slot else 1, pair[0]))
    return items


def _disk_report_clear_ipc(target):
    share = r"\\" + target + r"\IPC$"
    try:
        subprocess.run(["net", "use", share, "/delete", "/y"], capture_output=True,
                       text=True, errors="replace", timeout=5,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception:
        pass


def disk_report_probe_disks(atm, preferred_env=None):
    """Authenticate once to IPC$, then read C$/D$ with GetDiskFreeSpaceExW.

    Returns a result dictionary. Password value never leaves this function.
    """
    passwords = _disk_report_passwords(preferred_env)
    if not passwords:
        return {"access_status": "GİRİŞ OLMADI", "connection_ok": 0,
                "password_env": None, "c": None, "d": None,
                "error": "PASSWORD environment dəyişənləri tapılmadı."}

    target = atm
    try:
        resolved = socket.gethostbyname(atm)
        if resolved:
            target = resolved
    except Exception:
        pass

    try:
        with socket.create_connection((target, 445), timeout=3):
            pass
    except OSError as exc:
        return {"access_status": "GİRİŞ OLMADI", "connection_ok": 0,
                "password_env": None, "c": None, "d": None,
                "error": "TCP 445 əlçatan deyil: " + system_clean_error(exc)}

    share = r"\\" + target + r"\IPC$"
    _disk_report_clear_ipc(target)
    selected_slot = None
    last_error = "Uyğun PASSWORD slotu tapılmadı."
    existing_session = False
    try:
        for slot, password in passwords:
            if DISK_REPORT_CANCEL.is_set():
                return {"access_status": "DAYANDIRILDI", "connection_ok": 0,
                        "password_env": None, "c": None, "d": None,
                        "error": "Report istifadəçi tərəfindən dayandırıldı."}
            try:
                cp = subprocess.run(
                    ["net", "use", share, "/user:administrator", password],
                    capture_output=True, text=True, errors="replace", timeout=8,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
                )
            except subprocess.TimeoutExpired:
                last_error = f"PASSWORD{slot}: SMB credential testi timeout oldu."
                continue
            except Exception as exc:
                last_error = system_clean_error(exc)
                break
            output = (cp.stdout or "") + "\n" + (cp.stderr or "")
            if cp.returncode == 0:
                selected_slot = slot
                break
            code = extract_windows_error_code(output)
            last_error = system_clean_error(friendly_error(code, output))
            if code == 1219:
                # Do not destroy another module's session. If it can read the disks, reuse it.
                existing_session = True
                break
            if code in (53, 67, 64, 51, 121, 1231, 1909):
                break

        if selected_slot is None and not existing_session:
            return {"access_status": "GİRİŞ OLMADI", "connection_ok": 0,
                    "password_env": None, "c": None, "d": None, "error": last_error}

        c_disk, c_err = system_smb_disk(target, "C", timeout=7)
        d_disk, d_err = system_smb_disk(target, "D", timeout=7)
        found = int(c_disk is not None) + int(d_disk is not None)
        env_name = f"PASSWORD{selected_slot}" if selected_slot is not None else (preferred_env or None)
        if found == 2:
            status, ok, err = "UĞURLU", 1, None
        elif found == 1:
            status, ok = "QİSMƏN", 1
            missing = "C" if c_disk is None else "D"
            missing_err = c_err if c_disk is None else d_err
            err = f"{missing}: diski oxunmadı / mövcud deyil: {missing_err or 'naməlum səbəb'}"
        else:
            status, ok = "GİRİŞ OLMADI", 0
            err = "C və D diskləri oxunmadı. " + (c_err or "") + (" | " + d_err if d_err else "")
        return {"access_status": status, "connection_ok": ok, "password_env": env_name,
                "c": c_disk, "d": d_disk, "error": system_clean_error(err) if err else None}
    finally:
        # Only remove the IPC connection we created. Existing 1219 session is left untouched.
        if selected_slot is not None:
            _disk_report_clear_ipc(target)


def disk_report_create_run(count):
    now = datetime.now().isoformat(timespec="seconds")
    con = db_connect()
    try:
        cur = con.execute("""
            INSERT INTO disk_report_runs(started_at,status,selected_count)
            VALUES(?, 'RUNNING', ?)
        """, (now, int(count)))
        con.commit()
        return cur.lastrowid, now
    finally:
        con.close()


def disk_report_persist_result(run_id, item, result):
    now = datetime.now().isoformat(timespec="seconds")
    c = result.get("c") or {}
    d = result.get("d") or {}
    atm = str(item["atm_id"])
    env_name = result.get("password_env")
    error = str(result.get("error") or "")[:700] or None
    con = db_connect()
    try:
        con.execute("""
            INSERT OR REPLACE INTO disk_report_results(
                run_id,atm_id,access_status,connection_ok,password_env,
                c_total_bytes,c_used_bytes,c_free_bytes,c_used_percent,
                d_total_bytes,d_used_bytes,d_free_bytes,d_used_percent,
                checked_at,error
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            run_id, atm, result.get("access_status") or "GİRİŞ OLMADI",
            1 if result.get("connection_ok") else 0, env_name,
            c.get("total_bytes"), c.get("used_bytes"), c.get("free_bytes"), c.get("used_percent"),
            d.get("total_bytes"), d.get("used_bytes"), d.get("free_bytes"), d.get("used_percent"),
            now, error
        ))
        if env_name:
            con.execute("""
                UPDATE atms SET password_env=?, last_connection_at=?, last_connection_ok=?,
                    last_connection_error=?, last_disk_report_at=?, last_disk_report_status=?,
                    last_disk_report_run_id=?, last_disk_c_percent=?, last_disk_d_percent=?,
                    last_disk_report_error=?, updated_at=?
                WHERE atm_id=? COLLATE NOCASE
            """, (env_name, now, 1 if result.get("connection_ok") else 0, error,
                  now, result.get("access_status"), run_id, c.get("used_percent"), d.get("used_percent"),
                  error, now, atm))
        else:
            con.execute("""
                UPDATE atms SET last_connection_at=?, last_connection_ok=?, last_connection_error=?,
                    last_disk_report_at=?, last_disk_report_status=?, last_disk_report_run_id=?,
                    last_disk_c_percent=?, last_disk_d_percent=?, last_disk_report_error=?, updated_at=?
                WHERE atm_id=? COLLATE NOCASE
            """, (now, 1 if result.get("connection_ok") else 0, error,
                  now, result.get("access_status"), run_id, c.get("used_percent"), d.get("used_percent"),
                  error, now, atm))
        con.commit()
    finally:
        con.close()
    out = {
        "atm_id": atm, "access_status": result.get("access_status"),
        "connection_ok": 1 if result.get("connection_ok") else 0,
        "password_env": env_name, "checked_at": now, "error": error,
        "c_total_bytes": c.get("total_bytes"), "c_used_bytes": c.get("used_bytes"),
        "c_free_bytes": c.get("free_bytes"), "c_used_percent": c.get("used_percent"),
        "d_total_bytes": d.get("total_bytes"), "d_used_bytes": d.get("used_bytes"),
        "d_free_bytes": d.get("free_bytes"), "d_used_percent": d.get("used_percent"),
    }
    return out


def disk_report_check_one(run_id, item):
    if DISK_REPORT_CANCEL.is_set():
        return None
    atm = str(item["atm_id"])
    with DISK_REPORT_LOCK:
        DISK_REPORT_STATE["current_atm"] = atm
    disk_report_log(f"{atm}: C:/D: disk report yoxlanılır...")
    activity_id = atm_activity_start(atm, "DISK_REPORT", "Disk Report", "disk_report")
    try:
        result = disk_report_probe_disks(atm, item.get("password_env"))
        saved = disk_report_persist_result(run_id, item, result)
        c_text = "—" if saved["c_used_percent"] is None else f"{saved['c_used_percent']:.1f}%"
        d_text = "—" if saved["d_used_percent"] is None else f"{saved['d_used_percent']:.1f}%"
        detail = f"C: {c_text} · D: {d_text} · {saved['access_status']}"
        if saved.get("error"):
            detail += " · " + saved["error"][:260]
        atm_activity_finish(activity_id, atm, bool(saved["connection_ok"]), detail)
        with DISK_REPORT_LOCK:
            DISK_REPORT_STATE["processed"] += 1
            if saved["access_status"] == "UĞURLU":
                DISK_REPORT_STATE["success_count"] += 1
            elif saved["access_status"] == "QİSMƏN":
                DISK_REPORT_STATE["partial_count"] += 1
            else:
                DISK_REPORT_STATE["failed_count"] += 1
            total = max(1, int(DISK_REPORT_STATE["total"] or 0))
            DISK_REPORT_STATE["percent"] = round(DISK_REPORT_STATE["processed"] * 100.0 / total, 1)
            DISK_REPORT_STATE["completed_results"].append(saved)
        disk_report_log(f"{atm}: {saved['access_status']} | C: {c_text} | D: {d_text}" +
                        ((" | " + saved["error"]) if saved.get("error") else ""))
        return saved
    except Exception as exc:
        error = system_clean_error(exc)
        fallback = {"access_status": "GİRİŞ OLMADI", "connection_ok": 0,
                    "password_env": None, "c": None, "d": None, "error": error}
        try:
            saved = disk_report_persist_result(run_id, item, fallback)
        except Exception:
            saved = {"atm_id": atm, "access_status": "GİRİŞ OLMADI", "connection_ok": 0,
                     "password_env": None, "checked_at": datetime.now().isoformat(timespec="seconds"),
                     "error": error, "c_total_bytes": None, "c_used_bytes": None,
                     "c_free_bytes": None, "c_used_percent": None, "d_total_bytes": None,
                     "d_used_bytes": None, "d_free_bytes": None, "d_used_percent": None}
        atm_activity_finish(activity_id, atm, False, "Disk Report · " + error[:300])
        with DISK_REPORT_LOCK:
            DISK_REPORT_STATE["processed"] += 1
            DISK_REPORT_STATE["failed_count"] += 1
            total = max(1, int(DISK_REPORT_STATE["total"] or 0))
            DISK_REPORT_STATE["percent"] = round(DISK_REPORT_STATE["processed"] * 100.0 / total, 1)
            DISK_REPORT_STATE["completed_results"].append(saved)
        disk_report_log(f"{atm}: GİRİŞ OLMADI | {error}")
        return saved


def disk_report_finalize_run(run_id, started_at, status="COMPLETED", error=None):
    finished = datetime.now().isoformat(timespec="seconds")
    try:
        duration = round((datetime.fromisoformat(finished) - datetime.fromisoformat(started_at)).total_seconds(), 2)
    except Exception:
        duration = 0
    with DISK_REPORT_LOCK:
        checked = int(DISK_REPORT_STATE["processed"])
        success = int(DISK_REPORT_STATE["success_count"])
        partial = int(DISK_REPORT_STATE["partial_count"])
        failed = int(DISK_REPORT_STATE["failed_count"])
    con = db_connect()
    try:
        con.execute("""
            UPDATE disk_report_runs SET finished_at=?,status=?,checked_count=?,success_count=?,
                partial_count=?,failed_count=?,duration_seconds=?,error=? WHERE id=?
        """, (finished, status, checked, success, partial, failed, duration,
              str(error)[:700] if error else None, run_id))
        con.commit()
    finally:
        con.close()
    return finished


def disk_report_worker(run_id, started_at, rows):
    try:
        disk_report_log(f"Disk Report #{run_id} başladı. Seçilmiş ATM: {len(rows)}. Worker: {DISK_REPORT_MAX_WORKERS}.")
        executor = ThreadPoolExecutor(max_workers=DISK_REPORT_MAX_WORKERS)
        pending = set()
        try:
            for row in rows:
                if DISK_REPORT_CANCEL.is_set():
                    break
                pending.add(executor.submit(disk_report_check_one, run_id, dict(row)))
            while pending:
                if DISK_REPORT_CANCEL.is_set():
                    for f in pending:
                        f.cancel()
                    break
                done, pending = wait(pending, timeout=0.35, return_when=FIRST_COMPLETED)
                for f in done:
                    try:
                        f.result()
                    except Exception as exc:
                        disk_report_log("Worker xətası: " + system_clean_error(exc))
        finally:
            executor.shutdown(wait=not DISK_REPORT_CANCEL.is_set(), cancel_futures=DISK_REPORT_CANCEL.is_set())
        cancelled = DISK_REPORT_CANCEL.is_set()
        status = "CANCELLED" if cancelled else "COMPLETED"
        finished = disk_report_finalize_run(run_id, started_at, status=status,
                                            error="İstifadəçi tərəfindən dayandırıldı." if cancelled else None)
        with DISK_REPORT_LOCK:
            DISK_REPORT_STATE.update({"running": False, "finished": True,
                                      "cancel_requested": cancelled, "finished_at": finished,
                                      "current_atm": ""})
            if not cancelled:
                DISK_REPORT_STATE["percent"] = 100.0
        disk_report_log("Disk Report dayandırıldı." if cancelled else "Disk Report tamamlandı.")
    except Exception as exc:
        error = system_clean_error(exc)
        try:
            finished = disk_report_finalize_run(run_id, started_at, status="FAILED", error=error)
        except Exception:
            finished = datetime.now().isoformat(timespec="seconds")
        with DISK_REPORT_LOCK:
            DISK_REPORT_STATE.update({"running": False, "finished": True, "error": error,
                                      "finished_at": finished, "current_atm": ""})
        disk_report_log("DISK REPORT XƏTA: " + error)


def disk_report_start(atm_ids):
    if not isinstance(atm_ids, list):
        return False, "ATM siyahısı düzgün deyil.", None
    requested = []
    seen = set()
    for value in atm_ids:
        atm = str(value or "").strip().upper()
        if ATM_ID_PATTERN.fullmatch(atm) and atm.casefold() not in seen:
            seen.add(atm.casefold()); requested.append(atm)
    if not requested:
        return False, "Ən azı bir aktiv ATM seç.", None
    if len(requested) > 3000:
        return False, "Bir report üçün maksimum 3000 ATM seçilə bilər.", None
    with DISK_REPORT_LOCK:
        if DISK_REPORT_STATE["running"]:
            return False, "Disk Report artıq işləyir.", DISK_REPORT_STATE.get("run_id")
    with VA_LOCK:
        if VA_STATE["running"]:
            return False, "VIDEOARCHIVE Scan işləyir. Eyni ATM-lərə paralel qoşulmamaq üçün onun bitməsini gözlə.", None
    con = db_connect()
    try:
        placeholders = ",".join("?" for _ in requested)
        rows = con.execute(f"""
            SELECT id,atm_id,password_env FROM atms
            WHERE is_deleted=0 AND status=1 AND atm_id IN ({placeholders}) COLLATE NOCASE
        """, requested).fetchall()
        by_id = {str(r["atm_id"]).casefold(): r for r in rows}
        rows = [by_id[x.casefold()] for x in requested if x.casefold() in by_id]
    finally:
        con.close()
    if not rows:
        return False, "Seçilən ATM-lər arasında status=True olan aktiv ATM tapılmadı.", None
    if len(rows) != len(requested):
        missing = len(requested) - len(rows)
    else:
        missing = 0
    run_id, started_at = disk_report_create_run(len(rows))
    DISK_REPORT_CANCEL.clear()
    with DISK_REPORT_LOCK:
        DISK_REPORT_STATE.update({
            "running": True, "finished": False, "cancel_requested": False,
            "run_id": run_id, "started_at": started_at, "finished_at": None,
            "total": len(rows), "processed": 0, "success_count": 0,
            "partial_count": 0, "failed_count": 0, "percent": 0.0,
            "current_atm": "", "logs": [], "completed_results": [], "error": None,
        })
    if missing:
        disk_report_log(f"{missing} ATM deaktiv/silinmiş/tapılmadığı üçün reportdan çıxarıldı.")
    threading.Thread(target=disk_report_worker, args=(run_id, started_at, rows), daemon=True).start()
    return True, None, run_id


def disk_report_cancel():
    with DISK_REPORT_LOCK:
        if not DISK_REPORT_STATE["running"]:
            return False, "Aktiv Disk Report yoxdur."
        DISK_REPORT_STATE["cancel_requested"] = True
    DISK_REPORT_CANCEL.set()
    disk_report_log("STOP sorğusu qəbul edildi; növbədəki ATM-lər dayandırılır.")
    return True, None


def disk_report_history(limit=120):
    limit = max(1, min(int(limit or 120), 1000))
    con = db_connect()
    try:
        rows = con.execute("SELECT * FROM disk_report_runs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return {"success": True, "runs": [dict(r) for r in rows]}
    finally:
        con.close()


def disk_report_detail(run_id):
    run_id = int(run_id or 0)
    con = db_connect()
    try:
        run = con.execute("SELECT * FROM disk_report_runs WHERE id=?", (run_id,)).fetchone()
        if not run:
            return None
        rows = con.execute("""
            SELECT * FROM disk_report_results WHERE run_id=? ORDER BY atm_id COLLATE NOCASE
        """, (run_id,)).fetchall()
        return {"success": True, "run": dict(run), "results": [dict(r) for r in rows]}
    finally:
        con.close()

# ============================================================
# VIDEOARCHIVE SCAN — bütün aktiv ATM-lər üzrə toplu yoxlama
#   \\ATM_ID\D$\VIDEOARCHIVE\ATM_ID\YYYYMMDD\...  (alt qovluqlar daxil)
# Hər ATM üçün: şəkli olan ən son tarix folderi, ən son şəklin vaxtı, say.
# Yalnız OXUMA. Şifrə heç vaxt log/DB/UI-a yazılmır, yalnız PASSWORD slotu.
# ============================================================

VA_LOCK = threading.RLock()
VA_CANCEL = threading.Event()
VA_MAX_WORKERS = max(1, min(int(os.getenv("ATM_VA_WORKERS", "20") or 20), 48))
VA_ATM_TIMEOUT = max(30, int(os.getenv("ATM_VA_ATM_TIMEOUT", "300") or 300))   # bir ATM üçün maksimum saniyə
VA_LOOKBACK_FOLDERS = 30          # şəkil tapılmasa neçə tarix folderi geri baxılsın
VA_LATE_DAYS = max(1, int(os.getenv("ATM_VA_LATE_DAYS", "5") or 5))          # bu qədər günədək GECİKİR, sonra PROBLEM
VA_MAX_FILES_PER_ATM = 400000     # təhlükəsizlik limiti

VA_CATEGORIES = ["AKTİV", "GECİKİR", "PROBLEM", "ŞƏKİL YOXDUR", "VIDEOARCHIVE YOXDUR",
                 "QOŞULMADI", "VAXT AŞIMI", "XƏTA", "DAYANDIRILDI"]
VA_CATEGORY_FILL = {"AKTİV": "green", "GECİKİR": "yellow", "PROBLEM": "red",
                    "ŞƏKİL YOXDUR": "red", "VIDEOARCHIVE YOXDUR": "red",
                    "QOŞULMADI": "gray", "VAXT AŞIMI": "gray", "XƏTA": "gray", "DAYANDIRILDI": "gray"}

VA_STATE = {
    "running": False, "finished": False, "cancel_requested": False,
    "run_id": None, "started_at": None, "finished_at": None,
    "total": 0, "processed": 0, "percent": 0.0, "current_atms": [],
    "counts": {}, "logs": [], "completed_results": [], "error": None,
}


class VaTimeout(Exception):
    pass


class VaCancelled(Exception):
    pass


def va_log(message):
    line = datetime.now().strftime("%H:%M:%S") + "  " + system_clean_error(message)
    with VA_LOCK:
        VA_STATE["logs"].append(line)
        VA_STATE["logs"] = VA_STATE["logs"][-400:]


def va_snapshot(since=0):
    with VA_LOCK:
        completed = VA_STATE["completed_results"]
        try:
            since = max(0, min(int(since), len(completed)))
        except Exception:
            since = 0
        return {
            "running": VA_STATE["running"], "finished": VA_STATE["finished"],
            "cancel_requested": VA_STATE["cancel_requested"], "run_id": VA_STATE["run_id"],
            "started_at": VA_STATE["started_at"], "finished_at": VA_STATE["finished_at"],
            "total": VA_STATE["total"], "processed": VA_STATE["processed"],
            "percent": VA_STATE["percent"], "current_atms": list(VA_STATE["current_atms"]),
            "counts": dict(VA_STATE["counts"]), "logs": list(VA_STATE["logs"]),
            "new_results": [dict(x) for x in completed[since:]], "next_index": len(completed),
            "error": VA_STATE["error"], "late_days": VA_LATE_DAYS,
            "workers": VA_MAX_WORKERS, "atm_timeout": VA_ATM_TIMEOUT,
        }


def va_category_for_days(days):
    if days is None:
        return "ŞƏKİL YOXDUR"
    if days <= 1:
        return "AKTİV"
    if days <= VA_LATE_DAYS:
        return "GECİKİR"
    return "PROBLEM"


def va_scan_archive(atm, atm_archive_path, deadline, cancel_event, today=None, anchor="image"):
    """VIDEOARCHIVE\\ATM_ID qovluğunu oxuyur. SMB qoşulmasından asılı deyil (test edilə bilər).

    Qaytarır: dict (folder_count, latest_folder, media_folder, last_image_*, image_count, video_count, ...)
    Tarix folderi YYYYMMDD adına görə seçilir. anchor="image" — şəkli olan ən son folderi tapır
    (D$ VIDEOARCHIVE üçün); anchor="media" — şəkil VƏ YA video olan ən son folderi tapır
    (E$\\Video üçün, çünki orada yalnız video ola bilər). Fayl vaxtı = LastWriteTime.
    """
    today = today or date.today()
    out = {"folder_count": 0, "latest_folder": None, "media_folder": None,
           "last_image_ts": None, "last_image_name": None, "last_image_rel": None,
           "image_count": 0, "video_count": 0, "last_video_ts": None,
           "latest_folder_images": None, "folders_checked": 0, "read_errors": 0,
           "future_folders": 0}

    def guard():
        if cancel_event.is_set():
            raise VaCancelled()
        if time.monotonic() > deadline:
            raise VaTimeout()

    folders = []
    with os.scandir(atm_archive_path) as it:
        for entry in it:
            guard()
            try:
                if not entry.is_dir(follow_symlinks=False):
                    continue
            except OSError:
                out["read_errors"] += 1
                continue
            d = parse_date_folder(entry.name)
            if d is None:
                continue
            if d > today + timedelta(days=1):
                # ATM saatı səhvdirsə gələcək tarixli folder yarana bilər — nəzərə alınmır
                out["future_folders"] += 1
                continue
            folders.append((d, entry.name, entry.path))
    folders.sort(key=lambda x: x[0], reverse=True)
    out["folder_count"] = len(folders)
    if not folders:
        return out
    out["latest_folder"] = folders[0][1]

    files_seen = 0
    for idx, (fdate, fname, fpath) in enumerate(folders[:VA_LOOKBACK_FOLDERS]):
        guard()
        images = videos = 0
        best_img = None      # (mtime, name, rel)
        best_vid = None
        stack = [(fpath, fname)]
        while stack:
            guard()
            cur_path, cur_rel = stack.pop()
            try:
                with os.scandir(cur_path) as it:
                    for entry in it:
                        files_seen += 1
                        if files_seen % 500 == 0:
                            guard()
                        if files_seen > VA_MAX_FILES_PER_ATM:
                            raise VaTimeout()
                        try:
                            if entry.is_dir(follow_symlinks=False):
                                stack.append((entry.path, cur_rel + "\\" + entry.name))
                                continue
                            if not entry.is_file(follow_symlinks=False):
                                continue
                        except OSError:
                            out["read_errors"] += 1
                            continue
                        ext = os.path.splitext(entry.name)[1].lower()
                        is_img = ext in ARCHIVE_IMAGE_EXTENSIONS
                        is_vid = (not is_img) and (ext in ARCHIVE_VIDEO_EXTENSIONS)
                        if not is_img and not is_vid:
                            continue
                        try:
                            # Windows-da DirEntry.stat() kataloq siyahısından gəlir — əlavə SMB sorğusu yoxdur
                            mtime = entry.stat(follow_symlinks=False).st_mtime
                        except OSError:
                            out["read_errors"] += 1
                            mtime = None
                        if is_img:
                            images += 1
                            if mtime is not None and (best_img is None or mtime > best_img[0]):
                                best_img = (mtime, entry.name, cur_rel + "\\" + entry.name)
                        else:
                            videos += 1
                            if mtime is not None and (best_vid is None or mtime > best_vid[0]):
                                best_vid = (mtime, entry.name, cur_rel + "\\" + entry.name)
            except (VaTimeout, VaCancelled):
                raise
            except OSError:
                out["read_errors"] += 1
                continue
        out["folders_checked"] = idx + 1
        if idx == 0:
            out["latest_folder_images"] = images
        accept = (images > 0) if anchor == "image" else (images > 0 or videos > 0)
        if accept:
            out["media_folder"] = fname
            out["media_folder_date"] = fdate
            out["image_count"] = images
            out["video_count"] = videos
            if best_img:
                out["last_image_ts"], out["last_image_name"], out["last_image_rel"] = best_img
            if best_vid:
                out["last_video_ts"] = best_vid[0]
            break
    return out


def va_smb_connect(target, passwords, cancel_event):
    """IPC$-ə administrator ilə qoşulur. (slot, reused_existing, error) qaytarır."""
    share = r"\\" + target + r"\IPC$"
    _disk_report_clear_ipc(target)
    last_error = "Uyğun PASSWORD slotu tapılmadı."
    for slot, password in passwords:
        if cancel_event.is_set():
            raise VaCancelled()
        try:
            cp = subprocess.run(
                ["net", "use", share, "/user:administrator", password],
                capture_output=True, text=True, errors="replace", timeout=10,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except subprocess.TimeoutExpired:
            last_error = f"PASSWORD{slot}: NET USE 10 saniyədə cavab vermədi."
            continue
        except Exception as exc:
            return None, False, system_clean_error(exc)
        output = (cp.stdout or "") + "\n" + (cp.stderr or "")
        if cp.returncode == 0:
            return slot, False, None
        code = extract_windows_error_code(output)
        last_error = system_clean_error(friendly_error(code, output))
        if code == 1219:
            # Başqa modulun (məs. Video/şəkil) bu ATM-ə açıq sessiyası var — ona toxunmuruq, istifadə edirik
            return None, True, None
        if code in (53, 67, 64, 51, 121, 1231, 1909):
            # Şəbəkə xətası və ya hesab kilidlənib — qalan şifrələri sınamaq mənasızdır/təhlükəlidir
            break
    return None, False, last_error


def va_d_root(target):
    return rf"\\{target}\D$"


def _va_scan_source(atm, target, deadline, cancel_event, disk, folder,
                    use_atm_subfolder, missing_label, disk_missing_error, anchor="image"):
    r"""Bir mənbəni oxuyur: \\target\<disk>\<folder>[\atm].
    Status + son şəkil + folder sayı qaytarır (dict). Sahələr D$/E$ üçün eynidir."""
    out = {"category": "XƏTA", "path": "", "folder_count": None, "latest_folder": None,
           "media_folder": None, "last_image_at": None, "last_image_name": None,
           "image_count": None, "video_count": None, "last_video_at": None,
           "days_since": None, "error": None}
    disk_root = rf"\\{target}\{disk}"
    container = os.path.join(disk_root, folder)
    scan_path = os.path.join(container, atm) if use_atm_subfolder else container
    out["path"] = rf"\\{atm}\{disk}\{folder}" + (rf"\{atm}" if use_atm_subfolder else "")
    try:
        if not os.path.isdir(scan_path):
            if not os.path.isdir(os.path.join(disk_root, "")):
                if disk_missing_error:
                    out.update(category="XƏTA", error=f"{disk} diski oxunmadı (disk yoxdur və ya icazə yoxdur).")
                else:
                    out.update(category=missing_label, error=f"{disk} diski yoxdur.")
                return out
            if not os.path.isdir(container):
                out.update(category=missing_label, error=f"{disk}\\{folder} qovluğu yoxdur.")
                return out
            if use_atm_subfolder:
                subs = []
                try:
                    with os.scandir(container) as it:
                        subs = [e.name for e in it if e.is_dir(follow_symlinks=False)]
                except OSError:
                    subs = []
                if len(subs) == 1:
                    scan_path = os.path.join(container, subs[0])
                    out["path"] = rf"\\{atm}\{disk}\{folder}\{subs[0]}"
                    out["error"] = f"Qovluq adı ATM ID ilə üst-üstə düşmür: {folder}\\{subs[0]} istifadə olundu."
                else:
                    names = ", ".join(subs[:5]) if subs else "boşdur"
                    out.update(category=missing_label,
                               error=f"{folder}\\{atm} qovluğu yoxdur ({folder} içində: {names}).")
                    return out
            else:
                out.update(category=missing_label, error=f"{disk}\\{folder} qovluğu yoxdur.")
                return out

        scan = va_scan_archive(atm, scan_path, deadline, cancel_event, anchor=anchor)
        out["folder_count"] = scan["folder_count"]
        out["latest_folder"] = scan["latest_folder"]
        out["media_folder"] = scan["media_folder"]
        out["image_count"] = scan["image_count"] if scan["media_folder"] else 0
        out["video_count"] = scan["video_count"] if scan["media_folder"] else 0
        notes = [out["error"]] if out.get("error") else []
        if scan["last_image_ts"]:
            img_dt = datetime.fromtimestamp(scan["last_image_ts"])
            out["last_image_at"] = img_dt.isoformat(timespec="seconds")
            out["last_image_name"] = scan["last_image_name"]
            ref_date = img_dt.date()
            if ref_date > date.today() and scan.get("media_folder_date"):
                ref_date = scan["media_folder_date"]
                notes.append("Faylın vaxtı gələcəkdədir (ATM saatı səhv ola bilər) — folder tarixi götürüldü.")
            out["days_since"] = max(0, (date.today() - ref_date).days)
        elif scan["media_folder"] and scan.get("media_folder_date"):
            out["days_since"] = max(0, (date.today() - scan["media_folder_date"]).days)
        if scan["last_video_ts"]:
            out["last_video_at"] = datetime.fromtimestamp(scan["last_video_ts"]).isoformat(timespec="seconds")
        if scan["folder_count"] == 0:
            out["category"] = "ŞƏKİL YOXDUR"
            notes.append(f"{folder} içində YYYYMMDD tarix folderi yoxdur.")
        elif not scan["media_folder"]:
            out["category"] = "ŞƏKİL YOXDUR"
            notes.append(f"Son {scan['folders_checked']} tarix folderində şəkil tapılmadı (son folder: {scan['latest_folder']}).")
        else:
            out["category"] = va_category_for_days(out["days_since"])
            if scan["latest_folder"] != scan["media_folder"]:
                notes.append(f"Son folder ({scan['latest_folder']}) boşdur — şəkil {scan['media_folder']} folderindədir.")
        if scan["future_folders"]:
            notes.append(f"{scan['future_folders']} gələcək tarixli folder nəzərə alınmadı.")
        if scan["read_errors"]:
            notes.append(f"{scan['read_errors']} element oxunmadı.")
        out["error"] = " ".join(n for n in notes if n) or None
        return out
    except VaTimeout:
        out.update(category="VAXT AŞIMI",
                   error=f"{VA_ATM_TIMEOUT} saniyədə bitmədi (şəbəkə yavaşdır və ya fayl çoxdur).")
        return out
    except OSError as exc:
        out.update(category="XƏTA", error=f"{disk}\\{folder} oxunmadı: " + system_clean_error(exc))
        return out


def va_check_atm(item, cancel_event):
    r"""Bir ATM: qoşul → İKİ mənbəni paralel oxu:
      D$\VIDEOARCHIVE\ATM_ID  (əsas status)  və  E$\Video  (paralel hesabat)."""
    atm = str(item["atm_id"]).strip()
    started = time.monotonic()
    deadline = started + VA_ATM_TIMEOUT
    res = {"atm_id": atm, "name": item.get("name") or "", "region": item.get("region") or "",
           "category": "XƏTA", "connection_ok": 0, "password_env": None, "archive_path": "",
           "folder_count": None, "latest_folder": None, "media_folder": None,
           "last_image_at": None, "last_image_name": None, "image_count": None, "video_count": None,
           "last_video_at": None, "days_since": None, "error": None,
           # E$\Video (ikinci mənbə) — paralel sütunlar
           "video_archive_path": "", "video_category": None, "video_folder_count": None,
           "video_latest_folder": None, "video_media_folder": None, "video_last_image_at": None,
           "video_last_image_name": None, "video_image_count": None, "video_video_count": None,
           "video_days_since": None, "video_error": None}
    passwords = _disk_report_passwords(item.get("password_env"))
    if not passwords:
        res.update(category="QOŞULMADI", video_category="QOŞULMADI",
                   error="PASSWORD environment dəyişənləri tapılmadı.")
        return res

    target = atm
    try:
        resolved = socket.gethostbyname(atm)
        if resolved:
            target = resolved
    except Exception:
        pass
    try:
        with socket.create_connection((target, 445), timeout=4):
            pass
    except OSError as exc:
        res.update(category="QOŞULMADI", video_category="QOŞULMADI",
                   error="TCP 445 əlçatan deyil (ATM sönülü / şəbəkə yoxdur): " + system_clean_error(exc))
        return res

    slot, reused, err = va_smb_connect(target, passwords, cancel_event)
    if slot is None and not reused:
        res.update(category="QOŞULMADI", video_category="QOŞULMADI", error=err)
        return res
    res["connection_ok"] = 1
    res["password_env"] = f"PASSWORD{slot}" if slot is not None else (item.get("password_env") or None)
    try:
        # 1) D$\VIDEOARCHIVE\ATM_ID — əsas status
        d = _va_scan_source(atm, target, deadline, cancel_event, "D$", "VIDEOARCHIVE",
                            True, "VIDEOARCHIVE YOXDUR", True)
        res["archive_path"] = d["path"]
        res["category"] = d["category"]
        res["folder_count"] = d["folder_count"]
        res["latest_folder"] = d["latest_folder"]
        res["media_folder"] = d["media_folder"]
        res["last_image_at"] = d["last_image_at"]
        res["last_image_name"] = d["last_image_name"]
        res["image_count"] = d["image_count"]
        res["video_count"] = d["video_count"]
        res["last_video_at"] = d["last_video_at"]
        res["days_since"] = d["days_since"]
        res["error"] = d["error"]

        # 2) E$\Video — paralel mənbə (YYYYMMDD birbaşa Video içində; video-only ola bilər)
        e = _va_scan_source(atm, target, deadline, cancel_event, "E$", "Video",
                            False, "VIDEO YOXDUR", False, anchor="media")
        res["video_archive_path"] = e["path"]
        res["video_category"] = e["category"]
        res["video_folder_count"] = e["folder_count"]
        res["video_latest_folder"] = e["latest_folder"]
        res["video_media_folder"] = e["media_folder"]
        res["video_last_image_at"] = e["last_image_at"]
        res["video_last_image_name"] = e["last_image_name"]
        res["video_image_count"] = e["image_count"]
        res["video_video_count"] = e["video_count"]
        res["video_days_since"] = e["days_since"]
        res["video_error"] = e["error"]
        return res
    except OSError as exc:
        res.update(category="XƏTA", error="Oxuma xətası: " + system_clean_error(exc))
        return res
    finally:
        if slot is not None:
            _disk_report_clear_ipc(target)
        res["duration"] = round(time.monotonic() - started, 1)


def va_create_run(count, scope):
    now = datetime.now().isoformat(timespec="seconds")
    con = db_connect()
    try:
        cur = con.execute("INSERT INTO va_scan_runs(started_at,status,selected_count,scope) VALUES(?, 'RUNNING', ?, ?)",
                          (now, int(count), scope))
        con.commit()
        return cur.lastrowid, now
    finally:
        con.close()


def va_persist_result(run_id, res):
    now = datetime.now().isoformat(timespec="seconds")
    res["checked_at"] = now
    if res.get("error"):
        res["error"] = system_clean_error(res["error"])[:700]
    if res.get("video_error"):
        res["video_error"] = system_clean_error(res["video_error"])[:700]
    con = db_connect()
    try:
        con.execute("""
            INSERT OR REPLACE INTO va_scan_results(
                run_id,atm_id,name,region,category,connection_ok,password_env,archive_path,
                folder_count,latest_folder,media_folder,last_image_at,last_image_name,
                image_count,video_count,last_video_at,days_since,checked_at,duration_seconds,error,
                video_archive_path,video_category,video_folder_count,video_latest_folder,
                video_media_folder,video_last_image_at,video_last_image_name,video_image_count,
                video_video_count,video_days_since,video_error
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (run_id, res["atm_id"], res.get("name"), res.get("region"), res["category"],
              int(res.get("connection_ok") or 0), res.get("password_env"), res.get("archive_path"),
              res.get("folder_count"), res.get("latest_folder"), res.get("media_folder"),
              res.get("last_image_at"), res.get("last_image_name"), res.get("image_count"),
              res.get("video_count"), res.get("last_video_at"), res.get("days_since"),
              now, res.get("duration"), res.get("error"),
              res.get("video_archive_path"), res.get("video_category"), res.get("video_folder_count"),
              res.get("video_latest_folder"), res.get("video_media_folder"), res.get("video_last_image_at"),
              res.get("video_last_image_name"), res.get("video_image_count"), res.get("video_video_count"),
              res.get("video_days_since"), res.get("video_error")))
        if res.get("connection_ok") and res.get("password_env"):
            # Uğurlu slot bazaya yazılır — növbəti dəfə birbaşa həmin slot sınanır
            con.execute("""UPDATE atms SET password_env=?, last_connection_at=?, last_connection_ok=1,
                           last_connection_error=NULL, updated_at=? WHERE atm_id=? COLLATE NOCASE""",
                        (res["password_env"], now, now, res["atm_id"]))
        con.commit()
    finally:
        con.close()
    return res


def va_check_one(run_id, item):
    if VA_CANCEL.is_set():
        return None
    atm = str(item["atm_id"])
    with VA_LOCK:
        VA_STATE["current_atms"].append(atm)
    try:
        try:
            res = va_check_atm(item, VA_CANCEL)
        except VaCancelled:
            return None
        except Exception as exc:
            res = {"atm_id": atm, "name": item.get("name") or "", "region": item.get("region") or "",
                   "category": "XƏTA", "connection_ok": 0, "error": system_clean_error(exc)}
        try:
            va_persist_result(run_id, res)
        except Exception as exc:
            va_log(f"{atm}: nəticə bazaya yazılmadı: {exc}")
            res.setdefault("checked_at", datetime.now().isoformat(timespec="seconds"))
        with VA_LOCK:
            VA_STATE["processed"] += 1
            cat = res["category"]
            VA_STATE["counts"][cat] = VA_STATE["counts"].get(cat, 0) + 1
            total = max(1, int(VA_STATE["total"] or 0))
            VA_STATE["percent"] = round(VA_STATE["processed"] * 100.0 / total, 1)
            VA_STATE["completed_results"].append(dict(res))
        last = res.get("last_image_at")
        va_log(f"{atm}: {res['category']}" + (f" | son şəkil {last.replace('T', ' ')}" if last else "")
               + (f" | {res['error']}" if res.get("error") and res["category"] not in ("AKTİV",) else ""))
        return res
    finally:
        with VA_LOCK:
            try:
                VA_STATE["current_atms"].remove(atm)
            except ValueError:
                pass


def va_finalize_run(run_id, started_at, status, error=None):
    finished = datetime.now().isoformat(timespec="seconds")
    try:
        duration = round((datetime.fromisoformat(finished) - datetime.fromisoformat(started_at)).total_seconds(), 1)
    except Exception:
        duration = 0
    with VA_LOCK:
        counts = dict(VA_STATE["counts"])
        checked = int(VA_STATE["processed"])
    con = db_connect()
    try:
        con.execute("""UPDATE va_scan_runs SET finished_at=?,status=?,checked_count=?,active_count=?,
                       late_count=?,problem_count=?,nophoto_count=?,failed_count=?,duration_seconds=?,error=?
                       WHERE id=?""",
                    (finished, status, checked, counts.get("AKTİV", 0), counts.get("GECİKİR", 0),
                     counts.get("PROBLEM", 0),
                     counts.get("ŞƏKİL YOXDUR", 0) + counts.get("VIDEOARCHIVE YOXDUR", 0),
                     counts.get("QOŞULMADI", 0) + counts.get("VAXT AŞIMI", 0) + counts.get("XƏTA", 0),
                     duration, str(error)[:700] if error else None, run_id))
        con.commit()
    finally:
        con.close()
    return finished


def va_worker(run_id, started_at, rows):
    try:
        va_log(f"VIDEOARCHIVE Scan #{run_id} başladı. ATM: {len(rows)} · paralel: {VA_MAX_WORKERS} · "
               f"ATM başına limit: {VA_ATM_TIMEOUT} san.")
        executor = ThreadPoolExecutor(max_workers=VA_MAX_WORKERS)
        pending = set()
        try:
            for row in rows:
                if VA_CANCEL.is_set():
                    break
                pending.add(executor.submit(va_check_one, run_id, dict(row)))
            while pending:
                if VA_CANCEL.is_set():
                    for f in pending:
                        f.cancel()
                    break
                done, pending = wait(pending, timeout=0.4, return_when=FIRST_COMPLETED)
                for f in done:
                    try:
                        f.result()
                    except Exception as exc:
                        va_log("Worker xətası: " + system_clean_error(exc))
        finally:
            executor.shutdown(wait=True, cancel_futures=VA_CANCEL.is_set())
        cancelled = VA_CANCEL.is_set()
        status = "CANCELLED" if cancelled else "COMPLETED"
        finished = va_finalize_run(run_id, started_at, status,
                                   "İstifadəçi tərəfindən dayandırıldı." if cancelled else None)
        with VA_LOCK:
            VA_STATE.update({"running": False, "finished": True, "finished_at": finished,
                             "current_atms": [], "cancel_requested": cancelled})
            if not cancelled:
                VA_STATE["percent"] = 100.0
        va_log("Scan dayandırıldı. Yoxlanmış ATM-lərin nəticəsi saxlanıldı." if cancelled
               else "VIDEOARCHIVE Scan tamamlandı.")
    except Exception as exc:
        error = system_clean_error(exc)
        try:
            finished = va_finalize_run(run_id, started_at, "FAILED", error)
        except Exception:
            finished = datetime.now().isoformat(timespec="seconds")
        with VA_LOCK:
            VA_STATE.update({"running": False, "finished": True, "error": error,
                             "finished_at": finished, "current_atms": []})
        va_log("VIDEOARCHIVE SCAN XƏTA: " + error)


def va_start(atm_ids=None):
    """atm_ids boşdursa — bütün aktiv (silinməmiş, status=1) ATM-lər."""
    with VA_LOCK:
        if VA_STATE["running"]:
            return False, "VIDEOARCHIVE Scan artıq işləyir.", VA_STATE.get("run_id")
    with DISK_REPORT_LOCK:
        if DISK_REPORT_STATE["running"]:
            return False, "Disk Report işləyir. Eyni ATM-lərə paralel qoşulmamaq üçün onun bitməsini gözlə.", None
    if not get_restart_passwords():
        return False, "PASSWORD environment dəyişənləri tapılmadı (PASSWORD1, PASSWORD2, ...).", None
    requested = []
    if atm_ids:
        if not isinstance(atm_ids, list):
            return False, "ATM siyahısı düzgün deyil.", None
        seen = set()
        for value in atm_ids:
            a = str(value or "").strip().upper()
            if ATM_ID_PATTERN.fullmatch(a) and a.casefold() not in seen:
                seen.add(a.casefold())
                requested.append(a)
        if not requested:
            return False, "Siyahıda düzgün ATM ID yoxdur.", None
        if len(requested) > 5000:
            return False, "Bir scan üçün maksimum 5000 ATM.", None
    con = db_connect()
    try:
        all_rows = con.execute("""SELECT atm_id,name,region,password_env FROM atms
                                  WHERE is_deleted=0 AND status=1 ORDER BY atm_id COLLATE NOCASE""").fetchall()
    finally:
        con.close()
    missing = []
    if requested:
        by_id = {str(r["atm_id"]).casefold(): r for r in all_rows}
        rows = [by_id[a.casefold()] for a in requested if a.casefold() in by_id]
        missing = [a for a in requested if a.casefold() not in by_id]
        scope = "SEÇİLMİŞ"
    else:
        rows = list(all_rows)
        scope = "HAMISI"
    rows = [{"atm_id": r["atm_id"], "name": r["name"], "region": r["region"],
             "password_env": r["password_env"]} for r in rows]
    if not rows:
        return False, "Yoxlanacaq aktiv ATM tapılmadı (bazada status=aktiv, silinməmiş ATM olmalıdır).", None
    run_id, started_at = va_create_run(len(rows), scope)
    VA_CANCEL.clear()
    with VA_LOCK:
        VA_STATE.update({"running": True, "finished": False, "cancel_requested": False,
                         "run_id": run_id, "started_at": started_at, "finished_at": None,
                         "total": len(rows), "processed": 0, "percent": 0.0, "current_atms": [],
                         "counts": {}, "logs": [], "completed_results": [], "error": None})
    if missing:
        va_log(f"{len(missing)} ATM bazada aktiv deyil / tapılmadı, çıxarıldı: " + ", ".join(missing[:20])
               + (" …" if len(missing) > 20 else ""))
    threading.Thread(target=va_worker, args=(run_id, started_at, rows), daemon=True).start()
    return True, None, run_id


def va_cancel():
    with VA_LOCK:
        if not VA_STATE["running"]:
            return False, "Aktiv VIDEOARCHIVE Scan yoxdur."
        VA_STATE["cancel_requested"] = True
    VA_CANCEL.set()
    va_log("DAYANDIR sorğusu qəbul edildi — işləyən ATM-lər bitən kimi scan dayanacaq.")
    return True, None


def va_history(limit=100):
    limit = max(1, min(int(limit or 100), 1000))
    con = db_connect()
    try:
        rows = con.execute("SELECT * FROM va_scan_runs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return {"success": True, "runs": [dict(r) for r in rows]}
    finally:
        con.close()


# Son şəkil vaxtına görə (ən yenisi yuxarıda). Fayl vaxtı yoxlama vaxtından gələcəkdə olan
# (ATM saatı səhv) ATM-lər düzgün vaxtlılardan sonra, şəkli olmayanlar ən sonda.
VA_SORT_SQL = """ORDER BY CASE WHEN last_image_at IS NULL THEN 2
                               WHEN last_image_at > strftime('%Y-%m-%dT%H:%M:%S', checked_at, '+1 day') THEN 1
                               ELSE 0 END,
                 last_image_at DESC,
                 CASE category WHEN 'ŞƏKİL YOXDUR' THEN 0 WHEN 'VIDEOARCHIVE YOXDUR' THEN 1
                               WHEN 'XƏTA' THEN 2 WHEN 'VAXT AŞIMI' THEN 3 ELSE 4 END,
                 atm_id COLLATE NOCASE"""


def va_detail(run_id):
    run_id = int(run_id or 0)
    con = db_connect()
    try:
        run = con.execute("SELECT * FROM va_scan_runs WHERE id=?", (run_id,)).fetchone()
        if not run:
            return None
        rows = con.execute("SELECT * FROM va_scan_results WHERE run_id=? " + VA_SORT_SQL, (run_id,)).fetchall()
        return {"success": True, "run": dict(run), "results": [dict(r) for r in rows],
                "late_days": VA_LATE_DAYS}
    finally:
        con.close()


def _va_dt(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value))
    except ValueError:
        return str(value)


def va_excel(run_id):
    """Scan nəticəsini .xlsx kimi qaytarır: (bytes, fayl_adı)."""
    from xlsx_lite import Workbook
    detail = va_detail(run_id)
    if not detail:
        raise FileNotFoundError("Scan tapılmadı.")
    run, results = detail["run"], detail["results"]
    counts = {}
    for r in results:
        counts[r["category"]] = counts.get(r["category"], 0) + 1

    wb = Workbook()
    # 1) Xülasə
    s = wb.add_sheet("Xülasə", [("Göstərici", 42), ("Dəyər", 26)], autofilter=False)
    s.add_row(["VIDEOARCHIVE Scan hesabatı", f"#{run['id']}"], bold=True, fill="title")
    s.add_row(["Yol (D$)", r"\\ATM_ID\D$\VIDEOARCHIVE\ATM_ID"])
    s.add_row(["Yol (E$)", r"\\ATM_ID\E$\Video"])
    s.add_row(["Başlama", _va_dt(run["started_at"])])
    s.add_row(["Bitmə", _va_dt(run["finished_at"])])
    status_az = {"COMPLETED": "TAMAMLANDI", "CANCELLED": "DAYANDIRILDI", "RUNNING": "İŞLƏYİR",
                 "INTERRUPTED": "YARIMÇIQ (server dayandı)", "FAILED": "XƏTA"}
    s.add_row(["Status", status_az.get(run["status"], run["status"])])
    s.add_row(["Seçilmiş ATM", int(run["selected_count"] or 0)])
    s.add_row(["Yoxlanılmış ATM", len(results)])
    if run["duration_seconds"]:
        s.add_row(["Müddət (dəqiqə)", round(float(run["duration_seconds"]) / 60.0, 1)])
    s.add_blank()
    s.add_row(["Kateqoriya", "ATM sayı"], bold=True, fill="title")
    explain = {
        "AKTİV": "son şəkil bu gün və ya dünən",
        "GECİKİR": f"son şəkil 2–{VA_LATE_DAYS} gün əvvəl",
        "PROBLEM": f"son şəkil {VA_LATE_DAYS} gündən çox əvvəl",
        "ŞƏKİL YOXDUR": "qovluq var, şəkil tapılmadı",
        "VIDEOARCHIVE YOXDUR": "D$\\VIDEOARCHIVE\\ATM_ID yoxdur",
        "QOŞULMADI": "şəbəkə / şifrə",
        "VAXT AŞIMI": f"{VA_ATM_TIMEOUT} saniyədə bitmədi",
        "XƏTA": "oxuma xətası",
    }
    for cat in VA_CATEGORIES:
        if counts.get(cat):
            s.add_row([f"{cat} — {explain.get(cat, '')}".rstrip(" —"), counts[cat]],
                      fill=VA_CATEGORY_FILL.get(cat, "none"))

    cols = [("№", 6), ("ATM ID", 13), ("Ad", 36), ("Region", 15), ("Status", 18),
            ("Şəkil", 10), ("Video", 10), ("Şəkil sayı", 10), ("Video sayı", 10),
            ("Son şəkil (tarix-saat)", 21),
            ("D$ şəkil", 9), ("D$ video", 9), ("D$ son folder", 13),
            ("E$ şəkil", 9), ("E$ video", 9), ("E$ son folder", 13),
            ("PASSWORD slotu", 13), ("Yoxlama vaxtı", 20),
            ("D$ yolu", 38), ("E$ yolu", 30), ("Qeyd / xəta", 60)]

    _not_verified = ("QOŞULMADI", "VAXT AŞIMI", "XƏTA")

    def _rk(r, key):
        try:
            return r[key]
        except (IndexError, KeyError):
            return None

    def _folder_date(v):
        return (datetime.strptime(v, "%Y%m%d").date() if v and len(str(v)) == 8 and str(v).isdigit() else v)

    def _later(a, b):
        if not a:
            return b
        if not b:
            return a
        return a if a >= b else b

    def add_rows(sheet, rows):
        for i, r in enumerate(rows, 1):
            img_d = int(r["image_count"] or 0)
            img_e = int(_rk(r, "video_image_count") or 0)
            vid_d = int(r["video_count"] or 0)
            vid_e = int(_rk(r, "video_video_count") or 0)
            verified = r["category"] not in _not_verified
            tot_img, tot_vid = img_d + img_e, vid_d + vid_e
            sekil = ("—" if not verified else ("VAR" if tot_img > 0 else "YOXDUR"))
            video = ("—" if not verified else ("VAR" if tot_vid > 0 else "YOXDUR"))
            son = _later(r["last_image_at"], _rk(r, "video_last_image_at"))
            note = r["error"] or ""
            ve = _rk(r, "video_error")
            if ve and ve != note:
                note = (note + " · " if note else "") + "E$: " + ve
            sheet.add_row([
                i, r["atm_id"], r["name"] or "", r["region"] or "", r["category"],
                sekil, video, (tot_img if verified else None), (tot_vid if verified else None),
                _va_dt(son),
                img_d, vid_d, _folder_date(r["media_folder"]),
                img_e, vid_e, _folder_date(_rk(r, "video_media_folder")),
                r["password_env"], _va_dt(r["checked_at"]),
                r["archive_path"], _rk(r, "video_archive_path"), note,
            ], fill=VA_CATEGORY_FILL.get(r["category"], "none"), bold_cols=(1,))

    # 2) Bütün ATM-lər — son şəkil vaxtına görə (ən yenisi yuxarıda)
    add_rows(wb.add_sheet("Bütün ATM-lər", cols), results)
    # 3) Diqqət tələb edənlər — ən köhnəsi yuxarıda
    bad = [r for r in results if r["category"] != "AKTİV"]
    bad.sort(key=lambda r: (r["days_since"] is None, -(r["days_since"] or 0)))
    add_rows(wb.add_sheet("Diqqət tələb edənlər", cols), bad)
    # 4) Qoşulmayanlar
    failed = [r for r in results if r["category"] in ("QOŞULMADI", "VAXT AŞIMI", "XƏTA")]
    if failed:
        add_rows(wb.add_sheet("Qoşulmayanlar", cols), failed)

    stamp = (run["started_at"] or "").replace(":", "-").replace("T", "_")[:16]
    return wb.to_bytes(), f"VIDEOARCHIVE_Scan_{run['id']}_{stamp}.xlsx"


# ============================================================
# LIVE SCAN STATE
# ============================================================

def new_summary():
    return {
        "total_atm": 0,
        "checked": 0,
        "excellent": 0,
        "normal": 0,
        "problem": 0,
        "total_images": 0,
        "total_videos": 0,
        "total_txt": 0,
        "total_media": 0
    }


SCAN_LOCK = threading.RLock()
SCAN_CONTEXT = threading.local()
SCAN_CANCEL_EVENTS = {}


class ScanCancelled(Exception):
    """User stopped the running scan."""


def check_scan_cancel():
    event = getattr(SCAN_CONTEXT, "cancel_event", None)
    if event is not None and event.is_set():
        raise ScanCancelled("Scan istifadəçi tərəfindən dayandırıldı.")



def new_scan_state(scan_type):
    return {
        "scan_type": scan_type,
        "source_path": SCAN_SOURCES.get(scan_type, ""),
        "scan_id": None,
        "running": False,
        "finished": False,
        "started_at": None,
        "finished_at": None,
        "total_atms": 0,
        "processed_atms": 0,
        "percent": 0,
        "current_atm": "",
        "current_path": "",
        "current_action": "",
        "selected_date": "",
        "selected_date_display": "",
        "yesterday": "",
        "yesterday_display": "",
        "logs": [],
        "completed_results": [],
        "summary": new_summary(),
        "error": None,
        "cancel_requested": False,
    }


SCAN_STATES = {}  # filled by refresh_source_cache() from SQLite


def scan_context_type():
    return getattr(SCAN_CONTEXT, "scan_type", "D")


def add_log(message):
    line = datetime.now().strftime("%H:%M:%S") + "  " + message
    scan_type = scan_context_type()
    with SCAN_LOCK:
        if getattr(SCAN_CONTEXT, "cancel_event", None) is not None and SCAN_CONTEXT.cancel_event.is_set():
            return
        state = SCAN_STATES[scan_type]
        state["logs"].append(line)
        if len(state["logs"]) > 500:
            state["logs"] = state["logs"][-500:]


def update_current(atm=None, path=None, action=None):
    scan_type = scan_context_type()
    with SCAN_LOCK:
        if getattr(SCAN_CONTEXT, "cancel_event", None) is not None and SCAN_CONTEXT.cancel_event.is_set():
            return
        state = SCAN_STATES[scan_type]
        if atm is not None:
            state["current_atm"] = atm
        if path is not None:
            state["current_path"] = path
        if action is not None:
            state["current_action"] = action


def scan_atm_for_source(scan_type, cancel_event, *args):
    # ThreadPoolExecutor threads must retain their own source to avoid D/H mixing.
    SCAN_CONTEXT.scan_type = scan_type
    SCAN_CONTEXT.cancel_event = cancel_event
    try:
        check_scan_cancel()
        return scan_atm(*args)
    finally:
        del SCAN_CONTEXT.scan_type
        del SCAN_CONTEXT.cancel_event

# ============================================================
# SCAN HELPERS
# ============================================================

def parse_date_folder(name):
    if not DATE_PATTERN.match(name):
        return None
    try:
        return datetime.strptime(name, "%Y%m%d").date()
    except ValueError:
        return None


def date_display(value):
    return "-" if value is None else value.strftime("%d.%m.%Y")


def datetime_display(timestamp):
    if not timestamp:
        return "-"
    try:
        return datetime.fromtimestamp(timestamp).strftime("%d.%m.%Y %H:%M:%S")
    except Exception:
        return "-"


def get_media_type(filename):
    ext = os.path.splitext(filename)[1].lower()
    if is_journal_source(scan_context_type()):
        return "txt" if ext in TXT_EXTENSIONS else None
    if ext in IMAGE_EXTENSIONS:
        return "image"
    if ext in VIDEO_EXTENSIONS:
        return "video"
    return None


def folder_has_media(atm_name, folder_path):
    """Köhnə çağırışlarla uyğunluq üçün; əsas scan bir keçiddə sayır."""
    return scan_media_folder(atm_name, folder_path)["total"] > 0


def scan_media_folder(atm_name, folder_path):
    """Tarix folderinin içində (alt qovluqlar da daxil) JPG/video sayır.

    SMB qovluğuna girişdəki os.walk xətaları udulmur: HTML logunda görünür.
    """
    result = {
        "images": 0, "videos": 0, "txt": 0, "total": 0,
        "latest_file_time": None, "error": None
    }
    errors = []

    def walk_error(err):
        errors.append(str(err))
        add_log(f"{atm_name} -> FOLDER OXUMA XƏTASI: {err}")

    try:
        for walk_root, dirs, files in os.walk(folder_path, onerror=walk_error):
            check_scan_cancel()
            update_current(
                atm=atm_name,
                path=walk_root,
                action="Tarix folderinin içində JPG / video / TXT faylları yoxlanılır..."
            )
            for filename in files:
                check_scan_cancel()
                media_type = get_media_type(filename)
                if not media_type:
                    continue
                full_path = os.path.join(walk_root, filename)
                try:
                    modified = os.stat(full_path).st_mtime
                except OSError as err:
                    errors.append(f"{full_path}: {err}")
                    add_log(f"{atm_name} -> FAYL OXUMA XƏTASI: {full_path}: {err}")
                    continue

                if media_type == "image":
                    result["images"] += 1
                elif media_type == "video":
                    result["videos"] += 1
                else:
                    result["txt"] += 1
                result["total"] += 1
                if result["latest_file_time"] is None or modified > result["latest_file_time"]:
                    result["latest_file_time"] = modified
    except OSError as err:
        errors.append(str(err))

    if errors:
        result["error"] = "; ".join(errors[:3])
    return result


def journal_date_from_filename(filename):
    """Yalnız JRN/TXT adının YYYYMMDD tarix hissəsini oxuyur.

    Nümunə: 20260921, 20260921.jrn, 20260921.txt,
    20260921_1.jrn. Date Modified/Fayl sırası istifadə edilmir.
    """
    stem, ext = os.path.splitext(filename)
    if ext.casefold() not in TXT_EXTENSIONS:
        return None
    # Başdakı tarix tam 8 rəqəmli olmalıdır; əlavə suffix '_' / '-' ilə ola bilər.
    match = re.fullmatch(r"(\d{8})(?:[_-].*)?", stem)
    if not match:
        return None
    return parse_date_folder(match.group(1))


def scan_flat_d_journal(atm_name, atm_path, selected_date, yesterday, result):
    r"""D Jurnal: Journal varsa onun, yoxdursa birbaşa ATM-in fayllarını oxu.

    Bir dəfə bütün JRN/TXT fayllarını oxuyur, fayl adındakı YYYYMMDD
    tarixlərinə görə maksimumu tapır. Stat/Date Modified istifadə ETMİR.
    Ən yeni real fayl (bugün olsa belə) son fayl sütununda göstərilir.
    Status dünən və daha əvvəlki tarixli son etibarlı fayla görə hesablanır.
    """
    check_scan_cancel()
    result["yesterday_folder"] = yesterday.strftime("%Y%m%d")
    result["yesterday_state"] = "YOX"
    result["images"] = result["videos"] = 0
    result["latest_journal_filename"] = ""
    try:
        update_current(atm=atm_name, path=atm_path,
                       action="D Jurnal: ATM qovluğu və Journal alt-qovluğu yoxlanılır...")
        add_log(f"{atm_name} -> ATM folderi: {atm_path}")
        journal_path = None
        with os.scandir(atm_path) as entries:
            for entry in entries:
                check_scan_cancel()
                if entry.name.casefold() == "journal" and entry.is_dir(follow_symlinks=False):
                    journal_path = entry.path
                    break
        scan_path = journal_path or atm_path
        add_log(f"{atm_name} -> " + ("Journal VAR: " if journal_path else "Journal YOX, ATM daxilində: ") + scan_path)
        update_current(atm=atm_name, path=scan_path,
                       action="BÜTÜN JRN/TXT faylları adındakı YYYYMMDD ilə müqayisə edilir...")
        by_day = {}
        ignored = 0
        with os.scandir(scan_path) as entries:
            for entry in entries:
                check_scan_cancel()
                if not entry.is_file(follow_symlinks=False):
                    continue
                if os.path.splitext(entry.name)[1].casefold() not in TXT_EXTENSIONS:
                    continue
                file_day = journal_date_from_filename(entry.name)
                if file_day is None:
                    ignored += 1
                    continue
                by_day.setdefault(file_day, []).append(entry.name)

        total_named = sum(map(len, by_day.values()))
        add_log(f"{atm_name} -> Adında düzgün tarix olan JRN/TXT faylları: {total_named}; tarixi uyğun olmayanlar: {ignored}")
        if not by_day:
            result["yesterday_state"] = "BOŞ" if not ignored else "YOX"
            result["reason"] = "YYYYMMDD adlandırılmış JRN/TXT faylı tapılmadı."
            add_log(f"{atm_name} -> PROBLEM: {result['reason']}")
            return result

        # Sıra və Date Modified vacib deyil: bütün adlar arasında ən böyük tarix.
        newest_day = max(by_day)
        newest_name = max(by_day[newest_day], key=str.casefold)
        result["latest_date_folder"] = date_display(newest_day)
        result["latest_date_folder_raw"] = newest_day.isoformat()
        result["latest_journal_filename"] = newest_name
        add_log(f"{atm_name} -> BÜTÜN FAYLLAR ARASINDA ƏN SON: {newest_name} | tarix: {date_display(newest_day)}")

        if yesterday in by_day:
            result["yesterday_state"] = "VAR"
            add_log(f"{atm_name} -> Dünən adına uyğun fayl sayı: {len(by_day[yesterday])}")
        else:
            add_log(f"{atm_name} -> Dünən adına uyğun fayl yoxdur")

        # Backup kateqoriyasına bu günün/gələcəyin faylını salmırıq.
        # Onlar yuxarıdakı SON FAYL sahəsində yenə də göstərilir.
        past_days = [day for day in by_day if day <= yesterday]
        if not past_days:
            result["reason"] = f"Son fayl: {newest_name}. Dünən və daha əvvəl tarixli jurnal yoxdur."
            add_log(f"{atm_name} -> PROBLEM: {result['reason']}")
            return result

        backup_day = max(past_days)
        backup_files = by_day[backup_day]
        result["last_valid_backup"] = date_display(backup_day)
        result["last_valid_backup_raw"] = backup_day.isoformat()
        result["delay_days"] = (yesterday - backup_day).days
        result["txt"] = result["total"] = len(backup_files)
        # Son media vaxtı sütununda yalnız fayl ADINDAN alınan tarix verilir.
        # Saatı təxmin etmirik, Date Modified-ə baxmırıq.
        result["last_media_time"] = date_display(backup_day) + " (fayl adı)"

        if backup_day == yesterday:
            result["category"] = "EXCELLENT"
            result["reason"] = f"Dünən adına uyğun jurnal var. Son fayl: {newest_name}."
        elif selected_date <= backup_day < yesterday:
            result["category"] = "NORMAL"
            result["reason"] = f"Son etibarlı jurnal seçilən tarix intervalındadır. Son fayl: {newest_name}."
        else:
            result["category"] = "PROBLEM"
            result["reason"] = f"Son etibarlı jurnal seçilən tarixdən köhnədir. Son fayl: {newest_name}."
        add_log(f"{atm_name} -> {result['category']} | Son etibarlı: {date_display(backup_day)} | TXT/JRN: {result['txt']} | SON FAYL: {newest_name}")
        return result

    except Exception as err:
        result["category"] = "PROBLEM"
        result["yesterday_state"] = "XƏTA"
        result["reason"] = f"JRN/TXT siyahısı oxunmadı: {err}"
        add_log(f"{atm_name} -> JURNAL XƏTA: {result['reason']}")
        return result



# NORMAL kateqoriyası üçün tolerantlıq (gün): son etibarlı backup seçilən tarixdən
# ən çox bu qədər gün əvvəldirsə NORMAL, daha köhnədirsə PROBLEM.
# Mühit dəyişəni ilə dəyişmək olar: ATM_NORMAL_DAYS_D=5, ATM_NORMAL_DAYS_H=3 ...
NORMAL_TOLERANCE_DAYS = {"D": 5}


def normal_tolerance_days(scan_type):
    env = os.getenv("ATM_NORMAL_DAYS_" + str(scan_type or "").upper(), "").strip()
    if env.isdigit():
        return int(env)
    return NORMAL_TOLERANCE_DAYS.get(str(scan_type or "").upper(), 0)


def scan_atm(atm_name, atm_path, selected_date, yesterday):
    r"""D və H ÜÇÜN EYNİ QOVLUQ STRUKTURU:

       D:  <DB_IP>\d$\<DB_FOLDER>\ATM_ID\YYYYMMDD\fayllar
       H:  <DB_IP>\h$\<DB_FOLDER>\ATM_ID\YYYYMMDD\fayllar

    Əvvəl ATM qovluğuna daxil olur, sonra tarix adlı qovluqları oxuyur,
    ən yeni tarix qovluğuna daxil olub media fayllarını sayır. Ən yeni
    tarix boşdursa, D Scan-da olduğu kimi daha köhnə *etibarlı* backupı
    axtarır. Dünənki qovluğun VAR/BOŞ/YOX/XƏTA statusu ayrıca göstərilir.
    """
    yesterday_folder_name = yesterday.strftime("%Y%m%d")
    result = {
        "atm": atm_name,
        "category": "PROBLEM",
        "reason": "",
        "yesterday_folder": yesterday_folder_name,
        "yesterday_state": "YOX",
        "last_valid_backup": "-",
        "last_valid_backup_raw": "",
        "latest_date_folder": "-",
        "latest_date_folder_raw": "",
        "delay_days": None,
        "images": 0,
        "videos": 0,
        "txt": 0,
        "total": 0,
        "last_media_time": "-",
        "latest_journal_filename": ""
    }
    source_name = scan_context_type()

    # D Scan Jurnal: tarix adlı folder DEYİL, birbaşa JRN/TXT faylları.
    # JRN/TXT tarixi YALNIZ faylın adındakı YYYYMMDD ilə təyin edilir.
    if source_name == "DJ":
        return scan_flat_d_journal(atm_name, atm_path, selected_date, yesterday, result)

    try:
        check_scan_cancel()
        update_current(
            atm=atm_name,
            path=atm_path,
            action=f"{source_name} Scan: ATM qovluğuna daxil olunur..."
        )
        add_log(f"{source_name} | ATM: {atm_name} | ATM folderi: {atm_path}")

        # D/H JPG/Video və H Scan Jurnalın əvvəlki tarix-folder məntiqi saxlanılır.
        date_root = atm_path

        date_folders = []
        with os.scandir(date_root) as entries:
            for entry in entries:
                check_scan_cancel()
                try:
                    if not entry.is_dir():
                        continue
                    folder_date = parse_date_folder(entry.name)
                    if folder_date is None:
                        continue
                    # D Scan-dakı qayda: gələcək və bugünkü folderlər yox,
                    # dünənə qədər olan tarix folderləri qiymətləndirilir.
                    if folder_date > yesterday:
                        continue
                    date_folders.append({
                        "date": folder_date,
                        "name": entry.name,
                        "path": entry.path
                    })
                except OSError as err:
                    add_log(f"{atm_name} -> Tarix folderi oxunmadı: {entry.name}: {err}")

        date_folders.sort(key=lambda f: f["date"], reverse=True)
        if not date_folders:
            result["reason"] = (
                f"{date_root} daxilində dünənə qədər YYYYMMDD tarix folderi tapılmadı."
            )
            add_log(f"{atm_name} -> PROBLEM | {result['reason']}")
            return result

        latest = date_folders[0]
        result["latest_date_folder"] = date_display(latest["date"])
        result["latest_date_folder_raw"] = latest["date"].strftime("%Y-%m-%d")
        add_log(f"{atm_name} -> Son tarix folderi: {latest['name']}")
        add_log(f"{atm_name} -> Son tarix folderinin tam yolu: {latest['path']}")

        # Bir tarix qovluğu yalnız bir dəfə oxunur. Ən yeni tarixdən başlayır.
        last_valid = None
        last_valid_scan = None
        latest_error = None
        for folder in date_folders:
            check_scan_cancel()
            update_current(
                atm=atm_name,
                path=folder["path"],
                action=f"{source_name} Scan: {folder['name']} folderinin faylları yoxlanılır..."
            )
            if folder is latest:
                add_log(f"{atm_name} -> Son tarix folderinə daxil olunur: {folder['path']}")

            media = scan_media_folder(atm_name, folder["path"])
            if folder["name"] == yesterday_folder_name:
                if media["error"]:
                    result["yesterday_state"] = "XƏTA"
                elif media["total"] > 0:
                    result["yesterday_state"] = "VAR"
                else:
                    result["yesterday_state"] = "BOŞ"

            if folder is latest:
                add_log(
                    f"{atm_name} -> {folder['name']} | JPG: {media['images']} "
                    f"| Video: {media['videos']} | TXT: {media['txt']} | Cəmi: {media['total']}"
                )
                latest_error = media["error"]

            if media["error"]:
                add_log(f"{atm_name} -> {folder['name']} oxunma xətası: {media['error']}")
                continue
            if media["total"] > 0:
                last_valid = folder
                last_valid_scan = media
                break

            if folder is latest:
                add_log(f"{atm_name} -> Son tarix folderi boşdur. Əvvəlki tarix yoxlanılır...")

        if last_valid is None:
            result["category"] = "PROBLEM"
            result["reason"] = (
                "Tarix folderlərində oxuna bilən "+("TXT" if is_journal_source(source_name) else "JPG/Video")+" faylı tapılmadı."
            )
            if latest_error:
                result["reason"] += " Son tarix folderi xətası: " + latest_error
                result["yesterday_state"] = (
                    "XƏTA" if latest["name"] == yesterday_folder_name
                    else result["yesterday_state"]
                )
            add_log(f"{atm_name} -> PROBLEM | {result['reason']}")
            return result

        last_date = last_valid["date"]
        result["last_valid_backup"] = date_display(last_date)
        result["last_valid_backup_raw"] = last_date.strftime("%Y-%m-%d")
        result["delay_days"] = (yesterday - last_date).days
        result["images"] = last_valid_scan["images"]
        result["videos"] = last_valid_scan["videos"]
        result["txt"] = last_valid_scan["txt"]
        result["total"] = last_valid_scan["total"]
        result["last_media_time"] = datetime_display(last_valid_scan["latest_file_time"])

        tolerance = normal_tolerance_days(source_name)
        normal_limit = selected_date - timedelta(days=tolerance)
        days_before_selected = (selected_date - last_date).days
        limit_text = (f"seçilən tarixdən ({date_display(selected_date)}) ən çox {tolerance} gün əvvəl"
                      if tolerance else f"seçilən tarix ({date_display(selected_date)}) və sonrası")
        if last_date == yesterday:
            result["category"] = "EXCELLENT"
            result["reason"] = "Dünənki folderdə "+("TXT" if is_journal_source(source_name) else "JPG/Video")+" backup mövcuddur."
        elif normal_limit <= last_date < yesterday:
            result["category"] = "NORMAL"
            if days_before_selected > 0:
                within = f"Son etibarlı backup seçilən tarixdən {days_before_selected} gün əvvəldir ({tolerance} gün limiti daxilində)."
            else:
                within = "Son etibarlı backup tarix limiti daxilindədir."
            if result["yesterday_state"] == "BOŞ":
                result["reason"] = "Dünənki folder boşdur. " + within
            elif result["yesterday_state"] == "YOX":
                result["reason"] = "Dünənki folder yoxdur. " + within
            elif result["yesterday_state"] == "XƏTA":
                result["reason"] = "Dünənki folder oxunmadı. " + within
            else:
                result["reason"] = within
        else:
            result["category"] = "PROBLEM"
            result["reason"] = (f"Son etibarlı backup seçilən tarixdən {days_before_selected} gün köhnədir "
                                f"(NORMAL üçün limit: {limit_text}).")

        add_log(
            f"{atm_name} -> {result['category']} | Son etibarlı: {result['last_valid_backup']} "
            f"| JPG: {result['images']} | Video: {result['videos']} | TXT: {result['txt']}"
        )
        return result

    except Exception as err:
        result["category"] = "PROBLEM"
        result["reason"] = f"ATM folderi oxunmadı: {atm_path}. Xəta: {err}"
        result["yesterday_state"] = "XƏTA"
        add_log(f"{atm_name} -> ERROR | {result['reason']}")
        return result


def register_completed_result(result, scan_type, cancel_event):
    with SCAN_LOCK:
        if cancel_event.is_set():
            return
        state = SCAN_STATES[scan_type]
        state["completed_results"].append(result)
        state["processed_atms"] += 1

        processed = state["processed_atms"]
        total = state["total_atms"]
        if total > 0:
            state["percent"] = round(processed / total * 100, 1)

        summary = state["summary"]
        summary["checked"] += 1

        category = result["category"]
        if category == "EXCELLENT":
            summary["excellent"] += 1
        elif category == "NORMAL":
            summary["normal"] += 1
        else:
            summary["problem"] += 1

        summary["total_images"] += result["images"]
        summary["total_videos"] += result["videos"]
        summary["total_txt"] += result.get("txt", 0)
        summary["total_media"] += result["total"]

        scan_id = state["scan_id"]
        summary_copy = dict(summary)
        total_atm = state["total_atms"]

    # DB write lock-dan kənarda edilir.
    if scan_id is not None:
        persist_result_and_summary(scan_id, result, summary_copy, total_atm)


def perform_scan(selected_date, scan_id, started_at, scan_type, root_path, cancel_event):
    SCAN_CONTEXT.scan_type = scan_type
    SCAN_CONTEXT.cancel_event = cancel_event
    state = SCAN_STATES[scan_type]
    try:
        yesterday = date.today() - timedelta(days=1)

        add_log(f"{scan_type} SCAN BAŞLADI")
        add_log("Mənbə: " + root_path)
        add_log("Tarix limiti: " + date_display(selected_date))
        add_log("Dünən: " + date_display(yesterday))

        update_current(path=root_path, action="ATM siyahısı oxunur...")

        atms = []
        check_scan_cancel()
        with os.scandir(root_path) as entries:
            for entry in entries:
                check_scan_cancel()
                try:
                    if entry.is_dir():
                        atms.append((entry.name, entry.path))
                except Exception:
                    pass

        atms.sort(key=lambda x: x[0].lower())

        with SCAN_LOCK:
            state["total_atms"] = len(atms)
            state["summary"]["total_atm"] = len(atms)

        add_log(f"{scan_type} | ATM qovluqlarının sayı: {len(atms)}")
        if not atms:
            raise RuntimeError(
                f"{root_path} altında oxuna bilən ATM qovluğu tapılmadı. "
                "Network share path / permission / qovluq strukturunu yoxla."
            )
        add_log(f"{scan_type} | Nümunə ATM yolu: {atms[0][1]}")

        # Wait in short intervals so a page refresh / Stop Scan can cancel.
        # Queued ATM tasks are cancelled; running SMB reads stop cooperatively
        # after their current filesystem call finishes.
        executor = ThreadPoolExecutor(max_workers=MAX_WORKERS)
        cancelled = False
        try:
            pending = {
                executor.submit(
                    scan_atm_for_source,
                    scan_type,
                    cancel_event,
                    atm_name,
                    atm_path,
                    selected_date,
                    yesterday
                ): atm_name
                for atm_name, atm_path in atms
                if not cancel_event.is_set()
            }
            while pending:
                if cancel_event.is_set():
                    cancelled = True
                    break
                done, _ = wait(pending, timeout=0.2, return_when=FIRST_COMPLETED)
                for future in done:
                    atm_name = pending.pop(future)
                    if cancel_event.is_set():
                        cancelled = True
                        break
                    try:
                        result = future.result()
                    except ScanCancelled:
                        cancelled = True
                        break
                    except Exception as e:
                        result = {
                            "atm": atm_name, "category": "PROBLEM", "reason": str(e),
                            "yesterday_folder": yesterday.strftime("%Y%m%d"),
                            "yesterday_state": "XƏTA", "last_valid_backup": "-",
                            "last_valid_backup_raw": "", "latest_date_folder": "-",
                            "latest_date_folder_raw": "", "delay_days": None,
                            "images": 0, "videos": 0, "txt": 0, "total": 0,
                            "last_media_time": "-"
                        }
                    register_completed_result(result, scan_type, cancel_event)
                if cancelled:
                    break
        finally:
            # Do not wait indefinitely for a remote ATM / SMB path to return.
            executor.shutdown(wait=not(cancelled or cancel_event.is_set()),
                              cancel_futures=cancelled or cancel_event.is_set())

        if cancelled or cancel_event.is_set():
            with SCAN_LOCK:
                state["current_atm"] = ""
                state["current_action"] = "Scan dayandırıldı (səhifə yeniləndi və ya Stop basıldı)."
                state["finished_at"] = datetime.now().isoformat(timespec="seconds")
                state["finished"] = True
                state["running"] = False
                state["cancel_requested"] = True
                summary_copy = dict(state["summary"])
                total_atm = state["total_atms"]
                state["logs"].append(datetime.now().strftime("%H:%M:%S") +
                    "  Scan dayandırıldı; qismən nəticələr tarixçədə saxlanıldı.")
            finalize_scan_record(scan_id, started_at, summary_copy, total_atm,
                                 status="CANCELLED",
                                 error="İstifadəçi tərəfindən dayandırıldı.")
            return

        with SCAN_LOCK:
            state["percent"] = 100
            state["current_atm"] = ""
            state["current_path"] = root_path
            state["current_action"] = "Scan tamamlandı."
            state["finished_at"] = datetime.now().isoformat(timespec="seconds")
            summary_copy = dict(state["summary"])
            total_atm = state["total_atms"]

        finalize_scan_record(
            scan_id,
            started_at,
            summary_copy,
            total_atm,
            status="COMPLETED"
        )
        with SCAN_LOCK:
            state["running"] = False
            state["finished"] = True
        add_log(f"{scan_type} SCAN TAMAMLANDI")

    except ScanCancelled:
        with SCAN_LOCK:
            state["running"] = False
            state["finished"] = True
            state["cancel_requested"] = True
            state["current_action"] = "Scan dayandırıldı."
            state["finished_at"] = datetime.now().isoformat(timespec="seconds")
            summary_copy = dict(state["summary"])
            total_atm = state["total_atms"]
        finalize_scan_record(scan_id, started_at, summary_copy, total_atm,
                             status="CANCELLED", error="İstifadəçi tərəfindən dayandırıldı.")
    except Exception as e:
        with SCAN_LOCK:
            state["error"] = str(e)
            state["current_action"] = "SCAN ERROR"
            summary_copy = dict(state["summary"])
            total_atm = state["total_atms"]

        finalize_scan_record(
            scan_id,
            started_at,
            summary_copy,
            total_atm,
            status="FAILED",
            error=str(e)
        )
        with SCAN_LOCK:
            state["running"] = False
            state["finished"] = True
            state["finished_at"] = datetime.now().isoformat(timespec="seconds")
        add_log("SCAN ERROR -> " + str(e))


def start_scan(selected_date_text, scan_type="D"):
    if scan_type not in SCAN_LABELS:
        return False, "Scan tipi düzgün deyil.", None
    with CONFIG_LOCK:
        source_path = SCAN_SOURCES.get(scan_type)
    if not source_path:
        return False, "Bu scan üçün IP / disk / folder təyin edilməyib. IP ünvanları bölməsinə keç.", None
    try:
        selected_date = datetime.strptime(selected_date_text, "%Y-%m-%d").date()
    except Exception:
        return False, "Tarix düzgün deyil.", None

    yesterday = date.today() - timedelta(days=1)
    if selected_date > yesterday:
        return False, "Seçilən tarix dünəndən sonra ola bilməz.", None

    # Check + database insert + state update are atomic w.r.t. other start calls.
    with SCAN_LOCK:
        state = SCAN_STATES[scan_type]
        if state["running"]:
            return False, "Bu mənbə üçün scan artıq işləyir.", None
        scan_id, started_at = create_scan_record(selected_date, yesterday, scan_type, source_path)
        cancel_event = threading.Event()
        SCAN_CANCEL_EVENTS[scan_type] = (scan_id, cancel_event)
        state.update({
            "cancel_requested": False,
            "scan_id": scan_id,
            "scan_type": scan_type,
            "source_path": source_path,
            "running": True,
            "finished": False,
            "started_at": started_at,
            "finished_at": None,
            "total_atms": 0,
            "processed_atms": 0,
            "percent": 0,
            "current_atm": "",
            "current_path": source_path,
            "current_action": "Scan başladılır...",
            "selected_date": selected_date.strftime("%Y-%m-%d"),
            "selected_date_display": date_display(selected_date),
            "yesterday": yesterday.strftime("%Y-%m-%d"),
            "yesterday_display": date_display(yesterday),
            "logs": [],
            "completed_results": [],
            "summary": new_summary(),
            "error": None
        })

    thread = threading.Thread(
        target=perform_scan,
        args=(selected_date, scan_id, started_at, scan_type, source_path, cancel_event),
        daemon=True
    )
    thread.start()
    return True, None, scan_id

def cancel_scan(scan_type, scan_id):
    """Idempotent, race-safe cancellation for browser refresh / Stop Scan."""
    with SCAN_LOCK:
        state = SCAN_STATES.get(scan_type)
        if state is None or state.get("scan_id") != scan_id:
            return False, "Aktiv scan ID uyğun deyil."
        if not state["running"]:
            return True, None
        saved = SCAN_CANCEL_EVENTS.get(scan_type)
        if saved is None or saved[0] != scan_id:
            return False, "Scan artıq dəyişib."
        saved[1].set()
        state["cancel_requested"] = True
        state["current_action"] = "Scan dayandırılır..."
        state["logs"].append(datetime.now().strftime("%H:%M:%S") + "  STOP sorğusu qəbul edildi.")
        return True, None


# ============================================================
# ATM RESTART MODULE - NET USE + WINDOWS SHUTDOWN
#
# Bu hissə istifadəçinin işləyən R kodunun məntiqinə uyğun qurulub:
#
#   net use \\ATM /delete
#   net use \\ATM /user:administrator PASSWORD
#   \\ATM\C$ access yoxla
#   shutdown /r /m \\ATM /t 10 /f
#
# PASSWORD1-PASSWORD7 environment dəyişənlərindən götürülür.
# Real şifrələr HTML və CMD logunda göstərilmir.
# ============================================================

RESTART_LOCK = threading.Lock()

RESTART_STATE = {
    "running": False,
    "finished": False,
    "success": False,
    "target": "",
    "attempt": 0,
    "attempt_label": "",
    "attempt_elapsed": 0,
    "current_action": "",
    "started_at": None,
    "finished_at": None,
    "logs": [],
    "error": None,
    "matched_password_slot": None,
    "username": "administrator",
    "network_ok": None,
    "last_error_code": None
}

ATM_ID_PATTERN = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def get_restart_passwords():
    """
    PASSWORD1, PASSWORD2, ... environment dəyişənlərini dinamik tapır.
    Yuxarı limit yoxdur; real şifrə heç vaxt UI/log-a yazılmır.
    """
    items = []
    for name, value in os.environ.items():
        m = re.fullmatch(r"PASSWORD(\d+)", str(name).upper())
        if not m or not value:
            continue
        items.append((int(m.group(1)), value))
    items.sort(key=lambda x: x[0])
    return items


# ============================================================
# WINDOWS NÖVÜ ↔ PASSWORD slotu ↔ collector qovluğu
# PASSWORD slotu hansı Windows versiyasına aiddirsə, həmin versiyaya uyğun
# collector (eco_xp / eco_win7 / eco_win10) ATM-ə göndərilir. Real şifrə yox,
# yalnız slot NÖMRƏSİ istifadə olunur.
# ============================================================
WIN_TYPE_BY_SLOT = {
    1: "XP",   4: "XP",   8: "XP",
    3: "WIN10", 6: "WIN10", 10: "WIN10",
    2: "WIN7",  5: "WIN7",  9: "WIN7",
}
WIN_COLLECTOR_SUBDIR = {"XP": "eco_xp", "WIN7": "eco_win7", "WIN10": "eco_win10"}
WIN_TYPE_LABELS = {"XP": "Windows XP", "WIN7": "Windows 7", "WIN10": "Windows 10"}


def slot_from_env(env):
    m = re.fullmatch(r"PASSWORD(\d+)", str(env or "").upper())
    return int(m.group(1)) if m else None


def windows_type_for_env(env):
    """PASSWORD slotundan Windows növünü çıxarır (XP/WIN7/WIN10) və ya None."""
    slot = slot_from_env(env)
    return WIN_TYPE_BY_SLOT.get(slot) if slot is not None else None


def atminfo_collector_dir(win_type):
    """
    Windows növünə uyğun collector qovluğunu qaytarır:
      C:\\eco_xp, C:\\eco_win7, C:\\eco_win10 — yoxdursa köhnə C:\\eco-ya düşür.
    """
    sub = WIN_COLLECTOR_SUBDIR.get(str(win_type or "").upper())
    if sub:
        cand = os.path.join(os.path.dirname(ATMINFO_SRC_DIR.rstrip("\\/")), sub)
        if os.path.isdir(cand):
            return cand
    return ATMINFO_SRC_DIR


def atm_db_win_info(atm):
    """DB-dən ATM-in password_env və windows_type dəyərlərini oxuyur."""
    try:
        con = db_connect()
        row = con.execute(
            "SELECT password_env, windows_type FROM atms WHERE atm_id=? COLLATE NOCASE",
            (str(atm or "").strip(),)).fetchone()
        con.close()
    except Exception:
        return None, None
    if not row:
        return None, None
    return row[0], row[1]


def add_restart_log(message):
    line = datetime.now().strftime("%H:%M:%S") + "  " + message

    with RESTART_LOCK:
        RESTART_STATE["logs"].append(line)

        if len(RESTART_STATE["logs"]) > 300:
            RESTART_STATE["logs"] = RESTART_STATE["logs"][-300:]


def set_restart_state(**kwargs):
    with RESTART_LOCK:
        RESTART_STATE.update(kwargs)


def run_hidden(args, timeout=20):
    """
    Windows command-u CMD pəncərəsi açmadan işlədir.
    """
    return subprocess.run(
        args,
        capture_output=True,
        text=True,
        errors="replace",
        timeout=timeout,
        creationflags=CREATE_NO_WINDOW
    )


def clean_output(value, max_len=700):
    value = (value or "").replace("\r", "").strip()

    if len(value) > max_len:
        value = value[-max_len:]

    return value


def extract_windows_error_code(output):
    """
    NET USE çıxışından mümkün Windows/System error kodunu çıxarır.
    """
    if not output:
        return None

    # Ən çox rast gəlinən kodlar.
    known = [
        1326, 1219, 1909, 86, 67, 64,
        53, 51, 5, 121, 1231
    ]

    for code in known:
        if re.search(rf"(?<!\d){code}(?!\d)", output):
            return code

    m = re.search(r"(?<!\d)(\d{2,5})(?!\d)", output)

    if m:
        try:
            return int(m.group(1))
        except Exception:
            pass

    return None


def friendly_error(code, raw=""):
    mapping = {
        1326: "User adı və ya şifrə uyğun deyil.",
        86: "Şifrə düzgün deyil.",
        1909: "Administrator hesabı kilidlənib.",
        5: "Access Denied.",
        53: "Network path tapılmadı / ATM əlçatan deyil.",
        67: "Network name tapılmadı.",
        64: "Network bağlantısı artıq mövcud deyil.",
        51: "Remote kompüter əlçatan deyil.",
        121: "Əməliyyat timeout oldu.",
        1219: (
            "ATM-ə başqa credential ilə aktiv Windows network sessiyası var "
            "(error 1219)."
        ),
        1231: "Network location-a çatmaq mümkün deyil."
    }

    if code in mapping:
        return mapping[code]

    raw = clean_output(raw)

    if raw:
        return raw

    return "Windows əməliyyatı uğursuz oldu."


def delete_old_connection(atm):
    """
    R kodundakı:
        net use \\ATM /delete
    əməliyyatının Python qarşılığıdır.
    """
    try:
        run_hidden(
            [
                "net",
                "use",
                rf"\\{atm}",
                "/delete",
                "/y"
            ],
            timeout=8
        )
    except Exception:
        pass


def try_password(atm, password, label):
    """
    R kodundakı:
        net use \\ATM /user:administrator password
    məntiqinin Python qarşılığıdır.
    """
    set_restart_state(
        current_action=f"{label} ilə net use yoxlanılır...",
        attempt_elapsed=0
    )

    started = time.monotonic()

    try:
        process = subprocess.Popen(
            [
                "net",
                "use",
                rf"\\{atm}",
                "/user:administrator",
                password
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            errors="replace",
            creationflags=CREATE_NO_WINDOW
        )

        last_log_second = 0

        while True:
            rc = process.poll()
            elapsed = int(time.monotonic() - started)

            set_restart_state(
                attempt_elapsed=elapsed,
                current_action=f"{label} yoxlanılır... ({elapsed} saniyə)"
            )

            if elapsed >= 5 and elapsed - last_log_second >= 5:
                add_restart_log(
                    f"{label}: Windows cavabı gözlənilir... ({elapsed} saniyə)"
                )
                last_log_second = elapsed

            if rc is not None:
                stdout, stderr = process.communicate()

                output = clean_output(
                    (stdout or "") + "\n" + (stderr or "")
                )

                code = extract_windows_error_code(output)

                return rc == 0, rc, code, output

            if elapsed >= 20:
                try:
                    process.kill()
                except Exception:
                    pass

                try:
                    stdout, stderr = process.communicate(timeout=2)
                except Exception:
                    stdout, stderr = "", ""

                return (
                    False,
                    -1,
                    121,
                    "NET USE 20 saniyə ərzində cavab vermədi."
                )

            time.sleep(1)

    except Exception as e:
        return False, -1, None, str(e)


def check_c_share(atm):
    """
    R kodundakı:
        file.exists("\\\\ATM\\C$")
    məntiqinə uyğun C$ share yoxlaması.
    """
    c_path = rf"\\{atm}\C$"

    set_restart_state(
        current_action=f"C$ yoxlanılır: {c_path}"
    )

    add_restart_log(
        f"C$ access yoxlanılır: {c_path}"
    )

    try:
        return os.path.exists(c_path)
    except Exception:
        return False


def send_shutdown(atm):
    """
    R kodundakı:
        shutdown /r /m \\ATM /t 10 /f
    əməliyyatının Python qarşılığı.
    """
    args = [
        "shutdown",
        "/r",
        "/m",
        rf"\\{atm}",
        "/t",
        "10",
        "/f"
    ]

    try:
        return run_hidden(args, timeout=20)

    except subprocess.TimeoutExpired:
        return None


def restart_worker(target):
    try:
        passwords = get_restart_passwords()

        if not passwords:
            raise RuntimeError(
                "PASSWORD1-PASSWORD20 environment dəyişənlərindən heç biri tapılmadı."
            )

        username = "administrator"

        set_restart_state(
            username=username,
            current_action="Köhnə network sessiyası silinir..."
        )

        add_restart_log(f"ATM: {target}")
        add_restart_log("User: administrator")
        add_restart_log(f"{len(passwords)} PASSWORD slotu tapıldı.")
        add_restart_log("Köhnə network connection silinir...")

        # R kodundakı kimi əvvəl mövcud connection silinir.
        delete_old_connection(target)

        add_restart_log("Credential yoxlaması başladı.")

        connected = False
        matched_slot = None

        for attempt_no, (slot, password) in enumerate(passwords, start=1):
            label = f"PASSWORD{slot}"

            set_restart_state(
                attempt=attempt_no,
                attempt_label=label,
                attempt_elapsed=0,
                current_action=f"{label} yoxlanılır...",
                last_error_code=None
            )

            add_restart_log("")
            add_restart_log(
                f"{label} yoxlanılır... ({attempt_no}/{len(passwords)})"
            )

            ok, return_code, windows_code, raw_output = try_password(
                target,
                password,
                label
            )

            if ok:
                connected = True
                matched_slot = slot

                set_restart_state(
                    matched_password_slot=slot,
                    last_error_code=0,
                    network_ok=True,
                    current_action=f"{label} UYĞUNDUR."
                )

                add_restart_log(
                    f"{label} UYĞUNDUR."
                )

                break

            set_restart_state(
                last_error_code=windows_code,
                current_action=(
                    f"{label} alınmadı. Növbəti şifrəyə keçir..."
                )
            )

            reason = friendly_error(
                windows_code,
                raw_output
            )

            code_text = (
                f" [kod {windows_code}]"
                if windows_code is not None
                else ""
            )

            add_restart_log(
                f"{label} ALINMADI{code_text}: {reason}"
            )

            add_restart_log(
                "Növbəti PASSWORD slotuna keçir..."
            )

        if not connected:
            set_restart_state(network_ok=False)

            raise RuntimeError(
                "PASSWORD1-PASSWORD20 arasında uyğun administrator şifrəsi tapılmadı."
            )

        # R kodundakı file.exists(\\ATM\C$) yoxlaması.
        if not check_c_share(target):
            raise RuntimeError(
                rf"Credential qəbul edildi, amma \\{target}\C$ açılmır."
            )

        add_restart_log("C$ access UĞURLUDUR.")

        set_restart_state(
            current_action=(
                f"Credential PASSWORD{matched_slot} uyğundur. "
                "Restart əmri göndərilir..."
            )
        )

        add_restart_log(
            f"{target} üçün restart əmri göndərilir..."
        )

        result = send_shutdown(target)

        if result is None:
            raise RuntimeError(
                "shutdown komandası 20 saniyə ərzində cavab vermədi."
            )

        output = clean_output(
            (result.stdout or "") + "\n" + (result.stderr or "")
        )

        windows_code = extract_windows_error_code(output)

        if result.returncode != 0:
            reason = friendly_error(
                windows_code,
                output
            )

            raise RuntimeError(
                "Restart əmri alınmadı"
                + (
                    f" [kod {windows_code}]"
                    if windows_code is not None
                    else ""
                )
                + ": "
                + reason
            )

        set_restart_state(
            running=False,
            finished=True,
            success=True,
            current_action="Restart əmri uğurla göndərildi.",
            finished_at=datetime.now().isoformat(timespec="seconds")
        )
        atm_activity_finish(RESTART_STATE.get("activity_id"), target, True,
                            f"Restart əmri qəbul edildi · PASSWORD{matched_slot}")

        add_restart_log(
            f"UĞURLU: {target} restart əmri qəbul etdi."
        )

        add_restart_log(
            f"İstifadə olunan credential slotu: PASSWORD{matched_slot}."
        )

    except Exception as e:
        set_restart_state(
            running=False,
            finished=True,
            success=False,
            current_action="Restart alınmadı.",
            error=str(e),
            finished_at=datetime.now().isoformat(timespec="seconds")
        )

        atm_activity_finish(RESTART_STATE.get("activity_id"), target, False, str(e))
        add_restart_log("")
        add_restart_log("NƏTİCƏ: RESTART UĞURSUZ.")
        add_restart_log("SƏBƏB: " + str(e))


def start_restart(target):
    target = (target or "").strip()

    if not ATM_ID_PATTERN.fullmatch(target):
        return False, (
            "ATM ID düzgün deyil. "
            "Yalnız hərf, rəqəm, nöqtə, tire və alt-xətt istifadə et."
        )

    with RESTART_LOCK:
        if RESTART_STATE["running"]:
            return False, (
                "Hazırda başqa ATM üçün restart prosesi gedir."
            )

        now_iso = datetime.now().isoformat(timespec="seconds")
        now_text = datetime.now().strftime("%H:%M:%S")

        activity_id = atm_activity_start(target, "RESTART", "ATM Restart", "restart")
        RESTART_STATE.update({
            "activity_id": activity_id,
            "running": True,
            "finished": False,
            "success": False,
            "target": target,
            "attempt": 0,
            "attempt_label": "",
            "attempt_elapsed": 0,
            "current_action": "Restart prosesi başladılır...",
            "started_at": now_iso,
            "finished_at": None,
            "logs": [
                f"{now_text}  Restart sorğusu qəbul edildi.",
                f"{now_text}  ATM: {target}",
                f"{now_text}  User: administrator",
                f"{now_text}  PASSWORD1-PASSWORD20 ardıcıllıqla yoxlanacaq."
            ],
            "error": None,
            "matched_password_slot": None,
            "username": "administrator",
            "network_ok": None,
            "last_error_code": None
        })

    threading.Thread(
        target=restart_worker,
        args=(target,),
        daemon=True
    ).start()

    return True, None


def restart_config_info():
    passwords = get_restart_passwords()

    return {
        "configured_slots": [
            f"PASSWORD{i}"
            for i, _ in passwords
        ],
        "configured_count": len(passwords),
        "method": "NET USE + Windows shutdown",
        "username": "administrator"
    }



# ============================================================
# VIDEO ARCHIVE MODULE - NET USE + READ ONLY
#
# ATM ID HTML-dən gəlir.
# PASSWORD1-PASSWORD7 administrator user-i ilə ardıcıllıqla yoxlanılır.
# Uğurlu credential tapıldıqdan sonra yalnız bu path OXUNUR:
#     \\ATM\D$\VIDEOARCHIVE\ATM_ID
#
# Heç bir fayl silinmir/dəyişdirilmir.
# VIDEOARCHIVE\ATM_ID daxilində YYYYMMDD formatlı tarix folderləri axtarılır.
# Ən böyük/son tarix folderi seçilir.
# Həmin tarix folderində ən son şəkil və ən son video ayrıca tapılır.
# ============================================================

ARCHIVE_LOCK = threading.Lock()
ARCHIVE_STATE = {
    "running": False,
    "finished": False,
    "success": False,
    "target": "",
    "username": "administrator",
    "attempt": 0,
    "attempt_label": "",
    "current_action": "",
    "current_path": "",
    "started_at": None,
    "finished_at": None,
    "logs": [],
    "error": None,
    "matched_password_slot": None,
    "result": None
}

ARCHIVE_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".gif", ".webp"}
ARCHIVE_VIDEO_EXTENSIONS = {
    ".mp4", ".avi", ".mkv", ".mov", ".wmv", ".mpg", ".mpeg",
    ".m4v", ".3gp", ".webm", ".ts", ".mts", ".m2ts"
}


def add_archive_log(message):
    line = datetime.now().strftime("%H:%M:%S") + "  " + message

    with ARCHIVE_LOCK:
        ARCHIVE_STATE["logs"].append(line)

        if len(ARCHIVE_STATE["logs"]) > 300:
            ARCHIVE_STATE["logs"] = ARCHIVE_STATE["logs"][-300:]


def set_archive_state(**kwargs):
    with ARCHIVE_LOCK:
        ARCHIVE_STATE.update(kwargs)


def archive_try_password(atm, password, label):
    """
    Restart modulundakı işlək NET USE məntiqinin eynisidir.
    Şifrənin özü loga çıxmır.
    """
    set_archive_state(
        current_action=f"{label} yoxlanılır...",
        current_path=rf"\\{atm}"
    )

    delete_old_connection(atm)

    try:
        result = run_hidden(
            [
                "net",
                "use",
                rf"\\{atm}",
                "/user:administrator",
                password
            ],
            timeout=20
        )

        output = clean_output(
            (result.stdout or "") + "\n" + (result.stderr or "")
        )

        code = extract_windows_error_code(output)

        return result.returncode == 0, code, output

    except subprocess.TimeoutExpired:
        return False, 121, "NET USE 20 saniyə ərzində cavab vermədi."

    except Exception as e:
        return False, None, str(e)


def format_bytes(size):
    try:
        size = int(size)
    except Exception:
        return "-"

    units = ["B", "KB", "MB", "GB", "TB"]
    value = float(size)
    index = 0

    while value >= 1024 and index < len(units) - 1:
        value /= 1024.0
        index += 1

    if index == 0:
        return f"{int(value)} {units[index]}"

    return f"{value:.2f} {units[index]}"


def archive_file_info(path, stat):
    return {
        "name": os.path.basename(path),
        "path": path,
        "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%d.%m.%Y %H:%M:%S"),
        "modified_raw": stat.st_mtime,
        "size": stat.st_size,
        "size_display": format_bytes(stat.st_size)
    }


def scan_latest_archive_folder(atm):
    r"""
    Path strukturu:
        \\ATM_ID\D$\VIDEOARCHIVE\ATM_ID\YYYYMMDD\...

    VIDEOARCHIVE\ATM_ID daxilində yalnız YYYYMMDD formatında olan
    tarix folderləri nəzərə alınır. Ən son tarix folderi folder adındakı
    tarixə görə seçilir (LastWriteTime-a görə yox).

    Seçilmiş tarix folderinin daxilində (alt folderlər daxil olmaqla)
    ən son şəkil və ən son video LastWriteTime-a görə ayrıca tapılır.
    """
    archive_root = rf"\\{atm}\D$\VIDEOARCHIVE"
    atm_archive_path = os.path.join(archive_root, atm)

    set_archive_state(
        current_path=atm_archive_path,
        current_action="ATM VIDEOARCHIVE path yoxlanılır..."
    )

    add_archive_log(f"VIDEOARCHIVE root: {archive_root}")
    add_archive_log(f"ATM archive path: {atm_archive_path}")

    if not os.path.isdir(atm_archive_path):
        raise RuntimeError(
            f"ATM VIDEOARCHIVE folderi tapılmadı və ya access yoxdur: "
            f"{atm_archive_path}"
        )

    date_folders = []

    try:
        with os.scandir(atm_archive_path) as entries:
            for entry in entries:
                try:
                    if not entry.is_dir():
                        continue

                    # Scan modulundakı kimi YYYYMMDD tarix folderi.
                    if not re.fullmatch(r"\d{8}", entry.name):
                        continue

                    try:
                        folder_date = datetime.strptime(
                            entry.name,
                            "%Y%m%d"
                        ).date()
                    except ValueError:
                        # 20261399 kimi 8 rəqəm olsa belə düzgün tarix deyil.
                        continue

                    stat = entry.stat()

                    date_folders.append({
                        "name": entry.name,
                        "path": entry.path,
                        "date": folder_date,
                        "date_iso": folder_date.isoformat(),
                        "modified_raw": stat.st_mtime,
                        "modified": datetime.fromtimestamp(
                            stat.st_mtime
                        ).strftime("%d.%m.%Y %H:%M:%S")
                    })

                except Exception as e:
                    add_archive_log(
                        f"Folder oxunmadı: {entry.name} -> {e}"
                    )

    except Exception as e:
        raise RuntimeError(
            f"ATM VIDEOARCHIVE folder siyahısı oxunmadı: {e}"
        )

    if not date_folders:
        raise RuntimeError(
            f"{atm_archive_path} daxilində YYYYMMDD formatında "
            "heç bir tarix folderi tapılmadı."
        )

    # ƏSAS DƏYİŞİKLİK:
    # Folder LastWriteTime ilə yox, folder adındakı TARİX ilə seçilir.
    latest_folder = max(
        date_folders,
        key=lambda x: x["date"]
    )

    add_archive_log(
        "Son tarix folderi: "
        f"{latest_folder['name']} "
        f"({latest_folder['date'].strftime('%d.%m.%Y')})"
    )

    set_archive_state(
        current_path=latest_folder["path"],
        current_action=(
            "Son tarix folderində ən son şəkil və video axtarılır..."
        )
    )

    latest_image = None
    latest_video = None
    image_count = 0
    video_count = 0
    file_count = 0

    try:
        for walk_root, dirs, files in os.walk(latest_folder["path"]):
            set_archive_state(
                current_path=walk_root,
                current_action=(
                    "Fayllar oxunur... "
                    f"Şəkil: {image_count} | Video: {video_count}"
                )
            )

            for filename in files:
                full_path = os.path.join(walk_root, filename)
                ext = os.path.splitext(filename)[1].lower()
                file_count += 1

                if (
                    ext not in ARCHIVE_IMAGE_EXTENSIONS
                    and ext not in ARCHIVE_VIDEO_EXTENSIONS
                ):
                    continue

                try:
                    stat = os.stat(full_path)
                except Exception as e:
                    add_archive_log(
                        f"Fayl oxunmadı: {filename} -> {e}"
                    )
                    continue

                info = archive_file_info(full_path, stat)

                if ext in ARCHIVE_IMAGE_EXTENSIONS:
                    image_count += 1

                    if (
                        latest_image is None
                        or info["modified_raw"]
                        > latest_image["modified_raw"]
                    ):
                        latest_image = info

                elif ext in ARCHIVE_VIDEO_EXTENSIONS:
                    video_count += 1

                    if (
                        latest_video is None
                        or info["modified_raw"]
                        > latest_video["modified_raw"]
                    ):
                        latest_video = info

    except Exception as e:
        raise RuntimeError(
            f"Son tarix folderinin faylları oxunmadı: {e}"
        )

    latest_folder_public = dict(latest_folder)
    latest_folder_public["date"] = latest_folder_public["date"].isoformat()

    return {
        "archive_path": archive_root,
        "atm_archive_path": atm_archive_path,
        "folder_count": len(date_folders),
        "latest_folder": latest_folder_public,
        "file_count": file_count,
        "image_count": image_count,
        "video_count": video_count,
        "latest_image": latest_image,
        "latest_video": latest_video
    }


def archive_worker(target):
    try:
        passwords = get_restart_passwords()

        if not passwords:
            raise RuntimeError(
                "PASSWORD1-PASSWORD20 environment dəyişənlərindən heç biri tapılmadı."
            )

        add_archive_log(f"ATM: {target}")
        add_archive_log("User: administrator")
        add_archive_log(f"{len(passwords)} PASSWORD slotu tapıldı.")
        add_archive_log("Köhnə network connection silinir...")

        set_archive_state(
            current_path=rf"\\{target}",
            current_action="ATM əlçatanlığı yoxlanılır (TCP 445, maksimum 5 saniyə)..."
        )
        try:
            with socket.create_connection((target, 445), timeout=5):
                pass
        except OSError as network_error:
            raise RuntimeError(
                f"ATM {target} üçün SMB/TCP 445 bağlantısı alınmadı: {network_error}"
            ) from network_error
        add_archive_log("TCP 445 bağlantısı mövcuddur.")

        delete_old_connection(target)

        connected = False
        matched_slot = None

        for attempt_no, (slot, password) in enumerate(passwords, start=1):
            label = f"PASSWORD{slot}"

            set_archive_state(
                attempt=attempt_no,
                attempt_label=label,
                current_action=f"{label} yoxlanılır..."
            )

            add_archive_log("")
            add_archive_log(
                f"{label} yoxlanılır... ({attempt_no}/{len(passwords)})"
            )

            ok, windows_code, raw_output = archive_try_password(
                target,
                password,
                label
            )

            if ok:
                connected = True
                matched_slot = slot

                set_archive_state(
                    matched_password_slot=slot,
                    current_action=f"{label} UYĞUNDUR. D$ yoxlanılır..."
                )

                add_archive_log(f"{label} UYĞUNDUR.")
                break

            reason = friendly_error(windows_code, raw_output)
            code_text = (
                f" [kod {windows_code}]"
                if windows_code is not None
                else ""
            )

            add_archive_log(
                f"{label} ALINMADI{code_text}: {reason}"
            )
            add_archive_log("Növbəti PASSWORD slotuna keçir...")

        if not connected:
            raise RuntimeError(
                "PASSWORD1-PASSWORD20 arasında uyğun administrator şifrəsi tapılmadı."
            )

        # Bağlantı uğurla quruldu. Bahalı/uzun VIDEOARCHIVE scan-i burada
        # ETMİRİK: browser dərhal açılır, son tarix ayrıca endpoint-də oxunur.
        # Beləliklə ATM-in faylları çox olanda Qoşul düyməsi ilişmir.
        set_archive_state(
            running=False,
            finished=True,
            success=True,
            current_action="Qoşuldu. Qovluqlara baxmaq olar.",
            current_path=rf"\\{target}\D$",
            result=None,
            finished_at=datetime.now().isoformat(timespec="seconds")
        )
        atm_activity_finish(ARCHIVE_STATE.get("activity_id"), target, True,
                            f"Video Archive qoşulması uğurlu · PASSWORD{matched_slot}")
        add_archive_log("Qoşulma uğurlu oldu. D$ naviqatoru və son tarix analizi ayrı açılır.")

    except Exception as e:
        set_archive_state(
            running=False,
            finished=True,
            success=False,
            current_action="VIDEOARCHIVE yoxlaması uğursuz oldu.",
            error=str(e),
            finished_at=datetime.now().isoformat(timespec="seconds")
        )

        atm_activity_finish(ARCHIVE_STATE.get("activity_id"), target, False, str(e))
        add_archive_log("")
        add_archive_log("NƏTİCƏ: UĞURSUZ.")
        add_archive_log("SƏBƏB: " + str(e))

    finally:
        # Preview və folder gəzmək üçün autentifikasiya olunmuş SMB sessiyası qalır.
        # Növbəti ATM seçildikdə əvvəlki bağlantı yenidən qurulacaq.
        pass


def start_archive_scan(target):
    target = (target or "").strip()

    if not ATM_ID_PATTERN.fullmatch(target):
        return False, (
            "ATM ID düzgün deyil. "
            "Yalnız hərf, rəqəm, nöqtə, tire və alt-xətt istifadə et."
        )

    with ARCHIVE_LOCK:
        if ARCHIVE_STATE["running"]:
            return False, "Hazırda başqa VIDEOARCHIVE yoxlaması gedir."

        now_iso = datetime.now().isoformat(timespec="seconds")
        now_text = datetime.now().strftime("%H:%M:%S")

        activity_id = atm_activity_start(target, "VIDEO_ARCHIVE", "Video Archive", "archive")
        ARCHIVE_STATE.update({
            "activity_id": activity_id,
            "running": True,
            "finished": False,
            "success": False,
            "target": target,
            "username": "administrator",
            "attempt": 0,
            "attempt_label": "",
            "current_action": "VIDEOARCHIVE yoxlaması başladılır...",
            "current_path": rf"\\{target}\D$\VIDEOARCHIVE\{target}",
            "started_at": now_iso,
            "finished_at": None,
            "logs": [
                f"{now_text}  VIDEOARCHIVE sorğusu qəbul edildi.",
                f"{now_text}  ATM: {target}",
                f"{now_text}  User: administrator",
                f"{now_text}  Hədəf: \\\\{target}\\D$\\VIDEOARCHIVE\\{target}"
            ],
            "error": None,
            "matched_password_slot": None,
            "result": None
        })

    threading.Thread(
        target=archive_worker,
        args=(target,),
        daemon=True
    ).start()

    return True, None


def archive_config_info():
    passwords = get_restart_passwords()

    return {
        "configured_slots": [
            f"PASSWORD{i}"
            for i, _ in passwords
        ],
        "configured_count": len(passwords),
        "username": "administrator",
        "path_template": r"\\<ATM_ID>\D$\VIDEOARCHIVE\<ATM_ID>",
        "method": "NET USE + read-only UNC scan"
    }


# ============================================================
# ATM FILE EXPLORER - yalnız seçilmiş ATM, yalnız D$ və C$\JOURNAL
# ============================================================

EXPLORER_TEXT_EXTS = {".txt", ".jrn", ".log", ".csv"}
EXPLORER_VIEW_EXTS = (ARCHIVE_IMAGE_EXTENSIONS | ARCHIVE_VIDEO_EXTENSIONS |
                      EXPLORER_TEXT_EXTS)
EXPLORER_DATE_FILE = re.compile(r"^(\d{8})(?:\.[^.]+)?$", re.I)
EXPLORER_MAX_ENTRIES = 10000


def explorer_session():
    with ARCHIVE_LOCK:
        if not ARCHIVE_STATE["success"] or ARCHIVE_STATE["running"]:
            raise PermissionError("Əvvəl Video Archive-də ATM ID yazıb Qoşul düyməsini bas.")
        atm = ARCHIVE_STATE["target"]
    if not ATM_ID_PATTERN.fullmatch(atm):
        raise PermissionError("ATM ID düzgün deyil.")
    return atm


def explorer_is_inside(path, base):
    r"""UNC share kökündə ntpath.commonpath ValueError verə bilir.

    Windows UNC share (\\ATM\D$) ilə onun alt yolu
    (\\ATM\D$\VIDEOARCHIVE) fərqli ntpath absolute statusuna malikdir.
    Buna görə commonpath deyil, sərhədli prefix yoxlaması tətbiq edilir.
    """
    base_normal = ntpath.normcase(ntpath.normpath(base)).rstrip("\\")
    path_normal = ntpath.normcase(ntpath.normpath(path)).rstrip("\\")
    return path_normal == base_normal or path_normal.startswith(base_normal + "\\")


def explorer_path(root, rel=""):
    if isinstance(root, str) and root.lower().startswith("srv:"):
        # Video / Şəkil Server: \\<DB_IP>\<disk>$\<DB_FOLDER>\<ATM_ID> (ATM-ə qoşulma lazım deyil)
        atm, base = srvmedia_base(root)
    elif isinstance(root, str) and root.lower().startswith("srvdisk:"):
        # Server diski (bütöv): srvdisk:<HERF> -> \\<SERVER_IP>\<HERF>$  (ATM session lazım deyil)
        letter = root.split(":", 1)[1].strip().upper()
        if not re.fullmatch(r"[A-Z]", letter):
            raise ValueError("Disk hərfi düzgün deyil.")
        atm = "SERVER"
        base = rf"\\{srvexp_server_ip()}\{letter}$"
    else:
        atm = explorer_session()
        base = None
    if base is not None:
        pass
    elif root == "d":
        base = rf"\\{atm}\D$"
    elif root == "journal":
        base = rf"\\{atm}\C$\JOURNAL"
    elif isinstance(root, str) and root.lower().startswith("disk:"):
        # disk:<HERF> -> \\ATM\<HERF>$  (DB-dəki disklər üçün: D, H, E ...)
        letter = root.split(":", 1)[1].strip().upper()
        if not re.fullmatch(r"[A-Z]", letter):
            raise ValueError("Disk hərfi düzgün deyil.")
        base = rf"\\{atm}\{letter}$"
    else:
        raise ValueError("Yalnız mövcud disklər və C$ JOURNAL oxuna bilər.")
    if not isinstance(rel, str) or len(rel) > 2000 or "\x00" in rel:
        raise ValueError("Folder yolu düzgün deyil.")
    rel = rel.replace("/", "\\")
    if (rel.startswith("\\") or ":" in rel or
            any(part in ("..", ".") for part in rel.split("\\"))):
        raise ValueError("Folder kökündən kənara keçmək olmaz.")
    path = ntpath.normpath(ntpath.join(base, rel))
    if not explorer_is_inside(path, base):
        raise ValueError("Folder kökündən kənara keçmək olmaz.")
    # Junction və symlink vasitəsilə kənara çıxmağın qarşısı alınır.
    # Realpath müxtəlif Windows UNC formalara çevrilə bilər: hər ikisini
    # eyni qaydada normalizasiya edib müqayisə edirik.
    realbase = os.path.realpath(base)
    realpath = os.path.realpath(path)
    if not explorer_is_inside(realpath, realbase):
        raise ValueError("Qovluq əsas disk sərhədindən kənara yönləndirilir.")
    return atm, base, path


def explorer_entry(entry, parent_rel=""):
    stat = entry.stat(follow_symlinks=False)
    kind = "folder" if entry.is_dir(follow_symlinks=False) else "file"
    ext = ntpath.splitext(entry.name)[1].lower()
    rel = entry.name if not parent_rel else parent_rel.rstrip("\\/") + "\\" + entry.name
    return {
        "name": entry.name, "rel": rel, "kind": kind,
        "ext": ext, "previewable": kind == "file" and ext in EXPLORER_VIEW_EXTS,
        "size": None if kind == "folder" else stat.st_size,
        "size_display": "—" if kind == "folder" else format_bytes(stat.st_size),
        "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%d.%m.%Y %H:%M:%S")
    }


def explorer_list(root, rel=""):
    atm, base, path = explorer_path(root, rel)
    if not os.path.isdir(path):
        raise FileNotFoundError("Qovluq yoxdur və ya giriş icazəsi yoxdur: " + path)
    entries = []
    with os.scandir(path) as it:
        for entry in it:
            if entry.is_symlink():
                continue
            try:
                entries.append(explorer_entry(entry, rel))
            except OSError:
                continue
            if len(entries) >= EXPLORER_MAX_ENTRIES:
                break
    entries.sort(key=lambda e: (e["kind"] != "folder", e["name"].casefold()))
    return {"success": True, "atm": atm, "root": root, "rel": rel,
            "path": path, "entries": entries, "truncated": len(entries) >= EXPLORER_MAX_ENTRIES,
            "folder_count": sum(e["kind"] == "folder" for e in entries),
            "file_count": sum(e["kind"] == "file" for e in entries)}


def explorer_latest_journal():
    atm, base, path = explorer_path("journal")
    if not os.path.isdir(path):
        raise FileNotFoundError("ATM-də C$\\JOURNAL qovluğu yoxdur və ya giriş bağlıdır: " + path)
    found = []
    with os.scandir(path) as it:
        for entry in it:
            if not entry.is_file(follow_symlinks=False):
                continue
            ext = ntpath.splitext(entry.name)[1].lower()
            if ext not in {".jrn", ".txt"}:
                continue
            m = EXPLORER_DATE_FILE.fullmatch(entry.name)
            if not m:
                continue
            try:
                d = datetime.strptime(m.group(1), "%Y%m%d").date()
                info = explorer_entry(entry)
                info["date"] = d.isoformat()
                found.append(info)
            except (ValueError, OSError):
                continue
    found.sort(key=lambda f: (f["date"], f["name"].casefold()), reverse=True)
    return {"success": True, "atm": atm, "path": path,
            "count": len(found), "latest": found[0] if found else None,
            "note": "Son jurnal faylın adındakı YYYYMMDD tarixə əsasən seçilir; Date Modified seçimə təsir etmir."}


def explorer_latest_folder_files():
    atm = explorer_session()
    _, base, atm_path = explorer_path("d", ntpath.join("VIDEOARCHIVE", atm))
    if not os.path.isdir(atm_path):
        raise FileNotFoundError("VIDEOARCHIVE/ATM ID qovluğu tapılmadı: " + atm_path)
    candidates = []
    with os.scandir(atm_path) as it:
        for entry in it:
            try:
                if not entry.is_dir(follow_symlinks=False):
                    continue
                if not re.fullmatch(r"\d{8}", entry.name):
                    continue
                folder_date = datetime.strptime(entry.name, "%Y%m%d").date()
                candidates.append((folder_date, entry.name))
            except (ValueError, OSError):
                continue
    if not candidates:
        raise FileNotFoundError("VIDEOARCHIVE/ATM ID altında YYYYMMDD tarix folderi yoxdur.")
    latest = max(candidates, key=lambda item: item[0])[1]
    rel = ntpath.join("VIDEOARCHIVE", atm, latest)
    _, base, path = explorer_path("d", rel)
    if not os.path.isdir(path):
        raise FileNotFoundError("Son tarix folderi açılmadı: " + path)
    files = []
    folders = 0
    errors = 0
    for walk_root, dirs, filenames in os.walk(path, followlinks=False):
        dirs[:] = [d for d in dirs if not os.path.islink(os.path.join(walk_root, d))]
        folders += len(dirs)
        for filename in filenames:
            if len(files) >= EXPLORER_MAX_ENTRIES:
                break
            full = os.path.join(walk_root, filename)
            try:
                if os.path.islink(full):
                    continue
                relative = ntpath.relpath(full, base)
                info = explorer_entry(type("FileEntry", (), {
                    "name": filename,
                    "stat": lambda self, follow_symlinks=False: os.stat(full),
                    "is_dir": lambda self, follow_symlinks=False: False
                })(), ntpath.dirname(relative) if ntpath.dirname(relative) != "." else "")
                files.append(info)
            except (OSError, ValueError):
                errors += 1
        if len(files) >= EXPLORER_MAX_ENTRIES:
            break
    files.sort(key=lambda e: e["rel"].casefold())
    return {"success": True, "atm": atm, "path": path, "rel": rel,
            "date_folder": latest, "files": files, "folder_count": folders,
            "truncated": len(files) >= EXPLORER_MAX_ENTRIES, "errors": errors}


def explorer_preview_file(root, rel):
    atm, base, path = explorer_path(root, rel)
    extension = ntpath.splitext(path)[1].lower()
    if extension not in EXPLORER_VIEW_EXTS:
        raise ValueError("Bu fayl formatı web-də önizləmə üçün dəstəklənmir.")
    if not os.path.isfile(path):
        raise FileNotFoundError("Fayl tapılmadı: " + path)
    return path, extension

# ============================================================
# VIDEO / ŞƏKİL SERVER — backup serverindəki (DB: config_ips/disks/folders)
# ATM qovluqlarını yoxlama və gəzmə. Yalnız oxuma. ATM-ə qoşulma lazım deyil:
#   \\<DB_IP>\<disk>$\<DB_FOLDER>\<ATM_ID>\YYYYMMDD\fayllar
# ============================================================

SRVMEDIA_SIMILAR_LIMIT = 12
SRVMEDIA_STATS_MAX_FILES = 50000
SRVMEDIA_LAST_MEDIA_LOOKBACK = 15   # boş folderlərdən geri neçə tarixə baxılsın


def srvmedia_sources():
    """DB-dəki MEDIA (JPG/video) mənbələri. Jurnal (TXT) mənbələri daxil deyil."""
    with SCAN_LOCK:
        paths = dict(SCAN_SOURCES)
        labels = dict(SCAN_LABELS)
        kinds = dict(SOURCE_KINDS)
    out = []
    for src, path in paths.items():
        if not path or is_journal_source(src) or kinds.get(src) == "TXT":
            continue
        out.append({"src": src, "label": labels.get(src, src), "path": path})
    out.sort(key=lambda x: (x["src"] not in ("D", "H"), x["src"]))
    return out


def srvmedia_source_path(src):
    for s in srvmedia_sources():
        if s["src"] == src:
            return s["path"], s["label"]
    raise ValueError("Mənbə tapılmadı və ya media mənbəyi deyil: " + str(src))


def srvmedia_clean_atm(atm):
    atm = str(atm or "").strip()
    if not ATM_ID_PATTERN.fullmatch(atm) or atm in (".", ".."):
        raise ValueError("ATM nömrəsi düzgün deyil.")
    return atm


def srvmedia_base(root):
    """root = 'srv:<MƏNBƏ>:<ATM_ID>' -> (atm, \\\\IP\\disk$\\FOLDER\\ATM_ID)"""
    parts = str(root).split(":", 2)
    if len(parts) != 3:
        raise ValueError("Server kökü düzgün deyil.")
    src = parts[1].strip().upper()
    atm = srvmedia_clean_atm(parts[2])
    source_path, _ = srvmedia_source_path(src)
    return atm, ntpath.join(source_path, atm)


def srvmedia_folder_stats(folder_path):
    """Qovluğun içində (alt qovluqlar daxil) şəkil/video/digər fayl sayı."""
    st = {"images": 0, "videos": 0, "txt": 0, "other": 0, "total": 0, "bytes": 0,
          "first_time": None, "last_time": None, "truncated": False, "errors": 0}
    files_seen = 0

    def onerr(_err):
        st["errors"] += 1

    for walk_root, dirs, files in os.walk(folder_path, onerror=onerr, followlinks=False):
        for name in files:
            files_seen += 1
            if files_seen > SRVMEDIA_STATS_MAX_FILES:
                st["truncated"] = True
                break
            ext = ntpath.splitext(name)[1].lower()
            if ext in ARCHIVE_IMAGE_EXTENSIONS:
                st["images"] += 1
            elif ext in ARCHIVE_VIDEO_EXTENSIONS or ext in VIDEO_EXTENSIONS:
                st["videos"] += 1
            elif ext in EXPLORER_TEXT_EXTS:
                st["txt"] += 1
            else:
                st["other"] += 1
            try:
                info = os.stat(os.path.join(walk_root, name))
                st["bytes"] += info.st_size
                m = info.st_mtime
                if st["first_time"] is None or m < st["first_time"]:
                    st["first_time"] = m
                if st["last_time"] is None or m > st["last_time"]:
                    st["last_time"] = m
            except OSError:
                st["errors"] += 1
        if st["truncated"]:
            break
    st["total"] = st["images"] + st["videos"] + st["txt"] + st["other"]
    st["media"] = st["images"] + st["videos"]
    st["size_display"] = format_bytes(st["bytes"])
    st["first_display"] = datetime_display(st["first_time"])
    st["last_display"] = datetime_display(st["last_time"])
    return st


def srvmedia_check_one(src, label, source_path, atm, want_date):
    atm_path = ntpath.join(source_path, atm)
    res = {"src": src, "label": label, "root_path": source_path, "atm_path": atm_path,
           "root_ok": False, "atm_exists": False, "atm_folder_name": atm, "error": "",
           "dates": [], "date_count": 0, "other_folders": [], "loose_files": 0,
           "latest": None, "latest_stats": None, "selected": None, "similar": []}
    try:
        res["root_ok"] = os.path.isdir(source_path)
        if not res["root_ok"]:
            res["error"] = "Server qovluğu açılmadı (şəbəkə / icazə): " + source_path
            return res
        if not os.path.isdir(atm_path):
            # Oxşar ATM qovluqlarını təklif et
            needle = atm.casefold()
            similar = []
            try:
                with os.scandir(source_path) as it:
                    for e in it:
                        try:
                            if e.is_dir() and needle in e.name.casefold():
                                similar.append(e.name)
                        except OSError:
                            continue
            except OSError:
                pass
            similar.sort(key=lambda n: (len(n), n.casefold()))
            res["similar"] = similar[:SRVMEDIA_SIMILAR_LIMIT]
            return res
        res["atm_exists"] = True
        dates, others, loose = [], [], 0
        with os.scandir(atm_path) as it:
            for e in it:
                try:
                    if e.is_dir(follow_symlinks=False):
                        d = parse_date_folder(e.name)
                        if d is not None:
                            dates.append((d, e.name))
                        else:
                            others.append(e.name)
                    else:
                        loose += 1
                except OSError:
                    continue
        dates.sort(key=lambda x: x[0], reverse=True)
        res["dates"] = [{"name": n, "date": d.isoformat(), "display": date_display(d)} for d, n in dates]
        res["date_count"] = len(dates)
        res["other_folders"] = sorted(others, key=str.casefold)[:200]
        res["loose_files"] = loose
        if dates:
            latest_name = dates[0][1]
            res["latest"] = res["dates"][0]
            res["latest_stats"] = srvmedia_folder_stats(ntpath.join(atm_path, latest_name))
            res["latest_delay_days"] = (date.today() - dates[0][0]).days
            # Ən son folder boşdursa (məs. bugünkü hələ yazılır) şəkil/video olan son tarixi tap
            res["last_media"] = None
            for idx, (d, n) in enumerate(dates[:SRVMEDIA_LAST_MEDIA_LOOKBACK]):
                st = res["latest_stats"] if idx == 0 else srvmedia_folder_stats(ntpath.join(atm_path, n))
                if st["media"] > 0:
                    res["last_media"] = {"name": n, "date": d.isoformat(), "display": date_display(d),
                                         "delay_days": (date.today() - d).days, "stats": st}
                    break
        if want_date:
            name = want_date.strftime("%Y%m%d")
            sel = {"name": name, "date": want_date.isoformat(), "display": date_display(want_date),
                   "exists": any(n == name for _, n in dates), "stats": None}
            if sel["exists"]:
                sel["stats"] = (res["latest_stats"] if res["latest"] and res["latest"]["name"] == name
                                else srvmedia_folder_stats(ntpath.join(atm_path, name)))
            res["selected"] = sel
    except OSError as exc:
        res["error"] = str(exc)
    return res


def srvmedia_check(atm, date_text=""):
    atm = srvmedia_clean_atm(atm)
    want_date = None
    if date_text:
        try:
            want_date = datetime.strptime(date_text.replace("-", ""), "%Y%m%d").date()
        except ValueError:
            raise ValueError("Tarix düzgün deyil (YYYY-MM-DD).")
    sources = srvmedia_sources()
    if not sources:
        raise ValueError("DB-də media mənbəyi (IP / disk / folder) təyin edilməyib.")
    started = time.time()
    with ThreadPoolExecutor(max_workers=max(1, len(sources))) as ex:
        futures = [ex.submit(srvmedia_check_one, s["src"], s["label"], s["path"], atm, want_date)
                   for s in sources]
        results = [f.result() for f in futures]
    found = [r for r in results if r["atm_exists"]]
    return {"success": True, "atm": atm, "date": want_date.isoformat() if want_date else "",
            "sources": results, "found_in": [r["src"] for r in found],
            "any_found": bool(found), "duration": round(time.time() - started, 2)}


def srvmedia_stats(src, atm, folder):
    atm = srvmedia_clean_atm(atm)
    _, base, path = explorer_path("srv:" + str(src) + ":" + atm, folder or "")
    if not os.path.isdir(path):
        raise FileNotFoundError("Qovluq tapılmadı: " + path)
    return {"success": True, "src": src, "atm": atm, "folder": folder, "path": path,
            "stats": srvmedia_folder_stats(path)}


# ============================================================
# ATM SYSTEM MONITOR - WMI, read-only; original scan and explorer intact
# Windows PowerShell 5.1 Get-WmiObject supports older Win7/Win10 ATMs.
# Credentials are read from inherited PASSWORD1..PASSWORD7 environment vars.
# Passwords are NEVER part of command-line parameters, output, or history.
# ============================================================

SYSTEM_LOCK = threading.Lock()
SYSTEM_BACKEND_VERSION = "WMI135-DIAG-v3"

def new_system_diagnostics():
    return {
        "tcp135": "YOXLANMAYIB", "tcp135_detail": "",
        "credential": "YOXLANMAYIB", "credential_detail": "",
        "wmi": "YOXLANMAYIB", "wmi_detail": "",
        "smb": "YOXLANMAYIB", "smb_detail": "",
        "psexec": "YOXLANMAYIB", "psexec_detail": "",
        "final": "YOXLANILIR", "final_detail": ""
    }

SYSTEM_STATE = {
    "running": False, "finished": False, "success": False,
    "target": "", "started_at": None, "finished_at": None,
    "current_action": "ATM ID gözlənilir", "attempt_label": "",
    "elapsed_seconds": 0, "logs": [], "error": None, "metrics": None,
    "matched_password_slot": None, "warnings": [],
    "backend_version": SYSTEM_BACKEND_VERSION,
    "diagnostics": new_system_diagnostics()
}

# Son uğurlu credential slotunu yalnız proses yaddaşında saxlayırıq; şifrə saxlanılmır.
SYSTEM_SLOT_CACHE = {}

# PowerShell script has no password literals. Target and password slot are
# provided by the environment of a Windows PowerShell child process.
SYSTEM_WMI_PS = r"""
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$atm = $env:ATM_MONITOR_TARGET
$slot = $env:ATM_MONITOR_SLOT
$mode = $env:ATM_MONITOR_MODE
$user = $env:ATM_MONITOR_USER
$pass = [Environment]::GetEnvironmentVariable($slot, 'Process')
function EmitJson([object]$value) { Write-Output ($value | ConvertTo-Json -Compress -Depth 10) }
function SafeArray($value) { if ($null -eq $value) { return @() }; return @($value | ForEach-Object { [string]$_ }) }
try {
    if ([string]::IsNullOrWhiteSpace($pass)) { throw 'Environment password mövcud deyil.' }
    if ([string]::IsNullOrWhiteSpace($user)) { $user = 'Administrator' }
    $secure = ConvertTo-SecureString -String $pass -AsPlainText -Force
    $cred = New-Object System.Management.Automation.PSCredential ($user, $secure)
    $os = Get-WmiObject -ComputerName $atm -Credential $cred -Class Win32_OperatingSystem -ErrorAction Stop | Select-Object -First 1
    if (-not $os) { throw 'Win32_OperatingSystem məlumatı alınmadı.' }
    if ($mode -eq 'probe') { EmitJson @{ ok = $true; computer_name = [string]$os.CSName }; exit 0 }

    $warnings = @(); $cpus = @(); $disks = @(); $cs = $null; $bios = $null; $netConfigs = @()
    try { $cpus = @(Get-WmiObject -ComputerName $atm -Credential $cred -Class Win32_Processor -ErrorAction Stop) } catch { $warnings += ('CPU məlumatı alınmadı: ' + $_.Exception.Message) }
    try { $disks = @(Get-WmiObject -ComputerName $atm -Credential $cred -Class Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction Stop) } catch { $warnings += ('Disk məlumatı alınmadı: ' + $_.Exception.Message) }
    try { $cs = Get-WmiObject -ComputerName $atm -Credential $cred -Class Win32_ComputerSystem -ErrorAction Stop | Select-Object -First 1 } catch { $warnings += ('ComputerSystem məlumatı alınmadı: ' + $_.Exception.Message) }
    try { $bios = Get-WmiObject -ComputerName $atm -Credential $cred -Class Win32_BIOS -ErrorAction Stop | Select-Object -First 1 } catch { $warnings += ('BIOS məlumatı alınmadı: ' + $_.Exception.Message) }
    try { $netConfigs = @(Get-WmiObject -ComputerName $atm -Credential $cred -Class Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True' -ErrorAction Stop) } catch { $warnings += ('Network adapter məlumatı alınmadı: ' + $_.Exception.Message) }

    $cpuLoad = $null; $cpuName = ''; $coreCount = 0; $logicalCount = 0
    if ($cpus.Count -gt 0) {
        $loads = @($cpus | Where-Object { $null -ne $_.LoadPercentage } | ForEach-Object { [double]$_.LoadPercentage })
        if ($loads.Count -gt 0) { $cpuLoad = [math]::Round(($loads | Measure-Object -Average).Average, 1) }
        $cpuName = [string]$cpus[0].Name
        $coreCount = [int](($cpus | Measure-Object -Property NumberOfCores -Sum).Sum)
        $logicalCount = [int](($cpus | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum)
    }

    $totalRam = [double]$os.TotalVisibleMemorySize * 1024.0
    $freeRam = [double]$os.FreePhysicalMemory * 1024.0
    $usedRam = [math]::Max(0, $totalRam - $freeRam)
    $ramPercent = $null
    if ($totalRam -gt 0) { $ramPercent = [math]::Round(100.0 * $usedRam / $totalRam, 1) }

    $diskList = @()
    foreach ($d in $disks) {
        $size = [double]$d.Size; $free = [double]$d.FreeSpace; $used = [math]::Max(0.0, $size - $free)
        $percent = $null; if ($size -gt 0) { $percent = [math]::Round(100.0 * $used / $size, 1) }
        $diskList += @{ name=[string]$d.DeviceID; label=[string]$d.VolumeName; filesystem=[string]$d.FileSystem; total_bytes=[math]::Round($size); used_bytes=[math]::Round($used); free_bytes=[math]::Round($free); used_percent=$percent }
    }

    $networkList = @(); $primaryIp = ''
    foreach ($n in $netConfigs) {
        $ips = @(SafeArray $n.IPAddress); $subnets = @(SafeArray $n.IPSubnet); $gateways = @(SafeArray $n.DefaultIPGateway); $dns = @(SafeArray $n.DNSServerSearchOrder)
        $ipv4 = @($ips | Where-Object { $_ -match '^\d{1,3}(\.\d{1,3}){3}$' }); $ipv6 = @($ips | Where-Object { $_ -like '*:*' })
        if (-not $primaryIp) { foreach ($candidate in $ipv4) { if ($candidate -ne '127.0.0.1' -and -not $candidate.StartsWith('169.254.')) { $primaryIp=[string]$candidate; break } } }
        $connectionName = ''
        try { $idx=[int]$n.Index; $adapter=Get-WmiObject -ComputerName $atm -Credential $cred -Class Win32_NetworkAdapter -Filter ("Index="+$idx) -ErrorAction Stop | Select-Object -First 1; if($adapter){$connectionName=[string]$adapter.NetConnectionID} } catch { }
        $networkList += @{ name=$connectionName; description=[string]$n.Description; mac_address=[string]$n.MACAddress; ip_addresses=@($ips); ipv4=@($ipv4); ipv6=@($ipv6); subnets=@($subnets); gateways=@($gateways); dns_servers=@($dns); dns_domain=[string]$n.DNSDomain; dhcp_enabled=[bool]$n.DHCPEnabled; dhcp_server=[string]$n.DHCPServer }
    }

    $bootText=''; $uptimeSeconds=$null
    try { $boot=[System.Management.ManagementDateTimeConverter]::ToDateTime([string]$os.LastBootUpTime); $bootText=$boot.ToString('yyyy-MM-dd HH:mm:ss'); $uptimeSeconds=[math]::Round(((Get-Date)-$boot).TotalSeconds) } catch { }

    EmitJson @{
        ok=$true; collection_method='WMI/RPC (TCP 135)'; partial=$false
        computer_name=[string]$os.CSName; hostname=[string]$os.CSName
        manufacturer=if($cs){[string]$cs.Manufacturer}else{''}; model=if($cs){[string]$cs.Model}else{''}; system_type=if($cs){[string]$cs.SystemType}else{''}
        domain=if($cs){[string]$cs.Domain}else{''}; part_of_domain=if($cs){[bool]$cs.PartOfDomain}else{$false}; logged_on_user=if($cs){[string]$cs.UserName}else{''}
        bios_serial=if($bios){[string]$bios.SerialNumber}else{''}; bios_version=if($bios){[string]$bios.SMBIOSBIOSVersion}else{''}
        os_name=[string]$os.Caption; os_version=[string]$os.Version; os_build=[string]$os.BuildNumber; os_architecture=[string]$os.OSArchitecture; service_pack=[string]$os.CSDVersion
        last_boot=$bootText; uptime_seconds=$uptimeSeconds
        cpu_name=$cpuName; cpu_percent=$cpuLoad; cpu_cores=$coreCount; cpu_logical=$logicalCount
        ram_total_bytes=[math]::Round($totalRam); ram_used_bytes=[math]::Round($usedRam); ram_free_bytes=[math]::Round($freeRam); ram_percent=$ramPercent
        disk_count=@($diskList).Count; disks=@($diskList); disk_source='WMI/RPC (TCP 135)'
        primary_ip=$primaryIp; network_adapter_count=@($networkList).Count; network_adapters=@($networkList); warnings=@($warnings)
    }
    exit 0
} catch { EmitJson @{ ok=$false; error=[string]$_.Exception.Message }; exit 2 }
"""


def system_update(**values):
    with SYSTEM_LOCK:
        SYSTEM_STATE.update(values)


def system_diag(**values):
    """Sistem monitorunun bütün qoşulma səbəblərini bir diaqnostika obyektində saxla."""
    safe = {}
    for key, value in values.items():
        if key.endswith("_detail"):
            safe[key] = system_clean_error(value) if value else ""
        else:
            safe[key] = value
    with SYSTEM_LOCK:
        diag = dict(SYSTEM_STATE.get("diagnostics") or new_system_diagnostics())
        diag.update(safe)
        SYSTEM_STATE["diagnostics"] = diag


def system_log(message):
    line = datetime.now().strftime("%H:%M:%S") + "  " + str(message)
    with SYSTEM_LOCK:
        SYSTEM_STATE["logs"].append(line)
        SYSTEM_STATE["logs"] = SYSTEM_STATE["logs"][-150:]


def system_clean_error(error):
    """Do not reveal any environment password in PowerShell diagnostics."""
    message = str(error or "Naməlum WMI xətası")
    for _, password in get_restart_passwords():
        if len(password) >= 3:
            message = message.replace(password, "[REDACTED]")
    return message[:700]


def system_wmi_call(atm, slot, mode, timeout=24, username="Administrator"):
    """WMI/DCOM sorğusu. Şifrə command-line-a yazılmır, child env-dən oxunur."""
    import base64
    import subprocess
    env = os.environ.copy()
    env.update({
        "ATM_MONITOR_TARGET": atm,
        "ATM_MONITOR_SLOT": "PASSWORD" + str(slot),
        "ATM_MONITOR_MODE": mode,
        "ATM_MONITOR_USER": username or "Administrator"
    })
    encoded = base64.b64encode(SYSTEM_WMI_PS.encode("utf-16le")).decode("ascii")
    command = ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
               "-EncodedCommand", encoded]
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        proc = subprocess.run(command, env=env, capture_output=True, text=True,
                              encoding="utf-8", errors="replace", timeout=timeout,
                              creationflags=flags, shell=False)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"WMI sorğusu {timeout} saniyədə cavab vermədi (timeout)."}
    except FileNotFoundError:
        return {"ok": False, "error": "Windows PowerShell (powershell.exe) tapılmadı."}
    except Exception as exc:
        return {"ok": False, "error": system_clean_error(exc)}

    # The script writes one JSON object as its only stdout payload.
    stdout = (proc.stdout or "").strip()
    if not stdout:
        return {"ok": False, "error": system_clean_error(proc.stderr or f"PowerShell exit code {proc.returncode}")}
    try:
        answer = json.loads(stdout)
        if isinstance(answer, dict):
            if not answer.get("ok"):
                answer["error"] = system_clean_error(answer.get("error"))
            return answer
    except (ValueError, TypeError):
        pass
    return {"ok": False, "error": "PowerShell JSON cavabı oxunmadı: " + system_clean_error(stdout[-300:])}


# Windows SMB disk ölçüsü: WMI/RPC (135) lazım deyil; \ATM\C$ kimi paylaşımdan ölçülür.
# Yalnız C/D/E/F/H hərflərinə baxmaq mümkündür: SMB bütün diskləri sadalamaq üçün API vermir.
# WMI işləyəndə proqram əvvəlki qaydada bütün lokal sabit diskləri görür.
SYSTEM_SMB_DRIVES = ("C", "D", "E", "F", "H")
SYSTEM_DISK_PROBE_SCRIPT = r"""
import ctypes
import json
import sys
from ctypes import wintypes
path = sys.argv[1]
free_available = ctypes.c_ulonglong()
size = ctypes.c_ulonglong()
free = ctypes.c_ulonglong()
fn = ctypes.WinDLL("kernel32", use_last_error=True).GetDiskFreeSpaceExW
fn.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_ulonglong),
               ctypes.POINTER(ctypes.c_ulonglong), ctypes.POINTER(ctypes.c_ulonglong)]
fn.restype = wintypes.BOOL
try:
    if not fn(path, ctypes.byref(free_available), ctypes.byref(size), ctypes.byref(free)):
        raise ctypes.WinError(ctypes.get_last_error())
    print(json.dumps({"ok": True, "total": size.value, "free": free.value}))
except OSError as exc:
    print(json.dumps({"ok": False, "error_code": getattr(exc, "winerror", None),
                      "error": str(exc)}))
"""


def system_smb_disk(atm, drive, timeout=7):
    """GetDiskFreeSpaceExW(\\ATM\\C$\\) isolated by child process timeout."""
    share = "\\\\" + atm + "\\" + drive + "$\\"
    try:
        proc = subprocess.run(
            [sys.executable, "-c", SYSTEM_DISK_PROBE_SCRIPT, share],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=timeout, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        answer = json.loads((proc.stdout or "").strip())
        if not answer.get("ok"):
            return None, system_clean_error(answer.get("error") or "Share oxunmadı")
        total = int(answer["total"])
        free = min(total, int(answer["free"]))
        if total <= 0:
            return None, "Disk ölçüsü oxunmadı"
        used = total-free
        return {
            "name": drive + ":", "label": "", "filesystem": "",
            "total_bytes": total, "used_bytes": used, "free_bytes": free,
            "used_percent": round(used * 100 / total, 1),
        }, None
    except subprocess.TimeoutExpired:
        return None, f"{drive}: üçün {timeout} saniyədə SMB cavabı alınmadı"
    except Exception as exc:
        return None, system_clean_error(exc)


def system_tcp_probe(host, port=135, timeout=4):
    """Şəbəkə ACL/firewall baxımından TCP portun açıq olub-olmadığını ayrıca göstər."""
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            return True, None
    except OSError as exc:
        return False, system_clean_error(exc)


def system_resolve_target(atm):
    ip = ""
    short_name = ""
    try:
        ip = socket.gethostbyname(atm)
    except Exception:
        pass
    if ip:
        try:
            host = socket.gethostbyaddr(ip)[0]
            short_name = str(host).split(".")[0].strip()
        except Exception:
            pass
    return ip, short_name


def system_wmi_user_candidates(atm, ip="", reverse_name=""):
    """ATM ID DNS alias olsa belə lokal Administrator üçün bir neçə təhlükəsiz user forması."""
    values = ["Administrator"]
    if atm and not re.fullmatch(r"\d{1,3}(?:\.\d{1,3}){3}", atm):
        values.append(atm + r"\Administrator")
    if reverse_name and reverse_name.casefold() != str(atm).casefold():
        values.append(reverse_name + r"\Administrator")
    result = []
    seen = set()
    for value in values:
        key = value.casefold()
        if key not in seen:
            seen.add(key); result.append(value)
    return result


def system_discover_password_slot(atm):
    """Credential slotunu ayrıca müəyyən et.

    Sistem məlumatı SMB ilə OXUNMUR. Yalnız PASSWORD slotunun hansı olduğunu tapmaq
    üçün IPC$ autentifikasiya testi edilir. ATM adı üzrə mövcud SMB sessiyasına toxunmamaq
    üçün mümkün olduqda ayrıca IP aliasından istifadə olunur.
    """
    passwords = get_restart_passwords()
    if not passwords:
        return None, None, None, "PASSWORD environment dəyişənləri yoxdur."
    ip, _reverse = system_resolve_target(atm)
    alias = ip or atm
    share = r"\\" + alias + r"\IPC$"

    # Eyni IP aliasına bu moduldan qalmış köhnə IPC$ sessiyası varsa təmizlə.
    try:
        subprocess.run(["net", "use", share, "/delete", "/y"], capture_output=True,
                       text=True, errors="replace", timeout=5,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception:
        pass

    cached = SYSTEM_SLOT_CACHE.get(atm.casefold())
    ordered = list(passwords)
    if cached is not None:
        ordered.sort(key=lambda pair: 0 if pair[0] == cached else 1)

    last_error = "Credential slotu müəyyən edilmədi."
    for attempt_no, (slot, password) in enumerate(ordered, 1):
        label = f"PASSWORD{slot}"
        system_update(attempt_label=label,
                      current_action=f"Credential seçimi: {label} yoxlanılır ({attempt_no}/{len(ordered)})...")
        system_log(f"Credential seçimi (IPC$): {label} yoxlanılır...")
        try:
            cp = subprocess.run(
                ["net", "use", share, "/user:administrator", password],
                capture_output=True, text=True, errors="replace", timeout=10,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
            )
        except subprocess.TimeoutExpired:
            last_error = "IPC$ credential testi timeout oldu."
            system_log(last_error)
            break
        except Exception as exc:
            last_error = system_clean_error(exc)
            system_log("IPC$ credential xətası: " + last_error)
            break

        output = (cp.stdout or "") + "\n" + (cp.stderr or "")
        if cp.returncode == 0:
            SYSTEM_SLOT_CACHE[atm.casefold()] = slot
            system_log(f"Credential slotu tapıldı: {label}. IPC$ yalnız credential seçimi üçün istifadə olundu.")
            try:
                subprocess.run(["net", "use", share, "/delete", "/y"], capture_output=True,
                               text=True, errors="replace", timeout=5,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except Exception:
                pass
            return slot, password, alias, None

        code = extract_windows_error_code(output)
        last_error = system_clean_error(friendly_error(code, output))
        system_log(f"Credential {label} alınmadı" + (f" (Windows kodu {code})" if code is not None else "") + ": " + last_error)
        if code in (53, 67, 64, 51, 121, 1231, 1909):
            break
        if code == 1219:
            # IP aliası da artıq istifadədədirsə onu dağıtmırıq.
            break

    return None, None, alias, last_error


def system_smb_connect(atm):
    """Existing video-archive/restart user credentials; never log real password."""
    passwords = get_restart_passwords()
    if not passwords:
        return False, None, "PASSWORD1-PASSWORD20 environment dəyişənləri yoxdur."
    last_error = "SMB bağlantısı alınmadı."
    for i, (slot, password) in enumerate(passwords, 1):
        name = "PASSWORD" + str(slot)
        system_update(attempt_label=name, current_action=f"Disklər üçün SMB: {name} yoxlanılır ({i}/{len(passwords)})")
        system_log(f"SMB C$ giriş: {name} yoxlanılır...")
        try:
            # Əvvəlki işləyən R/net use yanaşması. Bu əmrin stdout-u və parol UI-ya çıxarılmır.
            proc = subprocess.run(
                ["net", "use", "\\\\"+atm+"\\C$", "/user:administrator", password],
                capture_output=True, text=True, errors="replace", timeout=12,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
            )
        except subprocess.TimeoutExpired:
            last_error = "SMB giriş timeout (12 saniyə)."
            system_log(last_error)
            break
        except Exception as exc:
            last_error = system_clean_error(exc)
            system_log("SMB xətası: " + last_error)
            break
        if proc.returncode == 0:
            system_log(f"SMB giriş uğurludur: {name}.")
            return True, slot, None
        output = (proc.stdout or "") + "\n" + (proc.stderr or "")
        code = extract_windows_error_code(output)
        last_error = friendly_error(code, output)
        last_error = system_clean_error(last_error)
        system_log(f"SMB {name} alınmadı" + (f" (Windows kodu {code})" if code is not None else "") + ": " + last_error)
        if code == 1219:
            # Eyni ATM-ə başqa moduldan açıq sessiyanı SİLMƏ. Mövcud bağlantını sına.
            disk, err = system_smb_disk(atm, "C", timeout=5)
            if disk:
                system_log("Mövcud SMB sessiyası ilə C: oxundu; sessiya saxlanılır.")
                return True, None, None
            return False, None, last_error + "; mövcud SMB sessiyası C$ oxumağa icazə vermədi."
        if code in (53, 67, 64, 51, 121, 1231, 1909):
            # şəbəkə və lockout xətası başqa parolla düzəlməz.
            break
    return False, None, last_error


def system_smb_fallback(atm, wmi_error):
    """RPC bağlı olanda diskləri C$/D$ üzərindən oxu, CPU/RAM-ı uydurma."""
    system_update(current_action="WMI alınmadı, disklər SMB (445) ilə oxunur...")
    system_log("WMI/RPC alınmadı. Diskləri WMI-siz SMB üzərindən oxumağa cəhd edilir...")
    system_log("C:, D: və digər ehtimal edilən disklər ayrıca yoxlanılır.")
    ok, slot, connection_error = system_smb_connect(atm)
    if not ok:
        return None, ("WMI/RPC: " + wmi_error + " | SMB: " + str(connection_error))
    drives = []
    for drive in SYSTEM_SMB_DRIVES:
        system_update(current_action=f"SMB: {drive}: diskinin tutumu oxunur...")
        disk, error = system_smb_disk(atm, drive)
        if disk:
            drives.append(disk)
            system_log(f"{drive}: — ümumi {disk['total_bytes']/1073741824:.2f} GB; dolu {disk['used_percent']}%")
        else:
            system_log(f"{drive}: oxunmadı / mövcud deyil: {error}")
    if not drives:
        return None, "WMI/RPC: " + wmi_error + " | SMB ilə disk ölçüləri də oxunmadı (paylaşım/firewall/icazə yoxlanılmalıdır)."
    return {
        "computer_name": atm, "os_name": "WMI bağlantısı yoxdur", "os_version": "",
        "cpu_name": "", "cpu_percent": None, "cpu_cores": None, "cpu_logical": None,
        "ram_total_bytes": None, "ram_used_bytes": None, "ram_free_bytes": None,
        "ram_percent": None, "disk_count": len(drives), "disks": drives,
        "disk_source": "SMB (445)", "partial": True,
        "disk_scope": "C:, D:, E:, F:, H: yoxlanılıb. WMI olmadığından digər disklər görünməyə bilər."
    }, slot


# CPU/RAM/disk ATM-nin ÖZÜNDƏ oxunur. Server -> ATM yalnız SMB/PsExec (445).
# Bu modul remote DCOM/WMI (TCP 135) istifadə etmir.
SYSTEM_LOCAL_PS = r"""
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
try {
    $os = Get-WmiObject -Class Win32_OperatingSystem -ErrorAction Stop | Select-Object -First 1
    $processors = @(Get-WmiObject -Class Win32_Processor -ErrorAction Stop)
    $localDisks = @(Get-WmiObject -Class Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction Stop)
    $cpuLoad = $null
    $cpuName = ''
    $cores = 0
    $logical = 0
    if ($processors.Count -gt 0) {
        $loads = @($processors | Where-Object { $null -ne $_.LoadPercentage } |
            ForEach-Object { [double]$_.LoadPercentage })
        if ($loads.Count -gt 0) {
            $cpuLoad = [math]::Round(($loads | Measure-Object -Average).Average, 1)
        }
        $cpuName = [string]$processors[0].Name
        $cores = [int](($processors | Measure-Object -Property NumberOfCores -Sum).Sum)
        $logical = [int](($processors | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum)
    }
    $ramTotal = [double]$os.TotalVisibleMemorySize * 1024.0
    $ramFree = [double]$os.FreePhysicalMemory * 1024.0
    $ramUsed = [math]::Max(0.0, $ramTotal - $ramFree)
    $ramPercent = $null
    if ($ramTotal -gt 0) { $ramPercent = [math]::Round(100.0 * $ramUsed / $ramTotal, 1) }
    $resultDisks = @()
    foreach ($disk in $localDisks) {
        $size = [double]$disk.Size
        $free = [double]$disk.FreeSpace
        $used = [math]::Max(0.0, $size - $free)
        $percent = $null
        if ($size -gt 0) { $percent = [math]::Round(100.0 * $used / $size, 1) }
        $resultDisks += @{
            name = [string]$disk.DeviceID
            label = [string]$disk.VolumeName
            filesystem = [string]$disk.FileSystem
            total_bytes = [long]$size
            used_bytes = [long]$used
            free_bytes = [long]$free
            used_percent = $percent
        }
    }
    $result = @{
        ok = $true
        computer_name = [string]$os.CSName
        os_name = [string]$os.Caption
        os_version = [string]$os.Version
        cpu_name = $cpuName
        cpu_percent = $cpuLoad
        cpu_cores = $cores
        cpu_logical = $logical
        ram_total_bytes = [long]$ramTotal
        ram_used_bytes = [long]$ramUsed
        ram_free_bytes = [long]$ramFree
        ram_percent = $ramPercent
        disk_count = $resultDisks.Count
        disks = @($resultDisks)
        disk_source = 'PsExec / ATM lokal WMI (445)'
        partial = $false
        warnings = @()
    }
    Write-Output '__ATM_METRICS_BEGIN__'
    Write-Output ($result | ConvertTo-Json -Compress -Depth 8)
    Write-Output '__ATM_METRICS_END__'
    exit 0
} catch {
    Write-Output '__ATM_METRICS_BEGIN__'
    Write-Output (@{ ok = $false; error = [string]$_.Exception.Message } | ConvertTo-Json -Compress)
    Write-Output '__ATM_METRICS_END__'
    exit 2
}
"""


def system_find_ffmpeg():
    """ffmpeg.exe-ni server qovluğunda və ya PATH-də tapır (AVI->MP4 transcode üçün)."""
    cand = os.environ.get("ATM_FFMPEG")
    if cand and os.path.isfile(cand):
        return cand
    for name in ("ffmpeg.exe", "ffmpeg"):
        local = os.path.join(BASE_DIR, name)
        if os.path.isfile(local):
            return local
        ext = shutil.which(name)
        if ext:
            return ext
    return None


# Brauzerin HTML5 <video> ilə birbaşa oynatdığı formatlar (transcode LAZIM DEYİL)
BROWSER_NATIVE_VIDEO = {".mp4", ".m4v", ".webm", ".ogg", ".ogv"}


def system_find_psexec(names=('PsExec64.exe', 'PsExec.exe')):
    for name in names:
        local = os.path.join(BASE_DIR, name)
        if os.path.isfile(local):
            return local
        external = shutil.which(name)
        if external:
            return external
    return None


def system_find_psexec_for_win(win_type):
    """
    Windows növünə görə düzgün PsExec seçir:
      XP / WIN7  -> PsExec.exe (32-bit) üstün; yoxdursa PsExec64.exe.
      WIN10 / bilinməyən -> PsExec64.exe üstün; yoxdursa PsExec.exe.
    32-bit maşında 64-bit PSEXESVC başlamadığına görə (rc=6 "not compatible")
    köhnə ATM-lər üçün 32-bit PsExec.exe lazımdır. 32-bit PsExec hər iki
    arxitekturada işləyir, ona görə fallback təhlükəsizdir.
    """
    wt = str(win_type or "").upper()
    if wt == "WIN10":
        # Modern 64-bit ATM: 64-bit üstün, yoxdursa 32-bit.
        order = ('PsExec64.exe', 'PsExec.exe')
    else:
        # XP / Win7 / bilinməyən: 32-bit PsExec hər arxitekturada işlədiyi üçün üstün.
        order = ('PsExec.exe', 'PsExec64.exe')
    return system_find_psexec(order)


# ============================================================
# ATM INFO MODULE  (ATM ID -> 445 qosulma -> collect.bat -> atminfo.json -> oxu)
# Server ATM-e qosulur, C:\<SUBDIR>\collect.bat-i PsExec ile isledir, bat
# C:\<SUBDIR>\atminfo.json yaradir, server onu C$ uzerinden (445) oxuyur.
# ============================================================
# Collector fayllari SERVERDE bu qovluqda durur (ATM-e avtomatik kopyalanir):
ATMINFO_SRC_DIR = os.environ.get("ATM_INFO_SRC", r"C:\eco")
# ATM-de collector-in qoyulacagi qovluq (tam lokal yol, ATM-in ozunde):
ATMINFO_REMOTE_DIR = os.environ.get("ATM_INFO_REMOTE_DIR", r"C:\Users\Administrator\Documents\.default_80")
ATMINFO_FILE = (os.environ.get("ATM_INFO_FILE", "atminfo.json") or "atminfo.json").strip("\\/ ") or "atminfo.json"
ATMINFO_BAT_NAME = (os.environ.get("ATM_INFO_BAT_NAME", "collect.bat") or "collect.bat").strip("\\/ ") or "collect.bat"
ATMINFO_COPY_FILES = [f.strip() for f in (os.environ.get("ATM_INFO_FILES", "collect.bat,collect.ps1")).split(",") if f.strip()]


def _c_local_to_unc(target, local_path):
    # C:\Users\...  ->  \\<target>\C$\Users\...   (admin share)
    lp = local_path.strip()
    if len(lp) >= 2 and lp[1] == ":":
        drive, rest = lp[0], lp[2:]
        return r"\\%s\%s$%s" % (target, drive, rest)
    # artiq UNC-dirse oldugu kimi
    return lp


def _atminfo_net_use(target, password, connect=True):
    share = r"\\%s" % target
    try:
        if connect:
            return run_hidden(["net", "use", share, "/user:administrator", password], timeout=8)
        return run_hidden(["net", "use", share, "/delete", "/y"], timeout=6)
    except Exception:
        return None


def _atminfo_445(atm):
    """445 (SMB): ATM-e qosul, collect.bat-i isled, atminfo.json-u oxu. Sifre log/HTTP-ye cixmir."""
    import time as _time
    atm = str(atm or "").strip().upper()
    if not re.fullmatch(r"[A-Z0-9][A-Z0-9._-]{1,40}", atm):
        return {"success": False, "error": "ATM ID yanlisdir."}

    # SÜRƏT: tək ATM üçün bütün slotları spray etmirik. DB-dəki məlum
    # password_env birbaşa ilk sınanır (preferred) və qısa timeout verilir ki,
    # 445 qoşulması ~5-10 saniyəyə bitsin (əvvəlki ~57 san əvəzinə).
    db_env, db_win = atm_db_win_info(atm)
    slot, err = atm_inventory_probe_password(atm, preferred_env=db_env, password_timeout=6)
    if slot is None:
        return {"success": True, "online": False, "atm": atm,
                "error": "Qosulma alinmadi: " + str(err or "Uygun PASSWORD slotu tapilmadi.")}
    password = dict(get_restart_passwords()).get(slot)
    if not password:
        return {"success": True, "online": False, "atm": atm,
                "error": "PASSWORD%d slotu tapildi, amma deyeri oxunmadi." % slot}

    # Windows növü: DB-dəki əl ilə təyin olunmuş dəyər üstündür, yoxdursa slotdan çıxarılır.
    win_type = (db_win or "").upper() or windows_type_for_env("PASSWORD%d" % slot)
    src_dir = atminfo_collector_dir(win_type)

    # Windows novune gore 32/64-bit PsExec secilir (XP/Win7 -> 32-bit PsExec.exe).
    exe = system_find_psexec_for_win(win_type)
    if not exe:
        need = "PsExec.exe (32-bit)" if str(win_type).upper() in ("XP", "WIN7") else "PsExec64.exe"
        return {"success": False,
                "error": "PsExec tapilmadi. " + need + " server qovlugunda olmalidir."}

    target = atm
    remote_dir_unc = _c_local_to_unc(target, ATMINFO_REMOTE_DIR)   # \\ATM\C$\Users\...\.default_80
    unc = remote_dir_unc.rstrip("\\") + "\\" + ATMINFO_FILE
    remote_bat_local = ATMINFO_REMOTE_DIR.rstrip("\\") + "\\" + ATMINFO_BAT_NAME  # ATM-de gorunen yol
    started = _time.time()
    atm_inventory_clear_sessions(target)
    _atminfo_net_use(target, password, connect=True)
    try:
        # (a) ATM-de hedef qovlugu yoxla/yarat (.default_80 yoxdursa yaradilir)
        try:
            os.makedirs(remote_dir_unc, exist_ok=True)
        except OSError as exc:
            return {"success": True, "online": False, "atm": atm, "password_env": "PASSWORD%d" % slot,
                    "error": "ATM-de qovluq yaradilmadi (" + ATMINFO_REMOTE_DIR + "): " + system_clean_error(exc)}

        # (b) serverdeki collector (Windows novune uygun: eco_xp/eco_win7/eco_win10,
        #     yoxdursa C:\eco) faylllarini ATM-in .default_80 qovluguna kopyala
        missing_src = [f for f in ATMINFO_COPY_FILES
                       if not os.path.isfile(os.path.join(src_dir, f))]
        if missing_src:
            return {"success": False,
                    "error": "Serverde " + src_dir + " icinde fayl(lar) yoxdur: " + ", ".join(missing_src)}
        try:
            for f in ATMINFO_COPY_FILES:
                shutil.copyfile(os.path.join(src_dir, f), remote_dir_unc.rstrip("\\") + "\\" + f)
        except OSError as exc:
            return {"success": True, "online": False, "atm": atm, "password_env": "PASSWORD%d" % slot,
                    "error": "Collector fayllari ATM-e kopyalanmadi: " + system_clean_error(exc)}

        # (c) kohne json-u sil ki, yalniz teze nusxe oxunsun (saat ferqi problemi olmasin)
        try:
            os.remove(unc)
        except OSError:
            pass

        # (d) -s: bat ATM-de SYSTEM altinda islesin (istifadeci "logon type" huququ
        # catismasa da - error 1385 - isleyir). Auth yene -u/-p ile olur.
        # Kohne Windows (XP/Win7) PowerShell v2 + WMI yavas oldugu ucun timeout daha
        # uzun verilir ki, "70 saniyede bitmedi" yalanci timeout cixmasin.
        _wt = str(win_type or "").upper()
        try:
            run_timeout = int(os.environ.get("ATM_INFO_RUN_TIMEOUT", "0") or 0)
        except ValueError:
            run_timeout = 0
        if run_timeout <= 0:
            run_timeout = 180 if _wt in ("XP", "WIN7") else 90
        cmd = [exe, "-accepteula", "-nobanner", "-s", "-n", "15", r"\\%s" % target,
               "-u", "administrator", "-p", password, "cmd", "/c", remote_bat_local]
        run_rc, run_out = None, ""
        try:
            cp = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                                errors="replace", timeout=run_timeout,
                                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), shell=False)
            run_rc = cp.returncode
            run_out = (cp.stdout or "") + "\n" + (cp.stderr or "")
        except subprocess.TimeoutExpired:
            return {"success": True, "online": False, "atm": atm, "password_env": "PASSWORD%d" % slot,
                    "error": "collect.bat %d saniyede bitmedi (timeout). ATM cox yavasdir ve ya PowerShell/WMI cavab vermir." % run_timeout}
        except OSError as exc:
            return {"success": True, "online": False, "atm": atm, "password_env": "PASSWORD%d" % slot,
                    "error": "PsExec islemedi: " + system_clean_error(exc)}

        # json faylinin yaranmasini gozle, sonra oxu (kohne Windows ucun daha uzun)
        data, read_err = None, ""
        deadline = _time.time() + (30 if _wt in ("XP", "WIN7") else 15)
        while _time.time() < deadline:
            try:
                with open(unc, "rb") as fh:
                    raw = fh.read()
                data = json.loads(raw.decode("utf-8-sig", "replace"))
                break
            except FileNotFoundError:
                read_err = ("atminfo.json yaranmadi (" + remote_bat_local + " islemedi?). "
                            "Serverde " + ATMINFO_SRC_DIR + " duzgundurmu?")
            except (ValueError, TypeError) as exc:
                read_err = "atminfo.json oxundu, amma JSON formati yanlisdir: " + str(exc)
                break
            except OSError as exc:
                read_err = "Fayl oxunmadi (C$/445/icaze): " + system_clean_error(exc)
            _time.sleep(1.2)

        if data is None:
            msg = read_err or "atminfo.json oxunmadi."
            if run_rc not in (0, None):
                msg += " (PsExec rc=%s)" % run_rc
            tail = clean_output(run_out, 300)
            return {"success": True, "online": False, "atm": atm, "password_env": "PASSWORD%d" % slot,
                    "error": msg, "detail": tail}

        if isinstance(data, dict):
            data.setdefault("atm_id", atm)
        return {"success": True, "online": True, "atm": atm, "password_env": "PASSWORD%d" % slot,
                "windows_type": win_type, "collector": os.path.basename(src_dir),
                "latency_ms": int((_time.time() - started) * 1000), "data": data}
    finally:
        _atminfo_net_use(target, None, connect=False)
        atm_inventory_clear_sessions(target)


def _atminfo_135(atm):
    """135 (WMI/RPC): serverden ATM-e WMI/DCOM ile qosul, CPU/RAM/disk/OS oxu.
    445 probe etmir - yalniz 135 lazimdir. Sifre log/HTTP-ye cixmir."""
    import time as _time
    try:
        with socket.create_connection((atm, 135), timeout=3):
            pass
    except OSError as exc:
        return {"success": True, "online": False, "atm": atm,
                "error": "TCP 135 elcatan deyil (ATM oflayn ve ya RPC bagli): " + system_clean_error(exc)}
    passwords = get_restart_passwords()
    if not passwords:
        return {"success": True, "online": False, "atm": atm,
                "error": "PASSWORD environment deyisenleri tapilmadi."}
    started = _time.time()
    good, last_err = None, "Uygun PASSWORD slotu tapilmadi."
    for slot, _pw in passwords:
        res = system_wmi_call(atm, slot, "probe", timeout=14)
        if res.get("ok"):
            good = slot
            break
        last_err = res.get("error") or last_err
    if good is None:
        return {"success": True, "online": False, "atm": atm,
                "error": "WMI/RPC (135) qosulmasi alinmadi: " + system_clean_error(last_err)}
    res = system_wmi_call(atm, good, "full", timeout=35)
    if not res.get("ok"):
        return {"success": True, "online": False, "atm": atm, "password_env": "PASSWORD%d" % good,
                "error": "WMI melumati alinmadi: " + system_clean_error(res.get("error"))}
    data = {
        "status": "online",
        "collection_method": res.get("collection_method") or "WMI/RPC (TCP 135)",
        "collected_at": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "atm_id": atm,
        "hostname": res.get("hostname") or res.get("computer_name"),
        "os_name": res.get("os_name"), "os_version": res.get("os_version"),
        "os_build": res.get("os_build"), "os_architecture": res.get("os_architecture"),
        "cpu_name": res.get("cpu_name"), "cpu_percent": res.get("cpu_percent"),
        "cpu_cores": res.get("cpu_cores"),
        "ram_total_bytes": res.get("ram_total_bytes"), "ram_used_bytes": res.get("ram_used_bytes"),
        "ram_free_bytes": res.get("ram_free_bytes"), "ram_percent": res.get("ram_percent"),
        "uptime_seconds": res.get("uptime_seconds"), "boot_time": res.get("last_boot"),
        "disks": res.get("disks") or [],
    }
    return {"success": True, "online": True, "atm": atm, "password_env": "PASSWORD%d" % good,
            "latency_ms": int((_time.time() - started) * 1000), "data": data}


def _atminfo_save_snapshot(atm, method, result):
    """Qosulma neticesini atm_info_snapshots-a yazir ve atms kesini yenileyir."""
    try:
        d = result.get("data") if isinstance(result, dict) else None
        d = d if isinstance(d, dict) else {}
        online = 1 if result.get("online") else 0
        disks = d.get("disks") if isinstance(d.get("disks"), list) else []
        now = datetime.now().isoformat(timespec="seconds")
        con = db_connect()
        try:
            con.execute("""INSERT INTO atm_info_snapshots(atm_id,collected_at,method,password_env,online,
                cpu_percent,cpu_name,cpu_cores,ram_total_bytes,ram_used_bytes,ram_free_bytes,ram_percent,
                os_name,os_version,os_build,os_architecture,hostname,uptime_seconds,boot_time,
                disk_count,disks_json,raw_json,latency_ms,error)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
                atm, d.get("collected_at") or now, result.get("method") or method, result.get("password_env"), online,
                d.get("cpu_percent"), d.get("cpu_name"), d.get("cpu_cores"),
                d.get("ram_total_bytes"), d.get("ram_used_bytes"), d.get("ram_free_bytes"), d.get("ram_percent"),
                d.get("os_name"), d.get("os_version"), d.get("os_build"), d.get("os_architecture"),
                d.get("hostname"), d.get("uptime_seconds"), d.get("boot_time"),
                len(disks), json.dumps(disks, ensure_ascii=False), json.dumps(d, ensure_ascii=False)[:200000],
                result.get("latency_ms"), (None if online else str(result.get("error") or "")[:700])))
            con.execute("""UPDATE atms SET last_info_at=?, last_info_ok=?, last_info_method=?,
                last_cpu_percent=?, last_ram_percent=?, last_os_name=?, last_hostname=?, last_info_error=?
                WHERE atm_id=? COLLATE NOCASE""", (
                now, online, result.get("method") or method,
                d.get("cpu_percent"), d.get("ram_percent"), d.get("os_name"), d.get("hostname"),
                (None if online else str(result.get("error") or "")[:700]), atm))
            con.commit()
        finally:
            con.close()
    except Exception as exc:
        try:
            print("[atminfo] snapshot save error:", exc)
        except Exception:
            pass


def atminfo_history(atm, limit=50):
    atm = str(atm or "").strip().upper()
    if not re.fullmatch(r"[A-Z0-9][A-Z0-9._-]{1,40}", atm):
        return {"success": False, "error": "ATM ID yanlisdir."}
    limit = max(1, min(300, int(limit or 50)))
    con = db_connect()
    try:
        rows = [dict(r) for r in con.execute(
            """SELECT id,atm_id,collected_at,method,password_env,online,cpu_percent,ram_percent,
                      os_name,hostname,disk_count,uptime_seconds,boot_time,latency_ms,error
               FROM atm_info_snapshots WHERE atm_id=? COLLATE NOCASE ORDER BY id DESC LIMIT ?""",
            (atm, limit)).fetchall()]
        return {"success": True, "atm": atm, "rows": rows}
    finally:
        con.close()


def atminfo_snapshot(snap_id):
    con = db_connect()
    try:
        r = con.execute("SELECT * FROM atm_info_snapshots WHERE id=?", (int(snap_id or 0),)).fetchone()
        if not r:
            return {"success": False, "error": "Qeyd tapilmadi."}
        d = dict(r)
        try:
            d["disks"] = json.loads(d.get("disks_json") or "[]")
        except Exception:
            d["disks"] = []
        return {"success": True, "snapshot": d}
    finally:
        con.close()


def atminfo_latest(atm):
    atm = str(atm or "").strip().upper()
    if not re.fullmatch(r"[A-Z0-9][A-Z0-9._-]{1,40}", atm):
        return {"success": False, "error": "ATM ID yanlisdir."}
    con = db_connect()
    try:
        meta = con.execute("SELECT * FROM atms WHERE atm_id=? COLLATE NOCASE", (atm,)).fetchone()
        r = con.execute("SELECT * FROM atm_info_snapshots WHERE atm_id=? COLLATE NOCASE AND online=1 ORDER BY id DESC LIMIT 1", (atm,)).fetchone()
        snap = None
        if r:
            snap = dict(r)
            try:
                snap["disks"] = json.loads(snap.get("disks_json") or "[]")
            except Exception:
                snap["disks"] = []
        return {"success": True, "atm": atm, "meta": (dict(meta) if meta else None), "snapshot": snap}
    finally:
        con.close()


def atminfo_collect(atm, method="445", save=True):
    """Secilen porta gore yonlendir: 445 -> collect.bat/atminfo.json, 135 -> WMI/RPC."""
    atm = str(atm or "").strip().upper()
    if not re.fullmatch(r"[A-Z0-9][A-Z0-9._-]{1,40}", atm):
        return {"success": False, "error": "ATM ID yanlisdir."}
    method = "135" if str(method or "").strip() == "135" else "445"
    result = _atminfo_135(atm) if method == "135" else _atminfo_445(atm)
    if isinstance(result, dict):
        result.setdefault("method", method)
        # ATM bazada varsa neticeni tarixceye yaz (online ve ya oflayn)
        if save and result.get("success") and ("online" in result):
            try:
                con = db_connect()
                exists = con.execute("SELECT 1 FROM atms WHERE atm_id=? COLLATE NOCASE", (atm,)).fetchone()
                con.close()
            except Exception:
                exists = True
            if exists:
                _atminfo_save_snapshot(atm, method, result)
    return result


def system_parse_remote_metrics(output):
    """PsExec-in banner/stderr sətrlərindən müstəqil JSON payload oxu."""
    start_mark = '__ATM_METRICS_BEGIN__'
    end_mark = '__ATM_METRICS_END__'
    p = output.find(start_mark)
    if p < 0:
        return None
    q = output.find(end_mark, p + len(start_mark))
    if q < 0:
        return None
    payload = output[p + len(start_mark):q].strip().lstrip('\ufeff')
    try:
        item = json.loads(payload)
    except (ValueError, TypeError):
        return None
    return item if isinstance(item, dict) else None


def system_psexec_metrics(atm, password, executable, timeout=55, username="Administrator"):
    """ATM üzərində lokal PowerShell+WMI; password None-dırsa mövcud SMB sessiyasını sınayır."""
    import base64
    remote_ps = base64.b64encode(SYSTEM_LOCAL_PS.encode('utf-16le')).decode('ascii')
    cmd = [executable, '-accepteula', '-nobanner', '-n', '10', '\\\\' + atm]
    if password is not None:
        # PsExec -p məcburi command-line arqumentidir; log/HTTP cavabına qaytarılmır.
        cmd += ['-u', username or 'Administrator', '-p', password]
    cmd += [
        'powershell.exe', '-NoProfile', '-NonInteractive', '-ExecutionPolicy',
        'Bypass', '-EncodedCommand', remote_ps,
    ]
    try:
        cp = subprocess.run(
            cmd, capture_output=True, text=True, encoding='utf-8',
            errors='replace', timeout=timeout,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0), shell=False,
        )
    except subprocess.TimeoutExpired:
        return None, f'PsExec {timeout} saniyədə cavab vermədi (timeout).'
    except OSError as err:
        return None, system_clean_error(err)
    raw = (cp.stdout or '') + '\n' + (cp.stderr or '')
    parsed = system_parse_remote_metrics(raw)
    if parsed is not None:
        if parsed.get('ok'):
            return parsed, None
        return None, 'ATM-də lokal sistem sorğusu alınmadı: ' + system_clean_error(parsed.get('error'))
    clean = system_clean_error(raw).strip()
    if 'Access is denied' in clean or 'access denied' in clean.lower():
        message = 'PsExec: Access Denied; uzaq service/ADMIN$ icazəsini yoxla.'
    elif 'could not start' in clean.lower() or 'not recognized' in clean.lower():
        message = 'ATM-də PowerShell/WMIC tapılmadı və ya remote proses başlaya bilmədi.'
    elif 'network path was not found' in clean.lower():
        message = 'ATM şəbəkə yolu tapılmadı.'
    else:
        message = f'PsExec cavabında sistem məlumatı tapılmadı (exit {cp.returncode}).'
    return None, message


def system_worker(atm):
    started = time.monotonic()
    heartbeat_end = threading.Event()

    def heartbeat():
        last_log = 0
        while not heartbeat_end.wait(1):
            elapsed = int(time.monotonic() - started)
            system_update(elapsed_seconds=elapsed)
            if elapsed - last_log >= 10:
                with SYSTEM_LOCK:
                    action = SYSTEM_STATE["current_action"]
                system_log(f"{action} — {elapsed} saniyə keçib, cavab gözlənilir...")
                last_log = elapsed

    threading.Thread(target=heartbeat, daemon=True).start()
    wmi_error = None
    matched_slot = None
    matched_password = None
    resolved_ip = ""
    reverse_name = ""
    try:
        passwords = get_restart_passwords()
        if not passwords:
            raise RuntimeError("PASSWORD environment dəyişənləri tapılmadı.")

        system_log(f"ATM: {atm}. Sistem monitorinqi başladı.")
        system_log("Əsas metod: WMI/DCOM. TCP 135 ayrıca yoxlanacaq; sistem məlumatları WMI ilə oxunacaq.")

        # 1) İstifadəçiyə 135-in həqiqətən açıq olub-olmadığını aydın göstər.
        system_update(current_action="TCP 135 bağlantısı yoxlanılır...")
        port_ok, port_error = system_tcp_probe(atm, 135, timeout=4)
        resolved_ip, reverse_name = system_resolve_target(atm)
        if port_ok:
            system_diag(tcp135="AÇIQ", tcp135_detail="RPC Endpoint Mapper TCP 135 əlçatandır.")
            system_log("TCP 135: AÇIQ. RPC Endpoint Mapper əlçatandır.")
            if resolved_ip:
                system_log(f"ATM IP: {resolved_ip}" + (f" | reverse hostname: {reverse_name}" if reverse_name else ""))
        else:
            wmi_error = "TCP 135 bağlantısı alınmadı: " + str(port_error)
            system_diag(tcp135="BAĞLI / ƏLÇATMAZ", tcp135_detail=wmi_error, wmi="YOXLANMADI", wmi_detail="TCP 135 açıq olmadığı üçün WMI başlanmadı.")
            system_log("TCP 135: BAĞLIDIR / ƏLÇATMAZ. " + str(port_error))

        # 2) Port açıqdırsa düzgün PASSWORD slotunu bir dəfə müəyyən et.
        # Bu, 11-20 yanlış WMI login cəhdinin qarşısını alır.
        if port_ok:
            system_update(current_action="WMI üçün düzgün credential slotu müəyyən edilir...")
            slot, password, _alias, credential_error = system_discover_password_slot(atm)
            if slot is not None:
                matched_slot, matched_password = slot, password
                label = f"PASSWORD{slot}"
                system_update(matched_password_slot=slot)
                system_diag(credential="UĞURLU", credential_detail=f"{label} IPC$/SMB credential testi ilə təsdiqləndi.")
                system_log(f"{label} credential olaraq təsdiqləndi. İndi məlumatlar WMI/RPC ilə alınır.")

                # ATM ID DNS alias ola bilər. Eyni düzgün şifrə ilə unqualified və host\Administrator formaları sınanır.
                access_denied = False
                for username in system_wmi_user_candidates(atm, resolved_ip, reverse_name):
                    safe_user = username
                    system_update(current_action=f"WMI/RPC: {label} / {safe_user} ilə Win32_OperatingSystem yoxlanılır...")
                    system_log(f"WMI/RPC sorğusu -> user: {safe_user}")
                    probe = system_wmi_call(atm, slot, "probe", timeout=18, username=username)
                    if probe.get("ok"):
                        system_diag(wmi="UĞURLU", wmi_detail=f"{label} / {safe_user} ilə WMI bağlantısı quruldu.")
                        system_log(f"WMI/RPC UĞURLU: {label} / {safe_user}. CPU, RAM, disk, OS və network məlumatları alınır...")
                        system_update(current_action="WMI/RPC ilə CPU, RAM, disk, OS və network məlumatları oxunur...")
                        metrics = system_wmi_call(atm, slot, "full", timeout=45, username=username)
                        if metrics.get("ok"):
                            warnings = [system_clean_error(x) for x in metrics.pop("warnings", [])]
                            metrics.pop("ok", None)
                            metrics["resolved_ip"] = resolved_ip
                            metrics["wmi_username"] = safe_user
                            system_diag(wmi="UĞURLU", wmi_detail=f"{label} / {safe_user}: CPU, RAM, disk, OS və network məlumatları oxundu.", final="UĞURLU", final_detail="Məlumatlar WMI/RPC (TCP 135) ilə tam alındı.")
                            system_update(success=True, metrics=metrics, warnings=warnings, error=None,
                                          current_action="WMI/RPC: bütün sistem məlumatları oxundu.")
                            system_log("UĞURLU: CPU, RAM, disklər, OS, hostname, IP, MAC və network adapter məlumatları WMI/RPC ilə oxundu.")
                            return
                        wmi_error = system_clean_error(metrics.get("error"))
                        system_log("WMI probe uğurlu oldu, amma tam sorğu alınmadı: " + wmi_error)
                        break

                    err = system_clean_error(probe.get("error"))
                    wmi_error = err
                    system_diag(wmi="XƏTA", wmi_detail=f"{safe_user}: {err}")
                    system_log(f"WMI/RPC alınmadı ({safe_user}): {err}")
                    low = err.lower()
                    if "access is denied" in low or "access denied" in low or "0x80070005" in low:
                        access_denied = True
                        # Eyni doğru password ilə növbəti user formatını sına.
                        continue
                    if ("rpc server is unavailable" in low or "rpc server" in low or
                        "server unavailable" in low or "0x800706ba" in low or "timeout" in low):
                        break

                if access_denied and (not wmi_error or "access" in wmi_error.lower()):
                    wmi_error = (
                        f"TCP 135 açıqdır və {label} SMB autentifikasiyasında qəbul edildi, "
                        "amma WMI/DCOM Access Denied qaytardı. Bu artıq password problemi deyil: "
                        "ATM-də WMI root\\cimv2 Remote Enable/DCOM Remote Access və UAC remote admin icazələri yoxlanmalıdır."
                    )
                    system_diag(wmi="ACCESS DENIED", wmi_detail=wmi_error)
                    system_log("DİAQNOSTİKA: " + wmi_error)
            else:
                system_diag(credential="MÜƏYYƏN EDİLMƏDİ", credential_detail=str(credential_error))
                system_log("Credential slotu IPC$ ilə müəyyən edilmədi: " + str(credential_error))
                system_log("SMB credential testi alınmadığı üçün WMI birbaşa PASSWORD slotları ilə yoxlanacaq.")
                # 445 bağlı ola bilər, amma 135 açıqdırsa WMI yenə işləyə bilər.
                for attempt_no, (slot, _password) in enumerate(passwords, 1):
                    label = f"PASSWORD{slot}"
                    system_update(attempt_label=label,
                                  current_action=f"WMI/RPC: {label} yoxlanılır ({attempt_no}/{len(passwords)})...")
                    probe = system_wmi_call(atm, slot, "probe", timeout=18, username="Administrator")
                    if probe.get("ok"):
                        matched_slot = slot
                        matched_password = next((pw for s, pw in passwords if s == slot), None)
                        SYSTEM_SLOT_CACHE[atm.casefold()] = slot
                        system_update(matched_password_slot=slot)
                        system_diag(credential="UĞURLU", credential_detail=f"{label} WMI probe ilə təsdiqləndi.", wmi="UĞURLU", wmi_detail=f"{label} / Administrator ilə WMI probe uğurlu oldu.")
                        metrics = system_wmi_call(atm, slot, "full", timeout=45, username="Administrator")
                        if metrics.get("ok"):
                            warnings = [system_clean_error(x) for x in metrics.pop("warnings", [])]
                            metrics.pop("ok", None); metrics["resolved_ip"] = resolved_ip
                            system_diag(final="UĞURLU", final_detail="Məlumatlar WMI/RPC (TCP 135) ilə tam alındı.")
                            system_update(success=True, metrics=metrics, warnings=warnings, error=None,
                                          current_action="WMI/RPC: bütün sistem məlumatları oxundu.")
                            system_log(f"WMI/RPC UĞURLU: {label}.")
                            return
                        wmi_error = system_clean_error(metrics.get("error")); break
                    err = system_clean_error(probe.get("error")); wmi_error = err
                    system_diag(wmi="XƏTA", wmi_detail=f"{label}: {err}")
                    system_log(f"{label} WMI alınmadı: {err}")
                    low = err.lower()
                    if ("rpc server" in low or "0x800706ba" in low or "timeout" in low):
                        break

        # 3) WMI alınmadısa əvvəlki fallback qalır, amma səbəb aydın loglanır.
        system_diag(wmi="XƏTA", wmi_detail=str(wmi_error or "WMI/RPC məlumatı alınmadı."))
        system_log("WMI/RPC məlumatları alınmadı. Səbəb: " + str(wmi_error or "naməlum"))
        system_log("Fallback başladılır: PsExec/SMB. Bu nəticə WMI nəticəsi kimi göstərilməyəcək.")

        # WMI-dən əvvəl credential slotu artıq tapılıbsa eyni slotu istifadə et.
        smb_ok = False
        smb_error = None
        if matched_slot is not None and matched_password is not None:
            smb_ok = True
        else:
            system_update(current_action="Fallback: SMB 445 / Administrator credential yoxlanılır...")
            smb_ok, smb_slot, smb_error = system_smb_connect(atm)
            if smb_ok:
                if smb_slot is not None:
                    system_diag(smb="UĞURLU", smb_detail=f"PASSWORD{smb_slot} ilə SMB/C$ bağlantısı uğurludur.")
                else:
                    system_diag(smb="MÖVCUD SESSİYA", smb_detail="C$ mövcud Windows SMB sessiyası ilə oxunur; həmin sessiyanın PASSWORD slotunu Windows açıqlamır.")
            else:
                system_diag(smb="XƏTA", smb_detail=str(smb_error or "SMB bağlantısı alınmadı."))
            if smb_ok and smb_slot is not None:
                matched_slot = smb_slot
                matched_password = next((pw for candidate, pw in passwords if candidate == smb_slot), None)
                SYSTEM_SLOT_CACHE[atm.casefold()] = smb_slot
                system_update(matched_password_slot=smb_slot)

        psexec = system_find_psexec()
        warning = None
        if psexec and (matched_password is not None or smb_ok):
            if matched_password is not None:
                system_update(current_action="PsExec fallback: ATM-də lokal WMI oxunur...")
                system_diag(psexec="YOXLANILIR", psexec_detail=f"{('PASSWORD'+str(matched_slot)) if matched_slot else 'credential'} ilə PsExec başladılır.")
                system_log(f"PsExec fallback {('PASSWORD'+str(matched_slot)) if matched_slot else ''} ilə yoxlanılır...")
                metrics, remote_error = system_psexec_metrics(atm, matched_password, psexec, username="Administrator")
            else:
                # 1219 / mövcud sessiya halında artıq 'PsExec yoxlanmadı' demirik.
                system_update(current_action="PsExec fallback: mövcud SMB sessiyası ilə yoxlanılır...")
                system_diag(psexec="YOXLANILIR", psexec_detail="Mövcud SMB sessiyası ilə PsExec credentialsiz yoxlanılır.")
                system_log("Mövcud SMB sessiyası var; PsExec -u/-p vermədən həmin sessiya ilə yoxlanılır...")
                metrics, remote_error = system_psexec_metrics(atm, None, psexec)
            if metrics is not None:
                metrics.setdefault("hostname", metrics.get("computer_name", atm))
                metrics.setdefault("primary_ip", resolved_ip)
                metrics.setdefault("network_adapter_count", 0)
                metrics.setdefault("network_adapters", [])
                metrics.setdefault("collection_method", "PsExec / ATM lokal WMI (445)")
                warnings = ["WMI/RPC alınmadı: " + str(wmi_error or "naməlum")]
                warnings.extend(system_clean_error(x) for x in metrics.pop("warnings", []))
                metrics.pop("ok", None)
                system_diag(psexec="UĞURLU", psexec_detail="PsExec ATM-də lokal WMI sorğusunu icra etdi.", final="UĞURLU FALLBACK", final_detail="Remote WMI alınmadı, amma CPU/RAM/disk PsExec ilə oxundu.")
                system_update(success=True, metrics=metrics, warnings=warnings, error=None,
                              current_action="PsExec fallback ilə sistem məlumatları oxundu.")
                system_log("UĞURLU FALLBACK: CPU, RAM və disk məlumatları PsExec ilə oxundu.")
                return
            warning = system_clean_error(remote_error)
            system_diag(psexec="XƏTA", psexec_detail=warning)
        elif not psexec:
            warning = "PsExec64.exe tapılmadı; CPU/RAM fallback ilə oxunmayacaq."
            system_diag(psexec="TAPILMADI", psexec_detail=warning)
        elif not smb_ok:
            warning = "SMB credential/session alınmadı; PsExec yoxlanmadı. " + str(smb_error or "")
            system_diag(psexec="YOXLANMADI", psexec_detail=warning)

        # 4) Son fallback: disk ölçüləri SMB ilə.
        if not smb_ok:
            smb_ok, smb_slot, smb_error = system_smb_connect(atm)
            if smb_ok:
                if smb_slot is not None:
                    system_diag(smb="UĞURLU", smb_detail=f"PASSWORD{smb_slot} ilə SMB/C$ bağlantısı uğurludur.")
                else:
                    system_diag(smb="MÖVCUD SESSİYA", smb_detail="C$ mövcud Windows SMB sessiyası ilə oxunur; PASSWORD slotu müəyyən deyil.")
            else:
                system_diag(smb="XƏTA", smb_detail=str(smb_error or "SMB bağlantısı alınmadı."))
            if smb_slot is not None:
                matched_slot = smb_slot; system_update(matched_password_slot=smb_slot)
        if not smb_ok:
            raise RuntimeError("WMI/RPC: " + str(wmi_error or "alınmadı") + " | SMB: " + str(smb_error or "alınmadı"))

        system_update(current_action="Son fallback: disklər SMB (445) ilə oxunur...")
        drives = []
        for drive in SYSTEM_SMB_DRIVES:
            disk, _disk_error = system_smb_disk(atm, drive, timeout=7)
            if disk:
                drives.append(disk); system_log(f"{drive}: — {disk['used_percent']}% doludur.")
        if not drives:
            raise RuntimeError((warning + " | " if warning else "") + "SMB ilə disk ölçüləri də alınmadı.")

        metrics = {
            "computer_name": atm, "hostname": atm, "primary_ip": resolved_ip,
            "os_name": "", "os_version": "", "os_build": "", "os_architecture": "",
            "manufacturer": "", "model": "", "domain": "", "bios_serial": "",
            "last_boot": "", "uptime_seconds": None,
            "cpu_name": "", "cpu_percent": None, "cpu_cores": None, "cpu_logical": None,
            "ram_total_bytes": None, "ram_used_bytes": None, "ram_free_bytes": None, "ram_percent": None,
            "disk_count": len(drives), "disks": drives,
            "network_adapter_count": 0, "network_adapters": [],
            "collection_method": "SMB 445 (yalnız disk fallback)", "disk_source": "SMB 445", "partial": True
        }
        msg = warning or "WMI/PsExec alınmadı; yalnız disklər SMB ilə oxundu."
        system_diag(final="QİSMƏN", final_detail="Yalnız disklər SMB ilə oxundu. CPU/RAM/OS üçün yuxarıdakı WMI və PsExec səbəblərinə bax.")
        system_update(success=True, metrics=metrics, matched_password_slot=matched_slot,
                      warnings=["WMI/RPC: " + str(wmi_error or "alınmadı"), msg], error=msg,
                      current_action="Disklər göstərildi; WMI/PsExec məlumatları alınmadı.")
    except Exception as exc:
        error = system_clean_error(exc)
        system_diag(final="XƏTA", final_detail=error)
        system_update(success=False, error=error, current_action="Sistem yoxlaması alınmadı.")
        system_log("XƏTA: " + error)
    finally:
        heartbeat_end.set()
        with SYSTEM_LOCK:
            activity_id = SYSTEM_STATE.get("activity_id")
            activity_success = bool(SYSTEM_STATE.get("success"))
            activity_error = SYSTEM_STATE.get("error")
            activity_metrics = SYSTEM_STATE.get("metrics") or {}
            activity_action = SYSTEM_STATE.get("current_action") or "Sistem yoxlaması tamamlandı."
        detail = activity_error or activity_action
        if activity_success and activity_metrics.get("collection_method"):
            detail = str(activity_metrics.get("collection_method")) + " · " + str(activity_action)
        atm_activity_finish(activity_id, atm, activity_success, detail)
        system_update(running=False, finished=True,
                      elapsed_seconds=int(time.monotonic() - started),
                      finished_at=datetime.now().isoformat(timespec="seconds"))


def start_system_monitor(atm):
    atm = (atm or "").strip().upper()
    if not ATM_ID_PATTERN.fullmatch(atm):
        return False, "ATM ID düzgün deyil.", None
    with SYSTEM_LOCK:
        if SYSTEM_STATE["running"]:
            running_target = str(SYSTEM_STATE.get("target") or "").strip().upper()
            # Eyni ATM üçün ikinci POST yeni worker yaratmır. Browser refresh,
            # iki dəfə klik və ya gecikmiş UI request-i mövcud yoxlamaya qoşulur.
            if running_target == atm:
                return True, None, atm
            return False, f"Hazırda {running_target or 'başqa ATM'} üçün sistem yoxlaması davam edir.", running_target or None
        activity_id = atm_activity_start(atm, "SYSTEM_MONITOR", "ATM Sistem Monitoru", "system")
        SYSTEM_STATE.update({
            "activity_id": activity_id,
            "running": True, "finished": False, "success": False,
            "target": atm, "started_at": datetime.now().isoformat(timespec="seconds"),
            "finished_at": None, "current_action": "WMI/RPC (TCP 135) bağlantısı hazırlanır...",
            "attempt_label": "", "elapsed_seconds": 0,
            "logs": [], "error": None, "metrics": None,
            "matched_password_slot": None, "warnings": [],
            "backend_version": SYSTEM_BACKEND_VERSION,
            "diagnostics": new_system_diagnostics()
        })
    threading.Thread(target=system_worker, args=(atm,), daemon=True).start()
    return True, None, atm

# ============================================================
# QOVLUQ BƏRPASI (BERPA) — ATM-də var, serverdə yox olan YYYYMMDD
#   qovluqlarını tapıb serverə köçürür (bərpa edir).
#   D$  \\ATM_ID\D$\VIDEOARCHIVE\ATM_ID\YYYYMMDD  ->  \\SRV\d$\ATMFILES\ATM_ID\YYYYMMDD
#   E$  \\ATM_ID\E$\Video\YYYYMMDD               ->  \\SRV\h$\ATM_GRG_files\ATM_ID\YYYYMMDD
#   Serverin kök yolları config-dən (D / H mənbələri) oxunur.
#   Hesabat Excel kimi həm yüklənir, həm də reports\berpa qovluğunda saxlanılır.
# ============================================================

BERPA_LOCK = threading.RLock()
BERPA_CANCEL = threading.Event()
BERPA_MAX_WORKERS = max(1, min(int(os.getenv("ATM_BERPA_WORKERS", "3") or 3), 16))
BERPA_ATM_TIMEOUT = max(60, int(os.getenv("ATM_BERPA_ATM_TIMEOUT", "3600") or 3600))  # bir ATM üçün maksimum saniyə
BERPA_MAX_FILES_PER_FOLDER = 2000000
BERPA_TMP_SUFFIX = ".__berpa_tmp"
BERPA_DATE_RE = re.compile(r"^\d{8}$")

# ATM tərəfindəki mənbələr. srv_src = config-dəki server mənbə açarı (D / H).
# atm_has_id_subfolder = ATM tərəfdə qovluq yolunun sonuna ATM_ID əlavə olunur (VIDEOARCHIVE üçün).
BERPA_MAP_DEFS = [
    {"key": "D", "label": "VIDEOARCHIVE → ATMFILES", "atm_disk": "D$",
     "atm_folder": "VIDEOARCHIVE", "atm_has_id_subfolder": True, "srv_src": "D"},
    {"key": "E", "label": "Video → ATM_GRG_files", "atm_disk": "E$",
     "atm_folder": "Video", "atm_has_id_subfolder": False, "srv_src": "H"},
]

BERPA_STATE = {
    "running": False, "finished": False, "cancel_requested": False,
    "run_id": None, "started_at": None, "finished_at": None, "dry_run": False,
    "maps": [], "total": 0, "processed": 0, "percent": 0.0, "current_atms": [],
    "counts": {}, "restored_total": 0, "failed_total": 0, "files_total": 0, "bytes_total": 0,
    "logs": [], "completed_results": [], "error": None,
}

BERPA_STATUS_FILL = {
    "BƏRPA OLUNDU": "green", "ÇATIŞMAYAN YOXDUR": "gray", "YALNIZ YOXLAMA": "blue",
    "QİSMƏN": "yellow", "QOŞULMADI": "gray", "MƏNBƏ YOXDUR": "gray",
    "SERVER XƏTA": "red", "XƏTA": "red", "DAYANDIRILDI": "gray",
}


class BerpaCancelled(Exception):
    pass


class BerpaTimeout(Exception):
    pass


def berpa_report_dir():
    d = os.path.join(BASE_DIR, "reports", "berpa")
    os.makedirs(d, exist_ok=True)
    return d


def berpa_log(message):
    line = datetime.now().strftime("%H:%M:%S") + "  " + system_clean_error(message)
    with BERPA_LOCK:
        BERPA_STATE["logs"].append(line)
        BERPA_STATE["logs"] = BERPA_STATE["logs"][-500:]


def berpa_maps_config():
    """Konfiqdəki server mənbələrinə görə aktual map siyahısı qaytarır."""
    out = []
    with SCAN_LOCK:
        paths = dict(SCAN_SOURCES)
    for m in BERPA_MAP_DEFS:
        srv_root = paths.get(m["srv_src"], "")
        atm_tmpl = rf"\\ATM_ID\{m['atm_disk']}\{m['atm_folder']}"
        if m["atm_has_id_subfolder"]:
            atm_tmpl += r"\ATM_ID"
        out.append({
            "key": m["key"], "label": m["label"],
            "atm_path": atm_tmpl, "server_root": srv_root or "(konfiqdə yoxdur)",
            "server_path": (srv_root + r"\ATM_ID") if srv_root else "(konfiqdə yoxdur)",
            "available": bool(srv_root),
        })
    return out


def berpa_snapshot(since=0):
    with BERPA_LOCK:
        completed = BERPA_STATE["completed_results"]
        try:
            since = max(0, min(int(since), len(completed)))
        except Exception:
            since = 0
        return {
            "running": BERPA_STATE["running"], "finished": BERPA_STATE["finished"],
            "cancel_requested": BERPA_STATE["cancel_requested"], "run_id": BERPA_STATE["run_id"],
            "started_at": BERPA_STATE["started_at"], "finished_at": BERPA_STATE["finished_at"],
            "dry_run": BERPA_STATE["dry_run"], "maps": list(BERPA_STATE["maps"]),
            "total": BERPA_STATE["total"], "processed": BERPA_STATE["processed"],
            "percent": BERPA_STATE["percent"], "current_atms": list(BERPA_STATE["current_atms"]),
            "counts": dict(BERPA_STATE["counts"]), "restored_total": BERPA_STATE["restored_total"],
            "failed_total": BERPA_STATE["failed_total"], "files_total": BERPA_STATE["files_total"],
            "bytes_total": BERPA_STATE["bytes_total"], "logs": list(BERPA_STATE["logs"]),
            "new_results": [dict(x) for x in completed[since:]], "next_index": len(completed),
            "error": BERPA_STATE["error"], "workers": BERPA_MAX_WORKERS,
        }


def berpa_list_date_folders(path):
    """path daxilində YYYYMMDD adlı real qovluqların adlarını qaytarır (sözlük: ad -> tam yol)."""
    found = {}
    try:
        with os.scandir(path) as it:
            for e in it:
                try:
                    if not e.is_dir(follow_symlinks=False):
                        continue
                except OSError:
                    continue
                name = e.name
                if not BERPA_DATE_RE.fullmatch(name):
                    continue
                try:
                    datetime.strptime(name, "%Y%m%d")
                except ValueError:
                    continue
                found[name] = e.path
    except FileNotFoundError:
        return None
    except OSError:
        raise
    return found


def berpa_remove_tree(path):
    try:
        shutil.rmtree(path, ignore_errors=True)
    except Exception:
        pass


def berpa_copy_folder(src, dst_final, deadline, cancel_event, status_cb):
    r"""src qovluğunu (alt qovluqlar daxil) dst_final-a köçürür.
    Əvvəlcə müvəqqəti ad altına köçürür, tam bitəndə əsl ada çevirir (yarımçıq
    köçürmə serverdə 'var' kimi görünməsin deyə). (files, bytes) qaytarır."""
    parent = ntpath.dirname(dst_final.rstrip("\\/")) if "\\" in dst_final else os.path.dirname(dst_final)
    base = os.path.basename(dst_final.rstrip("\\/"))
    tmp = os.path.join(parent, base + BERPA_TMP_SUFFIX)
    berpa_remove_tree(tmp)
    files = 0
    total_bytes = 0
    try:
        os.makedirs(tmp, exist_ok=True)
        for walk_root, dirs, filenames in os.walk(src):
            if cancel_event.is_set():
                raise BerpaCancelled()
            if time.monotonic() > deadline:
                raise BerpaTimeout()
            rel = os.path.relpath(walk_root, src)
            target_dir = tmp if rel == "." else os.path.join(tmp, rel)
            os.makedirs(target_dir, exist_ok=True)
            for fn in filenames:
                if cancel_event.is_set():
                    raise BerpaCancelled()
                if time.monotonic() > deadline:
                    raise BerpaTimeout()
                if files >= BERPA_MAX_FILES_PER_FOLDER:
                    raise RuntimeError(f"Fayl limiti aşıldı ({BERPA_MAX_FILES_PER_FOLDER}).")
                s = os.path.join(walk_root, fn)
                d = os.path.join(target_dir, fn)
                shutil.copy2(s, d)
                files += 1
                try:
                    total_bytes += os.path.getsize(d)
                except OSError:
                    pass
                if files % 25 == 0 and status_cb:
                    status_cb(files, total_bytes)
        # Tam köçürüldü — əsl ada çevir
        if os.path.exists(dst_final):
            berpa_remove_tree(dst_final)
        os.replace(tmp, dst_final)
        return files, total_bytes
    except Exception:
        berpa_remove_tree(tmp)
        raise


def berpa_set_current(atm, add=True):
    with BERPA_LOCK:
        if add:
            if atm not in BERPA_STATE["current_atms"]:
                BERPA_STATE["current_atms"].append(atm)
        else:
            try:
                BERPA_STATE["current_atms"].remove(atm)
            except ValueError:
                pass


def berpa_restore_atm_map(atm, mdef, dry_run, deadline, cancel_event):
    """Bir ATM + bir mənbə üçün nəticə dict qaytarır (qoşulma artıq edilib)."""
    res = {
        "atm_id": atm, "map_key": mdef["key"], "map_label": mdef["label"],
        "atm_path": "", "server_path": "", "status": "XƏTA",
        "atm_folder_count": None, "server_folder_count": None,
        "missing_count": 0, "restored_count": 0, "failed_count": 0,
        "files_copied": 0, "bytes_copied": 0,
        "restored_folders": [], "failed_folders": [], "error": None,
    }
    with SCAN_LOCK:
        srv_root = SCAN_SOURCES.get(mdef["srv_src"], "")
    if not srv_root:
        res.update(status="SERVER XƏTA", error=f"Server mənbəsi konfiqdə yoxdur ({mdef['srv_src']}).")
        return res

    atm_base = rf"\\{atm}\{mdef['atm_disk']}\{mdef['atm_folder']}"
    if mdef["atm_has_id_subfolder"]:
        atm_base = os.path.join(atm_base, atm)
    server_base = ntpath.join(srv_root, atm)
    res["atm_path"] = atm_base
    res["server_path"] = server_base

    # ATM mənbə qovluqları
    try:
        atm_folders = berpa_list_date_folders(atm_base)
    except OSError as exc:
        res.update(status="XƏTA", error="ATM qovluğu oxunmadı: " + system_clean_error(exc))
        return res
    if atm_folders is None:
        res.update(status="MƏNBƏ YOXDUR", error=f"ATM-də qovluq tapılmadı: {atm_base}")
        return res
    res["atm_folder_count"] = len(atm_folders)

    # Server qovluqları
    try:
        srv_folders = berpa_list_date_folders(server_base)
    except OSError as exc:
        res.update(status="SERVER XƏTA", error="Server qovluğu oxunmadı: " + system_clean_error(exc))
        return res
    if srv_folders is None:
        srv_folders = {}  # server kök qovluğu yoxdursa — hamısı çatışmır, bərpada yaradılacaq
    res["server_folder_count"] = len(srv_folders)

    missing = sorted(n for n in atm_folders if n not in srv_folders)
    res["missing_count"] = len(missing)

    if not missing:
        res["status"] = "ÇATIŞMAYAN YOXDUR"
        return res
    if dry_run:
        res["status"] = "YALNIZ YOXLAMA"
        res["restored_folders"] = missing
        return res

    # Server kök qovluğunu təmin et
    try:
        os.makedirs(server_base, exist_ok=True)
    except OSError as exc:
        res.update(status="SERVER XƏTA", error="Server qovluğu yaradılmadı: " + system_clean_error(exc))
        return res

    for name in missing:
        if cancel_event.is_set():
            raise BerpaCancelled()
        src = atm_folders[name]
        dst = ntpath.join(server_base, name)
        berpa_log(f"{atm} [{mdef['key']}] {name}: köçürülür...")
        try:
            files, bytes_ = berpa_copy_folder(src, dst, deadline, cancel_event, None)
            res["restored_count"] += 1
            res["files_copied"] += files
            res["bytes_copied"] += bytes_
            res["restored_folders"].append(name)
            with BERPA_LOCK:
                BERPA_STATE["restored_total"] += 1
                BERPA_STATE["files_total"] += files
                BERPA_STATE["bytes_total"] += bytes_
            berpa_log(f"{atm} [{mdef['key']}] {name}: BƏRPA OLUNDU ({files} fayl).")
        except BerpaCancelled:
            raise
        except BerpaTimeout:
            res["failed_count"] += 1
            res["failed_folders"].append({"name": name, "error": "vaxt aşımı"})
            with BERPA_LOCK:
                BERPA_STATE["failed_total"] += 1
            berpa_log(f"{atm} [{mdef['key']}] {name}: VAXT AŞIMI — köçürmə dayandırıldı.")
            raise BerpaTimeout()
        except Exception as exc:
            msg = system_clean_error(exc)
            res["failed_count"] += 1
            res["failed_folders"].append({"name": name, "error": msg})
            with BERPA_LOCK:
                BERPA_STATE["failed_total"] += 1
            berpa_log(f"{atm} [{mdef['key']}] {name}: XƏTA — {msg}")

    if res["restored_count"] and res["failed_count"]:
        res["status"] = "QİSMƏN"
    elif res["restored_count"]:
        res["status"] = "BƏRPA OLUNDU"
    elif res["failed_count"]:
        res["status"] = "XƏTA"
        res["error"] = res["failed_folders"][0]["error"] if res["failed_folders"] else "Köçürmə alınmadı."
    else:
        res["status"] = "ÇATIŞMAYAN YOXDUR"
    return res


def berpa_process_atm(item, maps, dry_run, cancel_event):
    """Bir ATM: qoşul → seçilmiş mənbələr üzrə bərpa → nəticə sətirləri (siyahı)."""
    atm = str(item["atm_id"]).strip()
    started = time.monotonic()
    deadline = started + BERPA_ATM_TIMEOUT
    berpa_set_current(atm, True)
    rows = []
    base_row = {"atm_id": atm, "name": item.get("name") or "", "region": item.get("region") or "",
                "password_env": item.get("password_env") or None}

    def fail_all(status, error):
        for mdef in maps:
            r = {"map_key": mdef["key"], "map_label": mdef["label"], "atm_path": "",
                 "server_path": "", "status": status, "atm_folder_count": None,
                 "server_folder_count": None, "missing_count": 0, "restored_count": 0,
                 "failed_count": 0, "files_copied": 0, "bytes_copied": 0,
                 "restored_folders": [], "failed_folders": [], "error": error}
            r.update(base_row)
            rows.append(r)

    passwords = _disk_report_passwords(item.get("password_env"))
    if not passwords:
        fail_all("QOŞULMADI", "PASSWORD environment dəyişənləri tapılmadı.")
        berpa_set_current(atm, False)
        return rows

    target = atm
    try:
        resolved = socket.gethostbyname(atm)
        if resolved:
            target = resolved
    except Exception:
        pass
    try:
        with socket.create_connection((target, 445), timeout=4):
            pass
    except OSError as exc:
        fail_all("QOŞULMADI", "TCP 445 əlçatan deyil (ATM sönülü / şəbəkə yoxdur): " + system_clean_error(exc))
        berpa_set_current(atm, False)
        return rows

    slot, reused, err = va_smb_connect(target, passwords, cancel_event)
    if slot is None and not reused:
        fail_all("QOŞULMADI", err)
        berpa_set_current(atm, False)
        return rows
    pwd_env = f"PASSWORD{slot}" if slot is not None else (item.get("password_env") or None)
    try:
        for mdef in maps:
            if cancel_event.is_set():
                raise BerpaCancelled()
            try:
                r = berpa_restore_atm_map(atm, mdef, dry_run, deadline, cancel_event)
            except BerpaCancelled:
                raise
            except BerpaTimeout:
                r = {"map_key": mdef["key"], "map_label": mdef["label"], "atm_path": "",
                     "server_path": "", "status": "XƏTA", "atm_folder_count": None,
                     "server_folder_count": None, "missing_count": 0, "restored_count": 0,
                     "failed_count": 0, "files_copied": 0, "bytes_copied": 0,
                     "restored_folders": [], "failed_folders": [],
                     "error": f"{BERPA_ATM_TIMEOUT} saniyə vaxt aşımı."}
            r.update(base_row)
            r["duration"] = round(time.monotonic() - started, 1)
            rows.append(r)
    except BerpaCancelled:
        done_keys = {x["map_key"] for x in rows}
        for mdef in maps:
            if mdef["key"] in done_keys:
                continue
            r = {"map_key": mdef["key"], "map_label": mdef["label"], "atm_path": "",
                 "server_path": "", "status": "DAYANDIRILDI", "atm_folder_count": None,
                 "server_folder_count": None, "missing_count": 0, "restored_count": 0,
                 "failed_count": 0, "files_copied": 0, "bytes_copied": 0,
                 "restored_folders": [], "failed_folders": [], "error": "Dayandırıldı."}
            r.update(base_row)
            rows.append(r)
    finally:
        if slot is not None:
            _disk_report_clear_ipc(target)
        berpa_set_current(atm, False)
    for r in rows:
        r.setdefault("password_env", pwd_env)
        r["password_env"] = pwd_env
    return rows


def berpa_check_one(item, maps, dry_run):
    try:
        rows = berpa_process_atm(item, maps, dry_run, BERPA_CANCEL)
    except BerpaCancelled:
        rows = []
    atm = str(item["atm_id"]).strip()
    with BERPA_LOCK:
        for r in rows:
            BERPA_STATE["completed_results"].append(dict(r))
            st = r["status"]
            BERPA_STATE["counts"][st] = BERPA_STATE["counts"].get(st, 0) + 1
        BERPA_STATE["processed"] += 1
        total = max(1, int(BERPA_STATE["total"] or 0))
        BERPA_STATE["percent"] = round(BERPA_STATE["processed"] * 100.0 / total, 1)
    return rows


def berpa_persist_run(run_id, meta, results):
    """Run-u JSON + Excel kimi reports\\berpa qovluğunda saxlayır."""
    try:
        d = berpa_report_dir()
        payload = {"run": meta, "results": results}
        with open(os.path.join(d, f"berpa_{run_id}.json"), "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=1)
        data, filename = berpa_build_excel(meta, results)
        with open(os.path.join(d, f"berpa_{run_id}.xlsx"), "wb") as f:
            f.write(data)
        berpa_log(f"Hesabat saxlanıldı: reports\\berpa\\berpa_{run_id}.xlsx")
    except Exception as exc:
        berpa_log("Hesabat saxlanmadı: " + system_clean_error(exc))


def berpa_next_run_id():
    d = berpa_report_dir()
    mx = 0
    try:
        for name in os.listdir(d):
            m = re.fullmatch(r"berpa_(\d+)\.json", name)
            if m:
                mx = max(mx, int(m.group(1)))
    except OSError:
        pass
    return mx + 1


def berpa_start(atm_ids=None, dry_run=False, map_keys=None):
    with BERPA_LOCK:
        if BERPA_STATE["running"]:
            return False, "Qovluq Bərpası artıq işləyir.", BERPA_STATE.get("run_id")
    with VA_LOCK:
        if VA_STATE["running"]:
            return False, "VIDEOARCHIVE Scan işləyir. Eyni ATM-lərə paralel qoşulmamaq üçün bitməsini gözlə.", None
    with DISK_REPORT_LOCK:
        if DISK_REPORT_STATE["running"]:
            return False, "Disk Report işləyir. Bitməsini gözlə.", None
    if not get_restart_passwords():
        return False, "PASSWORD environment dəyişənləri tapılmadı (PASSWORD1, PASSWORD2, ...).", None

    valid_keys = {m["key"] for m in BERPA_MAP_DEFS}
    if map_keys:
        chosen = [k for k in map_keys if k in valid_keys]
    else:
        chosen = [m["key"] for m in BERPA_MAP_DEFS]
    if not chosen:
        return False, "Ən azı bir mənbə seçilməlidir.", None
    with SCAN_LOCK:
        paths = dict(SCAN_SOURCES)
    maps = [m for m in BERPA_MAP_DEFS if m["key"] in chosen]
    unavailable = [m["label"] for m in maps if not paths.get(m["srv_src"])]
    if len(unavailable) == len(maps):
        return False, "Seçilmiş mənbələrin server yolu konfiqdə yoxdur.", None

    requested = []
    if atm_ids:
        if not isinstance(atm_ids, list):
            return False, "ATM siyahısı düzgün deyil.", None
        seen = set()
        for value in atm_ids:
            a = str(value or "").strip().upper()
            if ATM_ID_PATTERN.fullmatch(a) and a.casefold() not in seen:
                seen.add(a.casefold())
                requested.append(a)
        if not requested:
            return False, "Siyahıda düzgün ATM ID yoxdur.", None
        if len(requested) > 5000:
            return False, "Bir əməliyyat üçün maksimum 5000 ATM.", None

    con = db_connect()
    try:
        all_rows = con.execute("""SELECT atm_id,name,region,password_env FROM atms
                                  WHERE is_deleted=0 AND status=1 ORDER BY atm_id COLLATE NOCASE""").fetchall()
    finally:
        con.close()
    missing_ids = []
    if requested:
        by_id = {str(r["atm_id"]).casefold(): r for r in all_rows}
        rows = [by_id[a.casefold()] for a in requested if a.casefold() in by_id]
        missing_ids = [a for a in requested if a.casefold() not in by_id]
    else:
        rows = list(all_rows)
    rows = [{"atm_id": r["atm_id"], "name": r["name"], "region": r["region"],
             "password_env": r["password_env"]} for r in rows]
    if not rows:
        return False, "Yoxlanacaq aktiv ATM tapılmadı.", None

    run_id = berpa_next_run_id()
    started_at = datetime.now().isoformat(timespec="seconds")
    BERPA_CANCEL.clear()
    with BERPA_LOCK:
        BERPA_STATE.update({"running": True, "finished": False, "cancel_requested": False,
                            "run_id": run_id, "started_at": started_at, "finished_at": None,
                            "dry_run": bool(dry_run), "maps": chosen, "total": len(rows),
                            "processed": 0, "percent": 0.0, "current_atms": [], "counts": {},
                            "restored_total": 0, "failed_total": 0, "files_total": 0,
                            "bytes_total": 0, "logs": [], "completed_results": [], "error": None})
    if unavailable:
        berpa_log("Server yolu olmayan mənbələr buraxıldı: " + ", ".join(unavailable))
    if missing_ids:
        berpa_log(f"{len(missing_ids)} ATM bazada aktiv deyil / tapılmadı: "
                  + ", ".join(missing_ids[:20]) + (" …" if len(missing_ids) > 20 else ""))
    maps = [m for m in maps if paths.get(m["srv_src"])]
    threading.Thread(target=berpa_worker, args=(run_id, started_at, rows, maps, bool(dry_run)),
                     daemon=True).start()
    return True, None, run_id


def berpa_cancel():
    with BERPA_LOCK:
        if not BERPA_STATE["running"]:
            return False, "Aktiv bərpa əməliyyatı yoxdur."
        BERPA_STATE["cancel_requested"] = True
    BERPA_CANCEL.set()
    berpa_log("Dayandırma tələb olundu — işləyən köçürmələr təhlükəsiz dayandırılır.")
    return True, None


def berpa_worker(run_id, started_at, rows, maps, dry_run):
    try:
        mode = "YALNIZ YOXLAMA" if dry_run else "BƏRPA"
        berpa_log(f"Qovluq Bərpası #{run_id} başladı ({mode}). ATM: {len(rows)} · mənbə: "
                  + ", ".join(m["key"] for m in maps) + f" · paralel: {BERPA_MAX_WORKERS}")
        executor = ThreadPoolExecutor(max_workers=BERPA_MAX_WORKERS)
        pending = set()
        try:
            for row in rows:
                if BERPA_CANCEL.is_set():
                    break
                pending.add(executor.submit(berpa_check_one, dict(row), maps, dry_run))
            while pending:
                if BERPA_CANCEL.is_set():
                    for f in pending:
                        f.cancel()
                    break
                done, pending = wait(pending, timeout=0.4, return_when=FIRST_COMPLETED)
                for f in done:
                    try:
                        f.result()
                    except Exception as exc:
                        berpa_log("Worker xətası: " + system_clean_error(exc))
        finally:
            executor.shutdown(wait=True, cancel_futures=BERPA_CANCEL.is_set())
        cancelled = BERPA_CANCEL.is_set()
        finished = datetime.now().isoformat(timespec="seconds")
        try:
            duration = round((datetime.fromisoformat(finished)
                              - datetime.fromisoformat(started_at)).total_seconds(), 1)
        except Exception:
            duration = 0
        with BERPA_LOCK:
            BERPA_STATE.update({"running": False, "finished": True, "finished_at": finished,
                                "current_atms": [], "cancel_requested": cancelled})
            if not cancelled:
                BERPA_STATE["percent"] = 100.0
            results = [dict(x) for x in BERPA_STATE["completed_results"]]
            counts = dict(BERPA_STATE["counts"])
            meta = {"id": run_id, "started_at": started_at, "finished_at": finished,
                    "status": "CANCELLED" if cancelled else "COMPLETED", "dry_run": dry_run,
                    "maps": [m["key"] for m in maps], "selected_count": len(rows),
                    "checked_count": BERPA_STATE["processed"], "duration_seconds": duration,
                    "restored_total": BERPA_STATE["restored_total"],
                    "failed_total": BERPA_STATE["failed_total"],
                    "files_total": BERPA_STATE["files_total"],
                    "bytes_total": BERPA_STATE["bytes_total"], "counts": counts}
        berpa_persist_run(run_id, meta, results)
        berpa_log("Əməliyyat dayandırıldı." if cancelled else "Qovluq Bərpası tamamlandı.")
    except Exception as exc:
        error = system_clean_error(exc)
        finished = datetime.now().isoformat(timespec="seconds")
        with BERPA_LOCK:
            BERPA_STATE.update({"running": False, "finished": True, "error": error,
                                "finished_at": finished, "current_atms": []})
            results = [dict(x) for x in BERPA_STATE["completed_results"]]
            meta = {"id": run_id, "started_at": started_at, "finished_at": finished,
                    "status": "FAILED", "dry_run": dry_run, "maps": [m["key"] for m in maps],
                    "selected_count": len(rows), "checked_count": BERPA_STATE["processed"],
                    "duration_seconds": 0, "error": error,
                    "restored_total": BERPA_STATE["restored_total"],
                    "failed_total": BERPA_STATE["failed_total"],
                    "files_total": BERPA_STATE["files_total"],
                    "bytes_total": BERPA_STATE["bytes_total"], "counts": dict(BERPA_STATE["counts"])}
        berpa_persist_run(run_id, meta, results)
        berpa_log("QOVLUQ BƏRPASI XƏTA: " + error)


def berpa_history(limit=100):
    d = berpa_report_dir()
    runs = []
    try:
        names = [n for n in os.listdir(d) if re.fullmatch(r"berpa_\d+\.json", n)]
    except OSError:
        names = []
    names.sort(key=lambda n: int(re.findall(r"\d+", n)[0]), reverse=True)
    for name in names[:max(1, int(limit or 100))]:
        try:
            with open(os.path.join(d, name), "r", encoding="utf-8") as f:
                run = json.load(f).get("run", {})
            runs.append(run)
        except Exception:
            continue
    return {"success": True, "runs": runs}


def berpa_detail(run_id):
    path = os.path.join(berpa_report_dir(), f"berpa_{int(run_id)}.json")
    if not os.path.isfile(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)
    payload["success"] = True
    return payload


def _berpa_fmt_bytes(n):
    try:
        n = float(n or 0)
    except Exception:
        return "0 B"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return (f"{int(n)} {unit}" if unit == "B" else f"{n:.1f} {unit}")
        n /= 1024.0


def _berpa_dt(iso):
    if not iso:
        return ""
    try:
        return datetime.fromisoformat(str(iso).replace("T", " "))
    except Exception:
        return str(iso)


def berpa_build_excel(meta, results):
    """Run meta + results -> (xlsx bytes, filename)."""
    from xlsx_lite import Workbook
    wb = Workbook()
    status_az = {"COMPLETED": "TAMAMLANDI", "CANCELLED": "DAYANDIRILDI",
                 "FAILED": "XƏTA", "RUNNING": "İŞLƏYİR"}

    s = wb.add_sheet("Xülasə", [("Göstərici", 44), ("Dəyər", 30)], autofilter=False)
    s.add_row(["Qovluq Bərpası hesabatı", f"#{meta.get('id')}"], bold=True, fill="title")
    s.add_row(["Rejim", "YALNIZ YOXLAMA (kopyalama yoxdur)" if meta.get("dry_run") else "BƏRPA (kopyalanıb)"])
    s.add_row(["Mənbələr", ", ".join(meta.get("maps") or [])])
    s.add_row(["Başlama", _berpa_dt(meta.get("started_at"))])
    s.add_row(["Bitmə", _berpa_dt(meta.get("finished_at"))])
    s.add_row(["Status", status_az.get(meta.get("status"), meta.get("status") or "")])
    s.add_row(["Seçilmiş ATM", int(meta.get("selected_count") or 0)])
    s.add_row(["Yoxlanılmış ATM", int(meta.get("checked_count") or 0)])
    if meta.get("duration_seconds"):
        s.add_row(["Müddət (dəqiqə)", round(float(meta["duration_seconds"]) / 60.0, 1)])
    s.add_blank()
    s.add_row(["Bərpa olunan qovluq (cəmi)", int(meta.get("restored_total") or 0)], bold=True, fill="green")
    s.add_row(["Uğursuz qovluq (cəmi)", int(meta.get("failed_total") or 0)],
              fill=("red" if meta.get("failed_total") else "none"))
    s.add_row(["Köçürülən fayl (cəmi)", int(meta.get("files_total") or 0)])
    s.add_row(["Köçürülən həcm", _berpa_fmt_bytes(meta.get("bytes_total"))])
    if meta.get("error"):
        s.add_blank()
        s.add_row(["Xəta", str(meta["error"])], fill="red")
    s.add_blank()
    s.add_row(["Yollar", ""], bold=True, fill="title")
    for m in berpa_maps_config():
        s.add_row([f"{m['key']} — ATM", m["atm_path"]])
        s.add_row([f"{m['key']} — Server", m["server_path"]])

    # Bərpa olunan qovluqlar (qovluq başına bir sətir)
    rsheet = wb.add_sheet("Bərpa olunan qovluqlar",
                          [("ATM ID", 13), ("Mənbə", 8), ("Qovluq (tarix)", 14),
                           ("Fayl", 9), ("Server yolu", 60)])
    restored_any = False
    for r in results:
        folders = r.get("restored_folders") or []
        if r.get("status") in ("BƏRPA OLUNDU", "QİSMƏN", "YALNIZ YOXLAMA") and folders:
            per = None
            if r.get("restored_count"):
                per = int(round((r.get("files_copied") or 0) / max(1, r["restored_count"])))
            for name in folders:
                restored_any = True
                date_val = (datetime.strptime(name, "%Y%m%d").date()
                            if len(name) == 8 and name.isdigit() else name)
                rsheet.add_row([r["atm_id"], r["map_key"], date_val,
                                ("—" if r.get("status") == "YALNIZ YOXLAMA" else (per if per is not None else "")),
                                ntpath.join(r.get("server_path") or "", name)],
                               fill=("blue" if r.get("status") == "YALNIZ YOXLAMA" else "green"))
    if not restored_any:
        rsheet.add_row(["—", "—", "Bərpa olunan qovluq yoxdur", "", ""], fill="gray")

    # Hər ATM / mənbə
    cols = [("ATM ID", 13), ("Ad", 34), ("Region", 15), ("Mənbə", 8), ("Status", 18),
            ("ATM qovluq", 10), ("Server qovluq", 11), ("Çatışmayan", 10), ("Bərpa", 8),
            ("Uğursuz", 8), ("Fayl", 9), ("Həcm", 11), ("PASSWORD", 12),
            ("ATM yolu", 44), ("Server yolu", 44), ("Qeyd / xəta", 60)]
    allsheet = wb.add_sheet("Hər ATM / mənbə", cols)

    def add_rows(sheet, rows):
        for r in rows:
            note = r.get("error") or ""
            if r.get("failed_folders"):
                ff = "; ".join(f"{x['name']}: {x['error']}" for x in r["failed_folders"][:5])
                note = (note + " | " if note else "") + "Uğursuz: " + ff
            sheet.add_row([
                r["atm_id"], r.get("name") or "", r.get("region") or "", r.get("map_key"),
                r.get("status"), r.get("atm_folder_count"), r.get("server_folder_count"),
                r.get("missing_count"), r.get("restored_count"), r.get("failed_count"),
                r.get("files_copied"), _berpa_fmt_bytes(r.get("bytes_copied")),
                r.get("password_env") or "", r.get("atm_path") or "", r.get("server_path") or "", note,
            ], fill=BERPA_STATUS_FILL.get(r.get("status"), "none"), bold_cols=(0,))

    add_rows(allsheet, results)

    problems = [r for r in results if r.get("status") in
                ("QOŞULMADI", "XƏTA", "SERVER XƏTA", "QİSMƏN", "DAYANDIRILDI")]
    if problems:
        add_rows(wb.add_sheet("Problemlər", cols), problems)

    stamp = (meta.get("started_at") or "").replace(":", "-").replace("T", "_")[:16]
    return wb.to_bytes(), f"Qovluq_Berpasi_{meta.get('id')}_{stamp}.xlsx"


def berpa_excel(run_id):
    """Saxlanmış xlsx-i qaytarır; yoxdursa JSON-dan yenidən qurur."""
    run_id = int(run_id)
    saved = os.path.join(berpa_report_dir(), f"berpa_{run_id}.xlsx")
    detail = berpa_detail(run_id)
    if detail is None:
        raise FileNotFoundError("Hesabat tapılmadı.")
    meta, results = detail.get("run", {}), detail.get("results", [])
    _, filename = berpa_build_excel(meta, results) if not os.path.isfile(saved) else (None, None)
    if os.path.isfile(saved):
        with open(saved, "rb") as f:
            data = f.read()
        stamp = (meta.get("started_at") or "").replace(":", "-").replace("T", "_")[:16]
        return data, f"Qovluq_Berpasi_{run_id}_{stamp}.xlsx"
    data, filename = berpa_build_excel(meta, results)
    return data, filename


# ============================================================
# JOURNAL BƏRPASI (JBERPA) — ATM-də var, serverdə yox olan C$ jurnal
#   YYYYMMDD qovluqlarını serverə köçürür.
#   ATM namizəd yolları (sıra ilə yoxlanır, hər ikisi birləşdirilir):
#     1) \\ATM_ID\C$\Journal\YYYYMMDD
#     2) \\ATM_ID\C$\JOURNAL\Journal\YYYYMMDD
#   Server təyinatı (config DJ mənbəsi):
#     \\SRV\d$\JOURNAL_FILES\ATM_ID\YYYYMMDD
#   Qeyd: E$/H$ bu modula aid deyil. Hesabat Excel + reports\jberpa.
# ============================================================

JBERPA_LOCK = threading.RLock()
JBERPA_CANCEL = threading.Event()
JBERPA_MAX_WORKERS = max(1, min(int(os.getenv("ATM_JBERPA_WORKERS", "3") or 3), 16))
JBERPA_ATM_TIMEOUT = max(60, int(os.getenv("ATM_JBERPA_ATM_TIMEOUT", "3600") or 3600))
JBERPA_SRV_SRC = "DJ"  # server jurnal mənbəsi (config)
# ATM tərəfindəki namizəd jurnal kökləri (\\ATM_ID\ əlavə olunur). Sıra = prioritet.
JBERPA_ATM_ROOTS = [r"C$\Journal", r"C$\JOURNAL\Journal"]

JBERPA_STATE = {
    "running": False, "finished": False, "cancel_requested": False,
    "run_id": None, "started_at": None, "finished_at": None, "dry_run": False,
    "total": 0, "processed": 0, "percent": 0.0, "current_atms": [],
    "counts": {}, "restored_total": 0, "failed_total": 0, "files_total": 0, "bytes_total": 0,
    "logs": [], "completed_results": [], "error": None,
}


def jberpa_report_dir():
    d = os.path.join(BASE_DIR, "reports", "jberpa")
    os.makedirs(d, exist_ok=True)
    return d


def jberpa_log(message):
    line = datetime.now().strftime("%H:%M:%S") + "  " + system_clean_error(message)
    with JBERPA_LOCK:
        JBERPA_STATE["logs"].append(line)
        JBERPA_STATE["logs"] = JBERPA_STATE["logs"][-500:]


def jberpa_config():
    with SCAN_LOCK:
        srv = SCAN_SOURCES.get(JBERPA_SRV_SRC, "")
    return {
        "atm_paths": [rf"\\ATM_ID\{r}\YYYYMMDD" for r in JBERPA_ATM_ROOTS],
        "server_root": srv or "(konfiqdə yoxdur)",
        "server_path": (srv + r"\ATM_ID") if srv else "(konfiqdə yoxdur)",
        "available": bool(srv),
    }


def jberpa_snapshot(since=0):
    with JBERPA_LOCK:
        completed = JBERPA_STATE["completed_results"]
        try:
            since = max(0, min(int(since), len(completed)))
        except Exception:
            since = 0
        return {
            "running": JBERPA_STATE["running"], "finished": JBERPA_STATE["finished"],
            "cancel_requested": JBERPA_STATE["cancel_requested"], "run_id": JBERPA_STATE["run_id"],
            "started_at": JBERPA_STATE["started_at"], "finished_at": JBERPA_STATE["finished_at"],
            "dry_run": JBERPA_STATE["dry_run"], "total": JBERPA_STATE["total"],
            "processed": JBERPA_STATE["processed"], "percent": JBERPA_STATE["percent"],
            "current_atms": list(JBERPA_STATE["current_atms"]), "counts": dict(JBERPA_STATE["counts"]),
            "restored_total": JBERPA_STATE["restored_total"], "failed_total": JBERPA_STATE["failed_total"],
            "files_total": JBERPA_STATE["files_total"], "bytes_total": JBERPA_STATE["bytes_total"],
            "logs": list(JBERPA_STATE["logs"]), "new_results": [dict(x) for x in completed[since:]],
            "next_index": len(completed), "error": JBERPA_STATE["error"], "workers": JBERPA_MAX_WORKERS,
        }


def jberpa_set_current(atm, add=True):
    with JBERPA_LOCK:
        if add:
            if atm not in JBERPA_STATE["current_atms"]:
                JBERPA_STATE["current_atms"].append(atm)
        else:
            try:
                JBERPA_STATE["current_atms"].remove(atm)
            except ValueError:
                pass


def jberpa_gather_atm_folders(atm):
    """İki namizəd yolu yoxlayır, tapılan YYYYMMDD qovluqlarını birləşdirir.
    (folders{name->path}, src_found[bool,bool], read_error) qaytarır.
    Konflikt olarsa 1-ci yol (prioritet) qalır."""
    folders = {}
    found = [False, False]
    read_error = None
    for idx, root in enumerate(JBERPA_ATM_ROOTS):
        base = rf"\\{atm}\{root}"
        try:
            got = berpa_list_date_folders(base)
        except OSError as exc:
            read_error = system_clean_error(exc)
            continue
        if got is None:
            continue
        found[idx] = True
        for name, path in got.items():
            if name not in folders:  # 1-ci yol prioritetdir
                folders[name] = path
    return folders, found, read_error


def jberpa_process_atm(item, dry_run, cancel_event):
    """Bir ATM: qoşul → C$ jurnal → serverə çatışmayan qovluqları köçür → nəticə dict."""
    atm = str(item["atm_id"]).strip()
    started = time.monotonic()
    deadline = started + JBERPA_ATM_TIMEOUT
    jberpa_set_current(atm, True)
    res = {
        "atm_id": atm, "name": item.get("name") or "", "region": item.get("region") or "",
        "password_env": item.get("password_env") or None,
        "src1_path": rf"\\{atm}\{JBERPA_ATM_ROOTS[0]}", "src2_path": rf"\\{atm}\{JBERPA_ATM_ROOTS[1]}",
        "src1_found": False, "src2_found": False, "server_path": "",
        "atm_folder_count": None, "server_folder_count": None,
        "missing_count": 0, "restored_count": 0, "failed_count": 0,
        "files_copied": 0, "bytes_copied": 0, "restored_folders": [], "failed_folders": [],
        "status": "XƏTA", "error": None, "duration": 0,
    }
    try:
        with SCAN_LOCK:
            srv_root = SCAN_SOURCES.get(JBERPA_SRV_SRC, "")
        if not srv_root:
            res.update(status="SERVER XƏTA", error=f"Server jurnal mənbəsi konfiqdə yoxdur ({JBERPA_SRV_SRC}).")
            return res
        server_base = ntpath.join(srv_root, atm)
        res["server_path"] = server_base

        passwords = _disk_report_passwords(item.get("password_env"))
        if not passwords:
            res.update(status="QOŞULMADI", error="PASSWORD environment dəyişənləri tapılmadı.")
            return res

        target = atm
        try:
            resolved = socket.gethostbyname(atm)
            if resolved:
                target = resolved
        except Exception:
            pass
        try:
            with socket.create_connection((target, 445), timeout=4):
                pass
        except OSError as exc:
            res.update(status="QOŞULMADI",
                       error="TCP 445 əlçatan deyil (ATM sönülü / şəbəkə yoxdur): " + system_clean_error(exc))
            return res

        slot, reused, err = va_smb_connect(target, passwords, cancel_event)
        if slot is None and not reused:
            res.update(status="QOŞULMADI", error=err)
            return res
        res["password_env"] = f"PASSWORD{slot}" if slot is not None else (item.get("password_env") or None)
        try:
            atm_folders, found, read_error = jberpa_gather_atm_folders(atm)
            res["src1_found"], res["src2_found"] = found[0], found[1]
            if not found[0] and not found[1]:
                res.update(status="MƏNBƏ YOXDUR",
                           error=(read_error or "C$ jurnal qovluğu tapılmadı (Journal / JOURNAL\\Journal)."))
                return res
            res["atm_folder_count"] = len(atm_folders)

            try:
                srv_folders = berpa_list_date_folders(server_base)
            except OSError as exc:
                res.update(status="SERVER XƏTA", error="Server qovluğu oxunmadı: " + system_clean_error(exc))
                return res
            if srv_folders is None:
                srv_folders = {}
            res["server_folder_count"] = len(srv_folders)

            missing = sorted(n for n in atm_folders if n not in srv_folders)
            res["missing_count"] = len(missing)
            if not missing:
                res["status"] = "ÇATIŞMAYAN YOXDUR"
                return res
            if dry_run:
                res.update(status="YALNIZ YOXLAMA", restored_folders=missing)
                return res

            try:
                os.makedirs(server_base, exist_ok=True)
            except OSError as exc:
                res.update(status="SERVER XƏTA", error="Server qovluğu yaradılmadı: " + system_clean_error(exc))
                return res

            for name in missing:
                if cancel_event.is_set():
                    raise BerpaCancelled()
                src = atm_folders[name]
                dst = ntpath.join(server_base, name)
                jberpa_log(f"{atm} {name}: köçürülür...")
                try:
                    files, bytes_ = berpa_copy_folder(src, dst, deadline, cancel_event, None)
                    res["restored_count"] += 1
                    res["files_copied"] += files
                    res["bytes_copied"] += bytes_
                    res["restored_folders"].append(name)
                    with JBERPA_LOCK:
                        JBERPA_STATE["restored_total"] += 1
                        JBERPA_STATE["files_total"] += files
                        JBERPA_STATE["bytes_total"] += bytes_
                    jberpa_log(f"{atm} {name}: BƏRPA OLUNDU ({files} fayl).")
                except BerpaCancelled:
                    raise
                except BerpaTimeout:
                    res["failed_count"] += 1
                    res["failed_folders"].append({"name": name, "error": "vaxt aşımı"})
                    with JBERPA_LOCK:
                        JBERPA_STATE["failed_total"] += 1
                    jberpa_log(f"{atm} {name}: VAXT AŞIMI.")
                    res["error"] = f"{JBERPA_ATM_TIMEOUT} saniyə vaxt aşımı."
                    break
                except Exception as exc:
                    msg = system_clean_error(exc)
                    res["failed_count"] += 1
                    res["failed_folders"].append({"name": name, "error": msg})
                    with JBERPA_LOCK:
                        JBERPA_STATE["failed_total"] += 1
                    jberpa_log(f"{atm} {name}: XƏTA — {msg}")

            if res["restored_count"] and res["failed_count"]:
                res["status"] = "QİSMƏN"
            elif res["restored_count"]:
                res["status"] = "BƏRPA OLUNDU"
            elif res["failed_count"]:
                res["status"] = "XƏTA"
                if not res["error"] and res["failed_folders"]:
                    res["error"] = res["failed_folders"][0]["error"]
            else:
                res["status"] = "ÇATIŞMAYAN YOXDUR"
            return res
        finally:
            if slot is not None:
                _disk_report_clear_ipc(target)
    except BerpaCancelled:
        res["status"] = "DAYANDIRILDI"
        res["error"] = res.get("error") or "Dayandırıldı."
        return res
    except OSError as exc:
        res.update(status="XƏTA", error="Jurnal oxunmadı: " + system_clean_error(exc))
        return res
    finally:
        res["duration"] = round(time.monotonic() - started, 1)
        jberpa_set_current(atm, False)


def jberpa_check_one(item, dry_run):
    try:
        res = jberpa_process_atm(item, dry_run, JBERPA_CANCEL)
    except BerpaCancelled:
        res = None
    with JBERPA_LOCK:
        if res is not None:
            JBERPA_STATE["completed_results"].append(dict(res))
            st = res["status"]
            JBERPA_STATE["counts"][st] = JBERPA_STATE["counts"].get(st, 0) + 1
        JBERPA_STATE["processed"] += 1
        total = max(1, int(JBERPA_STATE["total"] or 0))
        JBERPA_STATE["percent"] = round(JBERPA_STATE["processed"] * 100.0 / total, 1)
    return res


def jberpa_next_run_id():
    d = jberpa_report_dir()
    mx = 0
    try:
        for name in os.listdir(d):
            m = re.fullmatch(r"jberpa_(\d+)\.json", name)
            if m:
                mx = max(mx, int(m.group(1)))
    except OSError:
        pass
    return mx + 1


def jberpa_persist_run(run_id, meta, results):
    try:
        d = jberpa_report_dir()
        with open(os.path.join(d, f"jberpa_{run_id}.json"), "w", encoding="utf-8") as f:
            json.dump({"run": meta, "results": results}, f, ensure_ascii=False, indent=1)
        data, _ = jberpa_build_excel(meta, results)
        with open(os.path.join(d, f"jberpa_{run_id}.xlsx"), "wb") as f:
            f.write(data)
        jberpa_log(f"Hesabat saxlanıldı: reports\\jberpa\\jberpa_{run_id}.xlsx")
    except Exception as exc:
        jberpa_log("Hesabat saxlanmadı: " + system_clean_error(exc))


def jberpa_start(atm_ids=None, dry_run=False):
    with JBERPA_LOCK:
        if JBERPA_STATE["running"]:
            return False, "Journal Bərpası artıq işləyir.", JBERPA_STATE.get("run_id")
    with VA_LOCK:
        if VA_STATE["running"]:
            return False, "VIDEOARCHIVE Scan işləyir. Bitməsini gözlə.", None
    with BERPA_LOCK:
        if BERPA_STATE["running"]:
            return False, "Qovluq Bərpası işləyir. Bitməsini gözlə.", None
    with DISK_REPORT_LOCK:
        if DISK_REPORT_STATE["running"]:
            return False, "Disk Report işləyir. Bitməsini gözlə.", None
    if not get_restart_passwords():
        return False, "PASSWORD environment dəyişənləri tapılmadı (PASSWORD1, PASSWORD2, ...).", None
    with SCAN_LOCK:
        srv = SCAN_SOURCES.get(JBERPA_SRV_SRC, "")
    if not srv:
        return False, f"Server jurnal mənbəsi ({JBERPA_SRV_SRC}) konfiqdə yoxdur.", None

    requested = []
    if atm_ids:
        if not isinstance(atm_ids, list):
            return False, "ATM siyahısı düzgün deyil.", None
        seen = set()
        for value in atm_ids:
            a = str(value or "").strip().upper()
            if ATM_ID_PATTERN.fullmatch(a) and a.casefold() not in seen:
                seen.add(a.casefold())
                requested.append(a)
        if not requested:
            return False, "Siyahıda düzgün ATM ID yoxdur.", None
        if len(requested) > 5000:
            return False, "Bir əməliyyat üçün maksimum 5000 ATM.", None

    con = db_connect()
    try:
        all_rows = con.execute("""SELECT atm_id,name,region,password_env FROM atms
                                  WHERE is_deleted=0 AND status=1 ORDER BY atm_id COLLATE NOCASE""").fetchall()
    finally:
        con.close()
    missing_ids = []
    if requested:
        by_id = {str(r["atm_id"]).casefold(): r for r in all_rows}
        rows = [by_id[a.casefold()] for a in requested if a.casefold() in by_id]
        missing_ids = [a for a in requested if a.casefold() not in by_id]
    else:
        rows = list(all_rows)
    rows = [{"atm_id": r["atm_id"], "name": r["name"], "region": r["region"],
             "password_env": r["password_env"]} for r in rows]
    if not rows:
        return False, "Yoxlanacaq aktiv ATM tapılmadı.", None

    run_id = jberpa_next_run_id()
    started_at = datetime.now().isoformat(timespec="seconds")
    JBERPA_CANCEL.clear()
    with JBERPA_LOCK:
        JBERPA_STATE.update({"running": True, "finished": False, "cancel_requested": False,
                             "run_id": run_id, "started_at": started_at, "finished_at": None,
                             "dry_run": bool(dry_run), "total": len(rows), "processed": 0,
                             "percent": 0.0, "current_atms": [], "counts": {}, "restored_total": 0,
                             "failed_total": 0, "files_total": 0, "bytes_total": 0, "logs": [],
                             "completed_results": [], "error": None})
    if missing_ids:
        jberpa_log(f"{len(missing_ids)} ATM bazada aktiv deyil / tapılmadı: "
                   + ", ".join(missing_ids[:20]) + (" …" if len(missing_ids) > 20 else ""))
    threading.Thread(target=jberpa_worker, args=(run_id, started_at, rows, bool(dry_run)),
                     daemon=True).start()
    return True, None, run_id


def jberpa_cancel():
    with JBERPA_LOCK:
        if not JBERPA_STATE["running"]:
            return False, "Aktiv Journal Bərpası yoxdur."
        JBERPA_STATE["cancel_requested"] = True
    JBERPA_CANCEL.set()
    jberpa_log("Dayandırma tələb olundu — işləyən köçürmələr təhlükəsiz dayandırılır.")
    return True, None


def jberpa_worker(run_id, started_at, rows, dry_run):
    try:
        mode = "YALNIZ YOXLAMA" if dry_run else "BƏRPA"
        jberpa_log(f"Journal Bərpası #{run_id} başladı ({mode}). ATM: {len(rows)} · paralel: {JBERPA_MAX_WORKERS}")
        executor = ThreadPoolExecutor(max_workers=JBERPA_MAX_WORKERS)
        pending = set()
        try:
            for row in rows:
                if JBERPA_CANCEL.is_set():
                    break
                pending.add(executor.submit(jberpa_check_one, dict(row), dry_run))
            while pending:
                if JBERPA_CANCEL.is_set():
                    for f in pending:
                        f.cancel()
                    break
                done, pending = wait(pending, timeout=0.4, return_when=FIRST_COMPLETED)
                for f in done:
                    try:
                        f.result()
                    except Exception as exc:
                        jberpa_log("Worker xətası: " + system_clean_error(exc))
        finally:
            executor.shutdown(wait=True, cancel_futures=JBERPA_CANCEL.is_set())
        cancelled = JBERPA_CANCEL.is_set()
        finished = datetime.now().isoformat(timespec="seconds")
        try:
            duration = round((datetime.fromisoformat(finished)
                              - datetime.fromisoformat(started_at)).total_seconds(), 1)
        except Exception:
            duration = 0
        with JBERPA_LOCK:
            JBERPA_STATE.update({"running": False, "finished": True, "finished_at": finished,
                                 "current_atms": [], "cancel_requested": cancelled})
            if not cancelled:
                JBERPA_STATE["percent"] = 100.0
            results = [dict(x) for x in JBERPA_STATE["completed_results"]]
            meta = {"id": run_id, "started_at": started_at, "finished_at": finished,
                    "status": "CANCELLED" if cancelled else "COMPLETED", "dry_run": dry_run,
                    "selected_count": len(rows), "checked_count": JBERPA_STATE["processed"],
                    "duration_seconds": duration, "restored_total": JBERPA_STATE["restored_total"],
                    "failed_total": JBERPA_STATE["failed_total"], "files_total": JBERPA_STATE["files_total"],
                    "bytes_total": JBERPA_STATE["bytes_total"], "counts": dict(JBERPA_STATE["counts"])}
        jberpa_persist_run(run_id, meta, results)
        jberpa_log("Əməliyyat dayandırıldı." if cancelled else "Journal Bərpası tamamlandı.")
    except Exception as exc:
        error = system_clean_error(exc)
        finished = datetime.now().isoformat(timespec="seconds")
        with JBERPA_LOCK:
            JBERPA_STATE.update({"running": False, "finished": True, "error": error,
                                 "finished_at": finished, "current_atms": []})
            results = [dict(x) for x in JBERPA_STATE["completed_results"]]
            meta = {"id": run_id, "started_at": started_at, "finished_at": finished, "status": "FAILED",
                    "dry_run": dry_run, "selected_count": len(rows),
                    "checked_count": JBERPA_STATE["processed"], "duration_seconds": 0, "error": error,
                    "restored_total": JBERPA_STATE["restored_total"], "failed_total": JBERPA_STATE["failed_total"],
                    "files_total": JBERPA_STATE["files_total"], "bytes_total": JBERPA_STATE["bytes_total"],
                    "counts": dict(JBERPA_STATE["counts"])}
        jberpa_persist_run(run_id, meta, results)
        jberpa_log("JOURNAL BƏRPASI XƏTA: " + error)


def jberpa_history(limit=100):
    d = jberpa_report_dir()
    runs = []
    try:
        names = [n for n in os.listdir(d) if re.fullmatch(r"jberpa_\d+\.json", n)]
    except OSError:
        names = []
    names.sort(key=lambda n: int(re.findall(r"\d+", n)[0]), reverse=True)
    for name in names[:max(1, int(limit or 100))]:
        try:
            with open(os.path.join(d, name), "r", encoding="utf-8") as f:
                runs.append(json.load(f).get("run", {}))
        except Exception:
            continue
    return {"success": True, "runs": runs}


def jberpa_detail(run_id):
    path = os.path.join(jberpa_report_dir(), f"jberpa_{int(run_id)}.json")
    if not os.path.isfile(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)
    payload["success"] = True
    return payload


def jberpa_build_excel(meta, results):
    from xlsx_lite import Workbook
    wb = Workbook()
    status_az = {"COMPLETED": "TAMAMLANDI", "CANCELLED": "DAYANDIRILDI", "FAILED": "XƏTA", "RUNNING": "İŞLƏYİR"}
    cfg = jberpa_config()

    s = wb.add_sheet("Xülasə", [("Göstərici", 44), ("Dəyər", 30)], autofilter=False)
    s.add_row(["Journal Bərpası hesabatı", f"#{meta.get('id')}"], bold=True, fill="title")
    s.add_row(["Rejim", "YALNIZ YOXLAMA (kopyalama yoxdur)" if meta.get("dry_run") else "BƏRPA (kopyalanıb)"])
    s.add_row(["Başlama", _berpa_dt(meta.get("started_at"))])
    s.add_row(["Bitmə", _berpa_dt(meta.get("finished_at"))])
    s.add_row(["Status", status_az.get(meta.get("status"), meta.get("status") or "")])
    s.add_row(["Seçilmiş ATM", int(meta.get("selected_count") or 0)])
    s.add_row(["Yoxlanılmış ATM", int(meta.get("checked_count") or 0)])
    if meta.get("duration_seconds"):
        s.add_row(["Müddət (dəqiqə)", round(float(meta["duration_seconds"]) / 60.0, 1)])
    s.add_blank()
    s.add_row(["Bərpa olunan qovluq (cəmi)", int(meta.get("restored_total") or 0)], bold=True, fill="green")
    s.add_row(["Uğursuz qovluq (cəmi)", int(meta.get("failed_total") or 0)],
              fill=("red" if meta.get("failed_total") else "none"))
    s.add_row(["Köçürülən fayl (cəmi)", int(meta.get("files_total") or 0)])
    s.add_row(["Köçürülən həcm", _berpa_fmt_bytes(meta.get("bytes_total"))])
    if meta.get("error"):
        s.add_blank(); s.add_row(["Xəta", str(meta["error"])], fill="red")
    s.add_blank()
    s.add_row(["Yollar", ""], bold=True, fill="title")
    for p in cfg["atm_paths"]:
        s.add_row(["ATM namizəd", p])
    s.add_row(["Server", cfg["server_path"]])

    rsheet = wb.add_sheet("Bərpa olunan qovluqlar",
                          [("ATM ID", 13), ("Qovluq (tarix)", 14), ("Fayl", 9), ("Server yolu", 64)])
    restored_any = False
    for r in results:
        folders = r.get("restored_folders") or []
        if r.get("status") in ("BƏRPA OLUNDU", "QİSMƏN", "YALNIZ YOXLAMA") and folders:
            per = None
            if r.get("restored_count"):
                per = int(round((r.get("files_copied") or 0) / max(1, r["restored_count"])))
            for name in folders:
                restored_any = True
                date_val = (datetime.strptime(name, "%Y%m%d").date()
                            if len(name) == 8 and name.isdigit() else name)
                rsheet.add_row([r["atm_id"], date_val,
                                ("—" if r.get("status") == "YALNIZ YOXLAMA" else (per if per is not None else "")),
                                ntpath.join(r.get("server_path") or "", name)],
                               fill=("blue" if r.get("status") == "YALNIZ YOXLAMA" else "green"))
    if not restored_any:
        rsheet.add_row(["—", "Bərpa olunan qovluq yoxdur", "", ""], fill="gray")

    cols = [("ATM ID", 13), ("Ad", 34), ("Region", 15), ("Status", 18),
            ("Journal var", 11), ("JOURNAL\\Journal var", 16), ("ATM qovluq", 10),
            ("Server qovluq", 11), ("Çatışmayan", 10), ("Bərpa", 8), ("Uğursuz", 8),
            ("Fayl", 9), ("Həcm", 11), ("PASSWORD", 12), ("Server yolu", 50), ("Qeyd / xəta", 60)]
    allsheet = wb.add_sheet("Hər ATM", cols)

    def add_rows(sheet, rows):
        for r in rows:
            note = r.get("error") or ""
            if r.get("failed_folders"):
                ff = "; ".join(f"{x['name']}: {x['error']}" for x in r["failed_folders"][:5])
                note = (note + " | " if note else "") + "Uğursuz: " + ff
            sheet.add_row([
                r["atm_id"], r.get("name") or "", r.get("region") or "", r.get("status"),
                ("bəli" if r.get("src1_found") else "yox"), ("bəli" if r.get("src2_found") else "yox"),
                r.get("atm_folder_count"), r.get("server_folder_count"), r.get("missing_count"),
                r.get("restored_count"), r.get("failed_count"), r.get("files_copied"),
                _berpa_fmt_bytes(r.get("bytes_copied")), r.get("password_env") or "",
                r.get("server_path") or "", note,
            ], fill=BERPA_STATUS_FILL.get(r.get("status"), "none"), bold_cols=(0,))

    add_rows(allsheet, results)
    problems = [r for r in results if r.get("status") in
                ("QOŞULMADI", "XƏTA", "SERVER XƏTA", "QİSMƏN", "MƏNBƏ YOXDUR", "DAYANDIRILDI")]
    if problems:
        add_rows(wb.add_sheet("Problemlər", cols), problems)

    stamp = (meta.get("started_at") or "").replace(":", "-").replace("T", "_")[:16]
    return wb.to_bytes(), f"Journal_Berpasi_{meta.get('id')}_{stamp}.xlsx"


def jberpa_excel(run_id):
    run_id = int(run_id)
    saved = os.path.join(jberpa_report_dir(), f"jberpa_{run_id}.xlsx")
    detail = jberpa_detail(run_id)
    if detail is None:
        raise FileNotFoundError("Hesabat tapılmadı.")
    meta, results = detail.get("run", {}), detail.get("results", [])
    stamp = (meta.get("started_at") or "").replace(":", "-").replace("T", "_")[:16]
    if os.path.isfile(saved):
        with open(saved, "rb") as f:
            return f.read(), f"Journal_Berpasi_{run_id}_{stamp}.xlsx"
    return jberpa_build_excel(meta, results)


# ============================================================
# ATM FOTO MONİTORİNQ (MONITOR) — avtomatik planlaşdırıcı.
#   Hər ATM üçün "maksimum neçə saatdan bir pul çıxır" həddi (Excel-dən).
#   Hər interval-da VIDEOARCHIVE yoxlanır; son şəkil həddən köhnədirsə
#   (və ya şəkil/arxiv yoxdursa) ATM "işləmir" sayılır və mail göndərilir.
#   VA scan məntiqi (va_check_atm) təkrar istifadə olunur — yalnız oxuma.
# ============================================================

MONITOR_LOCK = threading.RLock()
MONITOR_CANCEL = threading.Event()
MONITOR_MAX_WORKERS = max(1, min(int(os.getenv("ATM_MON_WORKERS", "16") or 16), 32))
MONITOR_PROBLEM_CATS = ("İŞLƏMİR", "ŞƏKİL YOXDUR", "QOŞULMADI")

MONITOR_SCHED = {"thread": None, "stop_event": None}
MONITOR_STATE = {
    "scheduler_on": False, "busy": False, "trigger": None,
    "last_run_at": None, "last_status": None, "next_run_at": None,
    "total": 0, "checked": 0, "problem_count": 0, "mail_sent": False, "mail_error": None,
    "logs": [], "last_results": [], "last_run_id": None, "error": None,
}


def monitor_log(message):
    line = datetime.now().strftime("%H:%M:%S") + "  " + system_clean_error(message)
    with MONITOR_LOCK:
        MONITOR_STATE["logs"].append(line)
        MONITOR_STATE["logs"] = MONITOR_STATE["logs"][-500:]


def monitor_report_dir():
    d = os.path.join(BASE_DIR, "reports", "monitor")
    os.makedirs(d, exist_ok=True)
    return d


MONITOR_CONFIG_DEFAULTS = {
    "enabled": 0, "interval_hours": 1.0, "default_threshold": 0.0, "grace_minutes": 0,
    "only_on_problem": 1, "include_offline": 1,
    "smtp_host": "", "smtp_port": 25, "smtp_security": "none",
    "smtp_user": "su_back_atm", "smtp_pass": "",
    "mail_from": "su_back_atm@kapitalbank.az", "mail_to": "ali.samadli@kapitalbank.az",
    "last_run_at": None, "last_status": None,
}


def monitor_ensure_db(con):
    con.execute("""CREATE TABLE IF NOT EXISTS monitor_config (
        id INTEGER PRIMARY KEY CHECK(id=1),
        enabled INTEGER DEFAULT 0, interval_hours REAL DEFAULT 1,
        default_threshold REAL DEFAULT 0, grace_minutes INTEGER DEFAULT 0,
        only_on_problem INTEGER DEFAULT 1, include_offline INTEGER DEFAULT 1,
        smtp_host TEXT DEFAULT '', smtp_port INTEGER DEFAULT 25,
        smtp_security TEXT DEFAULT 'none', smtp_user TEXT DEFAULT 'su_back_atm',
        smtp_pass TEXT DEFAULT '', mail_from TEXT DEFAULT 'su_back_atm@kapitalbank.az',
        mail_to TEXT DEFAULT 'ali.samadli@kapitalbank.az',
        last_run_at TEXT, last_status TEXT)""")
    con.execute("""CREATE TABLE IF NOT EXISTS monitor_thresholds (
        atm_id TEXT PRIMARY KEY COLLATE NOCASE,
        max_hours REAL NOT NULL, updated_at TEXT)""")
    con.execute("INSERT OR IGNORE INTO monitor_config (id) VALUES (1)")


def monitor_get_config(include_secret=False):
    con = db_connect()
    try:
        monitor_ensure_db(con)
        con.commit()
        row = con.execute("SELECT * FROM monitor_config WHERE id=1").fetchone()
        cfg = dict(MONITOR_CONFIG_DEFAULTS)
        if row:
            cfg.update({k: row[k] for k in row.keys()})
        n = con.execute("SELECT COUNT(*) FROM monitor_thresholds").fetchone()[0]
    finally:
        con.close()
    cfg["threshold_count"] = n
    if not include_secret:
        cfg["has_pass"] = bool(cfg.get("smtp_pass") or os.getenv("ATM_MON_SMTP_PASS"))
        cfg.pop("smtp_pass", None)
    return cfg


def monitor_save_config(data):
    allowed = ["enabled", "interval_hours", "default_threshold", "grace_minutes",
               "only_on_problem", "include_offline", "smtp_host", "smtp_port",
               "smtp_security", "smtp_user", "mail_from", "mail_to"]
    con = db_connect()
    try:
        monitor_ensure_db(con)
        sets, vals = [], []
        for k in allowed:
            if k in data and data[k] is not None:
                v = data[k]
                if k in ("enabled", "only_on_problem", "include_offline", "grace_minutes"):
                    v = int(v)
                elif k in ("interval_hours", "default_threshold"):
                    v = float(v)
                elif k == "smtp_port":
                    v = int(v)
                sets.append(f"{k}=?"); vals.append(v)
        # Şifrə yalnız göndərilibsə yenilənir (boş = dəyişmə)
        if data.get("smtp_pass"):
            sets.append("smtp_pass=?"); vals.append(str(data["smtp_pass"]))
        if sets:
            con.execute(f"UPDATE monitor_config SET {', '.join(sets)} WHERE id=1", vals)
            con.commit()
    finally:
        con.close()
    return monitor_get_config()


def monitor_get_thresholds():
    con = db_connect()
    try:
        monitor_ensure_db(con)
        con.commit()
        rows = con.execute("SELECT atm_id, max_hours FROM monitor_thresholds").fetchall()
    finally:
        con.close()
    return {str(r["atm_id"]).upper(): float(r["max_hours"]) for r in rows}


def monitor_threshold_list(limit=5000):
    con = db_connect()
    try:
        monitor_ensure_db(con)
        con.commit()
        rows = con.execute("""SELECT t.atm_id, t.max_hours, a.name, a.region
                              FROM monitor_thresholds t
                              LEFT JOIN atms a ON a.atm_id=t.atm_id COLLATE NOCASE
                              ORDER BY t.max_hours, t.atm_id COLLATE NOCASE
                              LIMIT ?""", (int(limit),)).fetchall()
    finally:
        con.close()
    return [{"atm_id": r["atm_id"], "max_hours": r["max_hours"],
             "name": r["name"] or "", "region": r["region"] or ""} for r in rows]


# ---- Excel/CSV oxuyucu (xarici paketsiz) ----
def _col_to_index(ref):
    letters = re.match(r"[A-Za-z]+", ref or "")
    if not letters:
        return 0
    s = letters.group(0).upper()
    idx = 0
    for ch in s:
        idx = idx * 26 + (ord(ch) - 64)
    return idx - 1


def _read_xlsx_rows(data):
    import zipfile, io
    import xml.etree.ElementTree as ET
    ns = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    z = zipfile.ZipFile(io.BytesIO(data))
    shared = []
    if "xl/sharedStrings.xml" in z.namelist():
        root = ET.fromstring(z.read("xl/sharedStrings.xml"))
        for si in root.findall(ns + "si"):
            shared.append("".join(si.itertext()))
    sheets = sorted(n for n in z.namelist()
                    if n.startswith("xl/worksheets/sheet") and n.endswith(".xml"))
    if not sheets:
        return []
    root = ET.fromstring(z.read(sheets[0]))
    rows = []
    for row in root.iter(ns + "row"):
        cells = {}
        maxc = -1
        for c in row.findall(ns + "c"):
            ci = _col_to_index(c.get("r") or "")
            t = c.get("t")
            val = ""
            v = c.find(ns + "v")
            if t == "s" and v is not None:
                try:
                    val = shared[int(v.text)]
                except Exception:
                    val = ""
            elif t == "inlineStr":
                is_ = c.find(ns + "is")
                val = "".join(is_.itertext()) if is_ is not None else ""
            elif v is not None:
                val = v.text or ""
            cells[ci] = str(val).strip()
            maxc = max(maxc, ci)
        rows.append([cells.get(i, "") for i in range(maxc + 1)])
    return rows


def _read_csv_rows(data):
    import csv, io
    text = data.decode("utf-8-sig", errors="replace")
    delim = ";" if text.count(";") > text.count(",") else ","
    return [list(r) for r in csv.reader(io.StringIO(text), delimiter=delim)]


def monitor_import_thresholds(data_bytes):
    """ATM ID → maksimum saat cədvəlini xlsx/csv-dən oxuyub bazaya yazır.
    Sütun sırası sərbəst: ATM ID (hərf olan) və saat (ədəd) avtomatik tapılır."""
    if data_bytes[:2] == b"PK":
        rows = _read_xlsx_rows(data_bytes)
    else:
        rows = _read_csv_rows(data_bytes)
    known = set()
    con = db_connect()
    try:
        monitor_ensure_db(con)
        con.commit()
        known = {str(r[0]).upper() for r in con.execute("SELECT atm_id FROM atms")}
    finally:
        con.close()

    parsed = {}
    skipped = 0
    for cells in rows:
        atm = None
        hours = None
        # 1) tanınan ATM ID varsa onu götür
        for c in cells:
            cu = str(c).strip().upper()
            if cu in known:
                atm = cu
                break
        # 2) tanınmadısa, hərf olan ATM-şəkilli xanaya bax
        if atm is None:
            for c in cells:
                cu = str(c).strip().upper()
                if re.fullmatch(r"[A-Z][A-Z0-9._-]{3,63}", cu) and re.search(r"\d", cu):
                    atm = cu
                    break
        # saat: kiçik müsbət ədəd (0 < h <= 168)
        for c in cells:
            cs = str(c).strip().replace(",", ".")
            try:
                h = float(cs)
            except ValueError:
                continue
            if 0 < h <= 168 and (atm is None or cs.upper() != atm):
                hours = h
                break
        if atm and hours:
            parsed[atm] = hours
        else:
            skipped += 1

    if not parsed:
        raise ValueError("Faylda ATM ID + saat tapılmadı. Sütunlardan biri ATM ID (məs. A0100051), "
                         "digəri saat (1/4/8) olmalıdır.")
    now = datetime.now().isoformat(timespec="seconds")
    con = db_connect()
    try:
        monitor_ensure_db(con)
        con.executemany("""INSERT INTO monitor_thresholds(atm_id,max_hours,updated_at)
                           VALUES(?,?,?)
                           ON CONFLICT(atm_id) DO UPDATE SET max_hours=excluded.max_hours,
                           updated_at=excluded.updated_at""",
                        [(a, h, now) for a, h in parsed.items()])
        con.commit()
        total = con.execute("SELECT COUNT(*) FROM monitor_thresholds").fetchone()[0]
    finally:
        con.close()
    monitor_log(f"Excel import: {len(parsed)} ATM həddi yazıldı, {skipped} sətir ötürüldü. Cəmi: {total}.")
    return {"success": True, "imported": len(parsed), "skipped": skipped, "total": total}


def monitor_clear_thresholds():
    con = db_connect()
    try:
        monitor_ensure_db(con)
        con.execute("DELETE FROM monitor_thresholds")
        con.commit()
    finally:
        con.close()
    return {"success": True}


# ---- Mail göndərmə (stdlib) ----
def monitor_send_mail(cfg, subject, html_body, text_body, attachment=None, attach_name=None):
    import smtplib, ssl
    from email.message import EmailMessage
    host = (cfg.get("smtp_host") or "").strip()
    if not host:
        raise ValueError("SMTP server (host) təyin edilməyib. Parametrlərdə göstər.")
    port = int(cfg.get("smtp_port") or 25)
    sec = (cfg.get("smtp_security") or "none").lower()
    user = (cfg.get("smtp_user") or "").strip()
    passwd = os.getenv("ATM_MON_SMTP_PASS") or cfg.get("smtp_pass") or ""
    recipients = [x.strip() for x in re.split(r"[;,]", cfg.get("mail_to") or "") if x.strip()]
    if not recipients:
        raise ValueError("Alıcı mail ünvanı yoxdur.")
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = cfg.get("mail_from") or user
    msg["To"] = ", ".join(recipients)
    msg.set_content(text_body or "")
    if html_body:
        msg.add_alternative(html_body, subtype="html")
    if attachment:
        msg.add_attachment(attachment, maintype="application",
                           subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                           filename=attach_name or "report.xlsx")
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    if sec == "ssl":
        s = smtplib.SMTP_SSL(host, port, timeout=30, context=ctx)
    else:
        s = smtplib.SMTP(host, port, timeout=30)
        if sec == "starttls":
            s.starttls(context=ctx)
    try:
        if user and passwd:
            s.login(user, passwd)
        s.send_message(msg, to_addrs=recipients)
    finally:
        try:
            s.quit()
        except Exception:
            pass


def _monitor_hours_since(last_image_at, now=None):
    if not last_image_at:
        return None
    try:
        ts = datetime.fromisoformat(str(last_image_at))
    except Exception:
        return None
    now = now or datetime.now()
    return max(0.0, (now - ts).total_seconds() / 3600.0)


def monitor_classify(res, threshold, grace_hours, now=None):
    """va_check_atm nəticəsini həddə görə statusa çevirir."""
    cat = res.get("category")
    if cat in ("QOŞULMADI", "VAXT AŞIMI", "XƏTA"):
        return "QOŞULMADI", None
    last = res.get("last_image_at")
    hrs = _monitor_hours_since(last, now)
    if hrs is None:
        return "ŞƏKİL YOXDUR", None
    if hrs > (threshold + grace_hours):
        return "İŞLƏMİR", hrs
    return "NORMAL", hrs


def monitor_build_excel(meta, results):
    from xlsx_lite import Workbook
    wb = Workbook()
    fill = {"İŞLƏMİR": "red", "ŞƏKİL YOXDUR": "red", "QOŞULMADI": "gray",
            "NORMAL": "green"}
    s = wb.add_sheet("Xülasə", [("Göstərici", 42), ("Dəyər", 30)], autofilter=False)
    s.add_row(["ATM Foto Monitorinq hesabatı", f"#{meta.get('id')}"], bold=True, fill="title")
    s.add_row(["Tarix", _berpa_dt(meta.get("run_at"))])
    s.add_row(["Tətik", meta.get("trigger") or ""])
    s.add_row(["Yoxlanılan ATM", int(meta.get("checked") or 0)])
    s.add_blank()
    s.add_row(["İŞLƏMİR (vaxtında şəkil yox)", int(meta.get("not_working") or 0)], bold=True, fill="red")
    s.add_row(["ŞƏKİL YOXDUR / arxiv yox", int(meta.get("no_image") or 0)], fill="red")
    s.add_row(["QOŞULMADI (offline)", int(meta.get("offline") or 0)], fill="gray")
    s.add_row(["NORMAL", int(meta.get("normal") or 0)], fill="green")

    cols = [("ATM ID", 13), ("Ad", 34), ("Region", 15), ("Status", 18),
            ("Hədd (saat)", 10), ("Son şəkildən keçib (saat)", 16),
            ("Son şəkil", 20), ("Son folder", 12), ("Şəkil", 8),
            ("PASSWORD", 12), ("Qeyd / xəta", 56)]

    def add_rows(sheet, rows):
        for r in rows:
            hs = r.get("hours_since")
            sheet.add_row([
                r["atm_id"], r.get("name") or "", r.get("region") or "", r.get("status"),
                r.get("threshold"), (round(hs, 1) if hs is not None else None),
                _berpa_dt(r.get("last_image_at")), r.get("media_folder") or "",
                r.get("image_count"), r.get("password_env") or "", r.get("error") or "",
            ], fill=fill.get(r.get("status"), "none"), bold_cols=(0,))

    problems = [r for r in results if r.get("status") in MONITOR_PROBLEM_CATS]
    add_rows(wb.add_sheet(f"Problemli ATM-lər ({len(problems)})", cols), problems or [])
    if not problems:
        wb  # boş
    add_rows(wb.add_sheet("Bütün nəticələr", cols), results)
    stamp = (meta.get("run_at") or "").replace(":", "-").replace("T", "_")[:16]
    return wb.to_bytes(), f"ATM_Foto_Monitorinq_{meta.get('id')}_{stamp}.xlsx"


def _monitor_build_mail_bodies(meta, problems):
    cnt = len(problems)
    rows_html = "".join(
        f"<tr><td style='padding:4px 8px;border:1px solid #ddd'>{html_escape(r['atm_id'])}</td>"
        f"<td style='padding:4px 8px;border:1px solid #ddd'>{html_escape(r.get('name') or '')}</td>"
        f"<td style='padding:4px 8px;border:1px solid #ddd'>{html_escape(str(r.get('threshold')))}</td>"
        f"<td style='padding:4px 8px;border:1px solid #ddd'>{html_escape(str(round(r['hours_since'],1)) if r.get('hours_since') is not None else '—')}</td>"
        f"<td style='padding:4px 8px;border:1px solid #ddd'>{html_escape(str(r.get('last_image_at') or '—'))}</td>"
        f"<td style='padding:4px 8px;border:1px solid #ddd'>{html_escape(r.get('status'))}</td></tr>"
        for r in problems)
    html = (f"<div style='font-family:Segoe UI,Arial,sans-serif;font-size:14px;color:#1a1a1a'>"
            f"<p><b>ATM Foto Monitorinq</b> — {html_escape(_berpa_dt(meta.get('run_at')))}</p>"
            f"<p>Yoxlanılan ATM: <b>{meta.get('checked')}</b> · Problemli: "
            f"<b style='color:#c0392b'>{cnt}</b> (işləmir: {meta.get('not_working')}, "
            f"şəkil yox: {meta.get('no_image')}, offline: {meta.get('offline')})</p>"
            f"<table style='border-collapse:collapse;font-size:13px'>"
            f"<tr style='background:#f0f0f0'>"
            f"<th style='padding:4px 8px;border:1px solid #ddd'>ATM ID</th>"
            f"<th style='padding:4px 8px;border:1px solid #ddd'>Ad</th>"
            f"<th style='padding:4px 8px;border:1px solid #ddd'>Hədd (saat)</th>"
            f"<th style='padding:4px 8px;border:1px solid #ddd'>Keçib (saat)</th>"
            f"<th style='padding:4px 8px;border:1px solid #ddd'>Son şəkil</th>"
            f"<th style='padding:4px 8px;border:1px solid #ddd'>Status</th></tr>"
            f"{rows_html}</table>"
            f"<p style='color:#777;font-size:12px'>Tam hesabat Excel əlavəsindədir. Avtomatik mesaj — Cihaz İdarəetmə Sistemi.</p></div>")
    lines = [f"{r['atm_id']}  hədd={r.get('threshold')}s  keçib={round(r['hours_since'],1) if r.get('hours_since') is not None else '—'}s  {r.get('status')}  son_şəkil={r.get('last_image_at') or '—'}"
             for r in problems]
    text = (f"ATM Foto Monitorinq — {_berpa_dt(meta.get('run_at'))}\n"
            f"Yoxlanılan: {meta.get('checked')} · Problemli: {cnt} "
            f"(işləmir {meta.get('not_working')}, şəkil yox {meta.get('no_image')}, offline {meta.get('offline')})\n\n"
            + "\n".join(lines) + "\n\nTam hesabat Excel əlavəsindədir.")
    return html, text


def monitor_next_run_id():
    d = monitor_report_dir()
    mx = 0
    try:
        for name in os.listdir(d):
            m = re.fullmatch(r"monitor_(\d+)\.json", name)
            if m:
                mx = max(mx, int(m.group(1)))
    except OSError:
        pass
    return mx + 1


def monitor_run_check(trigger="manual"):
    with MONITOR_LOCK:
        if MONITOR_STATE["busy"]:
            return False, "Monitorinq yoxlaması artıq gedir."
        MONITOR_STATE["busy"] = True
        MONITOR_STATE["trigger"] = trigger
        MONITOR_STATE["error"] = None
        MONITOR_STATE["mail_sent"] = False
        MONITOR_STATE["mail_error"] = None
        MONITOR_STATE["logs"] = []
    run_id = monitor_next_run_id()
    run_at = datetime.now().isoformat(timespec="seconds")
    try:
        cfg = monitor_get_config(include_secret=True)
        thresholds = monitor_get_thresholds()
        default_thr = float(cfg.get("default_threshold") or 0)
        grace_h = float(cfg.get("grace_minutes") or 0) / 60.0
        monitor_log(f"Yoxlama başladı (tətik: {trigger}). Hədli ATM: {len(thresholds)}, "
                    f"default hədd: {default_thr or 'yox'}.")

        con = db_connect()
        try:
            all_rows = con.execute("""SELECT atm_id,name,region,password_env FROM atms
                                      WHERE is_deleted=0 AND status=1
                                      ORDER BY atm_id COLLATE NOCASE""").fetchall()
        finally:
            con.close()

        items = []
        for r in all_rows:
            aid = str(r["atm_id"]).upper()
            thr = thresholds.get(aid)
            if thr is None:
                if default_thr > 0:
                    thr = default_thr
                else:
                    continue
            items.append({"atm_id": r["atm_id"], "name": r["name"], "region": r["region"],
                          "password_env": r["password_env"], "threshold": thr})
        if not items:
            MONITOR_STATE["last_status"] = "Hədd təyin edilmiş ATM yoxdur (Excel import et)."
            monitor_log(MONITOR_STATE["last_status"])
            meta = {"id": run_id, "run_at": run_at, "trigger": trigger, "checked": 0,
                    "not_working": 0, "no_image": 0, "offline": 0, "normal": 0,
                    "problem_count": 0, "mail_sent": False}
            monitor_persist_run(run_id, meta, [])
            with MONITOR_LOCK:
                MONITOR_STATE.update({"total": 0, "checked": 0, "problem_count": 0,
                                      "last_run_at": run_at, "last_run_id": run_id, "last_results": []})
            return True, None

        with MONITOR_LOCK:
            MONITOR_STATE.update({"total": len(items), "checked": 0, "problem_count": 0})
        MONITOR_CANCEL.clear()

        results = []
        now = datetime.now()

        def work(item):
            res = va_check_atm({"atm_id": item["atm_id"], "name": item["name"],
                                "region": item["region"], "password_env": item["password_env"]},
                               MONITOR_CANCEL)
            status, hrs = monitor_classify(res, item["threshold"], grace_h, now)
            return {"atm_id": item["atm_id"], "name": res.get("name") or item["name"],
                    "region": res.get("region") or item["region"], "threshold": item["threshold"],
                    "status": status, "hours_since": hrs, "last_image_at": res.get("last_image_at"),
                    "media_folder": res.get("media_folder"), "image_count": res.get("image_count"),
                    "password_env": res.get("password_env"), "va_category": res.get("category"),
                    "error": res.get("error")}

        executor = ThreadPoolExecutor(max_workers=MONITOR_MAX_WORKERS)
        pending = {executor.submit(work, it) for it in items}
        try:
            while pending:
                done, pending = wait(pending, timeout=0.5, return_when=FIRST_COMPLETED)
                for f in done:
                    try:
                        row = f.result()
                        results.append(row)
                    except Exception as exc:
                        monitor_log("Yoxlama xətası: " + system_clean_error(exc))
                    with MONITOR_LOCK:
                        MONITOR_STATE["checked"] = len(results)
        finally:
            executor.shutdown(wait=True)

        not_working = sum(1 for r in results if r["status"] == "İŞLƏMİR")
        no_image = sum(1 for r in results if r["status"] == "ŞƏKİL YOXDUR")
        offline = sum(1 for r in results if r["status"] == "QOŞULMADI")
        normal = sum(1 for r in results if r["status"] == "NORMAL")
        include_offline = int(cfg.get("include_offline") or 0)
        problem_cats = ("İŞLƏMİR", "ŞƏKİL YOXDUR") + (("QOŞULMADI",) if include_offline else ())
        problems = [r for r in results if r["status"] in problem_cats]
        problems.sort(key=lambda r: (r["status"] != "İŞLƏMİR", -(r.get("hours_since") or 0)))
        results.sort(key=lambda r: ({"İŞLƏMİR": 0, "ŞƏKİL YOXDUR": 1, "QOŞULMADI": 2, "NORMAL": 3}.get(r["status"], 4),
                                     -(r.get("hours_since") or 0)))

        meta = {"id": run_id, "run_at": run_at, "trigger": trigger, "checked": len(results),
                "not_working": not_working, "no_image": no_image, "offline": offline,
                "normal": normal, "problem_count": len(problems), "mail_sent": False}
        monitor_log(f"Nəticə: işləmir {not_working}, şəkil yox {no_image}, offline {offline}, normal {normal}.")

        # Mail
        mail_sent = False
        mail_error = None
        send_it = (len(problems) > 0) or not int(cfg.get("only_on_problem") or 0)
        if send_it:
            try:
                data, fname = monitor_build_excel(meta, results)
                html_b, text_b = _monitor_build_mail_bodies(meta, problems)
                subj = (f"ATM Foto Monitorinq — {len(problems)} problem ATM "
                        f"({datetime.now().strftime('%d.%m.%Y %H:%M')})")
                monitor_send_mail(cfg, subj, html_b, text_b, attachment=data, attach_name=fname)
                mail_sent = True
                monitor_log(f"Mail göndərildi → {cfg.get('mail_to')} ({len(problems)} problem ATM).")
            except Exception as exc:
                mail_error = system_clean_error(exc)
                monitor_log("MAIL XƏTA: " + mail_error)
        else:
            monitor_log("Problem yoxdur — mail göndərilmədi (yalnız problem olanda göndər rejimi).")

        meta["mail_sent"] = mail_sent
        meta["mail_error"] = mail_error
        monitor_persist_run(run_id, meta, results)

        con = db_connect()
        try:
            monitor_ensure_db(con)
            con.execute("UPDATE monitor_config SET last_run_at=?, last_status=? WHERE id=1",
                        (run_at, f"{len(problems)} problem · mail {'OK' if mail_sent else ('XƏTA' if mail_error else 'yox')}"))
            con.commit()
        finally:
            con.close()
        with MONITOR_LOCK:
            MONITOR_STATE.update({"checked": len(results), "problem_count": len(problems),
                                  "last_run_at": run_at, "last_run_id": run_id,
                                  "last_results": results, "mail_sent": mail_sent,
                                  "mail_error": mail_error,
                                  "last_status": f"{len(problems)} problem"})
        return True, None
    except Exception as exc:
        err = system_clean_error(exc)
        monitor_log("YOXLAMA XƏTA: " + err)
        with MONITOR_LOCK:
            MONITOR_STATE["error"] = err
        return False, err
    finally:
        with MONITOR_LOCK:
            MONITOR_STATE["busy"] = False


def monitor_persist_run(run_id, meta, results):
    try:
        d = monitor_report_dir()
        with open(os.path.join(d, f"monitor_{run_id}.json"), "w", encoding="utf-8") as f:
            json.dump({"run": meta, "results": results}, f, ensure_ascii=False, indent=1)
        data, _ = monitor_build_excel(meta, results)
        with open(os.path.join(d, f"monitor_{run_id}.xlsx"), "wb") as f:
            f.write(data)
    except Exception as exc:
        monitor_log("Hesabat saxlanmadı: " + system_clean_error(exc))


def monitor_history(limit=100):
    d = monitor_report_dir()
    runs = []
    try:
        names = [n for n in os.listdir(d) if re.fullmatch(r"monitor_\d+\.json", n)]
    except OSError:
        names = []
    names.sort(key=lambda n: int(re.findall(r"\d+", n)[0]), reverse=True)
    for name in names[:max(1, int(limit or 100))]:
        try:
            with open(os.path.join(d, name), "r", encoding="utf-8") as f:
                runs.append(json.load(f).get("run", {}))
        except Exception:
            continue
    return {"success": True, "runs": runs}


def monitor_detail(run_id):
    path = os.path.join(monitor_report_dir(), f"monitor_{int(run_id)}.json")
    if not os.path.isfile(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)
    payload["success"] = True
    return payload


def monitor_excel(run_id):
    run_id = int(run_id)
    saved = os.path.join(monitor_report_dir(), f"monitor_{run_id}.xlsx")
    detail = monitor_detail(run_id)
    if detail is None:
        raise FileNotFoundError("Hesabat tapılmadı.")
    meta, results = detail.get("run", {}), detail.get("results", [])
    stamp = (meta.get("run_at") or "").replace(":", "-").replace("T", "_")[:16]
    if os.path.isfile(saved):
        with open(saved, "rb") as f:
            return f.read(), f"ATM_Foto_Monitorinq_{run_id}_{stamp}.xlsx"
    return monitor_build_excel(meta, results)


# ---- Planlaşdırıcı ----
def monitor_scheduler_loop(stop_event):
    monitor_log("Planlaşdırıcı işə düşdü.")
    while not stop_event.is_set():
        try:
            cfg = monitor_get_config(include_secret=True)
            interval = max(0.05, float(cfg.get("interval_hours") or 1)) * 3600.0
        except Exception:
            interval = 3600.0
        try:
            monitor_run_check(trigger="schedule")
        except Exception as exc:
            monitor_log("Planlı yoxlama xətası: " + system_clean_error(exc))
        nxt = datetime.now() + timedelta(seconds=interval)
        with MONITOR_LOCK:
            MONITOR_STATE["next_run_at"] = nxt.isoformat(timespec="seconds")
        stop_event.wait(interval)
    with MONITOR_LOCK:
        MONITOR_STATE["next_run_at"] = None
    monitor_log("Planlaşdırıcı dayandı.")


def monitor_scheduler_start():
    with MONITOR_LOCK:
        if MONITOR_STATE["scheduler_on"] and MONITOR_SCHED.get("thread") and MONITOR_SCHED["thread"].is_alive():
            return False, "Planlaşdırıcı artıq işləyir."
        stop_event = threading.Event()
        MONITOR_SCHED["stop_event"] = stop_event
        t = threading.Thread(target=monitor_scheduler_loop, args=(stop_event,), daemon=True)
        MONITOR_SCHED["thread"] = t
        MONITOR_STATE["scheduler_on"] = True
    t.start()
    con = db_connect()
    try:
        monitor_ensure_db(con)
        con.execute("UPDATE monitor_config SET enabled=1 WHERE id=1")
        con.commit()
    finally:
        con.close()
    return True, None


def monitor_scheduler_stop():
    with MONITOR_LOCK:
        ev = MONITOR_SCHED.get("stop_event")
        MONITOR_STATE["scheduler_on"] = False
    if ev:
        ev.set()
    MONITOR_CANCEL.set()
    con = db_connect()
    try:
        monitor_ensure_db(con)
        con.execute("UPDATE monitor_config SET enabled=0 WHERE id=1")
        con.commit()
    finally:
        con.close()
    return True, None


def monitor_autostart():
    try:
        cfg = monitor_get_config()
        if int(cfg.get("enabled") or 0):
            monitor_scheduler_start()
            monitor_log("Server başlanğıcında planlaşdırıcı avtomatik işə salındı.")
    except Exception as exc:
        monitor_log("Autostart xətası: " + system_clean_error(exc))


def monitor_status():
    with MONITOR_LOCK:
        st = {k: (list(v) if isinstance(v, list) else v) for k, v in MONITOR_STATE.items()}
    cfg = monitor_get_config()
    st["config"] = cfg
    st["scheduler_on"] = bool(MONITOR_SCHED.get("thread") and MONITOR_SCHED["thread"].is_alive()
                              and MONITOR_STATE["scheduler_on"])
    return {"success": True, **st}


# ============================================================
# ATM-ə FOLDER GÖNDƏR (DEPLOY) — seçilmiş mənbə qovluğunu siyahıdakı
#   bütün ATM-lərə (məs. administrator desktopu) köçürür.
#   Mənbə: serveri işə salan maşında yol (lokal və ya UNC) — istifadəçi seçir.
#   Təyinat: ATM daxilində yol, məs. C$\Users\Administrator\Desktop — istifadəçi yazır.
#   \\ATM\<dest>\<folder_adı>  (və ya "yalnız içindəkilər" rejimi).
#   Hesabat Excel + reports\deploy. YALNIZ bu modul ATM-ə YAZIR.
# ============================================================

DEPLOY_LOCK = threading.RLock()
DEPLOY_CANCEL = threading.Event()
DEPLOY_MAX_WORKERS = max(1, min(int(os.getenv("ATM_DEPLOY_WORKERS", "4") or 4), 16))
DEPLOY_ATM_TIMEOUT = max(60, int(os.getenv("ATM_DEPLOY_ATM_TIMEOUT", "3600") or 3600))

DEPLOY_STATE = {
    "running": False, "finished": False, "cancel_requested": False,
    "run_id": None, "started_at": None, "finished_at": None,
    "source": "", "dest": "", "folder_name": "", "contents_only": False, "overwrite": True,
    "total": 0, "processed": 0, "percent": 0.0, "current_atms": [],
    "counts": {}, "ok_total": 0, "skip_total": 0, "fail_total": 0,
    "files_total": 0, "bytes_total": 0, "logs": [], "completed_results": [], "error": None,
}

DEPLOY_STATUS_FILL = {"GÖNDƏRİLDİ": "green", "ARTIQ VAR (ötürüldü)": "gray",
                      "QOŞULMADI": "gray", "XƏTA": "red", "DAYANDIRILDI": "gray"}


def deploy_report_dir():
    d = os.path.join(BASE_DIR, "reports", "deploy")
    os.makedirs(d, exist_ok=True)
    return d


def deploy_log(message):
    line = datetime.now().strftime("%H:%M:%S") + "  " + system_clean_error(message)
    with DEPLOY_LOCK:
        DEPLOY_STATE["logs"].append(line)
        DEPLOY_STATE["logs"] = DEPLOY_STATE["logs"][-500:]


def deploy_snapshot(since=0):
    with DEPLOY_LOCK:
        completed = DEPLOY_STATE["completed_results"]
        try:
            since = max(0, min(int(since), len(completed)))
        except Exception:
            since = 0
        return {
            "running": DEPLOY_STATE["running"], "finished": DEPLOY_STATE["finished"],
            "cancel_requested": DEPLOY_STATE["cancel_requested"], "run_id": DEPLOY_STATE["run_id"],
            "started_at": DEPLOY_STATE["started_at"], "finished_at": DEPLOY_STATE["finished_at"],
            "source": DEPLOY_STATE["source"], "dest": DEPLOY_STATE["dest"],
            "folder_name": DEPLOY_STATE["folder_name"], "contents_only": DEPLOY_STATE["contents_only"],
            "overwrite": DEPLOY_STATE["overwrite"], "total": DEPLOY_STATE["total"],
            "processed": DEPLOY_STATE["processed"], "percent": DEPLOY_STATE["percent"],
            "current_atms": list(DEPLOY_STATE["current_atms"]), "counts": dict(DEPLOY_STATE["counts"]),
            "ok_total": DEPLOY_STATE["ok_total"], "skip_total": DEPLOY_STATE["skip_total"],
            "fail_total": DEPLOY_STATE["fail_total"], "files_total": DEPLOY_STATE["files_total"],
            "bytes_total": DEPLOY_STATE["bytes_total"], "logs": list(DEPLOY_STATE["logs"]),
            "new_results": [dict(x) for x in completed[since:]], "next_index": len(completed),
            "error": DEPLOY_STATE["error"], "workers": DEPLOY_MAX_WORKERS,
        }


def deploy_folder_stats(path):
    files = 0
    total = 0
    for root, dirs, names in os.walk(path):
        for n in names:
            files += 1
            try:
                total += os.path.getsize(os.path.join(root, n))
            except OSError:
                pass
            if files > 2000000:
                return files, total
    return files, total


def deploy_check_source(path):
    path = str(path or "").strip()
    if not path:
        raise ValueError("Mənbə yolu boşdur.")
    if not os.path.isdir(path):
        raise ValueError("Mənbə qovluğu tapılmadı və ya əlçatan deyil: " + path)
    files, total = deploy_folder_stats(path)
    return {"success": True, "path": path, "name": os.path.basename(path.rstrip("\\/")) or path,
            "files": files, "bytes": total}


def deploy_browse(path):
    """Serverdəki qovluqları gəzmək (mənbə seçmək üçün). Yalnız qovluqlar."""
    path = str(path or "").strip()
    if not path:
        # Kök: Windows disk hərfləri + istifadəçi profili
        roots = []
        for L in "CDEFGHIJKLMNOPQRSTUVWXYZ":
            d = L + ":\\"
            if os.path.isdir(d):
                roots.append({"name": d, "path": d, "dir": True})
        prof = os.getenv("USERPROFILE") or os.path.expanduser("~")
        if prof and os.path.isdir(prof):
            roots.insert(0, {"name": "Profil: " + prof, "path": prof, "dir": True})
            desk = os.path.join(prof, "Desktop")
            if os.path.isdir(desk):
                roots.insert(1, {"name": "Desktop: " + desk, "path": desk, "dir": True})
        return {"success": True, "path": "", "parent": None, "dirs": roots}
    if not os.path.isdir(path):
        raise ValueError("Qovluq tapılmadı: " + path)
    dirs = []
    try:
        with os.scandir(path) as it:
            for e in it:
                try:
                    if e.is_dir(follow_symlinks=False):
                        dirs.append({"name": e.name, "path": e.path, "dir": True})
                except OSError:
                    continue
    except OSError as exc:
        raise ValueError("Qovluq oxunmadı: " + system_clean_error(exc))
    dirs.sort(key=lambda x: x["name"].lower())
    parent = os.path.dirname(path.rstrip("\\/")) or None
    return {"success": True, "path": path, "parent": parent, "dirs": dirs[:3000]}


def deploy_normalize_dest(dest):
    r"""İstifadəçinin yazdığı təyinat yolunu ATM share-ə uyğun formaya salır.
    C:\Users\...  ->  C$\Users\...   ;  əvvəldəki \ və / təmizlənir."""
    d = str(dest or "").strip().replace("/", "\\")
    d = d.lstrip("\\")
    m = re.match(r"^([A-Za-z]):\\?(.*)$", d)
    if m:
        d = m.group(1).upper() + "$\\" + m.group(2)
    d = d.strip("\\")
    if not d:
        raise ValueError("Təyinat yolu boşdur.")
    if any(part in ("..", ".") for part in d.split("\\")):
        raise ValueError("Təyinat yolunda .. / . ola bilməz.")
    if not re.match(r"^[A-Za-z]\$(\\|$)", d):
        raise ValueError(r"Təyinat admin share ilə başlamalıdır, məs. C$\Users\Administrator\Desktop")
    return d


def deploy_copy_children(src, dest_dir, deadline, cancel_event, overwrite):
    """Mənbənin içindəkiləri (qovluq + fayl) dest_dir-ə köçürür (yalnız içindəkilər rejimi)."""
    files = total = skipped = 0
    os.makedirs(dest_dir, exist_ok=True)
    with os.scandir(src) as it:
        children = list(it)
    for e in children:
        if cancel_event.is_set():
            raise BerpaCancelled()
        target = os.path.join(dest_dir, e.name)
        is_dir = False
        try:
            is_dir = e.is_dir(follow_symlinks=False)
        except OSError:
            is_dir = False
        if is_dir:
            if os.path.exists(target) and not overwrite:
                skipped += 1
                continue
            f, b = berpa_copy_folder(e.path, target, deadline, cancel_event, None)
            files += f
            total += b
        else:
            if os.path.exists(target) and not overwrite:
                skipped += 1
                continue
            shutil.copy2(e.path, target)
            files += 1
            try:
                total += os.path.getsize(target)
            except OSError:
                pass
    return files, total, skipped


def deploy_process_atm(item, source, dest_rel, folder_name, contents_only, overwrite, cancel_event):
    atm = str(item["atm_id"]).strip()
    started = time.monotonic()
    deadline = started + DEPLOY_ATM_TIMEOUT
    with DEPLOY_LOCK:
        if atm not in DEPLOY_STATE["current_atms"]:
            DEPLOY_STATE["current_atms"].append(atm)
    res = {"atm_id": atm, "name": item.get("name") or "", "region": item.get("region") or "",
           "password_env": item.get("password_env") or None, "status": "XƏTA",
           "target_path": "", "files_copied": 0, "bytes_copied": 0, "error": None, "duration": 0}
    try:
        passwords = _disk_report_passwords(item.get("password_env"))
        if not passwords:
            res.update(status="QOŞULMADI", error="PASSWORD environment dəyişənləri tapılmadı.")
            return res
        target = atm
        try:
            resolved = socket.gethostbyname(atm)
            if resolved:
                target = resolved
        except Exception:
            pass
        try:
            with socket.create_connection((target, 445), timeout=4):
                pass
        except OSError as exc:
            res.update(status="QOŞULMADI",
                       error="TCP 445 əlçatan deyil (ATM sönülü / şəbəkə yoxdur): " + system_clean_error(exc))
            return res
        slot, reused, err = va_smb_connect(target, passwords, cancel_event)
        if slot is None and not reused:
            res.update(status="QOŞULMADI", error=err)
            return res
        res["password_env"] = f"PASSWORD{slot}" if slot is not None else (item.get("password_env") or None)
        try:
            dest_dir = rf"\\{target}\{dest_rel}"
            if contents_only:
                res["target_path"] = rf"\\{atm}\{dest_rel}"
                try:
                    os.makedirs(dest_dir, exist_ok=True)
                except OSError as exc:
                    res.update(status="XƏTA", error="Təyinat qovluğu yaradılmadı: " + system_clean_error(exc))
                    return res
                f, b, sk = deploy_copy_children(source, dest_dir, deadline, cancel_event, overwrite)
                res["files_copied"] = f
                res["bytes_copied"] = b
                res["status"] = "GÖNDƏRİLDİ" if (f or not sk) else "ARTIQ VAR (ötürüldü)"
                if sk and f:
                    res["error"] = f"{sk} element artıq var idi (ötürüldü)."
            else:
                final = ntpath.join(dest_dir, folder_name)
                res["target_path"] = rf"\\{atm}\{dest_rel}\{folder_name}"
                try:
                    os.makedirs(dest_dir, exist_ok=True)
                except OSError as exc:
                    res.update(status="XƏTA", error="Təyinat qovluğu yaradılmadı: " + system_clean_error(exc))
                    return res
                if os.path.exists(final) and not overwrite:
                    res.update(status="ARTIQ VAR (ötürüldü)",
                               error="Qovluq ATM-də artıq var, üzərinə yazılmadı.")
                    return res
                f, b = berpa_copy_folder(source, final, deadline, cancel_event, None)
                res["files_copied"] = f
                res["bytes_copied"] = b
                res["status"] = "GÖNDƏRİLDİ"
            with DEPLOY_LOCK:
                if res["status"] == "GÖNDƏRİLDİ":
                    DEPLOY_STATE["ok_total"] += 1
                elif res["status"].startswith("ARTIQ VAR"):
                    DEPLOY_STATE["skip_total"] += 1
                DEPLOY_STATE["files_total"] += res["files_copied"]
                DEPLOY_STATE["bytes_total"] += res["bytes_copied"]
            deploy_log(f"{atm}: {res['status']} ({res['files_copied']} fayl) → {res['target_path']}")
            return res
        finally:
            if slot is not None:
                _disk_report_clear_ipc(target)
    except BerpaCancelled:
        res.update(status="DAYANDIRILDI", error="Dayandırıldı.")
        return res
    except BerpaTimeout:
        res.update(status="XƏTA", error=f"{DEPLOY_ATM_TIMEOUT} saniyə vaxt aşımı.")
        with DEPLOY_LOCK:
            DEPLOY_STATE["fail_total"] += 1
        return res
    except Exception as exc:
        res.update(status="XƏTA", error=system_clean_error(exc))
        with DEPLOY_LOCK:
            DEPLOY_STATE["fail_total"] += 1
        return res
    finally:
        res["duration"] = round(time.monotonic() - started, 1)
        with DEPLOY_LOCK:
            try:
                DEPLOY_STATE["current_atms"].remove(atm)
            except ValueError:
                pass


def deploy_check_one(item, source, dest_rel, folder_name, contents_only, overwrite):
    try:
        res = deploy_process_atm(item, source, dest_rel, folder_name, contents_only, overwrite, DEPLOY_CANCEL)
    except BerpaCancelled:
        res = None
    with DEPLOY_LOCK:
        if res is not None:
            DEPLOY_STATE["completed_results"].append(dict(res))
            st = res["status"]
            DEPLOY_STATE["counts"][st] = DEPLOY_STATE["counts"].get(st, 0) + 1
        DEPLOY_STATE["processed"] += 1
        total = max(1, int(DEPLOY_STATE["total"] or 0))
        DEPLOY_STATE["percent"] = round(DEPLOY_STATE["processed"] * 100.0 / total, 1)
    return res


def deploy_next_run_id():
    d = deploy_report_dir()
    mx = 0
    try:
        for name in os.listdir(d):
            m = re.fullmatch(r"deploy_(\d+)\.json", name)
            if m:
                mx = max(mx, int(m.group(1)))
    except OSError:
        pass
    return mx + 1


def deploy_persist_run(run_id, meta, results):
    try:
        d = deploy_report_dir()
        with open(os.path.join(d, f"deploy_{run_id}.json"), "w", encoding="utf-8") as f:
            json.dump({"run": meta, "results": results}, f, ensure_ascii=False, indent=1)
        data, _ = deploy_build_excel(meta, results)
        with open(os.path.join(d, f"deploy_{run_id}.xlsx"), "wb") as f:
            f.write(data)
        deploy_log(f"Hesabat saxlanıldı: reports\\deploy\\deploy_{run_id}.xlsx")
    except Exception as exc:
        deploy_log("Hesabat saxlanmadı: " + system_clean_error(exc))


def deploy_start(atm_ids, source, dest, contents_only=False, overwrite=True):
    with DEPLOY_LOCK:
        if DEPLOY_STATE["running"]:
            return False, "Folder göndərmə artıq işləyir.", DEPLOY_STATE.get("run_id")
    if not get_restart_passwords():
        return False, "PASSWORD environment dəyişənləri tapılmadı (PASSWORD1, PASSWORD2, ...).", None
    source = str(source or "").strip()
    if not os.path.isdir(source):
        return False, "Mənbə qovluğu tapılmadı və ya əlçatan deyil: " + source, None
    folder_name = os.path.basename(source.rstrip("\\/")) or "folder"
    try:
        dest_rel = deploy_normalize_dest(dest)
    except ValueError as exc:
        return False, str(exc), None

    if not isinstance(atm_ids, list):
        return False, "ATM siyahısı düzgün deyil.", None
    seen = set()
    requested = []
    for v in atm_ids:
        a = str(v or "").strip().upper()
        if ATM_ID_PATTERN.fullmatch(a) and a.casefold() not in seen:
            seen.add(a.casefold())
            requested.append(a)
    if not requested:
        return False, "Siyahıda düzgün ATM ID yoxdur.", None
    if len(requested) > 5000:
        return False, "Bir əməliyyat üçün maksimum 5000 ATM.", None

    con = db_connect()
    try:
        all_rows = con.execute("""SELECT atm_id,name,region,password_env FROM atms
                                  WHERE is_deleted=0 ORDER BY atm_id COLLATE NOCASE""").fetchall()
    finally:
        con.close()
    by_id = {str(r["atm_id"]).casefold(): r for r in all_rows}
    rows = []
    missing = []
    for a in requested:
        r = by_id.get(a.casefold())
        if r:
            rows.append({"atm_id": r["atm_id"], "name": r["name"], "region": r["region"],
                         "password_env": r["password_env"]})
        else:
            # bazada olmayan ATM ID-ni də göndər (ad/region boş)
            rows.append({"atm_id": a, "name": "", "region": "", "password_env": None})
            missing.append(a)
    if not rows:
        return False, "Göndəriləcək ATM yoxdur.", None

    run_id = deploy_next_run_id()
    started_at = datetime.now().isoformat(timespec="seconds")
    DEPLOY_CANCEL.clear()
    with DEPLOY_LOCK:
        DEPLOY_STATE.update({"running": True, "finished": False, "cancel_requested": False,
                             "run_id": run_id, "started_at": started_at, "finished_at": None,
                             "source": source, "dest": dest_rel, "folder_name": folder_name,
                             "contents_only": bool(contents_only), "overwrite": bool(overwrite),
                             "total": len(rows), "processed": 0, "percent": 0.0, "current_atms": [],
                             "counts": {}, "ok_total": 0, "skip_total": 0, "fail_total": 0,
                             "files_total": 0, "bytes_total": 0, "logs": [],
                             "completed_results": [], "error": None})
    if missing:
        deploy_log(f"{len(missing)} ATM bazada yoxdur, yenə də göndərilir: "
                   + ", ".join(missing[:20]) + (" …" if len(missing) > 20 else ""))
    threading.Thread(target=deploy_worker,
                     args=(run_id, started_at, rows, source, dest_rel, folder_name,
                           bool(contents_only), bool(overwrite)), daemon=True).start()
    return True, None, run_id


def deploy_cancel():
    with DEPLOY_LOCK:
        if not DEPLOY_STATE["running"]:
            return False, "Aktiv folder göndərmə yoxdur."
        DEPLOY_STATE["cancel_requested"] = True
    DEPLOY_CANCEL.set()
    deploy_log("Dayandırma tələb olundu — işləyən köçürmələr təhlükəsiz dayandırılır.")
    return True, None


def deploy_worker(run_id, started_at, rows, source, dest_rel, folder_name, contents_only, overwrite):
    try:
        deploy_log(f"Folder göndərmə #{run_id} başladı. ATM: {len(rows)} · mənbə: {source} · "
                   f"təyinat: \\\\<ATM>\\{dest_rel}" + ("" if contents_only else f"\\{folder_name}")
                   + f" · paralel: {DEPLOY_MAX_WORKERS}")
        executor = ThreadPoolExecutor(max_workers=DEPLOY_MAX_WORKERS)
        pending = set()
        try:
            for row in rows:
                if DEPLOY_CANCEL.is_set():
                    break
                pending.add(executor.submit(deploy_check_one, dict(row), source, dest_rel,
                                            folder_name, contents_only, overwrite))
            while pending:
                if DEPLOY_CANCEL.is_set():
                    for f in pending:
                        f.cancel()
                    break
                done, pending = wait(pending, timeout=0.4, return_when=FIRST_COMPLETED)
                for f in done:
                    try:
                        f.result()
                    except Exception as exc:
                        deploy_log("Worker xətası: " + system_clean_error(exc))
        finally:
            executor.shutdown(wait=True, cancel_futures=DEPLOY_CANCEL.is_set())
        cancelled = DEPLOY_CANCEL.is_set()
        finished = datetime.now().isoformat(timespec="seconds")
        try:
            duration = round((datetime.fromisoformat(finished)
                              - datetime.fromisoformat(started_at)).total_seconds(), 1)
        except Exception:
            duration = 0
        with DEPLOY_LOCK:
            DEPLOY_STATE.update({"running": False, "finished": True, "finished_at": finished,
                                 "current_atms": [], "cancel_requested": cancelled})
            if not cancelled:
                DEPLOY_STATE["percent"] = 100.0
            results = [dict(x) for x in DEPLOY_STATE["completed_results"]]
            meta = {"id": run_id, "started_at": started_at, "finished_at": finished,
                    "status": "CANCELLED" if cancelled else "COMPLETED", "source": source,
                    "dest": dest_rel, "folder_name": folder_name, "contents_only": contents_only,
                    "overwrite": overwrite, "selected_count": len(rows),
                    "checked_count": DEPLOY_STATE["processed"], "duration_seconds": duration,
                    "ok_total": DEPLOY_STATE["ok_total"], "skip_total": DEPLOY_STATE["skip_total"],
                    "fail_total": DEPLOY_STATE["fail_total"], "files_total": DEPLOY_STATE["files_total"],
                    "bytes_total": DEPLOY_STATE["bytes_total"], "counts": dict(DEPLOY_STATE["counts"])}
        deploy_persist_run(run_id, meta, results)
        deploy_log("Əməliyyat dayandırıldı." if cancelled else "Folder göndərmə tamamlandı.")
    except Exception as exc:
        error = system_clean_error(exc)
        finished = datetime.now().isoformat(timespec="seconds")
        with DEPLOY_LOCK:
            DEPLOY_STATE.update({"running": False, "finished": True, "error": error,
                                 "finished_at": finished, "current_atms": []})
            results = [dict(x) for x in DEPLOY_STATE["completed_results"]]
            meta = {"id": run_id, "started_at": started_at, "finished_at": finished, "status": "FAILED",
                    "source": source, "dest": dest_rel, "folder_name": folder_name,
                    "contents_only": contents_only, "overwrite": overwrite, "selected_count": len(rows),
                    "checked_count": DEPLOY_STATE["processed"], "duration_seconds": 0, "error": error,
                    "ok_total": DEPLOY_STATE["ok_total"], "skip_total": DEPLOY_STATE["skip_total"],
                    "fail_total": DEPLOY_STATE["fail_total"], "files_total": DEPLOY_STATE["files_total"],
                    "bytes_total": DEPLOY_STATE["bytes_total"], "counts": dict(DEPLOY_STATE["counts"])}
        deploy_persist_run(run_id, meta, results)
        deploy_log("FOLDER GÖNDƏRMƏ XƏTA: " + error)


def deploy_history(limit=100):
    d = deploy_report_dir()
    runs = []
    try:
        names = [n for n in os.listdir(d) if re.fullmatch(r"deploy_\d+\.json", n)]
    except OSError:
        names = []
    names.sort(key=lambda n: int(re.findall(r"\d+", n)[0]), reverse=True)
    for name in names[:max(1, int(limit or 100))]:
        try:
            with open(os.path.join(d, name), "r", encoding="utf-8") as f:
                runs.append(json.load(f).get("run", {}))
        except Exception:
            continue
    return {"success": True, "runs": runs}


def deploy_detail(run_id):
    path = os.path.join(deploy_report_dir(), f"deploy_{int(run_id)}.json")
    if not os.path.isfile(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)
    payload["success"] = True
    return payload


def deploy_build_excel(meta, results):
    from xlsx_lite import Workbook
    wb = Workbook()
    status_az = {"COMPLETED": "TAMAMLANDI", "CANCELLED": "DAYANDIRILDI", "FAILED": "XƏTA"}
    s = wb.add_sheet("Xülasə", [("Göstərici", 42), ("Dəyər", 50)], autofilter=False)
    s.add_row(["Folder göndərmə hesabatı", f"#{meta.get('id')}"], bold=True, fill="title")
    s.add_row(["Mənbə", meta.get("source") or ""])
    s.add_row(["Folder adı", meta.get("folder_name") or ""])
    s.add_row(["Təyinat (ATM)", r"\\<ATM>\%s%s" % (meta.get("dest") or "",
              "" if meta.get("contents_only") else ("\\" + (meta.get("folder_name") or "")))])
    s.add_row(["Rejim", "yalnız içindəkilər" if meta.get("contents_only") else "folderin özü"])
    s.add_row(["Üzərinə yaz", "bəli" if meta.get("overwrite") else "xeyr"])
    s.add_row(["Başlama", _berpa_dt(meta.get("started_at"))])
    s.add_row(["Bitmə", _berpa_dt(meta.get("finished_at"))])
    s.add_row(["Status", status_az.get(meta.get("status"), meta.get("status") or "")])
    s.add_row(["Seçilmiş ATM", int(meta.get("selected_count") or 0)])
    s.add_blank()
    s.add_row(["Göndərildi", int(meta.get("ok_total") or 0)], bold=True, fill="green")
    s.add_row(["Ötürüldü (artıq var)", int(meta.get("skip_total") or 0)], fill="gray")
    s.add_row(["Uğursuz / qoşulmadı", int(meta.get("fail_total") or 0)
               + int(meta.get("counts", {}).get("QOŞULMADI", 0))],
              fill=("red" if meta.get("fail_total") else "none"))
    s.add_row(["Köçürülən fayl (cəmi)", int(meta.get("files_total") or 0)])
    s.add_row(["Köçürülən həcm", _berpa_fmt_bytes(meta.get("bytes_total"))])
    if meta.get("error"):
        s.add_blank()
        s.add_row(["Xəta", str(meta["error"])], fill="red")

    cols = [("ATM ID", 13), ("Ad", 34), ("Region", 15), ("Status", 20),
            ("Fayl", 9), ("Həcm", 11), ("PASSWORD", 12), ("Təyinat yolu", 56), ("Qeyd / xəta", 56)]
    sheet = wb.add_sheet("Hər ATM", cols)
    for r in results:
        sheet.add_row([
            r["atm_id"], r.get("name") or "", r.get("region") or "", r.get("status"),
            r.get("files_copied"), _berpa_fmt_bytes(r.get("bytes_copied")),
            r.get("password_env") or "", r.get("target_path") or "", r.get("error") or "",
        ], fill=DEPLOY_STATUS_FILL.get(r.get("status"), "none"), bold_cols=(0,))
    stamp = (meta.get("started_at") or "").replace(":", "-").replace("T", "_")[:16]
    return wb.to_bytes(), f"Folder_Gonderme_{meta.get('id')}_{stamp}.xlsx"


def deploy_excel(run_id):
    run_id = int(run_id)
    saved = os.path.join(deploy_report_dir(), f"deploy_{run_id}.xlsx")
    detail = deploy_detail(run_id)
    if detail is None:
        raise FileNotFoundError("Hesabat tapılmadı.")
    meta, results = detail.get("run", {}), detail.get("results", [])
    stamp = (meta.get("started_at") or "").replace(":", "-").replace("T", "_")[:16]
    if os.path.isfile(saved):
        with open(saved, "rb") as f:
            return f.read(), f"Folder_Gonderme_{run_id}_{stamp}.xlsx"
    return deploy_build_excel(meta, results)


# ============================================================
# ATM IP RESOLVE — hər ATM üçün IP (gethostbyname), cache + paralel
# ============================================================
ATM_IP_CACHE = {}
ATM_IP_LOCK = threading.RLock()
ATM_IP_TTL = 3600


def _resolve_one_ip(atm):
    try:
        return atm, socket.gethostbyname(atm)
    except Exception:
        return atm, None


def resolve_atm_ips(atm_ids):
    now = time.time()
    out = {}
    todo = []
    with ATM_IP_LOCK:
        for a in atm_ids:
            au = str(a or "").strip().upper()
            if not au or not ATM_ID_PATTERN.fullmatch(au):
                continue
            c = ATM_IP_CACHE.get(au)
            if c and now - c[1] < ATM_IP_TTL:
                out[au] = c[0]
            elif au not in out:
                todo.append(au)
    todo = list(dict.fromkeys(todo))[:2000]
    if todo:
        with ThreadPoolExecutor(max_workers=min(40, max(1, len(todo)))) as ex:
            for atm, ip in ex.map(_resolve_one_ip, todo):
                out[atm] = ip
                with ATM_IP_LOCK:
                    ATM_IP_CACHE[atm] = (ip, now)
    return out


# ============================================================
# SERVER EXPLORER (SRVEXP) — 172.21.12.77 serverinin bütöv disklərini gəz
#   srvdisk:<HERF> -> \\<SERVER_IP>\<HERF>$   (D / H / M / F ...)
# ============================================================
SRVEXP_DISKS = [d.strip().upper() for d in os.getenv("ATM_SRVEXP_DISKS", "D,H,M,F").split(",")
                if re.fullmatch(r"[A-Za-z]", d.strip())]


def srvexp_server_ip():
    """Server IP-sini config-dəki mənbələrdən götürür; yoxdursa default 172.21.12.77."""
    override = os.getenv("ATM_SRVEXP_IP", "").strip()
    if override:
        return override
    try:
        with SCAN_LOCK:
            paths = list(SCAN_SOURCES.values())
        for p in paths:
            m = re.match(r"\\\\([^\\]+)\\", str(p or ""))
            if m:
                return m.group(1)
    except Exception:
        pass
    try:
        con = db_connect()
        try:
            row = con.execute("SELECT address FROM config_ips ORDER BY id LIMIT 1").fetchone()
        finally:
            con.close()
        if row and row[0]:
            return str(row[0])
    except Exception:
        pass
    return "172.21.12.77"


def srvexp_disks_info():
    ip = srvexp_server_ip()
    return {"success": True, "server": ip,
            "disks": [{"letter": L, "root": "srvdisk:" + L, "label": L + "$ diski"}
                      for L in (SRVEXP_DISKS or ["D", "H", "M", "F"])]}


def srvexp_disks_usage():
    """Hər server diski (D$/H$/M$/F$) üçün həcm məlumatı: total/used/free/percent.
    GetDiskFreeSpaceExW ilə \\\\IP\\<L>$\\ paylaşımından oxunur (ayrıca parol lazım
    deyil — gəzgin onsuz da bu paylaşımlara oxu icazəsi ilə baxır). Hər disk
    paralel yoxlanılır; oxunmayan disk üçün error sahəsi qaytarılır."""
    ip = srvexp_server_ip()
    letters = list(SRVEXP_DISKS or ["D", "H", "M", "F"])

    def probe(letter):
        try:
            info, err = system_smb_disk(ip, letter, timeout=8)
        except Exception as exc:  # noqa: BLE001
            info, err = None, system_clean_error(exc)
        return letter, info, err

    results = {}
    try:
        with ThreadPoolExecutor(max_workers=max(1, min(6, len(letters)))) as ex:
            for letter, info, err in ex.map(probe, letters):
                results[letter] = (info, err)
    except Exception as exc:  # noqa: BLE001
        for letter in letters:
            results.setdefault(letter, (None, system_clean_error(exc)))

    disks = []
    for letter in letters:
        info, err = results.get(letter, (None, "Naməlum xəta"))
        if info:
            disks.append({
                "letter": letter, "label": letter + "$ diski", "ok": True, "error": None,
                "total_bytes": info["total_bytes"], "used_bytes": info["used_bytes"],
                "free_bytes": info["free_bytes"], "used_percent": info["used_percent"],
            })
        else:
            disks.append({
                "letter": letter, "label": letter + "$ diski", "ok": False,
                "error": err or "Disk oxunmadı",
                "total_bytes": None, "used_bytes": None,
                "free_bytes": None, "used_percent": None,
            })
    return {"success": True, "server": ip, "disks": disks}


# ============================================================
# ATM SMART BACKUP MANAGER (BK2) — serverdəki disklərdə saxlanmış ATM
#   şəkil/jurnal fayllarını tarixə görə hədəf qovluğa köçürür.
#   Mənbə fayllar HEÇ VAXT dəyişdirilmir/silinmir (yalnız oxu + kopya).
#   İş prinsipi: disk/ATM aşkarla → tarix+ATM seç → Dry Run → backup.
# ============================================================
BK2_LOCK = threading.RLock()
BK2_CANCEL = threading.Event()
BK2_PAUSE = threading.Event()          # set = pauzadadır
BK2_SETTINGS_PATH = os.path.join(BASE_DIR, "backup_mgr_settings.json")
BK2_DRIVE_LETTERS = "CDEFGHIJKLMNOPQRSTUVWXYZ"
BK2_DEFAULTS = {
    "atm_regex": r"[A-Za-z]\d{7}",
    "source_roots": [],               # boş → lokal sabit disklər avtomatik aşkarlanır
    "image_ext": [".jpg", ".jpeg", ".png", ".bmp", ".gif", ".webp"],
    "log_ext": [".log", ".txt", ".xml", ".csv", ".json", ".jrn"],
    "date_mode": "filename",          # filename | subfolder | mtime
    "workers": 4,
    "retries": 2,
    "verify": "size",                 # size | sha256
    "incremental": True,
    "scan_depth": 3,
}
BK2_STATE = {
    "running": False, "finished": False, "paused": False, "phase": "",
    "job_id": None, "mode": "", "dest": "", "date_from": "", "date_to": "",
    "atm_total": 0, "atm_done": 0, "current_atm": "", "current_file": "",
    "files_total": 0, "files_done": 0, "files_skipped": 0,
    "bytes_total": 0, "bytes_done": 0, "speed_bps": 0.0, "eta_sec": None,
    "workers_active": 0, "ok_atms": 0, "failed_atms": 0,
    "started_at": None, "finished_at": None, "status": "", "error": None,
    "logs": [], "failed": [],
}


def bk2_load_settings():
    data = dict(BK2_DEFAULTS)
    try:
        with open(BK2_SETTINGS_PATH, "r", encoding="utf-8") as fh:
            saved = json.load(fh)
        if isinstance(saved, dict):
            data.update({k: saved[k] for k in BK2_DEFAULTS if k in saved})
    except Exception:
        pass
    # sanitize
    try:
        data["workers"] = max(1, min(32, int(data["workers"])))
    except Exception:
        data["workers"] = 4
    try:
        data["retries"] = max(0, min(10, int(data["retries"])))
    except Exception:
        data["retries"] = 2
    try:
        data["scan_depth"] = max(1, min(8, int(data["scan_depth"])))
    except Exception:
        data["scan_depth"] = 3
    if data["date_mode"] not in ("filename", "subfolder", "mtime"):
        data["date_mode"] = "filename"
    if data["verify"] not in ("size", "sha256"):
        data["verify"] = "size"
    data["image_ext"] = [str(e).lower() if str(e).startswith(".") else "." + str(e).lower()
                         for e in (data.get("image_ext") or [])]
    data["log_ext"] = [str(e).lower() if str(e).startswith(".") else "." + str(e).lower()
                       for e in (data.get("log_ext") or [])]
    try:
        re.compile(data["atm_regex"])
    except Exception:
        data["atm_regex"] = BK2_DEFAULTS["atm_regex"]
    return data


def bk2_save_settings(patch):
    cur = bk2_load_settings()
    for k in BK2_DEFAULTS:
        if k in patch:
            cur[k] = patch[k]
    cur = {k: cur[k] for k in BK2_DEFAULTS}
    with open(BK2_SETTINGS_PATH, "w", encoding="utf-8") as fh:
        json.dump(cur, fh, ensure_ascii=False, indent=2)
    return bk2_load_settings()


def bk2_detect_drives():
    """Serverdəki lokal sabit diskləri (D:\\, F:\\, ...) avtomatik aşkarla."""
    found = []
    for L in BK2_DRIVE_LETTERS:
        p = L + ":\\"
        try:
            if os.path.isdir(p):
                found.append(p)
        except Exception:
            pass
    return found


def bk2_sources(settings):
    roots = [r for r in (settings.get("source_roots") or []) if str(r).strip()]
    if not roots:
        roots = bk2_detect_drives()
    # normalize
    out = []
    seen = set()
    for r in roots:
        r = str(r).strip()
        key = r.rstrip("\\/").lower()
        if key and key not in seen:
            seen.add(key)
            out.append(r)
    return out


def bk2_log(msg):
    line = datetime.now().strftime("%H:%M:%S") + "  " + system_clean_error(msg)
    with BK2_LOCK:
        BK2_STATE["logs"].append(line)
        BK2_STATE["logs"] = BK2_STATE["logs"][-500:]


def bk2_snapshot():
    with BK2_LOCK:
        snap = {k: (list(v) if isinstance(v, list) else v) for k, v in BK2_STATE.items()}
    snap["logs"] = snap["logs"][-120:]
    return snap


def bk2_ensure_history_table():
    con = db_connect()
    try:
        con.execute("""CREATE TABLE IF NOT EXISTS backup_jobs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            started_at TEXT, finished_at TEXT, status TEXT, mode TEXT,
            date_from TEXT, date_to TEXT, file_types TEXT, dest TEXT,
            atm_total INTEGER, files_copied INTEGER, files_skipped INTEGER,
            bytes_copied INTEGER, ok_atms INTEGER, failed_atms INTEGER,
            error TEXT, detail TEXT)""")
        con.commit()
    finally:
        con.close()


_BK2_DATE_RX = re.compile(r"(20\d{2})[-_.]?(0[1-9]|1[0-2])[-_.]?(0[1-9]|[12]\d|3[01])")


def bk2_parse_date_token(text):
    """Mətndən YYYYMMDD / YYYY-MM-DD / YYYY_MM_DD tarixini çıxarır."""
    if not text:
        return None
    m = _BK2_DATE_RX.search(str(text))
    if not m:
        return None
    try:
        return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None


def bk2_file_date(full_path, name, parent_name, mode):
    if mode == "filename":
        return bk2_parse_date_token(name)
    if mode == "subfolder":
        return bk2_parse_date_token(parent_name)
    # mtime
    try:
        return datetime.fromtimestamp(os.path.getmtime(full_path)).date()
    except Exception:
        return None


def bk2_kind_of(name, settings):
    ext = os.path.splitext(name)[1].lower()
    if ext in settings["image_ext"]:
        return "Images"
    if ext in settings["log_ext"]:
        return "Logs"
    return None


def bk2_iter_atm_files(atm_folder, date_from, date_to, want_images, want_logs, settings, cancel=None):
    """atm_folder altındakı faylları tarix+növ filtrindən keçirib verir.
    (src_path, kind, size, file_date) qaytarır."""
    mode = settings["date_mode"]
    for walk_root, dirs, files in os.walk(atm_folder):
        if cancel is not None and cancel.is_set():
            return
        # simvolik link dövrlərinin qarşısını al
        dirs[:] = [d for d in dirs if not os.path.islink(os.path.join(walk_root, d))]
        parent_name = os.path.basename(walk_root)
        for fn in files:
            kind = bk2_kind_of(fn, settings)
            if kind is None:
                continue
            if kind == "Images" and not want_images:
                continue
            if kind == "Logs" and not want_logs:
                continue
            full = os.path.join(walk_root, fn)
            if os.path.islink(full):
                continue
            fdate = bk2_file_date(full, fn, parent_name, mode)
            if fdate is None or fdate < date_from or fdate > date_to:
                continue
            try:
                size = os.path.getsize(full)
            except OSError:
                continue
            yield full, kind, size, fdate


def bk2_discover(settings):
    """Mənbə disklərində ATM ID-lərini aşkarla (konfiqurasiya edilən regex)."""
    rx = re.compile(r"^(?:" + settings["atm_regex"] + r")$", re.IGNORECASE)
    depth = settings["scan_depth"]
    sources = bk2_sources(settings)
    atms = {}
    errors = []
    for root in sources:
        base = root.rstrip("\\/")
        base_depth = base.count(os.sep)
        try:
            for dirpath, dirnames, _files in os.walk(root, topdown=True):
                rel_depth = dirpath.rstrip("\\/").count(os.sep) - base_depth
                keep = []
                for d in dirnames:
                    if rx.match(d):
                        aid = d.upper()
                        rec = atms.setdefault(aid, {"id": aid, "paths": [], "sources": set()})
                        rec["paths"].append(os.path.join(dirpath, d))
                        rec["sources"].add(root)
                        # ATM qovluğunun içinə aşkarlama üçün girmirik (sürət)
                    elif rel_depth + 1 < depth and not os.path.islink(os.path.join(dirpath, d)):
                        keep.append(d)
                dirnames[:] = keep
        except Exception as exc:
            errors.append(root + ": " + system_clean_error(exc))
    out = []
    for aid in sorted(atms):
        rec = atms[aid]
        out.append({"id": aid, "paths": rec["paths"],
                    "sources": sorted(rec["sources"]), "path_count": len(rec["paths"])})
    return {"success": True, "atms": out, "count": len(out),
            "sources": sources, "errors": errors}


def bk2_resolve_atm_paths(settings, atm_ids=None):
    """Seçilmiş (və ya bütün) ATM-lər üçün qovluq yollarını tapır."""
    disc = bk2_discover(settings)
    wanted = set(a.upper() for a in atm_ids) if atm_ids else None
    result = {}
    for rec in disc["atms"]:
        if wanted is None or rec["id"] in wanted:
            result[rec["id"]] = rec["paths"]
    return result, disc


def bk2_date_bounds(data):
    df = bk2_parse_date_token(data.get("date_from") or "") or bk2_parse_date_token(
        (data.get("date_from") or "").replace("-", ""))
    dt = bk2_parse_date_token(data.get("date_to") or "") or df
    if df is None:
        raise ValueError("Başlanğıc tarix düzgün deyil (YYYY-MM-DD).")
    if dt is None:
        dt = df
    if dt < df:
        df, dt = dt, df
    return df, dt


def bk2_plan(data):
    """Dry Run: seçilmiş ATM/tarix üçün uyğun fayl sayı + həcm + hədəf önizləmə."""
    settings = bk2_load_settings()
    df, dt = bk2_date_bounds(data)
    ftype = (data.get("file_types") or "both").lower()
    want_images = ftype in ("both", "images")
    want_logs = ftype in ("both", "logs")
    mode = (data.get("mode") or "all").lower()
    atm_ids = data.get("atm_ids") if mode == "selected" else None
    paths_by_atm, _disc = bk2_resolve_atm_paths(settings, atm_ids)
    per_atm = []
    total_files = total_bytes = 0
    for aid in sorted(paths_by_atm):
        files = bytes_ = 0
        for folder in paths_by_atm[aid]:
            for _src, _kind, size, _fd in bk2_iter_atm_files(
                    folder, df, dt, want_images, want_logs, settings):
                files += 1
                bytes_ += size
        if files:
            per_atm.append({"id": aid, "files": files, "bytes": bytes_})
            total_files += files
            total_bytes += bytes_
    return {"success": True, "date_from": df.isoformat(), "date_to": dt.isoformat(),
            "atm_count": len(per_atm), "files_total": total_files,
            "bytes_total": total_bytes, "per_atm": per_atm,
            "date_mode": settings["date_mode"],
            "target_example": (data.get("dest") or "F:\\ATM_BACKUP")
            + r"\<ATM_ID>\%s\Images|Logs" % df.isoformat()}


def bk2_free_bytes(path):
    try:
        if path.startswith("\\\\"):
            # UNC → GetDiskFreeSpaceExW
            share = path
            info, _err = system_smb_disk_path(share)
            if info:
                return info
        usage = shutil.disk_usage(path)
        return usage.free
    except Exception:
        return None


def system_smb_disk_path(path):
    """Verilən (UNC/lokal) yol üçün boş bayt sayını GetDiskFreeSpaceExW ilə oxu."""
    try:
        proc = subprocess.run(
            [sys.executable, "-c", SYSTEM_DISK_PROBE_SCRIPT, path],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=8, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        answer = json.loads((proc.stdout or "").strip())
        if answer.get("ok"):
            return int(answer["free"]), None
        return None, answer.get("error")
    except Exception as exc:
        return None, system_clean_error(exc)


def bk2_unique_target(target):
    """Hədəfdə eyni adlı fayl varsa, təhlükəsiz yeni ad qaytarır (üzərinə yazmır)."""
    if not os.path.exists(target):
        return target
    base, ext = os.path.splitext(target)
    i = 1
    while True:
        cand = "%s_%d%s" % (base, i, ext)
        if not os.path.exists(cand):
            return cand
        i += 1


def bk2_sha256(path):
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def bk2_wait_if_paused():
    while BK2_PAUSE.is_set() and not BK2_CANCEL.is_set():
        with BK2_LOCK:
            BK2_STATE["paused"] = True
        time.sleep(0.3)
    with BK2_LOCK:
        BK2_STATE["paused"] = False


def bk2_copy_one(src, dest_file, settings):
    """Tək faylı təhlükəsiz köçür. (copied_bool, skipped_bool, bytes) qaytarır."""
    try:
        ssize = os.path.getsize(src)
    except OSError:
        ssize = -1
    # incremental: eyni ölçülü fayl varsa ötür
    if settings["incremental"] and os.path.exists(dest_file):
        try:
            if os.path.getsize(dest_file) == ssize and ssize >= 0:
                return False, True, 0
        except OSError:
            pass
    # toqquşma: fərqli ölçülü eyni adlı fayl → yeni ad
    target = dest_file
    if os.path.exists(dest_file):
        try:
            if os.path.getsize(dest_file) != ssize:
                target = bk2_unique_target(dest_file)
        except OSError:
            target = bk2_unique_target(dest_file)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    last_err = None
    for attempt in range(settings["retries"] + 1):
        if BK2_CANCEL.is_set():
            raise BerpaCancelled()
        try:
            shutil.copy2(src, target)
            # yoxlama
            if os.path.getsize(target) != ssize and ssize >= 0:
                raise IOError("Ölçü uyğunsuzluğu")
            if settings["verify"] == "sha256" and ssize >= 0:
                if bk2_sha256(src) != bk2_sha256(target):
                    raise IOError("SHA-256 uyğunsuzluğu")
            return True, False, (ssize if ssize >= 0 else 0)
        except Exception as exc:
            last_err = exc
            time.sleep(0.2 * (attempt + 1))
    raise last_err or IOError("Köçürmə alınmadı")


def bk2_backup_atm(aid, folders, dest, df, dt, want_images, want_logs, settings):
    """Tək ATM üçün bütün uyğun faylları hədəfə köçürür."""
    copied = skipped = 0
    cbytes = 0
    datestr = df.isoformat() if df == dt else (df.isoformat() + "_" + dt.isoformat())
    for folder in folders:
        for src, kind, size, fdate in bk2_iter_atm_files(
                folder, df, dt, want_images, want_logs, settings, BK2_CANCEL):
            if BK2_CANCEL.is_set():
                raise BerpaCancelled()
            bk2_wait_if_paused()
            day = fdate.isoformat()
            dest_dir = os.path.join(dest, aid, day, kind)
            dest_file = os.path.join(dest_dir, os.path.basename(src))
            with BK2_LOCK:
                BK2_STATE["current_atm"] = aid
                BK2_STATE["current_file"] = os.path.basename(src)
            did_copy, did_skip, nb = bk2_copy_one(src, dest_file, settings)
            if did_copy:
                copied += 1
                cbytes += nb
            elif did_skip:
                skipped += 1
            with BK2_LOCK:
                BK2_STATE["files_done"] += 1 if did_copy else 0
                BK2_STATE["files_skipped"] += 1 if did_skip else 0
                BK2_STATE["bytes_done"] += nb
    return copied, skipped, cbytes


def bk2_worker(data):
    settings = bk2_load_settings()
    df, dt = data["_df"], data["_dt"]
    dest = data["dest"]
    want_images, want_logs = data["_wi"], data["_wl"]
    paths_by_atm = data["_paths"]
    workers = settings["workers"]
    t_start = time.monotonic()
    last_t = t_start
    last_bytes = 0
    try:
        bk2_log("Backup başladı: %d ATM, %s–%s" % (len(paths_by_atm), df.isoformat(), dt.isoformat()))

        def speed_tick():
            nonlocal last_t, last_bytes
            now = time.monotonic()
            with BK2_LOCK:
                done = BK2_STATE["bytes_done"]
                total = BK2_STATE["bytes_total"]
            dtm = now - last_t
            if dtm >= 1.0:
                sp = (done - last_bytes) / dtm
                last_t, last_bytes = now, done
                remain = max(0, total - done)
                with BK2_LOCK:
                    BK2_STATE["speed_bps"] = sp
                    BK2_STATE["eta_sec"] = (remain / sp) if sp > 1 else None

        def run_atm(aid):
            if BK2_CANCEL.is_set():
                return aid, None, "cancel"
            with BK2_LOCK:
                BK2_STATE["workers_active"] += 1
            try:
                c, s, b = bk2_backup_atm(aid, paths_by_atm[aid], dest, df, dt,
                                         want_images, want_logs, settings)
                speed_tick()
                return aid, (c, s, b), None
            except BerpaCancelled:
                return aid, None, "cancel"
            except Exception as exc:
                return aid, None, system_clean_error(exc)
            finally:
                with BK2_LOCK:
                    BK2_STATE["workers_active"] -= 1
                    BK2_STATE["atm_done"] += 1

        with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
            futs = {ex.submit(run_atm, aid): aid for aid in sorted(paths_by_atm)}
            for fut in futs:
                aid, res, err = fut.result()
                speed_tick()
                if err == "cancel":
                    continue
                if err:
                    with BK2_LOCK:
                        BK2_STATE["failed_atms"] += 1
                        BK2_STATE["failed"].append({"atm": aid, "error": err})
                    bk2_log("XƏTA %s: %s" % (aid, err))
                else:
                    with BK2_LOCK:
                        BK2_STATE["ok_atms"] += 1
                    bk2_log("OK %s: %d köçürüldü, %d ötürüldü" % (aid, res[0], res[1]))

        status = "DAYANDIRILDI" if BK2_CANCEL.is_set() else "BİTDİ"
        with BK2_LOCK:
            BK2_STATE["status"] = status
            BK2_STATE["error"] = None
        bk2_log("Backup " + status.lower() + ".")
    except Exception as exc:
        with BK2_LOCK:
            BK2_STATE["status"] = "XƏTA"
            BK2_STATE["error"] = system_clean_error(exc)
        bk2_log("XƏTA: " + system_clean_error(exc))
    finally:
        with BK2_LOCK:
            BK2_STATE["running"] = False
            BK2_STATE["finished"] = True
            BK2_STATE["paused"] = False
            BK2_STATE["finished_at"] = datetime.now().isoformat(timespec="seconds")
            snap = dict(BK2_STATE)
        bk2_save_history(snap)


def bk2_save_history(snap):
    try:
        bk2_ensure_history_table()
        con = db_connect()
        try:
            con.execute(
                """INSERT INTO backup_jobs(started_at,finished_at,status,mode,date_from,
                   date_to,file_types,dest,atm_total,files_copied,files_skipped,
                   bytes_copied,ok_atms,failed_atms,error,detail)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (snap.get("started_at"), snap.get("finished_at"), snap.get("status"),
                 snap.get("mode"), snap.get("date_from"), snap.get("date_to"),
                 snap.get("file_types") if snap.get("file_types") else "",
                 snap.get("dest"), snap.get("atm_total"), snap.get("files_done"),
                 snap.get("files_skipped"), snap.get("bytes_done"), snap.get("ok_atms"),
                 snap.get("failed_atms"), snap.get("error"),
                 json.dumps(snap.get("failed", []), ensure_ascii=False)))
            con.commit()
        finally:
            con.close()
    except Exception:
        pass


def bk2_start(data):
    with BK2_LOCK:
        if BK2_STATE["running"]:
            return False, "Backup artıq işləyir.", None
    settings = bk2_load_settings()
    df, dt = bk2_date_bounds(data)
    ftype = (data.get("file_types") or "both").lower()
    want_images = ftype in ("both", "images")
    want_logs = ftype in ("both", "logs")
    if not (want_images or want_logs):
        return False, "Ən azı bir fayl növü seçin (Images / Logs).", None
    dest = str(data.get("dest") or "").strip()
    if not dest:
        return False, "Hədəf qovluq yolunu yazın.", None
    if ".." in dest.replace("\\", "/").split("/"):
        return False, "Hədəf yolu düzgün deyil.", None
    mode = (data.get("mode") or "all").lower()
    atm_ids = data.get("atm_ids") if mode == "selected" else None
    if mode == "selected" and not atm_ids:
        return False, "SELECTED rejim üçün ən azı bir ATM seçin.", None
    paths_by_atm, _disc = bk2_resolve_atm_paths(settings, atm_ids)
    if not paths_by_atm:
        return False, "Seçimə uyğun ATM tapılmadı.", None

    # Hədəf mənbə ilə üst-üstə düşməsin (backup hədəfi təkrar skan edilməsin)
    dest_norm = os.path.normcase(os.path.abspath(dest).rstrip("\\/"))
    for folders in paths_by_atm.values():
        for f in folders:
            fn = os.path.normcase(os.path.abspath(f).rstrip("\\/"))
            if dest_norm == fn or fn.startswith(dest_norm + os.sep) or dest_norm.startswith(fn + os.sep):
                return False, "Hədəf qovluq mənbə ilə üst-üstə düşür — başqa hədəf seçin.", None

    # plan (fayl sayı/həcm) + boş yer yoxlaması
    total_files = total_bytes = 0
    for aid in paths_by_atm:
        for folder in paths_by_atm[aid]:
            for _s, _k, size, _fd in bk2_iter_atm_files(folder, df, dt, want_images, want_logs, settings):
                total_files += 1
                total_bytes += size
    if total_files == 0:
        return False, "Seçilmiş tarix/ATM üçün fayl tapılmadı.", None
    try:
        os.makedirs(dest, exist_ok=True)
    except OSError as exc:
        return False, "Hədəf qovluq yaradılmadı: " + system_clean_error(exc), None
    free = bk2_free_bytes(dest if not dest.startswith("\\\\") else dest)
    if isinstance(free, int) and free < total_bytes:
        return False, ("Hədəf diskdə boş yer çatmır: lazım %s, boş %s"
                       % (bk2_fmt_size(total_bytes), bk2_fmt_size(free))), None

    BK2_CANCEL.clear()
    BK2_PAUSE.clear()
    with BK2_LOCK:
        BK2_STATE.update({
            "running": True, "finished": False, "paused": False, "phase": "backup",
            "job_id": int(time.time()), "mode": mode, "dest": dest,
            "date_from": df.isoformat(), "date_to": dt.isoformat(),
            "file_types": ("Images+Logs" if (want_images and want_logs) else
                           ("Images" if want_images else "Logs")),
            "atm_total": len(paths_by_atm), "atm_done": 0, "current_atm": "", "current_file": "",
            "files_total": total_files, "files_done": 0, "files_skipped": 0,
            "bytes_total": total_bytes, "bytes_done": 0, "speed_bps": 0.0, "eta_sec": None,
            "workers_active": 0, "ok_atms": 0, "failed_atms": 0,
            "started_at": datetime.now().isoformat(timespec="seconds"),
            "finished_at": None, "status": "İşləyir", "error": None, "logs": [], "failed": [],
        })
    data = dict(data)
    data.update({"_df": df, "_dt": dt, "_wi": want_images, "_wl": want_logs,
                 "_paths": paths_by_atm, "dest": dest})
    threading.Thread(target=bk2_worker, args=(data,), daemon=True).start()
    return True, None, {"files_total": total_files, "bytes_total": total_bytes,
                        "atm_total": len(paths_by_atm)}


def bk2_pause():
    with BK2_LOCK:
        if not BK2_STATE["running"]:
            return False, "Aktiv backup yoxdur."
    BK2_PAUSE.set()
    bk2_log("Pauza tələb olundu.")
    return True, None


def bk2_resume():
    with BK2_LOCK:
        if not BK2_STATE["running"]:
            return False, "Aktiv backup yoxdur."
    BK2_PAUSE.clear()
    bk2_log("Davam etdirilir.")
    return True, None


def bk2_cancel():
    with BK2_LOCK:
        if not BK2_STATE["running"]:
            return False, "Aktiv backup yoxdur."
    BK2_CANCEL.set()
    BK2_PAUSE.clear()
    bk2_log("Dayandırma tələb olundu.")
    return True, None


def bk2_fmt_size(b):
    try:
        b = float(b)
    except Exception:
        return "—"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if b < 1024 or unit == "TB":
            return ("%.0f %s" % (b, unit)) if unit in ("B", "KB") else ("%.2f %s" % (b, unit))
        b /= 1024
    return "%.2f TB" % b


def bk2_history(limit=50):
    bk2_ensure_history_table()
    con = db_connect()
    try:
        rows = con.execute(
            """SELECT id,started_at,finished_at,status,mode,date_from,date_to,file_types,
               dest,atm_total,files_copied,files_skipped,bytes_copied,ok_atms,failed_atms,error
               FROM backup_jobs ORDER BY id DESC LIMIT ?""", (int(limit),)).fetchall()
    finally:
        con.close()
    cols = ["id", "started_at", "finished_at", "status", "mode", "date_from", "date_to",
            "file_types", "dest", "atm_total", "files_copied", "files_skipped",
            "bytes_copied", "ok_atms", "failed_atms", "error"]
    return {"success": True, "jobs": [dict(zip(cols, r)) for r in rows]}


# ============================================================
# SERVER DİSKLƏR ARASI KÖÇÜR / YERİNİ DƏYİŞ (SRVMOVE)
#   77 serverinin öz diskləri arasında (D$/H$/M$/F$) fayl və qovluqları
#   KOPYALAYIR və ya KÖÇÜRÜR (move = kopya + mənbəni sil).
#   Hədəf mənbə ilə üst-üstə düşə bilməz; traversal explorer_path ilə qorunur.
# ============================================================
BK3_LOCK = threading.RLock()
BK3_CANCEL = threading.Event()
BK3_STATE = {
    "running": False, "finished": False, "op": "", "src": "", "dst": "",
    "items_total": 0, "items_done": 0, "current": "",
    "files_total": 0, "files_done": 0, "files_skipped": 0,
    "bytes_total": 0, "bytes_done": 0, "speed_bps": 0.0, "eta_sec": None,
    "ok_items": 0, "failed_items": 0, "status": "", "error": None,
    "started_at": None, "finished_at": None, "logs": [], "failed": [],
}


def srvmove_log(msg):
    line = datetime.now().strftime("%H:%M:%S") + "  " + system_clean_error(msg)
    with BK3_LOCK:
        BK3_STATE["logs"].append(line)
        BK3_STATE["logs"] = BK3_STATE["logs"][-500:]


def srvmove_snapshot():
    with BK3_LOCK:
        snap = {k: (list(v) if isinstance(v, list) else v) for k, v in BK3_STATE.items()}
    snap["logs"] = snap["logs"][-120:]
    return snap


def srvmove_resolve(disk, rel):
    """srvdisk:<HERF> → (\\IP\\<HERF>$ , tam yol). explorer_path traversal qoruyur."""
    letter = str(disk or "").strip().upper()
    if not re.fullmatch(r"[A-Z]", letter):
        raise ValueError("Disk hərfi düzgün deyil.")
    _atm, base, path = explorer_path("srvdisk:" + letter, rel or "")
    return base, path


def srvmove_collect(item_abs, item_name):
    """Seçilmiş element (fayl/qovluq) üçün (mənbə_fayl, element_daxili_nisbi_yol)."""
    out = []
    if os.path.isfile(item_abs):
        out.append((item_abs, item_name))
        return out
    for walk_root, dirs, files in os.walk(item_abs):
        dirs[:] = [d for d in dirs if not os.path.islink(os.path.join(walk_root, d))]
        rel_in = os.path.relpath(walk_root, os.path.dirname(item_abs))
        for fn in files:
            full = os.path.join(walk_root, fn)
            if os.path.islink(full):
                continue
            out.append((full, os.path.join(rel_in, fn)))
    return out


_BK3_TICK = {"t": 0.0, "b": 0}


def srvmove_tick():
    """Sürət/ETA-nı ən çox saniyədə bir yeniləyir."""
    now = time.monotonic()
    with BK3_LOCK:
        done = BK3_STATE["bytes_done"]
        total = BK3_STATE["bytes_total"]
    if _BK3_TICK["t"] <= 0:
        _BK3_TICK["t"] = now
        _BK3_TICK["b"] = done
        return
    dtm = now - _BK3_TICK["t"]
    if dtm >= 1.0:
        sp = (done - _BK3_TICK["b"]) / dtm
        _BK3_TICK["t"] = now
        _BK3_TICK["b"] = done
        with BK3_LOCK:
            BK3_STATE["speed_bps"] = sp
            BK3_STATE["eta_sec"] = ((total - done) / sp) if sp > 1 else None


def srvmove_is_local():
    """Python engine elə 77 serverin özündə işləyirsə True — onda UNC əvəzinə
    lokal disk yolları (D:\\ → H:\\) işlədilir (daha sürətli). Mühit dəyişəni ilə
    məcbur etmək olar: ATM_SRVEXP_LOCAL=1 / ATM_SRVEXP_REMOTE=1."""
    if os.getenv("ATM_SRVEXP_LOCAL", "").strip().lower() in ("1", "true", "yes"):
        return True
    if os.getenv("ATM_SRVEXP_REMOTE", "").strip().lower() in ("1", "true", "yes"):
        return False
    try:
        ip = srvexp_server_ip()
        local = {"127.0.0.1", "::1", "localhost"}
        host = socket.gethostname()
        local.add(host.lower())
        try:
            for res in socket.getaddrinfo(host, None):
                local.add(str(res[4][0]))
        except Exception:
            pass
        sip = ip
        try:
            sip = socket.gethostbyname(ip)
        except Exception:
            pass
        return ip.lower() in local or sip in local
    except Exception:
        return False


def srvmove_exec_path(disk, rel):
    """Köçürmə üçün real yol: lokal rejimdə L:\\..., əks halda \\IP\\L$\\..."""
    letter = str(disk).strip().upper()
    rel = (rel or "").replace("/", "\\").strip("\\")
    if srvmove_is_local() and os.path.isdir(letter + ":\\"):
        base = letter + ":\\"
        return os.path.join(base, rel) if rel else base
    base = "\\\\" + srvexp_server_ip() + "\\" + letter + "$"
    return base + ("\\" + rel if rel else "")


def srvmove_has_robocopy():
    try:
        return shutil.which("robocopy") is not None
    except Exception:
        return False


def _srvmove_mt():
    try:
        return max(1, min(128, int(os.getenv("ATM_SRVMOVE_MT", "16"))))
    except Exception:
        return 16


def srvmove_robocopy_item(item, src_item_abs, dst_root, conflict, base_files, base_bytes):
    """Tək elementi robocopy /MT ilə köçürür. Mənbə silinmir (move-u worker edir)."""
    name = item["name"]
    is_dir = (item["kind"] == "folder")
    if is_dir:
        src_dir = src_item_abs
        dst_dir = os.path.join(dst_root, name)
        file_args = []
        tree = ["/E"]
    else:
        src_dir = os.path.dirname(src_item_abs)
        dst_dir = dst_root
        file_args = [name]
        tree = []
    cmd = ["robocopy", src_dir, dst_dir] + file_args + tree + [
        "/MT:" + str(_srvmove_mt()), "/R:2", "/W:2", "/COPY:DAT", "/DCOPY:T",
        "/NP", "/NJH", "/NJS", "/NC", "/NDL", "/BYTES"]
    if conflict == "skip":
        cmd += ["/XC", "/XN", "/XO"]   # mövcud faylları heç cür dəyişmə
    copied_f = 0
    copied_b = 0
    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        encoding="utf-8", errors="replace", bufsize=1,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    try:
        for line in proc.stdout:
            if BK3_CANCEL.is_set():
                try:
                    proc.terminate()
                except Exception:
                    pass
                raise BerpaCancelled()
            t = line.strip()
            if not t:
                continue
            parts = t.split()
            if parts and parts[0].isdigit():
                try:
                    sz = int(parts[0])
                except ValueError:
                    continue
                copied_f += 1
                copied_b += sz
                with BK3_LOCK:
                    BK3_STATE["files_done"] = base_files + copied_f
                    BK3_STATE["bytes_done"] = base_bytes + copied_b
                    BK3_STATE["current"] = (parts[-1] if len(parts) > 1 else name)[-90:]
                srvmove_tick()
    finally:
        try:
            if proc.stdout:
                proc.stdout.close()
        except Exception:
            pass
        rc = proc.wait()
    if rc is not None and rc >= 8:
        raise IOError("robocopy xətası (rc=%d): %s" % (rc, name))


def srvmove_python_item(item, src_item_abs, dst_root, conflict, base_files, base_bytes):
    """robocopy olmayan mühit / 'yeni ad ver' siyasəti üçün təhlükəsiz Python köçürməsi."""
    copied_f = 0
    copied_b = 0
    if item["kind"] == "file":
        files = [(src_item_abs, item["name"])]
    else:
        files = []
        for walk_root, dirs, fns in os.walk(src_item_abs):
            dirs[:] = [d for d in dirs if not os.path.islink(os.path.join(walk_root, d))]
            rel = os.path.relpath(walk_root, src_item_abs)
            for fn in fns:
                full = os.path.join(walk_root, fn)
                if os.path.islink(full):
                    continue
                rel_in = fn if rel == "." else os.path.join(rel, fn)
                files.append((full, os.path.join(item["name"], rel_in)))
    for src_file, rel_in in files:
        if BK3_CANCEL.is_set():
            raise BerpaCancelled()
        try:
            sz = os.path.getsize(src_file)
        except OSError:
            sz = 0
        target = os.path.join(dst_root, rel_in)
        if os.path.exists(target):
            if conflict == "skip":
                with BK3_LOCK:
                    BK3_STATE["files_skipped"] += 1
                continue
            if conflict == "rename":
                target = bk2_unique_target(target)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        shutil.copy2(src_file, target)
        if sz and os.path.getsize(target) != sz:
            raise IOError("Ölçü uyğunsuzluğu: " + os.path.basename(src_file))
        copied_f += 1
        copied_b += sz
        with BK3_LOCK:
            BK3_STATE["files_done"] = base_files + copied_f
            BK3_STATE["bytes_done"] = base_bytes + copied_b
            BK3_STATE["current"] = rel_in[-90:]
        srvmove_tick()


def srvmove_worker(data):
    op = data["op"]
    conflict = data["conflict"]
    src_disk = data.get("src_disk")
    src_rel = data.get("src_rel") or ""
    dst_disk = data.get("dst_disk")
    dst_rel = data.get("dst_rel") or ""
    items = data["_items"]
    # Sürətli yol: robocopy var VƏ toqquşma siyasəti robocopy-yə uyğundur.
    # 'rename' (yeni ad ver) üçün təhlükəsiz Python yolu işlədilir.
    use_rc = srvmove_has_robocopy() and conflict in ("skip", "overwrite")
    local = srvmove_is_local()
    _BK3_TICK["t"] = 0.0
    _BK3_TICK["b"] = 0
    base_files = 0
    base_bytes = 0
    try:
        mode = ("robocopy /MT:%d" % _srvmove_mt()) if use_rc else "Python"
        where = "lokal disk" if local else "UNC (şəbəkə)"
        srvmove_log("%s başladı — engine: %s, yol: %s, %d element" % (
            ("Köçürmə" if op == "move" else "Kopya"), mode, where, len(items)))
        dst_root = srvmove_exec_path(dst_disk, dst_rel)
        for item in items:
            if BK3_CANCEL.is_set():
                break
            with BK3_LOCK:
                BK3_STATE["current"] = item["name"]
            src_item_abs = srvmove_exec_path(
                src_disk, (src_rel + "\\" + item["name"]) if src_rel else item["name"])
            item_ok = True
            try:
                if use_rc:
                    srvmove_robocopy_item(item, src_item_abs, dst_root, conflict, base_files, base_bytes)
                else:
                    srvmove_python_item(item, src_item_abs, dst_root, conflict, base_files, base_bytes)
                if op == "move" and not BK3_CANCEL.is_set():
                    if os.path.isdir(src_item_abs):
                        shutil.rmtree(src_item_abs)
                    else:
                        os.remove(src_item_abs)
                    srvmove_log("Mənbə silindi: " + item["name"])
            except BerpaCancelled:
                raise
            except Exception as exc:
                item_ok = False
                with BK3_LOCK:
                    BK3_STATE["failed_items"] += 1
                    BK3_STATE["failed"].append({"item": item["name"], "error": system_clean_error(exc)})
                srvmove_log("XƏTA %s: %s" % (item["name"], system_clean_error(exc)))
            base_files += int(item.get("files", 0) or 0)
            base_bytes += int(item.get("bytes", 0) or 0)
            with BK3_LOCK:
                if item_ok:
                    BK3_STATE["ok_items"] += 1
                    BK3_STATE["files_done"] = base_files
                    BK3_STATE["bytes_done"] = base_bytes
                BK3_STATE["items_done"] += 1
            srvmove_tick()
        status = "DAYANDIRILDI" if BK3_CANCEL.is_set() else "BİTDİ"
        with BK3_LOCK:
            BK3_STATE["status"] = status
        srvmove_log(("Köçürmə " if op == "move" else "Kopya ") + status.lower() + ".")
    except BerpaCancelled:
        with BK3_LOCK:
            BK3_STATE["status"] = "DAYANDIRILDI"
        srvmove_log("İstifadəçi dayandırdı.")
    except Exception as exc:
        with BK3_LOCK:
            BK3_STATE["status"] = "XƏTA"
            BK3_STATE["error"] = system_clean_error(exc)
        srvmove_log("XƏTA: " + system_clean_error(exc))
    finally:
        with BK3_LOCK:
            BK3_STATE["running"] = False
            BK3_STATE["finished"] = True
            BK3_STATE["finished_at"] = datetime.now().isoformat(timespec="seconds")


def srvmove_start(data):
    with BK3_LOCK:
        if BK3_STATE["running"]:
            return False, "Köçürmə artıq işləyir.", None
    op = (data.get("op") or "copy").lower()
    if op not in ("copy", "move"):
        return False, "Əməliyyat düzgün deyil (copy/move).", None
    conflict = (data.get("conflict") or "rename").lower()
    if conflict not in ("rename", "skip", "overwrite"):
        conflict = "rename"
    names = data.get("items") or []
    if not isinstance(names, list) or not names:
        return False, "Ən azı bir fayl/qovluq seçin.", None
    try:
        _src_base, src_path = srvmove_resolve(data.get("src_disk"), data.get("src_rel") or "")
        _dst_base, dst_path = srvmove_resolve(data.get("dst_disk"), data.get("dst_rel") or "")
    except ValueError as exc:
        return False, str(exc), None
    if not os.path.isdir(src_path):
        return False, "Mənbə qovluq tapılmadı.", None

    # elementləri yoxla + mənbə==hədəf / içiçə qarşısını al
    src_norm = os.path.normcase(os.path.abspath(src_path).rstrip("\\/"))
    dst_norm = os.path.normcase(os.path.abspath(dst_path).rstrip("\\/"))
    items = []
    for nm in names:
        nm = str(nm or "").strip()
        if not nm or "\\" in nm or "/" in nm or nm in ("..", "."):
            return False, "Element adı düzgün deyil: " + nm, None
        item_abs = os.path.join(src_path, nm)
        if not os.path.exists(item_abs):
            return False, "Element tapılmadı: " + nm, None
        item_norm = os.path.normcase(os.path.abspath(item_abs).rstrip("\\/"))
        # hədəf elementin içində ola bilməz (qovluğu öz içinə köçürmə)
        if dst_norm == item_norm or dst_norm.startswith(item_norm + os.sep):
            return False, "Hədəf seçilmiş qovluğun içindədir: " + nm, None
        items.append({"name": nm, "kind": "folder" if os.path.isdir(item_abs) else "file",
                      "abs": item_abs})
    if src_norm == dst_norm:
        return False, "Mənbə və hədəf eyni qovluqdur.", None

    # plan: hər element üçün fayl sayı + həcm (worker bunlara görə progress snap edir)
    total_files = total_bytes = 0
    for item in items:
        f = b = 0
        for src_file, _rel in srvmove_collect(item["abs"], item["name"]):
            f += 1
            try:
                b += os.path.getsize(src_file)
            except OSError:
                pass
        item["files"] = f
        item["bytes"] = b
        total_files += f
        total_bytes += b
    if total_files == 0:
        return False, "Seçimdə fayl yoxdur.", None
    try:
        os.makedirs(dst_path, exist_ok=True)
    except OSError as exc:
        return False, "Hədəf qovluq yaradılmadı: " + system_clean_error(exc), None
    free = bk2_free_bytes(dst_path)
    if isinstance(free, int) and free < total_bytes:
        return False, ("Hədəf diskdə boş yer çatmır: lazım %s, boş %s"
                       % (bk2_fmt_size(total_bytes), bk2_fmt_size(free))), None

    BK3_CANCEL.clear()
    with BK3_LOCK:
        BK3_STATE.update({
            "running": True, "finished": False, "op": op,
            "src": src_path, "dst": dst_path,
            "items_total": len(items), "items_done": 0, "current": "",
            "files_total": total_files, "files_done": 0, "files_skipped": 0,
            "bytes_total": total_bytes, "bytes_done": 0, "speed_bps": 0.0, "eta_sec": None,
            "ok_items": 0, "failed_items": 0,
            "started_at": datetime.now().isoformat(timespec="seconds"),
            "finished_at": None, "status": "İşləyir", "error": None, "logs": [], "failed": [],
        })
    data = dict(data)
    data.update({"op": op, "conflict": conflict, "_src_path": src_path,
                 "_dst_path": dst_path, "_items": items})
    threading.Thread(target=srvmove_worker, args=(data,), daemon=True).start()
    return True, None, {"files_total": total_files, "bytes_total": total_bytes,
                        "items": len(items)}


def srvmove_cancel():
    with BK3_LOCK:
        if not BK3_STATE["running"]:
            return False, "Aktiv köçürmə yoxdur."
    BK3_CANCEL.set()
    srvmove_log("Dayandırma tələb olundu.")
    return True, None


# ============================================================
# ATM FAYL KÖÇÜR (ATMCOPY) — ATM-in C$/D$ diskindən seçilmiş qovluğu
#   istifadəçinin göstərdiyi təyinata köçürür (tək ATM).
# ============================================================
ATMCOPY_LOCK = threading.RLock()
ATMCOPY_CANCEL = threading.Event()
ATMCOPY_STATE = {
    "running": False, "finished": False, "atm": "", "source": "", "dest": "",
    "target_path": "", "files": 0, "bytes": 0, "status": "", "error": None,
    "started_at": None, "finished_at": None, "logs": [],
}


def atmcopy_log(msg):
    line = datetime.now().strftime("%H:%M:%S") + "  " + system_clean_error(msg)
    with ATMCOPY_LOCK:
        ATMCOPY_STATE["logs"].append(line)
        ATMCOPY_STATE["logs"] = ATMCOPY_STATE["logs"][-300:]


def atmcopy_snapshot():
    with ATMCOPY_LOCK:
        return {k: (list(v) if isinstance(v, list) else v) for k, v in ATMCOPY_STATE.items()}


def atmcopy_start(atm, disk_letter, source_rel, dest):
    atm = str(atm or "").strip().upper()
    if not ATM_ID_PATTERN.fullmatch(atm):
        return False, "ATM ID düzgün deyil."
    disk_letter = str(disk_letter or "").strip().upper()
    if not re.fullmatch(r"[A-Z]", disk_letter):
        return False, "Disk hərfi düzgün deyil (C və ya D)."
    source_rel = str(source_rel or "").strip().replace("/", "\\").strip("\\")
    if not source_rel:
        return False, "Köçürüləcək qovluğu seç (mənbə boşdur)."
    if ":" in source_rel or any(p in ("..", ".") for p in source_rel.split("\\")):
        return False, "Mənbə yolu düzgün deyil."
    dest = str(dest or "").strip()
    if not dest:
        return False, "Təyinat yolunu yaz."
    if not get_restart_passwords():
        return False, "PASSWORD environment dəyişənləri tapılmadı (PASSWORD1, PASSWORD2, ...)."
    with ATMCOPY_LOCK:
        if ATMCOPY_STATE["running"]:
            return False, "Köçürmə artıq işləyir."
        ATMCOPY_CANCEL.clear()
        ATMCOPY_STATE.update({
            "running": True, "finished": False, "atm": atm, "disk": disk_letter,
            "source": rf"\\{atm}\{disk_letter}$\{source_rel}", "dest": dest,
            "target_path": "", "files": 0, "bytes": 0, "status": "İşləyir",
            "error": None, "started_at": datetime.now().isoformat(timespec="seconds"),
            "finished_at": None, "logs": [],
        })
    threading.Thread(target=atmcopy_worker,
                     args=(atm, disk_letter, source_rel, dest), daemon=True).start()
    return True, None


def atmcopy_worker(atm, disk_letter, source_rel, dest):
    started = time.monotonic()
    deadline = started + 7200
    status = "XƏTA"
    error = None
    files = total = 0
    target_path = ""
    try:
        atmcopy_log(f"{atm}: qoşulma başladılır...")
        passwords = _disk_report_passwords(None)
        if not passwords:
            raise RuntimeError("PASSWORD environment dəyişənləri tapılmadı.")
        target = atm
        try:
            resolved = socket.gethostbyname(atm)
            if resolved:
                target = resolved
        except Exception:
            pass
        try:
            with socket.create_connection((target, 445), timeout=4):
                pass
        except OSError as exc:
            raise RuntimeError("TCP 445 əlçatan deyil (ATM sönülü / şəbəkə yoxdur): "
                               + system_clean_error(exc))
        slot, reused, err = va_smb_connect(target, passwords, ATMCOPY_CANCEL)
        if slot is None and not reused:
            raise RuntimeError(err or "ATM-ə qoşulma alınmadı.")
        try:
            src = rf"\\{target}\{disk_letter}$\{source_rel}"
            if not os.path.isdir(src):
                raise RuntimeError("Mənbə qovluğu ATM-də tapılmadı: " + rf"\\{atm}\{disk_letter}$\{source_rel}")
            name = source_rel.rstrip("\\").split("\\")[-1] or "folder"
            try:
                os.makedirs(dest, exist_ok=True)
            except OSError as exc:
                raise RuntimeError("Təyinat qovluğu yaradılmadı: " + system_clean_error(exc))
            final = os.path.join(dest, name)
            target_path = final
            atmcopy_log(f"{atm}: köçürülür → {final}")
            files, total = berpa_copy_folder(src, final, deadline, ATMCOPY_CANCEL, None)
            status = "KÖÇÜRÜLDÜ"
            atmcopy_log(f"{atm}: KÖÇÜRÜLDÜ ({files} fayl) → {final}")
        finally:
            if slot is not None:
                _disk_report_clear_ipc(target)
    except BerpaCancelled:
        status = "DAYANDIRILDI"
        error = "İstifadəçi dayandırdı."
        atmcopy_log(error)
    except Exception as exc:
        error = system_clean_error(exc)
        atmcopy_log("XƏTA: " + error)
    finally:
        with ATMCOPY_LOCK:
            ATMCOPY_STATE.update({
                "running": False, "finished": True, "status": status, "error": error,
                "files": files, "bytes": total, "target_path": target_path,
                "finished_at": datetime.now().isoformat(timespec="seconds"),
            })


def atmcopy_cancel():
    with ATMCOPY_LOCK:
        if not ATMCOPY_STATE["running"]:
            return False, "Aktiv köçürmə yoxdur."
    ATMCOPY_CANCEL.set()
    atmcopy_log("Dayandırma tələb olundu.")
    return True, None


# ============================================================
# MÜQAYİSƏ (CMP) — ATM-dəki görüntü/jurnal faylları 172.21.12.77
#   server backup-ı ilə eyniləşdirmə. Uyğunluq: ad + ölçü + tarix folderi.
#   ATM:  D$\VIDEOARCHIVE\<ATM> , E$\Video        → server: D$\ATMFILES , H$\ATM_GRG_files
#         C$\JOURNAL , C$\Mobilpay\LOG            → server: D$\JOURNAL_FILES , H$\ATM_GRG_Journal_files
# ============================================================
CMP_LOCK = threading.Lock()
CMP_CANCEL = threading.Event()
CMP_WORKERS = max(2, min(32, VA_MAX_WORKERS))
CMP_MISSING_CAP = 400          # ATM başına saxlanan fərqli fayl detalı limiti
CMP_SRV_MAX_FILES = 40_000_000  # server indeksi üçün təhlükəsizlik limiti
CMP_STATE = {"running": False, "finished": False, "cancel_requested": False, "run_id": None,
             "phase": "", "started_at": None, "finished_at": None, "total": 0, "processed": 0,
             "percent": 0.0, "current_atms": [], "counts": {}, "logs": [], "error": None,
             "srv_img_files": 0, "srv_jrn_files": 0}

# ATM mənbələri: (disk, folder, ATM_ID alt-qovluğu lazımdır?)
CMP_ATM_IMG = [("D$", "VIDEOARCHIVE", True), ("E$", "Video", False)]
CMP_ATM_JRN = [("C$", "JOURNAL", False), ("C$", r"MobilPay\LOG", False)]
# Server mənbələri (SCAN_SOURCES açarları)
CMP_SRV_IMG_KEYS = ["D", "H"]
CMP_SRV_JRN_KEYS = ["DJ", "HJ"]


def cmp_log(msg):
    line = datetime.now().strftime("%H:%M:%S") + "  " + str(msg)
    with CMP_LOCK:
        CMP_STATE["logs"].append(line)
        CMP_STATE["logs"] = CMP_STATE["logs"][-400:]


def _cmp_srv_root(key):
    with CONFIG_LOCK:
        p = SCAN_SOURCES.get(key)
    return p or ""


def _cmp_key(name, size, dfolder):
    return hash(name.lower() + "|" + str(size) + "|" + (dfolder or ""))


def _cmp_walk(root, cancel, deadline, add, counter, start_date=""):
    r"""root altını rekursiv gəzir; hər faylı add(name,size,date_folder) ilə verir.
    date_folder = ən yaxın YYYYMMDD adlı ata-qovluq. counter[0] ümumi fayl sayğacıdır."""
    stack = [(root, start_date)]
    while stack:
        if cancel.is_set():
            raise VaCancelled()
        if deadline and time.monotonic() > deadline:
            raise VaTimeout()
        cur, cur_date = stack.pop()
        try:
            with os.scandir(cur) as it:
                for e in it:
                    try:
                        if e.is_dir(follow_symlinks=False):
                            d = parse_date_folder(e.name)
                            stack.append((e.path, e.name if d is not None else cur_date))
                            continue
                        if not e.is_file(follow_symlinks=False):
                            continue
                        st = e.stat(follow_symlinks=False)
                    except OSError:
                        continue
                    counter[0] += 1
                    if counter[0] % 2000 == 0 and cancel.is_set():
                        raise VaCancelled()
                    add(e.name, int(st.st_size), cur_date)
        except (VaCancelled, VaTimeout):
            raise
        except OSError:
            continue


CMP_SRV_LABEL = {"D": "ATMFILES", "H": "ATM_GRG_files",
                 "DJ": "JOURNAL_FILES", "HJ": "ATM_GRG_Journal_files"}


def _cmp_server_set(atm, keys, cancel, deadline):
    r"""Bir ATM-in server backup fayllarını toplayır: {root}\<ATM> altını rekursiv gəzir.
    Qaytarır: ( set((ad.lower, ölçü)), fayl_sayı, qeydlər ).
    Serverdə backup ATM nömrəli qovluqdadır:
      JOURNAL_FILES\<ATM>\Journal\<tarix>.jrn , ATM_GRG_Journal_files\<ATM>\<tarix>\...
      ATMFILES\<ATM>\<tarix>\... , ATM_GRG_files\<ATM>\<tarix>\..."""
    s = set()
    cnt = [0]
    notes = []
    for key in keys:
        root = _cmp_srv_root(key)
        label = CMP_SRV_LABEL.get(key, key)
        if not root:
            notes.append(f"{label} server mənbəyi təyin edilməyib")
            continue
        atmdir = os.path.join(root, atm)
        if not os.path.isdir(atmdir):
            # bu ATM üçün serverdə qovluq yoxdur (heç backup olmayıb) — qeyd kifayətdir
            continue
        try:
            _cmp_walk(atmdir, cancel, deadline,
                      lambda n, sz, d: s.add((n.lower(), sz)), cnt)
        except (VaCancelled, VaTimeout):
            raise
        except OSError as exc:
            notes.append(f"{label}\\{atm}: " + system_clean_error(exc))
    return s, cnt[0], notes


def _cmp_atm_collect(atm, target, sources, deadline, cancel):
    """ATM tərəfində bir kateqoriyanın bütün fayllarını toplayır.
    Qaytarır: (files list[(name,size,date,disk,folder)], notes list)."""
    files = []
    notes = []
    counter = [0]
    for disk, folder, use_sub in sources:
        base = rf"\\{target}\{disk}\{folder}"
        path = base + ("\\" + atm if use_sub else "")
        try:
            if not os.path.isdir(path):
                notes.append(f"{disk}\\{folder}" + (f"\\{atm}" if use_sub else "") + " yoxdur")
                continue

            def add(name, size, dfolder, _d=disk, _f=folder):
                files.append((name, size, dfolder, _d, _f))
            _cmp_walk(path, cancel, deadline, add, counter)
        except (VaCancelled, VaTimeout):
            raise
        except OSError as exc:
            notes.append(f"{disk}\\{folder}: " + system_clean_error(exc))
    return files, notes


def cmp_check_atm(item, _unused, cancel):
    r"""Bir ATM: içindəki görüntü/jurnal fayllarını həmin ATM-in server backup
    qovluğu ilə müqayisə edir. Uyğunluq: ad + ölçü (tarix fayl adının içindədir).
    Server BİR dəfə yox, hər ATM üçün öz qovluğundan oxunur (tez və dəqiq)."""
    atm = str(item["atm_id"]).strip()
    started = time.monotonic()
    deadline = started + VA_ATM_TIMEOUT
    res = {"atm_id": atm, "name": item.get("name") or "", "region": item.get("region") or "",
           "category": "XƏTA", "connection_ok": 0, "password_env": None,
           "img_total": 0, "img_backed": 0, "img_missing": 0,
           "jrn_total": 0, "jrn_backed": 0, "jrn_missing": 0,
           "missing": [], "error": None, "srv_img": 0, "srv_jrn": 0}
    passwords = _disk_report_passwords(item.get("password_env"))
    if not passwords:
        res.update(category="QOŞULMADI", error="PASSWORD environment dəyişənləri tapılmadı.")
        return res
    target = atm
    try:
        r = socket.gethostbyname(atm)
        if r:
            target = r
    except Exception:
        pass
    try:
        with socket.create_connection((target, 445), timeout=4):
            pass
    except OSError as exc:
        res.update(category="QOŞULMADI", error="TCP 445 əlçatan deyil: " + system_clean_error(exc))
        return res
    slot, reused, err = va_smb_connect(target, passwords, cancel)
    if slot is None and not reused:
        res.update(category="QOŞULMADI", error=err)
        return res
    res["connection_ok"] = 1
    res["password_env"] = f"PASSWORD{slot}" if slot is not None else (item.get("password_env") or None)
    notes = []
    try:
        # Server tərəf: bu ATM-in backup fayl dəstləri (ad.lower, ölçü)
        srv_img, si, n1 = _cmp_server_set(atm, CMP_SRV_IMG_KEYS, cancel, deadline)
        srv_jrn, sj, n2 = _cmp_server_set(atm, CMP_SRV_JRN_KEYS, cancel, deadline)
        res["srv_img"], res["srv_jrn"] = si, sj
        notes += n1 + n2
        for catkey, srcs, srvset, label in (
                ("img", CMP_ATM_IMG, srv_img, "Görüntü"),
                ("jrn", CMP_ATM_JRN, srv_jrn, "Jurnal")):
            files, n = _cmp_atm_collect(atm, target, srcs, deadline, cancel)
            notes += n
            total = backed = missing = 0
            for (name, size, dfolder, disk, folder) in files:
                total += 1
                if (name.lower(), size) in srvset:
                    backed += 1
                else:
                    missing += 1
                    if len(res["missing"]) < CMP_MISSING_CAP:
                        dstr, _ = _date_from_name(name)
                        res["missing"].append({"cat": label, "date": dstr or dfolder or "-",
                                               "name": name, "size": size,
                                               "src": f"{disk}\\{folder}"})
            res[catkey + "_total"] = total
            res[catkey + "_backed"] = backed
            res[catkey + "_missing"] = missing
        tot = res["img_total"] + res["jrn_total"]
        miss = res["img_missing"] + res["jrn_missing"]
        if tot == 0:
            res["category"] = "FAYL YOXDUR"
        elif miss == 0:
            res["category"] = "TAM BACKUP"
        else:
            res["category"] = "FƏRQ VAR"
        if res["missing"] and len(res["missing"]) >= CMP_MISSING_CAP:
            notes.append(f"Fərqli fayl siyahısı {CMP_MISSING_CAP} ilə məhdudlaşdırıldı.")
        res["error"] = " · ".join(n for n in notes if n) or None
        return res
    except VaTimeout:
        res.update(category="VAXT AŞIMI", error=f"{VA_ATM_TIMEOUT} saniyədə bitmədi.")
        return res
    except VaCancelled:
        raise
    except OSError as exc:
        res.update(category="XƏTA", error="Oxuma xətası: " + system_clean_error(exc))
        return res
    finally:
        if slot is not None:
            _disk_report_clear_ipc(target)
        res["duration"] = round(time.monotonic() - started, 1)


def cmp_persist(run_id, res):
    now = datetime.now().isoformat(timespec="seconds")
    err = system_clean_error(res["error"])[:700] if res.get("error") else None
    missing = res.get("missing") or []
    try:
        mj = json.dumps(missing, ensure_ascii=False)
    except Exception:
        mj = "[]"
    con = db_connect()
    try:
        con.execute("""INSERT OR REPLACE INTO cmp_results(
            run_id,atm_id,name,region,category,connection_ok,password_env,
            img_total,img_backed,img_missing,jrn_total,jrn_backed,jrn_missing,
            missing_json,checked_at,duration_seconds,error)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (run_id, res["atm_id"], res.get("name"), res.get("region"), res["category"],
             res.get("connection_ok", 0), res.get("password_env"),
             res.get("img_total"), res.get("img_backed"), res.get("img_missing"),
             res.get("jrn_total"), res.get("jrn_backed"), res.get("jrn_missing"),
             mj, now, res.get("duration"), err))
        con.commit()
    finally:
        con.close()


def cmp_snapshot(since=0):
    with CMP_LOCK:
        logs = CMP_STATE["logs"][since:] if since < len(CMP_STATE["logs"]) else []
        return {"running": CMP_STATE["running"], "finished": CMP_STATE["finished"],
                "cancel_requested": CMP_STATE["cancel_requested"], "run_id": CMP_STATE["run_id"],
                "phase": CMP_STATE["phase"], "total": CMP_STATE["total"],
                "processed": CMP_STATE["processed"], "percent": CMP_STATE["percent"],
                "current_atms": list(CMP_STATE["current_atms"]), "counts": dict(CMP_STATE["counts"]),
                "srv_img_files": CMP_STATE.get("srv_img_files", 0),
                "srv_jrn_files": CMP_STATE.get("srv_jrn_files", 0),
                "error": CMP_STATE["error"], "logs": logs, "log_total": len(CMP_STATE["logs"])}


def cmp_finalize(run_id, started_at, status, error=None):
    con = db_connect()
    try:
        rows = con.execute("SELECT category,img_total,img_missing,jrn_total,jrn_missing FROM cmp_results WHERE run_id=?",
                           (run_id,)).fetchall()
        checked = len(rows)
        okc = sum(1 for r in rows if r["category"] == "TAM BACKUP")
        diffc = sum(1 for r in rows if r["category"] == "FƏRQ VAR")
        failc = sum(1 for r in rows if r["category"] in ("QOŞULMADI", "VAXT AŞIMI", "XƏTA"))
        atmf = sum((r["img_total"] or 0) + (r["jrn_total"] or 0) for r in rows)
        missf = sum((r["img_missing"] or 0) + (r["jrn_missing"] or 0) for r in rows)
        dur = 0.0
        try:
            dur = (datetime.now() - datetime.fromisoformat(started_at)).total_seconds()
        except Exception:
            pass
        with CMP_LOCK:
            si = CMP_STATE.get("srv_img_files", 0)
            sj = CMP_STATE.get("srv_jrn_files", 0)
        con.execute("""UPDATE cmp_runs SET finished_at=?,status=?,checked_count=?,ok_count=?,
            diff_count=?,failed_count=?,atm_files=?,missing_files=?,srv_img_files=?,srv_jrn_files=?,
            duration_seconds=?,error=? WHERE id=?""",
            (datetime.now().isoformat(timespec="seconds"), status, checked, okc, diffc, failc,
             atmf, missf, si, sj, round(dur, 1), error, run_id))
        con.commit()
    finally:
        con.close()


def cmp_worker(run_id, started_at, rows):
    try:
        with CMP_LOCK:
            CMP_STATE["phase"] = "ATM-lər yoxlanılır..."
        cmp_log(f"Müqayisə başladı. ATM: {len(rows)} · paralel: {CMP_WORKERS}. "
                "Hər ATM öz server backup qovluğu ilə müqayisə olunur (ad + ölçü).")
        executor = ThreadPoolExecutor(max_workers=CMP_WORKERS)
        cancelled = False
        try:
            inflight = {executor.submit(cmp_check_atm, r, None, CMP_CANCEL): r for r in rows
                        if not CMP_CANCEL.is_set()}
            while inflight:
                if CMP_CANCEL.is_set():
                    cancelled = True
                    break
                done, _ = wait(list(inflight), timeout=0.3, return_when=FIRST_COMPLETED)
                for fut in done:
                    item = inflight.pop(fut)
                    try:
                        res = fut.result()
                    except VaCancelled:
                        cancelled = True
                        break
                    except Exception as exc:
                        res = {"atm_id": item["atm_id"], "name": item.get("name"),
                               "region": item.get("region"), "category": "XƏTA",
                               "connection_ok": 0, "missing": [], "error": system_clean_error(exc)}
                    cmp_persist(run_id, res)
                    with CMP_LOCK:
                        CMP_STATE["processed"] += 1
                        CMP_STATE["counts"][res["category"]] = CMP_STATE["counts"].get(res["category"], 0) + 1
                        CMP_STATE["srv_img_files"] = CMP_STATE.get("srv_img_files", 0) + int(res.get("srv_img") or 0)
                        CMP_STATE["srv_jrn_files"] = CMP_STATE.get("srv_jrn_files", 0) + int(res.get("srv_jrn") or 0)
                        CMP_STATE["percent"] = round(CMP_STATE["processed"] * 100.0 / max(1, CMP_STATE["total"]), 1)
                        CMP_STATE["phase"] = f"Yoxlanılır: {CMP_STATE['processed']} / {CMP_STATE['total']}"
                if cancelled:
                    break
        finally:
            executor.shutdown(wait=not cancelled, cancel_futures=cancelled)
        status = "CANCELLED" if (cancelled or CMP_CANCEL.is_set()) else "COMPLETED"
        cmp_finalize(run_id, started_at, status,
                     error="İstifadəçi dayandırdı." if status == "CANCELLED" else None)
        with CMP_LOCK:
            CMP_STATE.update({"running": False, "finished": True,
                              "finished_at": datetime.now().isoformat(timespec="seconds"),
                              "phase": "Dayandırıldı." if status == "CANCELLED" else "Tamamlandı."})
        cmp_log("Müqayisə " + ("dayandırıldı." if status == "CANCELLED" else "tamamlandı."))
    except VaCancelled:
        cmp_finalize(run_id, started_at, "CANCELLED", error="İstifadəçi dayandırdı.")
        with CMP_LOCK:
            CMP_STATE.update({"running": False, "finished": True, "phase": "Dayandırıldı.",
                              "finished_at": datetime.now().isoformat(timespec="seconds")})
        cmp_log("Müqayisə dayandırıldı.")
    except Exception as exc:
        error = system_clean_error(exc)
        cmp_finalize(run_id, started_at, "FAILED", error=error)
        with CMP_LOCK:
            CMP_STATE.update({"running": False, "finished": True, "error": error, "phase": "XƏTA",
                              "finished_at": datetime.now().isoformat(timespec="seconds")})
        cmp_log("MÜQAYİSƏ XƏTA: " + error)


def cmp_start(atm_ids=None):
    with CMP_LOCK:
        if CMP_STATE["running"]:
            return False, "Müqayisə artıq işləyir.", CMP_STATE.get("run_id")
    with VA_LOCK:
        if VA_STATE["running"]:
            return False, "VIDEOARCHIVE Scan işləyir, bitməsini gözləyin.", None
    with DISK_REPORT_LOCK:
        if DISK_REPORT_STATE["running"]:
            return False, "Disk Report işləyir, bitməsini gözləyin.", None
    if not get_restart_passwords():
        return False, "PASSWORD environment dəyişənləri tapılmadı.", None
    rows, scope, err = _select_active_atms(atm_ids)
    if err:
        return False, err, None
    now = datetime.now().isoformat(timespec="seconds")
    con = db_connect()
    try:
        cur = con.execute("INSERT INTO cmp_runs(started_at,status,selected_count,scope) VALUES(?,?,?,?)",
                          (now, "RUNNING", len(rows), scope))
        con.commit()
        run_id = cur.lastrowid
    finally:
        con.close()
    CMP_CANCEL.clear()
    with CMP_LOCK:
        CMP_STATE.update({"running": True, "finished": False, "cancel_requested": False,
                          "run_id": run_id, "started_at": now, "finished_at": None,
                          "phase": "Başladılır...", "total": len(rows), "processed": 0,
                          "percent": 0.0, "current_atms": [], "counts": {}, "logs": [],
                          "error": None, "srv_img_files": 0, "srv_jrn_files": 0})
    threading.Thread(target=cmp_worker, args=(run_id, now, rows), daemon=True).start()
    return True, None, run_id


def cmp_cancel():
    with CMP_LOCK:
        if not CMP_STATE["running"]:
            return False, "Aktiv müqayisə yoxdur."
        CMP_STATE["cancel_requested"] = True
    CMP_CANCEL.set()
    cmp_log("DAYANDIR sorğusu qəbul edildi.")
    return True, None


def cmp_history(limit=100):
    con = db_connect()
    try:
        rows = con.execute("SELECT * FROM cmp_runs ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
        return {"success": True, "runs": [dict(r) for r in rows]}
    finally:
        con.close()


def cmp_detail(run_id):
    con = db_connect()
    try:
        run = con.execute("SELECT * FROM cmp_runs WHERE id=?", (run_id,)).fetchone()
        if not run:
            return None
        rows = con.execute("""SELECT * FROM cmp_results WHERE run_id=?
            ORDER BY CASE category WHEN 'FƏRQ VAR' THEN 0 WHEN 'QOŞULMADI' THEN 1
            WHEN 'XƏTA' THEN 2 WHEN 'VAXT AŞIMI' THEN 3 WHEN 'FAYL YOXDUR' THEN 4 ELSE 5 END,
            (COALESCE(img_missing,0)+COALESCE(jrn_missing,0)) DESC, atm_id COLLATE NOCASE""",
            (run_id,)).fetchall()
        return {"success": True, "run": dict(run), "results": [dict(r) for r in rows]}
    finally:
        con.close()


def cmp_excel(run_id):
    from xlsx_lite import Workbook
    detail = cmp_detail(run_id)
    if not detail:
        raise FileNotFoundError("Müqayisə tapılmadı.")
    run, results = detail["run"], detail["results"]
    wb = Workbook()
    s = wb.add_sheet("Xülasə", [("Göstərici", 44), ("Dəyər", 30)], autofilter=False)
    s.add_row(["Müqayisə hesabatı (ATM ↔ server backup)", f"#{run['id']}"], bold=True, fill="title")
    s.add_row(["Uyğunluq meyarı", "ad + ölçü (tarix fayl adının içindədir)"])
    s.add_row(["ATM görüntü mənbəyi", r"D$\VIDEOARCHIVE\<ATM> , E$\Video"])
    s.add_row(["ATM jurnal mənbəyi", r"C$\JOURNAL , C$\MobilPay\LOG"])
    s.add_row(["Server görüntü backup", r"ATMFILES\<ATM> , ATM_GRG_files\<ATM>"])
    s.add_row(["Server jurnal backup", r"JOURNAL_FILES\<ATM> , ATM_GRG_Journal_files\<ATM>"])
    s.add_row(["Başlama", str(run["started_at"] or "")])
    s.add_row(["Bitmə", str(run["finished_at"] or "")])
    s.add_row(["Status", run["status"]])
    s.add_row(["Yoxlanılmış ATM", int(run["checked_count"] or 0)])
    s.add_row(["Tam backup olan ATM", int(run["ok_count"] or 0)])
    s.add_row(["Fərqi olan ATM", int(run["diff_count"] or 0)], fill="red" if run["diff_count"] else "none")
    s.add_row(["Qoşulmayan / xəta", int(run["failed_count"] or 0)])
    s.add_row(["ATM-dəki ümumi fayl", int(run["atm_files"] or 0)])
    s.add_row(["Backup olmayan fayl (cəmi)", int(run["missing_files"] or 0)], fill="red" if run["missing_files"] else "none")
    s.add_row(["Serverdə tapılan görüntü backup (fayl)", int(run["srv_img_files"] or 0)])
    s.add_row(["Serverdə tapılan jurnal backup (fayl)", int(run["srv_jrn_files"] or 0)])

    cols = [("№", 6), ("ATM ID", 14), ("Ad", 30), ("Region", 14), ("Nəticə", 14),
            ("Görüntü (cəmi)", 13), ("Görüntü backup", 14), ("Görüntü fərq", 13),
            ("Jurnal (cəmi)", 13), ("Jurnal backup", 13), ("Jurnal fərq", 12),
            ("PASSWORD", 12), ("Yoxlama", 20), ("Qeyd / xəta", 60)]
    fill_for = {"TAM BACKUP": "green", "FƏRQ VAR": "red", "FAYL YOXDUR": "yellow",
                "QOŞULMADI": "yellow", "XƏTA": "red", "VAXT AŞIMI": "yellow"}
    sheet = wb.add_sheet("ATM-lər", cols)
    for i, r in enumerate(results, 1):
        sheet.add_row([i, r["atm_id"], r["name"] or "", r["region"] or "", r["category"],
                       r["img_total"], r["img_backed"], r["img_missing"],
                       r["jrn_total"], r["jrn_backed"], r["jrn_missing"],
                       r["password_env"] or "", str(r["checked_at"] or ""), r["error"] or ""],
                      fill=fill_for.get(r["category"], "none"), bold_cols=(1,))

    d = wb.add_sheet("Fərqli fayllar", [("ATM ID", 14), ("Kateqoriya", 12), ("Tarix", 12),
                                        ("Fayl adı", 46), ("Ölçü (bayt)", 14), ("ATM mənbəyi", 24)])
    for r in results:
        if not r.get("missing_json"):
            continue
        try:
            items = json.loads(r["missing_json"])
        except Exception:
            items = []
        for m in items:
            d.add_row([r["atm_id"], m.get("cat", ""), m.get("date", ""), m.get("name", ""),
                       m.get("size", ""), m.get("src", "")], bold_cols=(0,))

    stamp = (run["started_at"] or "").replace(":", "-").replace("T", "_")[:16]
    return wb.to_bytes(), f"Muqayise_{run['id']}_{stamp}.xlsx"


# ============================================================
# ÇATIŞMAYAN TARİX SCAN (MISSDATE) — Server 77 D/H diskində hər ATM qovluğu
# üçün mövcud tarixlər yığılır, aralıqda (ən köhnə → ən yeni) olmayan günlər
# "çatışmayan" kimi hesabat verilir. Mənbə: SCAN_SOURCES[D] / SCAN_SOURCES[H].
# ============================================================
MD_LOCK = threading.Lock()
MD_CANCEL = threading.Event()
MD_WORKERS = max(2, min(32, VA_MAX_WORKERS))
MD_STATE = {"running": False, "finished": False, "cancel_requested": False,
            "key": None, "label": None, "root": None, "start_date": None, "end_date": None,
            "started_at": None, "finished_at": None,
            "total": 0, "processed": 0, "percent": 0.0,
            "counts": {"full": 0, "partial": 0, "none": 0, "uncheck": 0},
            "results": [], "logs": [], "error": None}
MD_SRC_LABEL = {"D": "D disk (ATMFILES)", "H": "H disk (ATM_GRG_files)"}


def md_log(msg):
    line = datetime.now().strftime("%H:%M:%S") + "  " + str(msg)
    with MD_LOCK:
        MD_STATE["logs"].append(line)
        MD_STATE["logs"] = MD_STATE["logs"][-400:]


def _md_collect_dates(atm_dir, cancel, deadline, max_files=400000):
    r"""{root}\<ATM> altını gəzib bütün mövcud tarixləri yığır (qovluq adından VƏ
    fayl adından). set(date) qaytarır."""
    dates = set()
    seen = [0]
    stack = [atm_dir]
    while stack:
        if cancel.is_set():
            raise VaCancelled()
        if deadline and time.monotonic() > deadline:
            raise VaTimeout()
        cur = stack.pop()
        try:
            with os.scandir(cur) as it:
                for e in it:
                    try:
                        nm = e.name
                        if e.is_dir(follow_symlinks=False):
                            d = parse_date_folder(nm)
                            if d is not None and d <= date.today() + timedelta(days=2):
                                dates.add(d)
                            stack.append(e.path)
                            continue
                        if not e.is_file(follow_symlinks=False):
                            continue
                    except OSError:
                        continue
                    seen[0] += 1
                    if seen[0] > max_files:
                        return dates
                    _, dobj = _date_from_name(nm)
                    if dobj is not None:
                        dates.add(dobj)
        except OSError:
            continue
    return dates


def md_check_atm(item, key, cancel, start=None, end=None):
    r"""Seçilmiş tarix intervalı [start,end] üzrə ATM-in şəkil backup-ını yoxlayır.
    Kateqoriyalar: TAM (hər gün var), QİSMƏN, YOX (heç biri), YOXLANILMADI (qovluq yox/xəta).
    start/end verilməsə, köhnə davranış: mövcud tarixlər arasındakı boşluqlar."""
    atm = item["atm_id"]
    started = time.monotonic()
    deadline = started + VA_ATM_TIMEOUT
    out = {"atm_id": atm, "name": item.get("name"), "region": item.get("region"),
           "first": None, "last": None, "present": 0, "expected": 0,
           "missing": [], "missing_count": 0, "category": "OK", "error": None}
    root = _cmp_srv_root(key)
    if not root:
        out["category"] = "YOXLANILMADI"
        out["error"] = "server mənbəyi təyin edilməyib"
        return out
    atm_dir = os.path.join(root, atm)
    if not os.path.isdir(atm_dir):
        out["category"] = "YOXLANILMADI"
        out["error"] = "ATM qovluğu yoxdur"
        return out
    try:
        dates = _md_collect_dates(atm_dir, cancel, deadline)
    except (VaCancelled, VaTimeout):
        raise
    except Exception as exc:
        out["category"] = "YOXLANILMADI"
        out["error"] = system_clean_error(exc)
        return out
    if dates:
        out["first"] = min(dates).isoformat()
        out["last"] = max(dates).isoformat()
    one = timedelta(days=1)
    if start and end:
        # İnterval üzrə: hansı günlər var, hansı yox
        total = (end - start).days + 1
        missing = []
        present = 0
        cur = start
        while cur <= end:
            if cur in dates:
                present += 1
            else:
                missing.append(cur.isoformat())
            cur += one
        out["expected"] = total
        out["present"] = present
        out["missing"] = missing
        out["missing_count"] = len(missing)
        if present >= total:
            out["category"] = "TAM"
        elif present > 0:
            out["category"] = "QİSMƏN"
        else:
            out["category"] = "YOX"
        return out
    # start/end yoxdursa — köhnə boşluq rejimi
    if not dates:
        out["category"] = "YOXLANILMADI"
        out["error"] = "heç bir tarix tapılmadı"
        return out
    lo, hi = min(dates), max(dates)
    out["present"] = len(dates)
    missing = []
    cur = lo
    while cur <= hi:
        if cur not in dates:
            missing.append(cur.isoformat())
        cur += one
    out["missing"] = missing
    out["missing_count"] = len(missing)
    out["category"] = "QİSMƏN" if missing else "TAM"
    return out


def md_snapshot(since=0):
    with MD_LOCK:
        logs = MD_STATE["logs"][since:] if since < len(MD_STATE["logs"]) else []
        return {"running": MD_STATE["running"], "finished": MD_STATE["finished"],
                "cancel_requested": MD_STATE["cancel_requested"], "key": MD_STATE["key"],
                "label": MD_STATE["label"], "root": MD_STATE["root"],
                "start_date": MD_STATE.get("start_date"), "end_date": MD_STATE.get("end_date"),
                "total": MD_STATE["total"], "processed": MD_STATE["processed"],
                "percent": MD_STATE["percent"], "counts": dict(MD_STATE["counts"]),
                "results": list(MD_STATE["results"]), "error": MD_STATE["error"],
                "logs": logs, "log_total": len(MD_STATE["logs"])}


def md_worker(key, rows, start=None, end=None):
    try:
        rng = (" · interval: " + start.isoformat() + " → " + end.isoformat()) if (start and end) else ""
        md_log("Şəkil mövcudluğu yoxlaması başladı: " + str(MD_SRC_LABEL.get(key, key)) +
               rng + " · ATM: " + str(len(rows)) + " · paralel: " + str(MD_WORKERS))
        executor = ThreadPoolExecutor(max_workers=MD_WORKERS)
        cancelled = False
        try:
            inflight = {executor.submit(md_check_atm, r, key, MD_CANCEL, start, end): r for r in rows
                        if not MD_CANCEL.is_set()}
            while inflight:
                if MD_CANCEL.is_set():
                    cancelled = True
                    break
                done, _ = wait(list(inflight), timeout=0.3, return_when=FIRST_COMPLETED)
                for fut in done:
                    item = inflight.pop(fut)
                    try:
                        res = fut.result()
                    except VaCancelled:
                        cancelled = True
                        break
                    except Exception as exc:
                        res = {"atm_id": item["atm_id"], "name": item.get("name"),
                               "region": item.get("region"), "category": "YOXLANILMADI",
                               "first": None, "last": None, "present": 0, "expected": 0,
                               "missing": [], "missing_count": 0, "error": system_clean_error(exc)}
                    with MD_LOCK:
                        MD_STATE["results"].append(res)
                        cat = res["category"]
                        if cat == "TAM":
                            MD_STATE["counts"]["full"] += 1
                        elif cat == "QİSMƏN":
                            MD_STATE["counts"]["partial"] += 1
                        elif cat == "YOX":
                            MD_STATE["counts"]["none"] += 1
                        else:
                            MD_STATE["counts"]["uncheck"] += 1
                        MD_STATE["processed"] += 1
                        MD_STATE["percent"] = round(MD_STATE["processed"] * 100.0 / max(1, MD_STATE["total"]), 1)
                if cancelled:
                    break
        finally:
            executor.shutdown(wait=not cancelled, cancel_futures=cancelled)
        # nəticələri ən çox çatışmayan əvvəldə olacaq şəkildə sırala
        with MD_LOCK:
            MD_STATE["results"].sort(key=lambda r: (-(r.get("missing_count") or 0), str(r.get("atm_id"))))
        status = "CANCELLED" if (cancelled or MD_CANCEL.is_set()) else "COMPLETED"
        # Excel yaradıb Bildirişlərə qeyd et (yalnız tam bitəndə)
        if status == "COMPLETED":
            try:
                data, fname, summary = md_build_excel(key)
                report_register("missdate", "Çatışmayan tarixlər — " + str(MD_SRC_LABEL.get(key, key)),
                                data, fname, summary)
                md_log("Excel hesabatı yaradıldı və Bildirişlərə əlavə olundu.")
            except Exception as exc:
                md_log("Excel yaradıla bilmədi: " + system_clean_error(exc))
        with MD_LOCK:
            MD_STATE.update({"running": False, "finished": True,
                             "finished_at": datetime.now().isoformat(timespec="seconds")})
        md_log("Axtarış " + ("dayandırıldı." if status == "CANCELLED" else "tamamlandı."))
    except VaCancelled:
        with MD_LOCK:
            MD_STATE.update({"running": False, "finished": True,
                             "finished_at": datetime.now().isoformat(timespec="seconds")})
        md_log("Axtarış dayandırıldı.")
    except Exception as exc:
        error = system_clean_error(exc)
        with MD_LOCK:
            MD_STATE.update({"running": False, "finished": True, "error": error,
                             "finished_at": datetime.now().isoformat(timespec="seconds")})
        md_log("XƏTA: " + error)


def md_start(key, atm_ids=None, start_date=None, end_date=None):
    key = str(key or "").strip().upper()
    if key not in ("D", "H"):
        return False, "Yalnız D və ya H mənbəsi dəstəklənir.", None
    with MD_LOCK:
        if MD_STATE["running"]:
            return False, "Yoxlama artıq işləyir.", None
    root = _cmp_srv_root(key)
    if not root:
        return False, MD_SRC_LABEL.get(key, key) + " üçün server mənbəyi təyin edilməyib.", None
    start = end = None
    if start_date or end_date:
        try:
            start = datetime.strptime(str(start_date), "%Y-%m-%d").date()
            end = datetime.strptime(str(end_date), "%Y-%m-%d").date()
        except (ValueError, TypeError):
            return False, "Tarix formatı düzgün deyil (YYYY-MM-DD).", None
        if start > end:
            start, end = end, start
        if (end - start).days > 400:
            return False, "İnterval çox genişdir (maksimum 400 gün).", None
    rows, scope, err = _select_active_atms(atm_ids)
    if err:
        return False, err, None
    now = datetime.now().isoformat(timespec="seconds")
    MD_CANCEL.clear()
    with MD_LOCK:
        MD_STATE.update({"running": True, "finished": False, "cancel_requested": False,
                         "key": key, "label": MD_SRC_LABEL.get(key, key), "root": root,
                         "start_date": start.isoformat() if start else None,
                         "end_date": end.isoformat() if end else None,
                         "started_at": now, "finished_at": None, "total": len(rows), "processed": 0,
                         "percent": 0.0, "counts": {"full": 0, "partial": 0, "none": 0, "uncheck": 0},
                         "results": [], "logs": [], "error": None})
    threading.Thread(target=md_worker, args=(key, rows, start, end), daemon=True).start()
    return True, None, len(rows)


def md_cancel():
    with MD_LOCK:
        if not MD_STATE["running"]:
            return False, "Aktiv axtarış yoxdur."
        MD_STATE["cancel_requested"] = True
    MD_CANCEL.set()
    md_log("DAYANDIR sorğusu qəbul edildi.")
    return True, None


def md_build_excel(key=None):
    from xlsx_lite import Workbook
    with MD_LOCK:
        snap_key = key or MD_STATE["key"]
        label = MD_SRC_LABEL.get(snap_key, snap_key)
        root = MD_STATE["root"]
        started = MD_STATE["started_at"]
        counts = dict(MD_STATE["counts"])
        results = list(MD_STATE["results"])
        sd = MD_STATE.get("start_date")
        ed = MD_STATE.get("end_date")
    rng = (str(sd) + " → " + str(ed)) if (sd and ed) else "bütün tarixlər"
    wb = Workbook()
    s = wb.add_sheet("Xülasə", [("Göstərici", 40), ("Dəyər", 40)], autofilter=False)
    s.add_row(["Şəkil mövcudluğu hesabatı", str(label)], bold=True, fill="title")
    s.add_row(["Tarix intervalı", rng])
    s.add_row(["Server mənbəyi (kök)", str(root or "-")])
    s.add_row(["Başlama vaxtı", str(started or "-")])
    s.add_row(["Yoxlanılan ATM", str(len(results))])
    s.add_row(["TAM (bütün günlər var)", str(counts.get("full", 0))], fill="green")
    s.add_row(["QİSMƏN (bəzi günlər yox)", str(counts.get("partial", 0))], fill="yellow")
    s.add_row(["YOX (heç bir gün)", str(counts.get("none", 0))], fill="red")
    s.add_row(["YOXLANILMADI (qovluq yox/xəta)", str(counts.get("uncheck", 0))])

    d = wb.add_sheet("Detal", [("ATM ID", 16), ("Ad", 22), ("Region", 18), ("Status", 14),
                               ("Mövcud gün", 12), ("Gözlənilən", 12), ("Çatışmayan gün", 14),
                               ("İlk tarix", 13), ("Son tarix", 13), ("Qeyd", 26)])
    for r in results:
        cat = r.get("category", "")
        fill = "green" if cat == "TAM" else ("yellow" if cat == "QİSMƏN" else ("red" if cat == "YOX" else "none"))
        d.add_row([r.get("atm_id", ""), r.get("name") or "", r.get("region") or "", cat,
                   r.get("present") or 0, r.get("expected") or 0, r.get("missing_count") or 0,
                   r.get("first") or "-", r.get("last") or "-", r.get("error") or ""], fill=fill)

    m = wb.add_sheet("Çatışmayan günlər", [("ATM ID", 16), ("Çatışmayan tarix", 16)])
    for r in results:
        for dt_str in (r.get("missing") or []):
            m.add_row([r.get("atm_id", ""), dt_str])

    bad = counts.get("none", 0) + counts.get("partial", 0)
    summary = str(label) + " (" + rng + "): " + str(bad) + " ATM-də şəkil çatışmır (" + str(len(results)) + " yoxlanıldı)."
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    fname = "sekil_movcudlugu_" + str(snap_key) + "_" + stamp + ".xlsx"
    return wb.to_bytes(), fname, summary


# ============================================================
# AVTOMATİK BACKUP (AUTOBK) — serverdə (D$\ATMFILES\<ATM>\<tarix>) backup yoxdursa
# və ya boşdursa, ATM-dən (D$\videoarchive\<ATM>\<tarix>) robocopy ilə köçürür.
# Mənbə kökü: SCAN_SOURCES["D"] (yoxdursa \\172.21.12.77\D$\ATMFILES fallback).
# ============================================================
BK_LOCK = threading.Lock()
BK_CANCEL = threading.Event()
BK_WORKERS = max(1, min(int(os.getenv("ATM_BK_WORKERS", "6") or 6), 16))
BK_SERVER_FALLBACK = r"\\172.21.12.77\D$\ATMFILES"
BK_ROBO_PATTERNS = ["*.jpg", "*.AVI", "*.zip"]
BK_STATE = {"running": False, "finished": False, "cancel_requested": False,
            "mode": None, "target_date": None, "server_root": None,
            "started_at": None, "finished_at": None, "total": 0, "processed": 0,
            "percent": 0.0, "counts": {"copied": 0, "exists": 0, "nodata": 0, "failed": 0},
            "results": [], "logs": [], "error": None}


def bk_log(msg):
    line = datetime.now().strftime("%H:%M:%S") + "  " + str(msg)
    with BK_LOCK:
        BK_STATE["logs"].append(line)
        BK_STATE["logs"] = BK_STATE["logs"][-500:]


def bk_server_root():
    with CONFIG_LOCK:
        p = SCAN_SOURCES.get("D")
    return p or BK_SERVER_FALLBACK


def _bk_dir_state(path):
    r"""Qovluğun vəziyyəti: ('yox'|'bos'|'dolu')."""
    if not os.path.isdir(path):
        return "yox"
    try:
        with os.scandir(path) as it:
            for _ in it:
                return "dolu"
        return "bos"
    except OSError:
        return "yox"


def bk_check_and_copy(item, target_date, server_root, do_copy, passwords, cancel):
    atm = item["atm_id"]
    out = {"atm_id": atm, "name": item.get("name"), "region": item.get("region"),
           "date": target_date, "server_status": "", "atm_status": "", "backup_status": "Yox",
           "category": "", "error": None}
    if cancel.is_set():
        raise VaCancelled()
    server_date_path = os.path.join(server_root, atm, target_date)
    st = _bk_dir_state(server_date_path)
    if st == "dolu":
        out["server_status"] = "Serverdə var (doludur)"
        out["atm_status"] = "Serverdə artıq var"
        out["backup_status"] = "Lazım deyil"
        out["category"] = "ARTIQ VAR"
        return out
    out["server_status"] = "Serverdə yoxdur" if st == "yox" else "Serverdə var (boşdur)"

    # ATM-ə qoşul (IPC$) — mövcud infrastruktur
    slot, reused, cerr = va_smb_connect(atm, passwords, cancel)
    if slot is None and not reused:
        out["atm_status"] = "ATM-ə qoşulmadı"
        out["backup_status"] = "Yox"
        out["category"] = "QOŞULMADI"
        out["error"] = cerr
        return out
    try:
        atm_folder = rf"\\{atm}\D$\videoarchive\{atm}\{target_date}"
        ast = _bk_dir_state(atm_folder)
        if ast == "yox":
            out["atm_status"] = "ATM-də yoxdur"
            out["category"] = "ATM-DƏ YOX"
            return out
        if ast == "bos":
            out["atm_status"] = "ATM-də var (boşdur)"
            out["category"] = "ATM-DƏ BOŞ"
            return out
        out["atm_status"] = "ATM-də var (doludur)"
        if not do_copy:
            out["backup_status"] = "Köçürülmədi (yalnız yoxlama)"
            out["category"] = "KÖÇÜRMƏ LAZIMDIR"
            return out
        # Köçür: robocopy
        try:
            os.makedirs(server_date_path, exist_ok=True)
        except OSError as exc:
            out["backup_status"] = "Server qovluğu yaradılmadı"
            out["category"] = "XƏTA"
            out["error"] = system_clean_error(exc)
            return out
        cmd = ["robocopy", atm_folder, server_date_path] + BK_ROBO_PATTERNS + [
            "/E", "/Z", "/MT:16", "/R:1", "/W:1", "/COPY:DAT",
            "/XC", "/XN", "/XO", "/NP", "/NFL", "/NDL"]
        try:
            cp = subprocess.run(cmd, capture_output=True, text=True, errors="replace",
                                timeout=VA_ATM_TIMEOUT,
                                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            rc = cp.returncode
        except subprocess.TimeoutExpired:
            out["backup_status"] = "Vaxt aşımı (robocopy)"
            out["category"] = "XƏTA"
            out["error"] = "robocopy vaxt aşımı"
            return out
        if rc < 8:
            out["backup_status"] = "Backup olundu"
            out["category"] = "KÖÇÜRÜLDÜ"
        else:
            out["backup_status"] = f"Robocopy xəta kodu: {rc}"
            out["category"] = "XƏTA"
            out["error"] = f"robocopy rc={rc}"
        return out
    finally:
        if not reused:
            try:
                _disk_report_clear_ipc(atm)
            except Exception:
                pass


def bk_snapshot(since=0):
    with BK_LOCK:
        logs = BK_STATE["logs"][since:] if since < len(BK_STATE["logs"]) else []
        return {"running": BK_STATE["running"], "finished": BK_STATE["finished"],
                "cancel_requested": BK_STATE["cancel_requested"], "mode": BK_STATE["mode"],
                "target_date": BK_STATE["target_date"], "server_root": BK_STATE["server_root"],
                "total": BK_STATE["total"], "processed": BK_STATE["processed"],
                "percent": BK_STATE["percent"], "counts": dict(BK_STATE["counts"]),
                "results": list(BK_STATE["results"]), "error": BK_STATE["error"],
                "logs": logs, "log_total": len(BK_STATE["logs"])}


def bk_worker(rows, target_date, server_root, do_copy, passwords):
    try:
        bk_log(("Köçürmə" if do_copy else "Yalnız yoxlama") + " rejimi · tarix: " + target_date +
               " · ATM: " + str(len(rows)) + " · paralel: " + str(BK_WORKERS))
        bk_log("Server kökü: " + server_root)
        executor = ThreadPoolExecutor(max_workers=BK_WORKERS)
        cancelled = False
        try:
            inflight = {executor.submit(bk_check_and_copy, r, target_date, server_root, do_copy, passwords, BK_CANCEL): r
                        for r in rows if not BK_CANCEL.is_set()}
            while inflight:
                if BK_CANCEL.is_set():
                    cancelled = True
                    break
                done, _ = wait(list(inflight), timeout=0.3, return_when=FIRST_COMPLETED)
                for fut in done:
                    item = inflight.pop(fut)
                    try:
                        res = fut.result()
                    except VaCancelled:
                        cancelled = True
                        break
                    except Exception as exc:
                        res = {"atm_id": item["atm_id"], "name": item.get("name"),
                               "region": item.get("region"), "date": target_date,
                               "server_status": "", "atm_status": "", "backup_status": "Yox",
                               "category": "XƏTA", "error": system_clean_error(exc)}
                    with BK_LOCK:
                        BK_STATE["results"].append(res)
                        cat = res["category"]
                        if cat == "KÖÇÜRÜLDÜ":
                            BK_STATE["counts"]["copied"] += 1
                        elif cat == "ARTIQ VAR":
                            BK_STATE["counts"]["exists"] += 1
                        elif cat in ("ATM-DƏ YOX", "ATM-DƏ BOŞ"):
                            BK_STATE["counts"]["nodata"] += 1
                        elif cat in ("XƏTA", "QOŞULMADI"):
                            BK_STATE["counts"]["failed"] += 1
                        BK_STATE["processed"] += 1
                        BK_STATE["percent"] = round(BK_STATE["processed"] * 100.0 / max(1, BK_STATE["total"]), 1)
                if cancelled:
                    break
        finally:
            executor.shutdown(wait=not cancelled, cancel_futures=cancelled)
        status = "CANCELLED" if (cancelled or BK_CANCEL.is_set()) else "COMPLETED"
        if status == "COMPLETED":
            try:
                data, fname, summary = bk_build_excel()
                report_register("autobk", "Avtomatik backup — " + target_date, data, fname, summary)
                bk_log("Excel hesabatı yaradıldı və Bildirişlərə əlavə olundu.")
            except Exception as exc:
                bk_log("Excel yaradıla bilmədi: " + system_clean_error(exc))
        with BK_LOCK:
            BK_STATE.update({"running": False, "finished": True,
                             "finished_at": datetime.now().isoformat(timespec="seconds")})
        bk_log("Əməliyyat " + ("dayandırıldı." if status == "CANCELLED" else "tamamlandı."))
    except Exception as exc:
        error = system_clean_error(exc)
        with BK_LOCK:
            BK_STATE.update({"running": False, "finished": True, "error": error,
                             "finished_at": datetime.now().isoformat(timespec="seconds")})
        bk_log("XƏTA: " + error)


def bk_start(data):
    with BK_LOCK:
        if BK_STATE["running"]:
            return False, "Avtomatik backup artıq işləyir.", None
    if not get_restart_passwords():
        return False, "PASSWORD environment dəyişənləri tapılmadı.", None
    # Tarix: açıq tarix (YYYY-MM-DD) və ya 'days_ago' (default 6)
    target_date = ""
    raw_date = str(data.get("date") or "").strip()
    if raw_date:
        try:
            target_date = datetime.strptime(raw_date, "%Y-%m-%d").strftime("%Y%m%d")
        except ValueError:
            return False, "Tarix formatı düzgün deyil (YYYY-MM-DD).", None
    else:
        try:
            days_ago = int(data.get("days_ago", 6))
        except (TypeError, ValueError):
            days_ago = 6
        days_ago = max(0, min(365, days_ago))
        target_date = (datetime.today() - timedelta(days=days_ago)).strftime("%Y%m%d")
    do_copy = str(data.get("mode", "copy")).lower() != "check"
    rows, scope, err = _select_active_atms(data.get("atm_ids") or None)
    if err:
        return False, err, None
    # Skip siyahısı (artıq backup olunmuş ATM-lər)
    skip = set()
    for v in (data.get("skip") or []):
        a = str(v or "").strip().upper()
        if a:
            skip.add(a)
    if skip:
        rows = [r for r in rows if str(r["atm_id"]).upper() not in skip]
    if not rows:
        return False, "Yoxlanılacaq ATM qalmadı (hamısı skip siyahısındadır?).", None
    server_root = bk_server_root()
    passwords = _disk_report_passwords()
    now = datetime.now().isoformat(timespec="seconds")
    BK_CANCEL.clear()
    with BK_LOCK:
        BK_STATE.update({"running": True, "finished": False, "cancel_requested": False,
                         "mode": "copy" if do_copy else "check", "target_date": target_date,
                         "server_root": server_root, "started_at": now, "finished_at": None,
                         "total": len(rows), "processed": 0, "percent": 0.0,
                         "counts": {"copied": 0, "exists": 0, "nodata": 0, "failed": 0},
                         "results": [], "logs": [], "error": None})
    threading.Thread(target=bk_worker, args=(rows, target_date, server_root, do_copy, passwords),
                     daemon=True).start()
    return True, None, {"total": len(rows), "target_date": target_date, "mode": "copy" if do_copy else "check"}


def bk_cancel():
    with BK_LOCK:
        if not BK_STATE["running"]:
            return False, "Aktiv əməliyyat yoxdur."
        BK_STATE["cancel_requested"] = True
    BK_CANCEL.set()
    bk_log("DAYANDIR sorğusu qəbul edildi.")
    return True, None


def bk_build_excel():
    from xlsx_lite import Workbook
    with BK_LOCK:
        target_date = BK_STATE["target_date"]
        server_root = BK_STATE["server_root"]
        started = BK_STATE["started_at"]
        mode = BK_STATE["mode"]
        counts = dict(BK_STATE["counts"])
        results = list(BK_STATE["results"])
    wb = Workbook()
    s = wb.add_sheet("Xülasə", [("Göstərici", 40), ("Dəyər", 40)], autofilter=False)
    s.add_row(["Avtomatik backup hesabatı", str(target_date)], bold=True, fill="title")
    s.add_row(["Rejim", "Köçürmə" if mode == "copy" else "Yalnız yoxlama"])
    s.add_row(["Server kökü", str(server_root or "-")])
    s.add_row(["Başlama vaxtı", str(started or "-")])
    s.add_row(["Yoxlanılan ATM", str(len(results))])
    s.add_row(["Backup olundu", str(counts.get("copied", 0))], fill="green")
    s.add_row(["Serverdə artıq var", str(counts.get("exists", 0))])
    s.add_row(["ATM-də məlumat yoxdur/boş", str(counts.get("nodata", 0))], fill="yellow")
    s.add_row(["Qoşulmadı / xəta", str(counts.get("failed", 0))], fill="red")

    d = wb.add_sheet("Detal", [("ATM_ID", 16), ("Ad", 22), ("Region", 18), ("Tarix", 12),
                               ("Server statusu", 26), ("ATM statusu", 24), ("Backup statusu", 24)])
    for r in results:
        cat = r.get("category", "")
        fill = "green" if cat == "KÖÇÜRÜLDÜ" else ("red" if cat in ("XƏTA", "QOŞULMADI") else ("yellow" if cat in ("ATM-DƏ YOX", "ATM-DƏ BOŞ", "KÖÇÜRMƏ LAZIMDIR") else "none"))
        d.add_row([r.get("atm_id", ""), r.get("name") or "", r.get("region") or "",
                   r.get("date") or "", r.get("server_status") or "", r.get("atm_status") or "",
                   r.get("backup_status") or ""], fill=fill)

    copied = counts.get("copied", 0)
    summary = target_date + ": " + str(copied) + " ATM backup olundu (" + str(len(results)) + " yoxlanıldı)."
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    fname = "avtomatik_backup_" + target_date + "_" + stamp + ".xlsx"
    return wb.to_bytes(), fname, summary


# ============================================================
# ATM JURNAL SCAN (AJSCAN) — C$\JOURNAL + C$\Mobilpay\LOG (sonuncu tarix)
# ============================================================
AJ_LOCK = threading.Lock()
AJ_CANCEL = threading.Event()
AJ_WORKERS = max(2, min(32, VA_MAX_WORKERS))
AJ_STATE = {"running": False, "finished": False, "cancel_requested": False, "run_id": None,
            "started_at": None, "finished_at": None, "total": 0, "processed": 0,
            "percent": 0.0, "counts": {}, "logs": [], "error": None}
AJ_PATHS = [("j", "JOURNAL"), ("m", r"Mobilpay\LOG")]  # hər ikisi C$ diskində


def aj_log(msg):
    line = datetime.now().strftime("%H:%M:%S") + "  " + str(msg)
    with AJ_LOCK:
        AJ_STATE["logs"].append(line)
        AJ_STATE["logs"] = AJ_STATE["logs"][-400:]


_DATE8_RE = re.compile(r"(\d{8})")


def _date_from_name(name):
    r"""Fayl adının içindən ilk YYYYMMDD tarixini çıxarır (məs. 20261026.jrn → 20261026)."""
    for m in _DATE8_RE.finditer(name or ""):
        s = m.group(1)
        try:
            d = datetime.strptime(s, "%Y%m%d").date()
            if d <= date.today() + timedelta(days=2):
                return s, d
        except ValueError:
            continue
    return "", None


def _aj_scan_path(target, atm, folder, deadline, cancel):
    r"""\\target\C$\<folder> içindəki faylları oxuyur. Fayllar birbaşa qovluqdadır,
    tarix fayl adındadır (məs. JOURNAL\20261026.jrn, MobilPay\LOG\20250521_..._webext.zip).
    Ən son tarixli fayl(lar) hesabatda göstərilir."""
    out = {"date": None, "files": 0, "bytes": 0, "last": None, "error": None}
    base = rf"\\{target}\C$\{folder}"
    if not os.path.isdir(base):
        out["error"] = f"C$\\{folder} yoxdur"
        return out
    # Bütün faylları topla (birbaşa + alt-qovluqlar); tarix = fayl adından
    items = []  # (date_obj, date_str, name, size, mtime)
    stack = [base]
    seen = 0
    try:
        while stack:
            if cancel.is_set():
                raise VaCancelled()
            if deadline and time.monotonic() > deadline:
                raise VaTimeout()
            cur = stack.pop()
            with os.scandir(cur) as it:
                for e in it:
                    try:
                        if e.is_dir(follow_symlinks=False):
                            stack.append(e.path)
                            continue
                        if not e.is_file(follow_symlinks=False):
                            continue
                        st = e.stat(follow_symlinks=False)
                    except OSError:
                        continue
                    seen += 1
                    if seen > VA_MAX_FILES_PER_ATM:
                        raise VaTimeout()
                    dstr, dobj = _date_from_name(e.name)
                    items.append((dobj, dstr, e.name, int(st.st_size), st.st_mtime))
    except (VaCancelled, VaTimeout):
        raise
    except OSError as exc:
        out["error"] = system_clean_error(exc)
        return out
    if not items:
        out["error"] = "fayl yoxdur"
        return out
    dated = [x for x in items if x[0] is not None]
    if dated:
        latest = max(x[0] for x in dated)
        group = [x for x in dated if x[0] == latest]
        out["date"] = group[0][1]
    else:
        # tarix adda tapılmadı — bütün fayllar üzrə hesabat
        group = items
        out["date"] = "—"
    out["files"] = len(group)
    out["bytes"] = sum(x[3] for x in group)
    last = max((x[4] for x in group), default=None)
    if last:
        out["last"] = datetime.fromtimestamp(last).isoformat(timespec="seconds")
    return out


def aj_check_atm(item, cancel):
    atm = str(item["atm_id"]).strip()
    started = time.monotonic()
    deadline = started + VA_ATM_TIMEOUT
    res = {"atm_id": atm, "name": item.get("name") or "", "region": item.get("region") or "",
           "category": "XƏTA", "connection_ok": 0, "password_env": None,
           "j": None, "m": None, "error": None}
    passwords = _disk_report_passwords(item.get("password_env"))
    if not passwords:
        res.update(category="QOŞULMADI", error="PASSWORD tapılmadı.")
        return res
    target = atm
    try:
        r = socket.gethostbyname(atm)
        if r:
            target = r
    except Exception:
        pass
    try:
        with socket.create_connection((target, 445), timeout=4):
            pass
    except OSError as exc:
        res.update(category="QOŞULMADI", error="TCP 445 əlçatan deyil: " + system_clean_error(exc))
        return res
    slot, reused, err = va_smb_connect(target, passwords, cancel)
    if slot is None and not reused:
        res.update(category="QOŞULMADI", error=err)
        return res
    res["connection_ok"] = 1
    res["password_env"] = f"PASSWORD{slot}" if slot is not None else (item.get("password_env") or None)
    try:
        # 1-ci yol: C$\Journal\<sonuncu tarix>. Faylı olsa — nəticə budur, Mobilpay oxunmur.
        j = _aj_scan_path(target, atm, "Journal", deadline, cancel)
        res["j"] = j
        m = None
        if not (j["files"] and j["files"] > 0):
            # Journal-da fayl yoxdursa (və ya qovluq yoxdursa) — 2-ci yol: C$\MobilPay\LOG
            m = _aj_scan_path(target, atm, r"MobilPay\LOG", deadline, cancel)
            res["m"] = m
        jf = (j["files"] or 0)
        mf = (m["files"] or 0) if m else 0
        if jf > 0 or mf > 0:
            res["category"] = "OK"
        else:
            # heç bir yolda fayl yoxdur
            j_missing = bool(j["error"]) and not j["date"]
            m_missing = (m is None) or (bool(m["error"]) and not m["date"])
            res["category"] = "YOXDUR" if (j_missing and m_missing) else "BOŞ"
        return res
    except VaTimeout:
        res.update(category="VAXT AŞIMI", error=f"{VA_ATM_TIMEOUT} saniyədə bitmədi.")
        return res
    except VaCancelled:
        raise
    except OSError as exc:
        res.update(category="XƏTA", error="Oxuma xətası: " + system_clean_error(exc))
        return res
    finally:
        if slot is not None:
            _disk_report_clear_ipc(target)
        res["duration"] = round(time.monotonic() - started, 1)


def aj_persist(run_id, res):
    now = datetime.now().isoformat(timespec="seconds")
    j = res.get("j") or {}
    m = res.get("m") or {}
    err = system_clean_error(res["error"])[:700] if res.get("error") else None
    con = db_connect()
    try:
        con.execute("""INSERT OR REPLACE INTO ajscan_results(
            run_id,atm_id,name,region,category,connection_ok,password_env,
            j_date,j_files,j_bytes,j_last,j_error,m_date,m_files,m_bytes,m_last,m_error,
            checked_at,duration_seconds,error) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (run_id, res["atm_id"], res.get("name"), res.get("region"), res["category"],
             res.get("connection_ok", 0), res.get("password_env"),
             j.get("date"), j.get("files"), j.get("bytes"), j.get("last"), j.get("error"),
             m.get("date"), m.get("files"), m.get("bytes"), m.get("last"), m.get("error"),
             now, res.get("duration"), err))
        con.commit()
    finally:
        con.close()


def aj_snapshot(since=0):
    with AJ_LOCK:
        logs = AJ_STATE["logs"][since:] if since < len(AJ_STATE["logs"]) else []
        return {"running": AJ_STATE["running"], "finished": AJ_STATE["finished"],
                "cancel_requested": AJ_STATE["cancel_requested"], "run_id": AJ_STATE["run_id"],
                "total": AJ_STATE["total"], "processed": AJ_STATE["processed"],
                "percent": AJ_STATE["percent"], "counts": dict(AJ_STATE["counts"]),
                "error": AJ_STATE["error"], "logs": logs, "log_total": len(AJ_STATE["logs"])}


def aj_finalize(run_id, started_at, status, error=None):
    con = db_connect()
    try:
        rows = con.execute("SELECT category FROM ajscan_results WHERE run_id=?", (run_id,)).fetchall()
        checked = len(rows)
        okc = sum(1 for r in rows if r["category"] == "OK")
        emptyc = sum(1 for r in rows if r["category"] in ("BOŞ", "YOXDUR"))
        failc = sum(1 for r in rows if r["category"] in ("QOŞULMADI", "VAXT AŞIMI", "XƏTA"))
        dur = 0.0
        try:
            dur = (datetime.now() - datetime.fromisoformat(started_at)).total_seconds()
        except Exception:
            pass
        con.execute("""UPDATE ajscan_runs SET finished_at=?,status=?,checked_count=?,ok_count=?,
            empty_count=?,failed_count=?,duration_seconds=?,error=? WHERE id=?""",
            (datetime.now().isoformat(timespec="seconds"), status, checked, okc, emptyc, failc,
             round(dur, 1), error, run_id))
        con.commit()
    finally:
        con.close()


def aj_worker(run_id, started_at, rows):
    try:
        aj_log(f"ATM Jurnal Scan #{run_id} başladı. ATM: {len(rows)}")
        executor = ThreadPoolExecutor(max_workers=AJ_WORKERS)
        cancelled = False
        try:
            inflight = {executor.submit(aj_check_atm, r, AJ_CANCEL): r for r in rows
                        if not AJ_CANCEL.is_set()}
            while inflight:
                if AJ_CANCEL.is_set():
                    cancelled = True
                    break
                done, _ = wait(list(inflight), timeout=0.3, return_when=FIRST_COMPLETED)
                for fut in done:
                    item = inflight.pop(fut)
                    try:
                        res = fut.result()
                    except VaCancelled:
                        cancelled = True
                        break
                    except Exception as exc:
                        res = {"atm_id": item["atm_id"], "name": item.get("name"),
                               "region": item.get("region"), "category": "XƏTA",
                               "connection_ok": 0, "error": system_clean_error(exc)}
                    aj_persist(run_id, res)
                    with AJ_LOCK:
                        AJ_STATE["processed"] += 1
                        AJ_STATE["counts"][res["category"]] = AJ_STATE["counts"].get(res["category"], 0) + 1
                        AJ_STATE["percent"] = round(AJ_STATE["processed"] * 100.0 / max(1, AJ_STATE["total"]), 1)
                if cancelled:
                    break
        finally:
            executor.shutdown(wait=not cancelled, cancel_futures=cancelled)
        status = "CANCELLED" if (cancelled or AJ_CANCEL.is_set()) else "COMPLETED"
        aj_finalize(run_id, started_at, status, error="İstifadəçi dayandırdı." if status == "CANCELLED" else None)
        with AJ_LOCK:
            AJ_STATE.update({"running": False, "finished": True,
                             "finished_at": datetime.now().isoformat(timespec="seconds")})
        aj_log("ATM Jurnal Scan " + ("dayandırıldı." if status == "CANCELLED" else "tamamlandı."))
    except Exception as exc:
        error = system_clean_error(exc)
        aj_finalize(run_id, started_at, "FAILED", error=error)
        with AJ_LOCK:
            AJ_STATE.update({"running": False, "finished": True, "error": error,
                             "finished_at": datetime.now().isoformat(timespec="seconds")})
        aj_log("ATM JURNAL SCAN XƏTA: " + error)


def aj_start(atm_ids=None):
    with AJ_LOCK:
        if AJ_STATE["running"]:
            return False, "ATM Jurnal Scan artıq işləyir.", AJ_STATE.get("run_id")
    with VA_LOCK:
        if VA_STATE["running"]:
            return False, "VIDEOARCHIVE Scan işləyir, bitməsini gözləyin.", None
    with DISK_REPORT_LOCK:
        if DISK_REPORT_STATE["running"]:
            return False, "Disk Report işləyir, bitməsini gözləyin.", None
    if not get_restart_passwords():
        return False, "PASSWORD environment dəyişənləri tapılmadı.", None
    rows, scope, err = _select_active_atms(atm_ids)
    if err:
        return False, err, None
    now = datetime.now().isoformat(timespec="seconds")
    con = db_connect()
    try:
        cur = con.execute("INSERT INTO ajscan_runs(started_at,status,selected_count,scope) VALUES(?,?,?,?)",
                          (now, "RUNNING", len(rows), scope))
        con.commit()
        run_id = cur.lastrowid
    finally:
        con.close()
    AJ_CANCEL.clear()
    with AJ_LOCK:
        AJ_STATE.update({"running": True, "finished": False, "cancel_requested": False,
                         "run_id": run_id, "started_at": now, "finished_at": None,
                         "total": len(rows), "processed": 0, "percent": 0.0, "counts": {},
                         "logs": [], "error": None})
    threading.Thread(target=aj_worker, args=(run_id, now, rows), daemon=True).start()
    return True, None, run_id


def aj_cancel():
    with AJ_LOCK:
        if not AJ_STATE["running"]:
            return False, "Aktiv ATM Jurnal Scan yoxdur."
        AJ_STATE["cancel_requested"] = True
    AJ_CANCEL.set()
    aj_log("DAYANDIR sorğusu qəbul edildi.")
    return True, None


def aj_history(limit=100):
    con = db_connect()
    try:
        rows = con.execute("SELECT * FROM ajscan_runs ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
        return {"success": True, "runs": [dict(r) for r in rows]}
    finally:
        con.close()


def aj_detail(run_id):
    con = db_connect()
    try:
        run = con.execute("SELECT * FROM ajscan_runs WHERE id=?", (run_id,)).fetchone()
        if not run:
            return None
        rows = con.execute("""SELECT * FROM ajscan_results WHERE run_id=?
            ORDER BY CASE category WHEN 'OK' THEN 0 WHEN 'BOŞ' THEN 1 WHEN 'YOXDUR' THEN 2
            WHEN 'QOŞULMADI' THEN 3 WHEN 'XƏTA' THEN 4 ELSE 5 END, atm_id COLLATE NOCASE""",
            (run_id,)).fetchall()
        return {"success": True, "run": dict(run), "results": [dict(r) for r in rows]}
    finally:
        con.close()


def _aj_mb(b):
    try:
        return round(int(b or 0) / 1048576.0, 2)
    except Exception:
        return 0


def aj_excel(run_id):
    from xlsx_lite import Workbook
    detail = aj_detail(run_id)
    if not detail:
        raise FileNotFoundError("ATM Jurnal Scan tapılmadı.")
    run, results = detail["run"], detail["results"]
    wb = Workbook()
    s = wb.add_sheet("Xülasə", [("Göstərici", 40), ("Dəyər", 28)], autofilter=False)
    s.add_row(["ATM Jurnal Scan hesabatı", f"#{run['id']}"], bold=True, fill="title")
    s.add_row(["Yol 1", r"\\ATM_ID\C$\JOURNAL\<sonuncu tarix>"])
    s.add_row(["Yol 2", r"\\ATM_ID\C$\Mobilpay\LOG\<sonuncu tarix>"])
    s.add_row(["Başlama", str(run["started_at"] or "")])
    s.add_row(["Bitmə", str(run["finished_at"] or "")])
    s.add_row(["Status", run["status"]])
    s.add_row(["Yoxlanılmış ATM", int(run["checked_count"] or 0)])
    s.add_row(["Faylı olan (OK)", int(run["ok_count"] or 0)])
    s.add_row(["Boş / yoxdur", int(run["empty_count"] or 0)])
    s.add_row(["Qoşulmayan / xəta", int(run["failed_count"] or 0)])

    cols = [("№", 6), ("ATM ID", 14), ("Ad", 30), ("Region", 14), ("Nəticə", 12),
            ("JOURNAL tarix", 14), ("JOURNAL fayl", 12), ("JOURNAL MB", 11), ("JOURNAL son", 20),
            ("Mobilpay tarix", 14), ("Mobilpay fayl", 12), ("Mobilpay MB", 11), ("Mobilpay son", 20),
            ("PASSWORD", 12), ("Yoxlama", 20), ("Qeyd / xəta", 50)]
    fill_for = {"OK": "green", "BOŞ": "yellow", "YOXDUR": "yellow", "QOŞULMADI": "yellow",
                "XƏTA": "red", "VAXT AŞIMI": "yellow"}
    sheet = wb.add_sheet("ATM-lər", cols)
    for i, r in enumerate(results, 1):
        note = r["error"] or ""
        for lbl, ek in (("JOURNAL", "j_error"), ("Mobilpay", "m_error")):
            if r[ek]:
                note = (note + " · " if note else "") + lbl + ": " + r[ek]
        sheet.add_row([i, r["atm_id"], r["name"] or "", r["region"] or "", r["category"],
                       r["j_date"] or "", r["j_files"], _aj_mb(r["j_bytes"]), str(r["j_last"] or ""),
                       r["m_date"] or "", r["m_files"], _aj_mb(r["m_bytes"]), str(r["m_last"] or ""),
                       r["password_env"] or "", str(r["checked_at"] or ""), note],
                      fill=fill_for.get(r["category"], "none"), bold_cols=(1,))
    stamp = (run["started_at"] or "").replace(":", "-").replace("T", "_")[:16]
    return wb.to_bytes(), f"ATM_Jurnal_Scan_{run['id']}_{stamp}.xlsx"


def _select_active_atms(atm_ids=None):
    """Ortaq ATM seçimi: boşdursa bütün aktiv ATM-lər. (rows, scope, error) qaytarır."""
    requested = []
    if atm_ids:
        if not isinstance(atm_ids, list):
            return None, None, "ATM siyahısı düzgün deyil."
        seen = set()
        for v in atm_ids:
            a = str(v or "").strip().upper()
            if ATM_ID_PATTERN.fullmatch(a) and a.casefold() not in seen:
                seen.add(a.casefold())
                requested.append(a)
        if not requested:
            return None, None, "Siyahıda düzgün ATM ID yoxdur."
        if len(requested) > 5000:
            return None, None, "Bir əməliyyat üçün maksimum 5000 ATM."
    con = db_connect()
    try:
        all_rows = con.execute("""SELECT atm_id,name,region,password_env FROM atms
                                  WHERE is_deleted=0 AND status=1 ORDER BY atm_id COLLATE NOCASE""").fetchall()
    finally:
        con.close()
    if requested:
        by_id = {str(r["atm_id"]).casefold(): r for r in all_rows}
        rows = [by_id[a.casefold()] for a in requested if a.casefold() in by_id]
        scope = "SEÇİLMİŞ"
    else:
        rows = list(all_rows)
        scope = "HAMISI"
    rows = [{"atm_id": r["atm_id"], "name": r["name"], "region": r["region"],
             "password_env": r["password_env"]} for r in rows]
    if not rows:
        return None, None, "Yoxlanacaq aktiv ATM tapılmadı."
    return rows, scope, None


# ============================================================
# XƏBƏRDARLIQLAR (ALERTS) — avtomatik şəkil/jurnal/backup yoxlaması
#   Proqram işləyərkən planlı olaraq bütün aktiv ATM-ləri yoxlayır,
#   şəkli / jurnalı / server backup-ı olmayanları aşkarlayır və in-app bildirir.
# ============================================================
ALERT_LOCK = threading.Lock()
ALERT_CANCEL = threading.Event()
ALERT_WORKERS = max(2, min(32, VA_MAX_WORKERS))
ALERT_SCHED = {"thread": None, "stop": None}
ALERT_STATE = {"busy": False, "scheduler_on": False, "trigger": None,
               "started_at": None, "finished_at": None, "total": 0, "processed": 0,
               "last_run": None, "last_summary": {}, "error": None}
ALERT_KIND_LABEL = {"IMAGE": "Şəkil yoxdur", "JOURNAL": "Jurnal/log yoxdur",
                    "BACKUP": "Server backup yoxdur", "CONN": "Qoşulma yoxdur",
                    "IMAGE_OLD": "Şəkil köhnədir", "JOURNAL_OLD": "Jurnal köhnədir"}


def alert_get_config():
    con = db_connect()
    try:
        r = con.execute("SELECT * FROM alert_config WHERE id=1").fetchone()
        if not r:
            return {"enabled": 0, "interval_minutes": 180, "image_max_days": 2, "journal_max_days": 2,
                    "check_images": 1, "check_journals": 1, "check_server": 0, "mail_on": 0}
        return dict(r)
    finally:
        con.close()


def alert_save_config(data):
    cur = alert_get_config()
    def pick(k, lo, hi, default):
        try:
            v = int(data.get(k, cur.get(k, default)))
            return max(lo, min(hi, v))
        except (TypeError, ValueError):
            return cur.get(k, default)
    def pb(k):
        v = data.get(k, cur.get(k))
        return 1 if (v in (1, True, "1", "true", "on", "yes")) else 0
    row = {
        "enabled": pb("enabled"),
        "interval_minutes": pick("interval_minutes", 15, 1440, 180),
        "image_max_days": pick("image_max_days", 0, 365, 2),
        "journal_max_days": pick("journal_max_days", 0, 365, 2),
        "check_images": pb("check_images"),
        "check_journals": pb("check_journals"),
        "check_server": pb("check_server"),
        "mail_on": pb("mail_on"),
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    }
    con = db_connect()
    try:
        con.execute("""UPDATE alert_config SET enabled=?,interval_minutes=?,image_max_days=?,
            journal_max_days=?,check_images=?,check_journals=?,check_server=?,mail_on=?,updated_at=? WHERE id=1""",
            (row["enabled"], row["interval_minutes"], row["image_max_days"], row["journal_max_days"],
             row["check_images"], row["check_journals"], row["check_server"], row["mail_on"], row["updated_at"]))
        con.commit()
    finally:
        con.close()
    # planlayıcını config-ə uyğunlaşdır
    if row["enabled"]:
        alert_scheduler_start()
    else:
        alert_scheduler_stop()
    return {"success": True, "config": alert_get_config()}


def _alert_days_since_folder(dstr):
    """YYYYMMDD -> bu günə qədər gün sayı (None əgər parse olunmasa)."""
    try:
        d = datetime.strptime(str(dstr), "%Y%m%d").date()
        return max(0, (date.today() - d).days)
    except (ValueError, TypeError):
        return None


def alert_check_atm(item, cfg, cancel):
    """Bir ATM-i yoxlayır. Problem siyahısı qaytarır: [(kind, severity, message)]."""
    atm = str(item["atm_id"]).strip()
    started = time.monotonic()
    deadline = started + VA_ATM_TIMEOUT
    problems = []
    passwords = _disk_report_passwords(item.get("password_env"))
    if not passwords:
        return [("CONN", "problem", "PASSWORD environment dəyişənləri tapılmadı.")]
    target = atm
    try:
        r = socket.gethostbyname(atm)
        if r:
            target = r
    except Exception:
        pass
    try:
        with socket.create_connection((target, 445), timeout=4):
            pass
    except OSError as exc:
        return [("CONN", "problem", "TCP 445 əlçatan deyil: " + system_clean_error(exc))]
    slot, reused, err = va_smb_connect(target, passwords, cancel)
    if slot is None and not reused:
        return [("CONN", "problem", err or "Qoşulma alınmadı.")]
    try:
        has_img = False
        img_days = None
        if cfg["check_images"]:
            d = _va_scan_source(atm, target, deadline, cancel, "D$", "VIDEOARCHIVE",
                                True, "VIDEOARCHIVE YOXDUR", True)
            e = _va_scan_source(atm, target, deadline, cancel, "E$", "Video",
                                False, "VIDEO YOXDUR", False, anchor="media")
            for src in (d, e):
                if src.get("media_folder"):
                    has_img = True
                    ds = src.get("days_since")
                    if ds is not None and (img_days is None or ds < img_days):
                        img_days = ds
            if not has_img:
                problems.append(("IMAGE", "problem", "Şəkil yoxdur (VIDEOARCHIVE/Video boşdur)."))
            elif img_days is not None and img_days > cfg["image_max_days"]:
                problems.append(("IMAGE_OLD", "warn", "Son şəkil " + str(img_days) + " gün əvvəldir."))

        has_jrn = False
        jrn_days = None
        if cfg["check_journals"]:
            j = _aj_scan_path(target, atm, "Journal", deadline, cancel)
            m = None
            if not (j["files"] and j["files"] > 0):
                m = _aj_scan_path(target, atm, r"MobilPay\LOG", deadline, cancel)
            use = j if (j["files"] and j["files"] > 0) else (m or j)
            if use.get("files"):
                has_jrn = True
                jrn_days = _alert_days_since_folder(use.get("date"))
            if not has_jrn:
                problems.append(("JOURNAL", "problem", "Jurnal/log yoxdur (JOURNAL və MobilPay\\LOG boşdur)."))
            elif jrn_days is not None and jrn_days > cfg["journal_max_days"]:
                problems.append(("JOURNAL_OLD", "warn", "Son jurnal " + str(jrn_days) + " gün əvvəldir."))

        if cfg["check_server"]:
            try:
                if has_img:
                    si, _, _ = _cmp_server_set(atm, CMP_SRV_IMG_KEYS, cancel, deadline)
                    if not si:
                        problems.append(("BACKUP", "problem", "Serverdə şəkil backup-ı tapılmadı."))
                if has_jrn:
                    sj, _, _ = _cmp_server_set(atm, CMP_SRV_JRN_KEYS, cancel, deadline)
                    if not sj:
                        problems.append(("BACKUP", "problem", "Serverdə jurnal backup-ı tapılmadı."))
            except (VaTimeout, VaCancelled):
                raise
            except Exception:
                pass
        return problems
    except (VaTimeout, VaCancelled):
        return []  # keçici — növbəti dövrdə yoxlanılacaq
    except OSError as exc:
        return [("CONN", "problem", "Oxuma xətası: " + system_clean_error(exc))]
    finally:
        if slot is not None:
            _disk_report_clear_ipc(target)


def alert_reconcile(results):
    """results: {atm_id: [(kind,severity,message)]}. alerts cədvəlini yeniləyir.
    Qaytarır: yeni açılan xəbərdarlıqların sayı."""
    now = datetime.now().isoformat(timespec="seconds")
    new_count = 0
    con = db_connect()
    try:
        for atm, probs in results.items():
            cur_kinds = {}
            for (kind, sev, msg) in probs:
                cur_kinds[kind] = (sev, msg)
            existing = {r["kind"]: dict(r) for r in con.execute(
                "SELECT kind,status FROM alerts WHERE atm_id=? COLLATE NOCASE", (atm,)).fetchall()}
            # aktiv problemlər
            for kind, (sev, msg) in cur_kinds.items():
                prev = existing.get(kind)
                if prev and prev["status"] == "active":
                    con.execute("UPDATE alerts SET severity=?,message=?,last_seen=? WHERE atm_id=? AND kind=?",
                                (sev, msg, now, atm, kind))
                else:
                    con.execute("""INSERT INTO alerts(atm_id,kind,severity,status,message,details,first_seen,last_seen)
                        VALUES(?,?,?,'active',?,?,?,?)
                        ON CONFLICT(atm_id,kind) DO UPDATE SET status='active',severity=excluded.severity,
                        message=excluded.message,last_seen=excluded.last_seen,resolved_at=NULL,
                        first_seen=CASE WHEN alerts.status='active' THEN alerts.first_seen ELSE excluded.first_seen END""",
                        (atm, kind, sev, msg, "", now, now))
                    new_count += 1
            # artıq problem olmayan köhnə xəbərdarlıqları həll et
            for kind, prev in existing.items():
                if prev["status"] == "active" and kind not in cur_kinds:
                    con.execute("UPDATE alerts SET status='resolved',resolved_at=? WHERE atm_id=? AND kind=?",
                                (now, atm, kind))
        con.commit()
    finally:
        con.close()
    return new_count


def alert_summary():
    con = db_connect()
    try:
        rows = con.execute("SELECT kind,severity,COUNT(*) c FROM alerts WHERE status='active' GROUP BY kind,severity").fetchall()
        by_kind = {}
        total = 0
        problem = 0
        for r in rows:
            by_kind[r["kind"]] = by_kind.get(r["kind"], 0) + r["c"]
            total += r["c"]
            if r["severity"] == "problem":
                problem += r["c"]
        atm_count = con.execute("SELECT COUNT(DISTINCT atm_id) FROM alerts WHERE status='active'").fetchone()[0]
    finally:
        con.close()
    with ALERT_LOCK:
        st = dict(ALERT_STATE)
    return {"success": True, "active_total": total, "active_problem": problem,
            "active_atms": atm_count, "by_kind": by_kind,
            "busy": st["busy"], "scheduler_on": st["scheduler_on"],
            "processed": st["processed"], "total": st["total"],
            "last_run": st["last_run"], "trigger": st["trigger"], "error": st["error"]}


def alert_list(limit=1000, status="active"):
    con = db_connect()
    try:
        if status == "all":
            rows = con.execute("SELECT * FROM alerts ORDER BY (status='active') DESC, last_seen DESC LIMIT ?", (int(limit),)).fetchall()
        else:
            rows = con.execute("SELECT * FROM alerts WHERE status=? ORDER BY severity, last_seen DESC LIMIT ?",
                               (status, int(limit))).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["kind_label"] = ALERT_KIND_LABEL.get(d["kind"], d["kind"])
            out.append(d)
        return {"success": True, "alerts": out}
    finally:
        con.close()


def alert_excel(status="all"):
    from xlsx_lite import Workbook
    data = alert_list(status=status if status in ("active", "all", "resolved") else "all")["alerts"]
    summ = alert_summary()
    cfg = alert_get_config()
    wb = Workbook()
    s = wb.add_sheet("Xülasə", [("Göstərici", 40), ("Dəyər", 28)], autofilter=False)
    s.add_row(["ATM Xəbərdarlıqları hesabatı", datetime.now().strftime("%Y-%m-%d %H:%M")], bold=True, fill="title")
    s.add_row(["Aktiv xəbərdarlıq (cəmi)", int(summ.get("active_total") or 0)], fill="red" if summ.get("active_total") else "none")
    s.add_row(["Problemli ATM sayı", int(summ.get("active_atms") or 0)])
    by = summ.get("by_kind") or {}
    s.add_row(["Şəkil yoxdur", int(by.get("IMAGE", 0))], fill="red" if by.get("IMAGE") else "none")
    s.add_row(["Şəkil köhnədir", int(by.get("IMAGE_OLD", 0))])
    s.add_row(["Jurnal yoxdur", int(by.get("JOURNAL", 0))], fill="red" if by.get("JOURNAL") else "none")
    s.add_row(["Jurnal köhnədir", int(by.get("JOURNAL_OLD", 0))])
    s.add_row(["Server backup yoxdur", int(by.get("BACKUP", 0))])
    s.add_row(["Qoşulmayan", int(by.get("CONN", 0))])
    s.add_row(["Son yoxlama", str(summ.get("last_run") or "—")])
    s.add_row(["Avtomatik yoxlama", "AKTİV" if cfg.get("enabled") else "söndürülüb"])
    s.add_row(["Interval (dəqiqə)", int(cfg.get("interval_minutes") or 0)])

    cols = [("№", 6), ("ATM ID", 14), ("Problem", 20), ("Səviyyə", 12), ("Mesaj", 56),
            ("İlk görülüb", 20), ("Son görülüb", 20), ("Status", 12)]
    sheet = wb.add_sheet("Xəbərdarlıqlar", cols)
    fill_for = {"problem": "red", "warn": "yellow"}
    for i, a in enumerate(data, 1):
        sheet.add_row([i, a.get("atm_id", ""), a.get("kind_label") or a.get("kind", ""),
                       "PROBLEM" if a.get("severity") == "problem" else "xəbərdarlıq",
                       a.get("message") or "", str(a.get("first_seen") or ""), str(a.get("last_seen") or ""),
                       "aktiv" if a.get("status") == "active" else "həll olunub"],
                      fill=(fill_for.get(a.get("severity"), "none") if a.get("status") == "active" else "gray"),
                      bold_cols=(1,))
    stamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    return wb.to_bytes(), "ATM_Xeberdarliqlar_" + stamp + ".xlsx"


def alert_send_mail_if_needed(new_count):
    cfg = alert_get_config()
    if not cfg.get("mail_on") or new_count <= 0:
        return
    try:
        mcfg = monitor_get_config(include_secret=True)
        lst = alert_list(status="active")["alerts"]
        rows_html = "".join(
            "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (
                a["atm_id"], ALERT_KIND_LABEL.get(a["kind"], a["kind"]), a.get("severity", ""),
                (a.get("message") or "")) for a in lst[:200])
        html = ("<h3>ATM Xəbərdarlıqları</h3><p>Aktiv: %d · yeni: %d</p>"
                "<table border=1 cellpadding=4><tr><th>ATM</th><th>Problem</th><th>Səviyyə</th><th>Mesaj</th></tr>%s</table>") % (
            len(lst), new_count, rows_html)
        text = "ATM Xəbərdarlıqları — aktiv: %d, yeni: %d" % (len(lst), new_count)
        monitor_send_mail(mcfg, "ATM Xəbərdarlıqları (%d yeni)" % new_count, html, text)
        alert_log("Mail göndərildi (%d yeni xəbərdarlıq)." % new_count)
    except Exception as exc:
        alert_log("Mail göndərilmədi: " + system_clean_error(exc))


def alert_log(msg):
    try:
        monitor_log("[ALERTS] " + str(msg))
    except Exception:
        pass


def alert_run(trigger="manual"):
    with ALERT_LOCK:
        if ALERT_STATE["busy"]:
            return False, "Xəbərdarlıq yoxlaması artıq işləyir."
        ALERT_STATE.update({"busy": True, "trigger": trigger, "error": None,
                            "started_at": datetime.now().isoformat(timespec="seconds"),
                            "processed": 0, "total": 0})
    ALERT_CANCEL.clear()
    threading.Thread(target=_alert_worker, args=(trigger,), daemon=True).start()
    return True, None


def _alert_worker(trigger):
    try:
        cfg = alert_get_config()
        rows, scope, err = _select_active_atms(None)
        if err:
            raise RuntimeError(err)
        with ALERT_LOCK:
            ALERT_STATE["total"] = len(rows)
        alert_log("Yoxlama başladı (%s): %d ATM · şəkil=%s jurnal=%s server=%s" % (
            trigger, len(rows), cfg["check_images"], cfg["check_journals"], cfg["check_server"]))
        results = {}
        executor = ThreadPoolExecutor(max_workers=ALERT_WORKERS)
        try:
            inflight = {executor.submit(alert_check_atm, r, cfg, ALERT_CANCEL): r for r in rows}
            while inflight:
                if ALERT_CANCEL.is_set():
                    break
                done, _ = wait(list(inflight), timeout=0.3, return_when=FIRST_COMPLETED)
                for fut in done:
                    item = inflight.pop(fut)
                    try:
                        probs = fut.result()
                    except Exception as exc:
                        probs = [("CONN", "problem", system_clean_error(exc))]
                    results[item["atm_id"]] = probs
                    with ALERT_LOCK:
                        ALERT_STATE["processed"] += 1
        finally:
            executor.shutdown(wait=False, cancel_futures=True)
        new_count = alert_reconcile(results)
        summ = alert_summary()
        with ALERT_LOCK:
            ALERT_STATE.update({"busy": False, "finished_at": datetime.now().isoformat(timespec="seconds"),
                                "last_run": datetime.now().isoformat(timespec="seconds"),
                                "last_summary": summ})
        alert_log("Yoxlama bitdi. Aktiv: %d · yeni: %d" % (summ.get("active_total", 0), new_count))
        # Hər yoxlamadan sonra Excel yarat və Bildirişlər qutusuna yaz
        try:
            xdata, xfn = alert_excel("active")
            report_register("alerts", "ATM Xəbərdarlıqları", xdata, xfn,
                            "Aktiv: %d · yeni: %d" % (summ.get("active_total", 0), new_count))
        except Exception as exc:
            alert_log("Excel yaradılmadı: " + system_clean_error(exc))
        alert_send_mail_if_needed(new_count)
    except Exception as exc:
        with ALERT_LOCK:
            ALERT_STATE.update({"busy": False, "error": system_clean_error(exc),
                                "finished_at": datetime.now().isoformat(timespec="seconds")})
        alert_log("XƏTA: " + system_clean_error(exc))


def alert_scheduler_loop(stop_event):
    while not stop_event.is_set():
        cfg = alert_get_config()
        if not cfg.get("enabled"):
            break
        # dövrü yoxla
        ok, _ = alert_run("schedule")
        # interval qədər gözlə (dayandırmaya həssas)
        interval = max(15, int(cfg.get("interval_minutes") or 180)) * 60
        waited = 0
        while waited < interval and not stop_event.is_set():
            time.sleep(2)
            waited += 2
            # config söndürülübsə dayan
            if waited % 30 == 0 and not alert_get_config().get("enabled"):
                return


def alert_scheduler_start():
    with ALERT_LOCK:
        if ALERT_SCHED["thread"] and ALERT_SCHED["thread"].is_alive():
            ALERT_STATE["scheduler_on"] = True
            return
        stop = threading.Event()
        t = threading.Thread(target=alert_scheduler_loop, args=(stop,), daemon=True)
        ALERT_SCHED["thread"] = t
        ALERT_SCHED["stop"] = stop
        ALERT_STATE["scheduler_on"] = True
    t.start()


def alert_scheduler_stop():
    with ALERT_LOCK:
        if ALERT_SCHED["stop"]:
            ALERT_SCHED["stop"].set()
        ALERT_STATE["scheduler_on"] = False


def alert_autostart():
    try:
        if alert_get_config().get("enabled"):
            alert_scheduler_start()
    except Exception:
        pass


# ============================================================
# BİLDİRİŞLƏR — hesabat (Excel) qutusu. Hər scan Excel yaradanda ora düşür.
# ============================================================
REPORTS_NOTIF_DIR = os.path.join(BASE_DIR, "reports", "notifications")
REPORTS_KEEP = 500
REPORTS_LOCK = threading.Lock()


def report_register(module, title, data_bytes, filename, summary=""):
    """Yaradılmış Excel-i qeydə alıb saxlayır (Bildirişlər bölməsinə düşür)."""
    try:
        with REPORTS_LOCK:
            if not os.path.isdir(REPORTS_NOTIF_DIR):
                os.makedirs(REPORTS_NOTIF_DIR)
            now = datetime.now()
            safe = re.sub(r"[^A-Za-z0-9._-]", "_", filename or "report.xlsx")
            stored = now.strftime("%Y%m%d_%H%M%S_") + safe
            path = os.path.join(REPORTS_NOTIF_DIR, stored)
            with open(path, "wb") as f:
                f.write(data_bytes)
            con = db_connect()
            try:
                con.execute("""INSERT INTO report_files(module,title,filename,path,size_bytes,summary,created_at)
                    VALUES(?,?,?,?,?,?,?)""",
                    (module, title or filename, filename, path, len(data_bytes), summary,
                     now.isoformat(timespec="seconds")))
                # köhnələri təmizlə (fayl + sətir)
                old = con.execute("SELECT id,path FROM report_files ORDER BY id DESC LIMIT -1 OFFSET ?",
                                  (REPORTS_KEEP,)).fetchall()
                for r in old:
                    try:
                        if r["path"] and os.path.isfile(r["path"]):
                            os.remove(r["path"])
                    except OSError:
                        pass
                    con.execute("DELETE FROM report_files WHERE id=?", (r["id"],))
                con.commit()
            finally:
                con.close()
        return True
    except Exception as exc:
        try:
            monitor_log("[REPORTS] qeyd alınmadı: " + system_clean_error(exc))
        except Exception:
            pass
        return False


def report_list(limit=500):
    con = db_connect()
    try:
        rows = con.execute("SELECT id,module,title,filename,size_bytes,summary,created_at FROM report_files ORDER BY id DESC LIMIT ?",
                           (int(limit),)).fetchall()
        return {"success": True, "reports": [dict(r) for r in rows]}
    finally:
        con.close()


def report_path(report_id):
    con = db_connect()
    try:
        r = con.execute("SELECT path,filename FROM report_files WHERE id=?", (int(report_id),)).fetchone()
        return (r["path"], r["filename"]) if r else (None, None)
    finally:
        con.close()


def report_delete(report_id):
    con = db_connect()
    try:
        r = con.execute("SELECT path FROM report_files WHERE id=?", (int(report_id),)).fetchone()
        if not r:
            return {"success": False, "error": "Tapılmadı."}
        try:
            if r["path"] and os.path.isfile(r["path"]):
                os.remove(r["path"])
        except OSError:
            pass
        con.execute("DELETE FROM report_files WHERE id=?", (int(report_id),))
        con.commit()
        return {"success": True}
    finally:
        con.close()


# ============================================================
# SERVER (77) BACKUP XƏBƏRDARLIQLARI — bütün disklər, ən son tarix / problem
#   Yalnız server tərəf (os.scandir, sürətli; ATM-ə qoşulmur).
#   Mənbələr: ATMFILES\<ATM> , ATM_GRG_files\<ATM> , JOURNAL_FILES\<ATM> , ATM_GRG_Journal_files\<ATM>
# ============================================================
SRVALERT_LOCK = threading.Lock()
SRVALERT_CANCEL = threading.Event()
SRVALERT_SCHED = {"thread": None, "stop": None}
SRVALERT_STATE = {"busy": False, "scheduler_on": False, "processed": 0, "total": 0,
                  "last_run": None, "last_summary": {}, "error": None}
SRVALERT_SOURCES = [("D", "ATMFILES"), ("H", "ATM_GRG_files"),
                    ("DJ", "JOURNAL_FILES"), ("HJ", "ATM_GRG_Journal_files")]


def srvalert_get_config():
    con = db_connect()
    try:
        r = con.execute("SELECT * FROM srvalert_config WHERE id=1").fetchone()
        return dict(r) if r else {"enabled": 0, "interval_minutes": 180, "max_days": 2, "mail_on": 0}
    finally:
        con.close()


def srvalert_save_config(data):
    cur = srvalert_get_config()
    def pi(k, lo, hi, d):
        try:
            return max(lo, min(hi, int(data.get(k, cur.get(k, d)))))
        except (TypeError, ValueError):
            return cur.get(k, d)
    def pb(k):
        v = data.get(k, cur.get(k))
        return 1 if (v in (1, True, "1", "true", "on", "yes")) else 0
    row = {"enabled": pb("enabled"), "interval_minutes": pi("interval_minutes", 15, 1440, 180),
           "max_days": pi("max_days", 0, 365, 2), "mail_on": pb("mail_on"),
           "updated_at": datetime.now().isoformat(timespec="seconds")}
    con = db_connect()
    try:
        con.execute("UPDATE srvalert_config SET enabled=?,interval_minutes=?,max_days=?,mail_on=?,updated_at=? WHERE id=1",
                    (row["enabled"], row["interval_minutes"], row["max_days"], row["mail_on"], row["updated_at"]))
        con.commit()
    finally:
        con.close()
    if row["enabled"]:
        srvalert_scheduler_start()
    else:
        srvalert_scheduler_stop()
    return {"success": True, "config": srvalert_get_config()}


def _srv_latest_date(atm_dir, cancel, deadline, max_files=200000):
    """{root}\\<ATM> altını gəzib ən son tarixi tapır (qovluq adından VƏ fayl adından)."""
    latest = None
    seen = [0]
    stack = [atm_dir]
    while stack:
        if cancel.is_set():
            raise VaCancelled()
        if deadline and time.monotonic() > deadline:
            raise VaTimeout()
        cur = stack.pop()
        try:
            with os.scandir(cur) as it:
                for e in it:
                    try:
                        nm = e.name
                        if e.is_dir(follow_symlinks=False):
                            d = parse_date_folder(nm)
                            if d is not None and d <= date.today() + timedelta(days=2):
                                if latest is None or d > latest:
                                    latest = d
                            stack.append(e.path)
                            continue
                        if not e.is_file(follow_symlinks=False):
                            continue
                    except OSError:
                        continue
                    seen[0] += 1
                    if seen[0] > max_files:
                        return latest
                    _, dobj = _date_from_name(nm)
                    if dobj is not None and (latest is None or dobj > latest):
                        latest = dobj
        except OSError:
            continue
    return latest


def srvalert_check_atm(atm, cfg, cancel):
    started = time.monotonic()
    deadline = started + VA_ATM_TIMEOUT
    out = {"atm_id": atm, "sources": {}, "problem": False, "has_any": False}
    for key, label in SRVALERT_SOURCES:
        root = _cmp_srv_root(key)
        info = {"date": None, "days": None, "status": "—"}
        if not root:
            info["status"] = "MƏNBƏ YOX"
            out["sources"][key] = info
            continue
        atm_dir = os.path.join(root, atm)
        if not os.path.isdir(atm_dir):
            info["status"] = "QOVLUQ YOXDUR"
            out["problem"] = True
            out["sources"][key] = info
            continue
        try:
            d = _srv_latest_date(atm_dir, cancel, deadline)
        except (VaCancelled, VaTimeout):
            raise
        except Exception:
            d = None
        if d is None:
            info["status"] = "TARİX YOXDUR"
            out["problem"] = True
        else:
            out["has_any"] = True
            info["date"] = d.strftime("%Y%m%d")
            info["days"] = max(0, (date.today() - d).days)
            if info["days"] > cfg["max_days"]:
                info["status"] = "KÖHNƏ (" + str(info["days"]) + " gün)"
                out["problem"] = True
            else:
                info["status"] = "YENİ"
        out["sources"][key] = info
    return out


def srvalert_build_excel(results, cfg):
    from xlsx_lite import Workbook
    wb = Workbook()
    s = wb.add_sheet("Xülasə", [("Göstərici", 40), ("Dəyər", 26)], autofilter=False)
    total = len(results)
    problem = sum(1 for r in results if r["problem"])
    s.add_row(["Server (77) backup xəbərdarlıq hesabatı", datetime.now().strftime("%Y-%m-%d %H:%M")], bold=True, fill="title")
    s.add_row(["Server", srvexp_server_ip()])
    s.add_row(["Yoxlanılmış ATM", total])
    s.add_row(["Problemli ATM", problem], fill="red" if problem else "none")
    s.add_row(["Qaydasında (bütün disklərdə yeni)", total - problem], fill="green")
    s.add_row(["Köhnə sayılma həddi (gün)", int(cfg.get("max_days") or 2)])
    cols = [("№", 6), ("ATM ID", 14),
            ("ATMFILES tarix", 15), ("ATMFILES gün", 12),
            ("GRG_files tarix", 15), ("GRG_files gün", 12),
            ("JOURNAL_FILES tarix", 17), ("JOURNAL gün", 12),
            ("GRG_Journal tarix", 16), ("GRG_Journal gün", 13),
            ("Nəticə", 12)]
    sheet = wb.add_sheet("ATM-lər (server)", cols)
    def df(x):
        v = x.get("date")
        return (v[6:8] + "." + v[4:6] + "." + v[0:4]) if (v and len(v) == 8) else (x.get("status") or "—")
    for i, r in enumerate(results, 1):
        src = r["sources"]
        d = src.get("D", {}); h = src.get("H", {}); dj = src.get("DJ", {}); hj = src.get("HJ", {})
        sheet.add_row([i, r["atm_id"],
                       df(d), d.get("days"), df(h), h.get("days"),
                       df(dj), dj.get("days"), df(hj), hj.get("days"),
                       "PROBLEM" if r["problem"] else "OK"],
                      fill=("red" if r["problem"] else "green"), bold_cols=(1,))
    # problemli ayrıca vərəq
    bad = [r for r in results if r["problem"]]
    if bad:
        sb = wb.add_sheet("Yalnız problemli", cols)
        for i, r in enumerate(bad, 1):
            src = r["sources"]; d = src.get("D", {}); h = src.get("H", {}); dj = src.get("DJ", {}); hj = src.get("HJ", {})
            sb.add_row([i, r["atm_id"], df(d), d.get("days"), df(h), h.get("days"),
                        df(dj), dj.get("days"), df(hj), hj.get("days"), "PROBLEM"],
                       fill="red", bold_cols=(1,))
    stamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    return wb.to_bytes(), "Server77_Backup_Xeberdarliq_" + stamp + ".xlsx", total, problem


def srvalert_run(trigger="manual"):
    with SRVALERT_LOCK:
        if SRVALERT_STATE["busy"]:
            return False, "Server yoxlaması artıq işləyir."
        SRVALERT_STATE.update({"busy": True, "error": None, "processed": 0, "total": 0})
    SRVALERT_CANCEL.clear()
    threading.Thread(target=_srvalert_worker, args=(trigger,), daemon=True).start()
    return True, None


def _srvalert_worker(trigger):
    try:
        cfg = srvalert_get_config()
        rows, scope, err = _select_active_atms(None)
        if err:
            raise RuntimeError(err)
        with SRVALERT_LOCK:
            SRVALERT_STATE["total"] = len(rows)
        alert_log("Server(77) yoxlaması başladı (%s): %d ATM" % (trigger, len(rows)))
        results = []
        executor = ThreadPoolExecutor(max_workers=CMP_WORKERS)
        try:
            inflight = {executor.submit(srvalert_check_atm, r["atm_id"], cfg, SRVALERT_CANCEL): r for r in rows}
            while inflight:
                if SRVALERT_CANCEL.is_set():
                    break
                done, _ = wait(list(inflight), timeout=0.3, return_when=FIRST_COMPLETED)
                for fut in done:
                    item = inflight.pop(fut)
                    try:
                        results.append(fut.result())
                    except Exception as exc:
                        results.append({"atm_id": item["atm_id"], "sources": {}, "problem": True,
                                        "has_any": False, "error": system_clean_error(exc)})
                    with SRVALERT_LOCK:
                        SRVALERT_STATE["processed"] += 1
        finally:
            executor.shutdown(wait=False, cancel_futures=True)
        results.sort(key=lambda r: (not r["problem"], str(r["atm_id"])))
        data, fn, total, problem = srvalert_build_excel(results, cfg)
        report_register("server77", "Server (77) backup xəbərdarlıq", data, fn,
                        "Problemli: %d / %d" % (problem, total))
        summ = {"total": total, "problem": problem, "ok": total - problem}
        with SRVALERT_LOCK:
            SRVALERT_STATE.update({"busy": False, "last_run": datetime.now().isoformat(timespec="seconds"),
                                   "last_summary": summ})
        alert_log("Server(77) yoxlaması bitdi. Problemli: %d / %d · Excel yaradıldı." % (problem, total))
        if cfg.get("mail_on") and problem > 0:
            try:
                mcfg = monitor_get_config(include_secret=True)
                monitor_send_mail(mcfg, "Server (77) backup — %d problemli ATM" % problem,
                                  "<p>Server backup yoxlaması: problemli %d / %d ATM. Excel əlavədədir.</p>" % (problem, total),
                                  "Server backup: problemli %d / %d" % (problem, total),
                                  attachment=data, attach_name=fn)
            except Exception as exc:
                alert_log("Server(77) mail göndərilmədi: " + system_clean_error(exc))
    except Exception as exc:
        with SRVALERT_LOCK:
            SRVALERT_STATE.update({"busy": False, "error": system_clean_error(exc)})
        alert_log("Server(77) XƏTA: " + system_clean_error(exc))


def srvalert_summary():
    with SRVALERT_LOCK:
        st = dict(SRVALERT_STATE)
    return {"success": True, "busy": st["busy"], "scheduler_on": st["scheduler_on"],
            "processed": st["processed"], "total": st["total"], "last_run": st["last_run"],
            "last_summary": st["last_summary"], "error": st["error"]}


def srvalert_scheduler_loop(stop_event):
    while not stop_event.is_set():
        cfg = srvalert_get_config()
        if not cfg.get("enabled"):
            break
        srvalert_run("schedule")
        interval = max(15, int(cfg.get("interval_minutes") or 180)) * 60
        waited = 0
        while waited < interval and not stop_event.is_set():
            time.sleep(2)
            waited += 2
            if waited % 30 == 0 and not srvalert_get_config().get("enabled"):
                return


def srvalert_scheduler_start():
    with SRVALERT_LOCK:
        if SRVALERT_SCHED["thread"] and SRVALERT_SCHED["thread"].is_alive():
            SRVALERT_STATE["scheduler_on"] = True
            return
        stop = threading.Event()
        t = threading.Thread(target=srvalert_scheduler_loop, args=(stop,), daemon=True)
        SRVALERT_SCHED["thread"] = t
        SRVALERT_SCHED["stop"] = stop
        SRVALERT_STATE["scheduler_on"] = True
    t.start()


def srvalert_scheduler_stop():
    with SRVALERT_LOCK:
        if SRVALERT_SCHED["stop"]:
            SRVALERT_SCHED["stop"].set()
        SRVALERT_STATE["scheduler_on"] = False


def srvalert_autostart():
    try:
        if srvalert_get_config().get("enabled"):
            srvalert_scheduler_start()
    except Exception:
        pass


# ============================================================
# HTTP SERVER
# ============================================================

class ATMHandler(SimpleHTTPRequestHandler):
    # Brauzerin texniki GET/POST request loglarini CMD-de gostermirik.
    # Meselen: 127.0.0.1 - - "GET /api/..." 200 kimi setirler susdurulur.
    def log_message(self, format, *args):
        pass

    def handle(self):
        # Browser reload / tab close aborts an in-flight HTTP request.
        # This is not an ATM error and should not flood the CMD window.
        try:
            super().handle()
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            pass
        except OSError as exc:
            if getattr(exc, "winerror", None) not in (10053, 10054, 10058) and exc.errno not in (32, 54, 103, 104):
                raise

    def send_json(self, data, status=200):
        output = json.dumps(
            data, ensure_ascii=False,
            default=lambda value: value.isoformat()
            if isinstance(value, (date, datetime))
            else (_ for _ in ()).throw(TypeError("JSON tipi dəstəklənmir"))
        ).encode("utf-8")
        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(output)))
            self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
            self.end_headers()
            self.wfile.write(output)
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            # User refreshed page before response was delivered.
            return
        except OSError as exc:
            if getattr(exc, "winerror", None) in (10053, 10054, 10058) or exc.errno in (32, 54, 103, 104):
                return
            raise

    def do_GET(self):
        parsed = urlparse(self.path)

        if parsed.path.startswith("/api/srvmove/"):
            try:
                op = parsed.path.rsplit("/", 1)[-1]
                if op == "progress":
                    self.send_json({"success": True, "state": srvmove_snapshot()})
                elif op == "disks":
                    self.send_json(srvexp_disks_info())
                elif op == "list":
                    q = parse_qs(parsed.query)
                    disk = (q.get("disk", [""])[0] or "").strip().upper()
                    rel = q.get("rel", [""])[0]
                    self.send_json(explorer_list("srvdisk:" + disk, rel))
                else:
                    self.send_json({"success": False, "error": "Endpoint tapılmadı."}, 404)
            except (ValueError, FileNotFoundError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path.startswith("/api/backup/"):
            try:
                op = parsed.path.rsplit("/", 1)[-1]
                if op == "config":
                    s = bk2_load_settings()
                    self.send_json({"success": True, "settings": s,
                                    "detected_drives": bk2_detect_drives(),
                                    "active_sources": bk2_sources(s)})
                elif op == "status":
                    self.send_json({"success": True, "state": bk2_snapshot()})
                elif op == "history":
                    q = parse_qs(parsed.query)
                    self.send_json(bk2_history(int(q.get("limit", ["50"])[0] or 50)))
                else:
                    self.send_json({"success": False, "error": "Endpoint tapılmadı."}, 404)
            except ValueError as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path == "/api/atms":
            try:
                q = parse_qs(parsed.query)
                query = q.get("q", [""])[0]
                state = q.get("state", ["visible"])[0]
                self.send_json(atm_inventory_list(query, state))
            except ValueError as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        if parsed.path == "/api/atms/resolve-ips":
            try:
                q = parse_qs(parsed.query)
                raw = q.get("atms", [""])[0]
                if raw.strip():
                    atm_ids = [x for x in re.split(r"[\s,;]+", raw) if x]
                else:
                    con = db_connect()
                    try:
                        atm_ids = [r[0] for r in con.execute(
                            "SELECT atm_id FROM atms WHERE is_deleted=0 ORDER BY atm_id COLLATE NOCASE")]
                    finally:
                        con.close()
                self.send_json({"success": True, "ips": resolve_atm_ips(atm_ids)})
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path == "/api/atmcopy/progress":
            self.send_json({"success": True, **atmcopy_snapshot()})
            return

        if parsed.path == "/api/agent/list":
            try:
                self.send_json(agent_report_list())
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        if parsed.path == "/api/agent/tokens":
            try:
                self.send_json(agent_token_list())
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path == "/api/sagent/list":
            try:
                self.send_json(sagent_list())
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path.startswith("/api/alerts/"):
            op = parsed.path.rsplit("/", 1)[-1]
            try:
                if op == "summary" or op == "progress":
                    self.send_json(alert_summary())
                elif op == "list":
                    q = parse_qs(parsed.query)
                    self.send_json(alert_list(status=q.get("status", ["active"])[0]))
                elif op == "config":
                    self.send_json({"success": True, "config": alert_get_config()})
                elif op == "excel":
                    q = parse_qs(parsed.query)
                    data, filename = alert_excel(q.get("status", ["all"])[0])
                    self.send_response(200)
                    self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    self.send_header("Content-Disposition", 'attachment; filename="' + filename + '"')
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.end_headers()
                    self.wfile.write(data)
                else:
                    self.send_json({"success": False, "error": "Naməlum əməliyyat."}, 404)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path.startswith("/api/srvalert/"):
            op = parsed.path.rsplit("/", 1)[-1]
            try:
                if op in ("summary", "progress"):
                    self.send_json(srvalert_summary())
                elif op == "config":
                    self.send_json({"success": True, "config": srvalert_get_config()})
                else:
                    self.send_json({"success": False, "error": "Naməlum əməliyyat."}, 404)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path == "/api/reports/list":
            try:
                self.send_json(report_list())
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path == "/api/reports/download":
            try:
                q = parse_qs(parsed.query)
                path, filename = report_path(q.get("id", ["0"])[0] or 0)
                if not path or not os.path.isfile(path):
                    self.send_json({"success": False, "error": "Fayl tapılmadı."}, 404)
                    return
                with open(path, "rb") as f:
                    data = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                self.send_header("Content-Disposition", 'attachment; filename="' + (filename or "report.xlsx") + '"')
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.end_headers()
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path == "/api/agent/detail":
            try:
                q = parse_qs(parsed.query)
                atm_id = q.get("atm", [""])[0]
                self.send_json(agent_report_detail(atm_id))
            except ValueError as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        if parsed.path == "/api/atms/bulk_progress":
            self.send_json({"success": True, **atm_bulk_snapshot()})
            return

        if parsed.path == "/api/atms/activity":
            try:
                q = parse_qs(parsed.query)
                atm_id = q.get("atm_id", [""])[0]
                limit = int(q.get("limit", ["8"])[0])
                self.send_json(atm_activity_list(atm_id, limit))
            except (ValueError, TypeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        if parsed.path == "/api/atminfo/history":
            q = parse_qs(parsed.query)
            self.send_json(atminfo_history(q.get("atm", [""])[0], q.get("limit", ["50"])[0]))
            return
        if parsed.path == "/api/atminfo/latest":
            q = parse_qs(parsed.query)
            self.send_json(atminfo_latest(q.get("atm", [""])[0]))
            return
        if parsed.path == "/api/atminfo/snapshot":
            q = parse_qs(parsed.query)
            self.send_json(atminfo_snapshot(q.get("id", ["0"])[0]))
            return
        if parsed.path == "/api/disks":
            try:
                con = db_connect()
                try:
                    letters = [r[0] for r in con.execute(
                        "SELECT DISTINCT UPPER(letter) FROM config_disks ORDER BY letter").fetchall() if r[0]]
                finally:
                    con.close()
                if not letters:
                    letters = ["D"]
                self.send_json({"success": True, "disks": [{"letter": x} for x in letters]})
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        if parsed.path == "/api/activity/recent":
            try:
                q = parse_qs(parsed.query)
                limit = int(q.get("limit", ["15"])[0])
                self.send_json(atm_activity_recent(limit))
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        if parsed.path == "/api/atms/winmap":
            try:
                q = parse_qs(parsed.query)
                state = q.get("state", ["visible"])[0]
                self.send_json(atm_winmap_list(state if state in ("visible", "all") else "visible"))
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        if parsed.path == "/api/atms/map":
            try:
                q = parse_qs(parsed.query)
                state = q.get("state", ["visible"])[0]
                # Map yalnız silinməmiş ATM-ləri göstərir; active/inactive filtri dəstəklənir.
                if state not in ("visible", "active", "inactive"):
                    state = "visible"
                self.send_json(atm_inventory_list("", state))
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        # VIDEOARCHIVE Scan
        if parsed.path.startswith("/api/cmp/") or parsed.path.startswith("/api/ajscan/"):
            q = parse_qs(parsed.query)
            is_cmp = parsed.path.startswith("/api/cmp/")
            op = parsed.path.rsplit("/", 1)[-1]
            snap_fn = cmp_snapshot if is_cmp else aj_snapshot
            hist_fn = cmp_history if is_cmp else aj_history
            det_fn = cmp_detail if is_cmp else aj_detail
            xls_fn = cmp_excel if is_cmp else aj_excel
            try:
                if op == "progress":
                    try:
                        since = int(q.get("since", ["0"])[0])
                    except ValueError:
                        since = 0
                    snap = snap_fn(since)
                    try:
                        con = db_connect()
                        try:
                            snap["active_atm_count"] = con.execute(
                                "SELECT COUNT(*) FROM atms WHERE is_deleted=0 AND status=1").fetchone()[0]
                        finally:
                            con.close()
                    except Exception:
                        snap["active_atm_count"] = None
                    self.send_json({"success": True, **snap})
                elif op == "history":
                    self.send_json(hist_fn(int(q.get("limit", ["100"])[0] or 100)))
                elif op == "detail":
                    detail = det_fn(int(q.get("id", ["0"])[0] or 0))
                    if detail is None:
                        self.send_json({"success": False, "error": "Tapılmadı."}, 404)
                    else:
                        self.send_json(detail)
                elif op == "excel":
                    data, filename = xls_fn(int(q.get("id", ["0"])[0] or 0))
                    self.send_response(200)
                    self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.end_headers()
                    self.wfile.write(data)
                else:
                    self.send_json({"success": False, "error": "Naməlum əməliyyat."}, 404)
            except FileNotFoundError as exc:
                self.send_json({"success": False, "error": str(exc)}, 404)
            except ValueError as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        # Avtomatik backup (AUTOBK)
        if parsed.path.startswith("/api/autobk/"):
            q = parse_qs(parsed.query)
            op = parsed.path.rsplit("/", 1)[-1]
            try:
                if op == "progress":
                    try:
                        since = int(q.get("since", ["0"])[0])
                    except ValueError:
                        since = 0
                    self.send_json({"success": True, **bk_snapshot(since)})
                elif op == "excel":
                    with BK_LOCK:
                        have = bool(BK_STATE["results"])
                    if not have:
                        raise FileNotFoundError("Hələ nəticə yoxdur.")
                    data, filename, _ = bk_build_excel()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.end_headers()
                    self.wfile.write(data)
                else:
                    self.send_json({"success": False, "error": "Naməlum əməliyyat."}, 404)
            except FileNotFoundError as exc:
                self.send_json({"success": False, "error": str(exc)}, 404)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        # Çatışmayan tarix scan (MISSDATE)
        if parsed.path.startswith("/api/missdate/"):
            q = parse_qs(parsed.query)
            op = parsed.path.rsplit("/", 1)[-1]
            try:
                if op == "progress":
                    try:
                        since = int(q.get("since", ["0"])[0])
                    except ValueError:
                        since = 0
                    self.send_json({"success": True, **md_snapshot(since)})
                elif op == "excel":
                    with MD_LOCK:
                        have = bool(MD_STATE["results"])
                    if not have:
                        raise FileNotFoundError("Hələ nəticə yoxdur.")
                    data, filename, _ = md_build_excel()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.end_headers()
                    self.wfile.write(data)
                else:
                    self.send_json({"success": False, "error": "Naməlum əməliyyat."}, 404)
            except FileNotFoundError as exc:
                self.send_json({"success": False, "error": str(exc)}, 404)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/vascan/progress", "/api/vascan/history", "/api/vascan/detail", "/api/vascan/excel"):
            q = parse_qs(parsed.query)
            try:
                if parsed.path == "/api/vascan/progress":
                    try:
                        since = int(q.get("since", ["0"])[0])
                    except ValueError:
                        since = 0
                    snap = va_snapshot(since)
                    try:
                        con = db_connect()
                        try:
                            snap["active_atm_count"] = con.execute(
                                "SELECT COUNT(*) FROM atms WHERE is_deleted=0 AND status=1").fetchone()[0]
                        finally:
                            con.close()
                    except Exception:
                        snap["active_atm_count"] = None
                    self.send_json({"success": True, **snap})
                elif parsed.path == "/api/vascan/history":
                    self.send_json(va_history(int(q.get("limit", ["100"])[0] or 100)))
                elif parsed.path == "/api/vascan/detail":
                    detail = va_detail(int(q.get("id", ["0"])[0] or 0))
                    if detail is None:
                        self.send_json({"success": False, "error": "Scan tapılmadı."}, 404)
                    else:
                        self.send_json(detail)
                else:
                    data, filename = va_excel(int(q.get("id", ["0"])[0] or 0))
                    self.send_response(200)
                    self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.end_headers()
                    self.wfile.write(data)
            except FileNotFoundError as exc:
                self.send_json({"success": False, "error": str(exc)}, 404)
            except ValueError as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/berpa/maps", "/api/berpa/progress",
                           "/api/berpa/history", "/api/berpa/detail", "/api/berpa/excel"):
            q = parse_qs(parsed.query)
            try:
                if parsed.path == "/api/berpa/maps":
                    out = {"success": True, "maps": berpa_maps_config()}
                    try:
                        con = db_connect()
                        try:
                            out["active_atm_count"] = con.execute(
                                "SELECT COUNT(*) FROM atms WHERE is_deleted=0 AND status=1").fetchone()[0]
                        finally:
                            con.close()
                    except Exception:
                        out["active_atm_count"] = None
                    self.send_json(out)
                elif parsed.path == "/api/berpa/progress":
                    try:
                        since = int(q.get("since", ["0"])[0])
                    except ValueError:
                        since = 0
                    self.send_json({"success": True, **berpa_snapshot(since)})
                elif parsed.path == "/api/berpa/history":
                    self.send_json(berpa_history(int(q.get("limit", ["100"])[0] or 100)))
                elif parsed.path == "/api/berpa/detail":
                    detail = berpa_detail(int(q.get("id", ["0"])[0] or 0))
                    if detail is None:
                        self.send_json({"success": False, "error": "Hesabat tapılmadı."}, 404)
                    else:
                        self.send_json(detail)
                else:
                    data, filename = berpa_excel(int(q.get("id", ["0"])[0] or 0))
                    self.send_response(200)
                    self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.end_headers()
                    self.wfile.write(data)
            except FileNotFoundError as exc:
                self.send_json({"success": False, "error": str(exc)}, 404)
            except ValueError as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/deploy/progress", "/api/deploy/history", "/api/deploy/detail",
                           "/api/deploy/excel", "/api/deploy/browse", "/api/deploy/check-source"):
            q = parse_qs(parsed.query)
            try:
                if parsed.path == "/api/deploy/progress":
                    try:
                        since = int(q.get("since", ["0"])[0])
                    except ValueError:
                        since = 0
                    self.send_json({"success": True, **deploy_snapshot(since)})
                elif parsed.path == "/api/deploy/history":
                    self.send_json(deploy_history(int(q.get("limit", ["100"])[0] or 100)))
                elif parsed.path == "/api/deploy/browse":
                    self.send_json(deploy_browse(q.get("path", [""])[0]))
                elif parsed.path == "/api/deploy/check-source":
                    self.send_json(deploy_check_source(q.get("path", [""])[0]))
                elif parsed.path == "/api/deploy/detail":
                    detail = deploy_detail(int(q.get("id", ["0"])[0] or 0))
                    if detail is None:
                        self.send_json({"success": False, "error": "Hesabat tapılmadı."}, 404)
                    else:
                        self.send_json(detail)
                else:
                    data, filename = deploy_excel(int(q.get("id", ["0"])[0] or 0))
                    self.send_response(200)
                    self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.end_headers()
                    self.wfile.write(data)
            except FileNotFoundError as exc:
                self.send_json({"success": False, "error": str(exc)}, 404)
            except ValueError as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/monitor/status", "/api/monitor/config", "/api/monitor/thresholds",
                           "/api/monitor/history", "/api/monitor/detail", "/api/monitor/excel"):
            q = parse_qs(parsed.query)
            try:
                if parsed.path == "/api/monitor/status":
                    self.send_json(monitor_status())
                elif parsed.path == "/api/monitor/config":
                    self.send_json({"success": True, "config": monitor_get_config()})
                elif parsed.path == "/api/monitor/thresholds":
                    self.send_json({"success": True, "rows": monitor_threshold_list()})
                elif parsed.path == "/api/monitor/history":
                    self.send_json(monitor_history(int(q.get("limit", ["100"])[0] or 100)))
                elif parsed.path == "/api/monitor/detail":
                    detail = monitor_detail(int(q.get("id", ["0"])[0] or 0))
                    if detail is None:
                        self.send_json({"success": False, "error": "Hesabat tapılmadı."}, 404)
                    else:
                        self.send_json(detail)
                else:
                    data, filename = monitor_excel(int(q.get("id", ["0"])[0] or 0))
                    self.send_response(200)
                    self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.end_headers()
                    self.wfile.write(data)
            except FileNotFoundError as exc:
                self.send_json({"success": False, "error": str(exc)}, 404)
            except ValueError as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/jberpa/config", "/api/jberpa/progress",
                           "/api/jberpa/history", "/api/jberpa/detail", "/api/jberpa/excel"):
            q = parse_qs(parsed.query)
            try:
                if parsed.path == "/api/jberpa/config":
                    out = {"success": True, "config": jberpa_config()}
                    try:
                        con = db_connect()
                        try:
                            out["active_atm_count"] = con.execute(
                                "SELECT COUNT(*) FROM atms WHERE is_deleted=0 AND status=1").fetchone()[0]
                        finally:
                            con.close()
                    except Exception:
                        out["active_atm_count"] = None
                    self.send_json(out)
                elif parsed.path == "/api/jberpa/progress":
                    try:
                        since = int(q.get("since", ["0"])[0])
                    except ValueError:
                        since = 0
                    self.send_json({"success": True, **jberpa_snapshot(since)})
                elif parsed.path == "/api/jberpa/history":
                    self.send_json(jberpa_history(int(q.get("limit", ["100"])[0] or 100)))
                elif parsed.path == "/api/jberpa/detail":
                    detail = jberpa_detail(int(q.get("id", ["0"])[0] or 0))
                    if detail is None:
                        self.send_json({"success": False, "error": "Hesabat tapılmadı."}, 404)
                    else:
                        self.send_json(detail)
                else:
                    data, filename = jberpa_excel(int(q.get("id", ["0"])[0] or 0))
                    self.send_response(200)
                    self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.end_headers()
                    self.wfile.write(data)
            except FileNotFoundError as exc:
                self.send_json({"success": False, "error": str(exc)}, 404)
            except ValueError as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path == "/api/disk-report/progress":
            try:
                q = parse_qs(parsed.query)
                since = int(q.get("since", ["0"])[0])
            except Exception:
                since = 0
            self.send_json({"success": True, **disk_report_snapshot(since)})
            return

        if parsed.path == "/api/disk-report/history":
            try:
                q = parse_qs(parsed.query)
                limit = int(q.get("limit", ["120"])[0])
                self.send_json(disk_report_history(limit))
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        if parsed.path == "/api/disk-report/detail":
            try:
                q = parse_qs(parsed.query)
                run_id = int(q.get("id", ["0"])[0])
                detail = disk_report_detail(run_id)
                if detail is None:
                    self.send_json({"success": False, "error": "Disk Report tapılmadı."}, 404)
                else:
                    self.send_json(detail)
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            return

        if parsed.path == "/api/system/progress":
            with SYSTEM_LOCK:
                snapshot = dict(SYSTEM_STATE)
                snapshot["logs"] = list(SYSTEM_STATE["logs"])
                snapshot["warnings"] = list(SYSTEM_STATE["warnings"])
            self.send_json({"request_ok": True, **snapshot})
            return


        # VIDEO / ŞƏKİL SERVER — mənbələr, ATM yoxlaması, tarix folderi statistikası
        if parsed.path in ("/api/srvmedia/sources", "/api/srvmedia/check", "/api/srvmedia/stats"):
            try:
                q = parse_qs(parsed.query)
                if parsed.path == "/api/srvmedia/sources":
                    self.send_json({"success": True, "sources": srvmedia_sources()})
                elif parsed.path == "/api/srvmedia/check":
                    self.send_json(srvmedia_check(q.get("atm", [""])[0], q.get("date", [""])[0]))
                else:
                    self.send_json(srvmedia_stats(q.get("src", [""])[0].upper(),
                                                  q.get("atm", [""])[0], q.get("folder", [""])[0]))
            except ValueError as e:
                self.send_json({"success": False, "error": str(e)}, 400)
            except OSError as e:
                self.send_json({"success": False, "error": str(e)}, 404)
            except Exception as e:
                self.send_json({"success": False, "error": str(e)}, 500)
            return

        if (parsed.path.startswith("/api/explorer/") or parsed.path.startswith("/api/srvmedia/")
                or parsed.path.startswith("/api/srvexp/")):
            try:
                q = parse_qs(parsed.query)
                root = q.get("root", ["d"])[0]
                rel = q.get("rel", [""])[0]
                op = parsed.path.rsplit("/", 1)[-1]
                is_srvexp = parsed.path.startswith("/api/srvexp/")
                if is_srvexp:
                    # Server Explorer: yalnız srvdisk: kökü; disks op-u disk siyahısını verir
                    if op == "disks":
                        self.send_json(srvexp_disks_info())
                        return
                    if op == "usage":
                        # Hər server diski üçün sxematik həcm (total/used/free/percent)
                        self.send_json(srvexp_disks_usage())
                        return
                    if not str(root).lower().startswith("srvdisk:"):
                        raise ValueError("Bu endpoint yalnız server diski (srvdisk:) üçündür.")
                    if op not in ("list", "text", "media", "transcode"):
                        self.send_json({"success": False, "error": "Endpoint tapılmadı."}, 404)
                        return
                else:
                    # /api/srvmedia/* yalnız server kökü (srv:...) ilə, /api/explorer/* isə yalnız ATM kökü ilə
                    # işləyir — icazələr (archive.* / videoserver.*) bir-birinə keçməsin.
                    is_srv = parsed.path.startswith("/api/srvmedia/")
                    if is_srv != str(root).lower().startswith("srv:"):
                        raise ValueError("Bu kök bu endpoint üçün deyil.")
                    if is_srv and op not in ("list", "text", "media", "transcode"):
                        self.send_json({"success": False, "error": "Endpoint tapılmadı."}, 404)
                        return
                if op == "list":
                    self.send_json(explorer_list(root, rel))
                elif op == "latest":
                    self.send_json(explorer_latest_folder_files())
                elif op == "journal":
                    self.send_json(explorer_latest_journal())
                elif op == "text":
                    path, ext = explorer_preview_file(root, rel)
                    if ext not in EXPLORER_TEXT_EXTS:
                        raise ValueError("Yalnız TXT/JRN/LOG/CSV mətn kimi açılır.")
                    max_bytes = 1024 * 1024
                    with open(path, "rb") as f:
                        content = f.read(max_bytes + 1)
                    truncated = len(content) > max_bytes
                    content = content[:max_bytes]
                    # JRN içində 0x00 ola bilər, binary mətnini olduğu kimi göstərmə.
                    for encoding in ("utf-8-sig", "utf-16", "cp1251", "cp1252"):
                        try:
                            decoded = content.decode(encoding)
                            break
                        except UnicodeError:
                            continue
                    else:
                        decoded = content.decode("utf-8", errors="replace")
                    self.send_json({"success": True, "name": ntpath.basename(path),
                                    "text": decoded, "truncated": truncated})
                elif op == "transcode":
                    # AVI/WMV/MKV və s. -> uçuş zamanı MP4(H.264) axını (ffmpeg).
                    # Brauzer <video> birbaşa AVI oynatmadığı üçün lazımdır.
                    path, ext = explorer_preview_file(root, rel)
                    if ext in EXPLORER_TEXT_EXTS or ext in ARCHIVE_IMAGE_EXTENSIONS:
                        raise ValueError("Transcode yalnız video fayllar üçündür.")
                    ffmpeg = system_find_ffmpeg()
                    if not ffmpeg:
                        self.send_json({"success": False, "error":
                            "ffmpeg tapılmadı. AVI-ni brauzerdə oynatmaq üçün ffmpeg.exe server qovluğuna qoyulmalıdır."}, 400)
                        return
                    cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-i", path,
                           "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28", "-pix_fmt", "yuv420p",
                           "-c:a", "aac", "-b:a", "128k",
                           "-movflags", "frag_keyframe+empty_moov+default_base_moof",
                           "-f", "mp4", "pipe:1"]
                    self.send_response(200)
                    self.send_header("Content-Type", "video/mp4")
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.end_headers()
                    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                    try:
                        while True:
                            chunk = proc.stdout.read(65536)
                            if not chunk:
                                break
                            self.wfile.write(chunk)
                    except (BrokenPipeError, ConnectionResetError):
                        pass  # istifadəçi videonu bağladı
                    finally:
                        try:
                            proc.stdout.close()
                        except Exception:
                            pass
                        try:
                            proc.terminate()
                        except Exception:
                            pass
                    return
                elif op == "media":
                    path, ext = explorer_preview_file(root, rel)
                    if ext in EXPLORER_TEXT_EXTS:
                        raise ValueError("Mətn üçün /api/explorer/text istifadə et.")
                    mime = mimetypes.types_map.get(ext, "application/octet-stream")
                    if ext == ".mp4": mime = "video/mp4"
                    size = os.path.getsize(path)
                    range_header = self.headers.get("Range", "")
                    first, last = 0, max(size - 1, 0)
                    status = 200
                    if range_header:
                        m = re.fullmatch(r"bytes=(\d*)-(\d*)", range_header.strip())
                        if not m or size == 0 or (not m.group(1) and not m.group(2)):
                            raise ValueError("Video byte range düzgün deyil.")
                        if not m.group(1):
                            suffix = int(m.group(2))
                            first = max(0, size - suffix)
                        else:
                            first = int(m.group(1))
                        if m.group(2) and m.group(1):
                            last = min(size - 1, int(m.group(2)))
                        if first >= size or last < first:
                            self.send_response(416)
                            self.send_header("Content-Range", f"bytes */{size}")
                            self.end_headers()
                            return
                        status = 206
                    self.send_response(status)
                    self.send_header("Content-Type", mime)
                    self.send_header("Accept-Ranges", "bytes")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.send_header("Content-Disposition", "inline")
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("Content-Length", str(last - first + 1 if size else 0))
                    if status == 206:
                        self.send_header("Content-Range", f"bytes {first}-{last}/{size}")
                    self.end_headers()
                    with open(path, "rb") as f:
                        f.seek(first)
                        remaining = last - first + 1 if size else 0
                        while remaining > 0:
                            chunk = f.read(min(1024 * 1024, remaining))
                            if not chunk: break
                            self.wfile.write(chunk)
                            remaining -= len(chunk)
                else:
                    self.send_json({"success": False, "error": "Endpoint tapılmadı."}, 404)
            except (ValueError, PermissionError) as e:
                self.send_json({"success": False, "error": str(e)}, 400)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except OSError as e:
                self.send_json({"success": False, "error": str(e)}, 404)
            return

        if parsed.path == "/api/config":
            # 4 standart SCAN mənbəsindən (D/H/DJ/HJ) hər hansı biri itibsə — həmin an bərpa et.
            # (Yalnız hamısı boş olanda yox: bəziləri varsa belə, çatışmayanı təmir edir.)
            try:
                con = db_connect()
                try:
                    present = set(db_source_paths(con))
                finally:
                    con.close()
                if {"D", "H", "DJ", "HJ"} - present and seed_default_sources():
                    refresh_source_cache()
            except Exception:
                pass
            self.send_json(config_snapshot())
            return

        # START SCAN
        if parsed.path == "/api/start":
            params = parse_qs(parsed.query)
            selected_date = params.get("date", [""])[0]
            scan_type = params.get("scan_type", ["D"])[0].upper()
            started, error, scan_id = start_scan(selected_date, scan_type)
            self.send_json({
                "success": error is None,
                "started": started,
                "scan_id": scan_id,
                "scan_type": scan_type,
                "source_path": SCAN_STATES[scan_type]["source_path"] if scan_type in SCAN_STATES else None,
                "error": error
            })
            return

        # LIVE PROGRESS
        if parsed.path == "/api/progress":
            params = parse_qs(parsed.query)
            scan_type = params.get("scan_type", ["D"])[0].upper()
            if scan_type not in SCAN_LABELS:
                self.send_json({"success": False, "error": "Scan tipi düzgün deyil."}, 400)
                return
            try:
                since = int(params.get("since", ["0"])[0])
            except Exception:
                since = 0

            with SCAN_LOCK:
                state = SCAN_STATES[scan_type]
                completed = state["completed_results"]
                if since < 0 or since > len(completed):
                    since = 0
                response = {
                    "success": True,
                    "scan_type": scan_type,
                    "source_path": state["source_path"],
                    "scan_id": state["scan_id"],
                    "running": state["running"],
                    "cancel_requested": state.get("cancel_requested", False),
                    "finished": state["finished"],
                    "started_at": state["started_at"],
                    "finished_at": state["finished_at"],
                    "total_atms": state["total_atms"],
                    "processed_atms": state["processed_atms"],
                    "percent": state["percent"],
                    "current_atm": state["current_atm"],
                    "current_path": state["current_path"],
                    "current_action": state["current_action"],
                    "selected_date": state["selected_date"],
                    "selected_date_display": state["selected_date_display"],
                    "yesterday": state["yesterday"],
                    "yesterday_display": state["yesterday_display"],
                    "summary": dict(state["summary"]),
                    "results": completed[since:],
                    "next_index": len(completed),
                    "logs": state["logs"][-160:],
                    "error": state["error"]
                }
            self.send_json(response)
            return

        # HISTORY LIST — yeni D/H və yalnız oxunan köhnə C tarixçəsi.
        if parsed.path == "/api/history":
            params = parse_qs(parsed.query)
            try:
                limit = min(max(int(params.get("limit", ["500"])[0]), 1), 5000)
            except Exception:
                limit = 500

            scan_type = params.get("scan_type", ["D"])[0].upper()
            con=db_connect()
            try:
                historic=con.execute("SELECT source_path FROM scans WHERE scan_type=? ORDER BY id DESC LIMIT 1",(scan_type,)).fetchone()
            finally:
                con.close()
            if scan_type not in SCAN_LABELS and historic is None:
                self.send_json({"success": False, "error": "Scan tipi düzgün deyil."}, 400)
                return
            self.send_json({
                "success": True,
                "scan_type": scan_type,
                "source_path": SCAN_SOURCES.get(scan_type) or (historic[0] if historic else ""),
                "scans": get_history(limit, scan_type)
            })
            return

        # HISTORY DETAIL
        if parsed.path == "/api/history_detail":
            params = parse_qs(parsed.query)
            try:
                scan_id = int(params.get("id", ["0"])[0])
            except Exception:
                scan_id = 0

            detail = get_scan_detail(scan_id)
            if detail is None:
                self.send_json({"success": False, "error": "Scan tapılmadı."}, 404)
            else:
                self.send_json({"success": True, **detail})
            return

        if parsed.path == "/api/scan/excel":
            params = parse_qs(parsed.query)
            try:
                scan_id = int(params.get("id", ["0"])[0] or 0)
                data, filename = scan_excel(scan_id)
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                self.send_header("Content-Disposition", 'attachment; filename="' + filename + '"')
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.end_headers()
                self.wfile.write(data)
            except FileNotFoundError as exc:
                self.send_json({"success": False, "error": str(exc)}, 404)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        # COMPARE TWO SCANS
        if parsed.path == "/api/compare":
            params = parse_qs(parsed.query)
            try:
                old_id = int(params.get("old_id", ["0"])[0])
                new_id = int(params.get("new_id", ["0"])[0])
            except Exception:
                old_id = 0
                new_id = 0

            try:
                data = compare_scans(old_id, new_id)
            except ValueError as e:
                self.send_json({"success": False, "error": str(e)}, 400)
                return
            if data is None:
                self.send_json({"success": False, "error": "Müqayisə üçün scan tapılmadı."}, 404)
            else:
                self.send_json({"success": True, **data})
            return

        # RESTART MODULE CONFIG
        if parsed.path == "/api/restart/config":
            self.send_json({"success": True, **restart_config_info()})
            return

        # RESTART MODULE PROGRESS
        if parsed.path == "/api/restart/progress":
            with RESTART_LOCK:
                state = dict(RESTART_STATE)
                state["logs"] = list(RESTART_STATE["logs"])
            self.send_json({"success": True, **state})
            return

        # VIDEO ARCHIVE MODULE CONFIG
        if parsed.path == "/api/archive/config":
            self.send_json({"success": True, **archive_config_info()})
            return

        # VIDEO ARCHIVE MODULE PROGRESS
        if parsed.path == "/api/archive/progress":
            with ARCHIVE_LOCK:
                state = dict(ARCHIVE_STATE)
                state["logs"] = list(ARCHIVE_STATE["logs"])
                if ARCHIVE_STATE["result"] is not None:
                    state["result"] = dict(ARCHIVE_STATE["result"])
            self.send_json({"request_ok": True, **state})
            return

        if parsed.path == "/favicon.ico":
            self.send_response(204)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if parsed.path == "/":
            self.path = "/index.html"
        elif parsed.path != "/index.html":
            self.send_json({"success": False, "error": "Bu fayla web-dən giriş bağlıdır."}, 404)
            return

        super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)

        if parsed.path.startswith("/api/srvmove/"):
            op = parsed.path.rsplit("/", 1)[-1]
            try:
                if op == "cancel":
                    ok, error = srvmove_cancel()
                    self.send_json({"success": ok, "error": error}, 200 if ok else 409)
                    return
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length > 5000000:
                    raise ValueError("Sorğu çox böyükdür.")
                data = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}
                if not isinstance(data, dict):
                    raise ValueError("Sorğu formatı düzgün deyil.")
                if op == "start":
                    ok, error, info = srvmove_start(data)
                    self.send_json({"success": ok, "error": error, "info": info}, 200 if ok else 409)
                else:
                    self.send_json({"success": False, "error": "Endpoint tapılmadı."}, 404)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path.startswith("/api/backup/"):
            op = parsed.path.rsplit("/", 1)[-1]
            try:
                if op in ("pause", "resume", "cancel"):
                    fn = {"pause": bk2_pause, "resume": bk2_resume, "cancel": bk2_cancel}[op]
                    ok, error = fn()
                    self.send_json({"success": ok, "error": error}, 200 if ok else 409)
                    return
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length > 5000000:
                    raise ValueError("Sorğu çox böyükdür.")
                data = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}
                if not isinstance(data, dict):
                    raise ValueError("Sorğu formatı düzgün deyil.")
                if op == "config":
                    self.send_json({"success": True, "settings": bk2_save_settings(data)})
                elif op == "discover":
                    if data:
                        bk2_save_settings(data)
                    self.send_json(bk2_discover(bk2_load_settings()))
                elif op == "plan":
                    self.send_json(bk2_plan(data))
                elif op == "start":
                    ok, error, info = bk2_start(data)
                    self.send_json({"success": ok, "error": error, "info": info}, 200 if ok else 409)
                else:
                    self.send_json({"success": False, "error": "Endpoint tapılmadı."}, 404)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/cmp/start", "/api/cmp/cancel", "/api/ajscan/start", "/api/ajscan/cancel"):
            is_cmp = parsed.path.startswith("/api/cmp/")
            try:
                if parsed.path.endswith("/cancel"):
                    ok, error = (cmp_cancel() if is_cmp else aj_cancel())
                    self.send_json({"success": ok, "error": error}, 200 if ok else 409)
                    return
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length > 500000:
                    raise ValueError("Sorğu çox böyükdür.")
                data = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}
                if not isinstance(data, dict):
                    raise ValueError("Sorğu formatı düzgün deyil.")
                starter = cmp_start if is_cmp else aj_start
                ok, error, run_id = starter(data.get("atm_ids") or None)
                self.send_json({"success": ok, "error": error, "run_id": run_id}, 200 if ok else 409)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/autobk/start", "/api/autobk/cancel"):
            try:
                if parsed.path.endswith("/cancel"):
                    ok, error = bk_cancel()
                    self.send_json({"success": ok, "error": error}, 200 if ok else 409)
                    return
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length > 2000000:
                    raise ValueError("Sorğu çox böyükdür.")
                data = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}
                if not isinstance(data, dict):
                    raise ValueError("Sorğu formatı düzgün deyil.")
                ok, error, info = bk_start(data)
                self.send_json({"success": ok, "error": error, "info": info}, 200 if ok else 409)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/missdate/start", "/api/missdate/cancel"):
            try:
                if parsed.path.endswith("/cancel"):
                    ok, error = md_cancel()
                    self.send_json({"success": ok, "error": error}, 200 if ok else 409)
                    return
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length > 500000:
                    raise ValueError("Sorğu çox böyükdür.")
                data = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}
                if not isinstance(data, dict):
                    raise ValueError("Sorğu formatı düzgün deyil.")
                ok, error, total = md_start(data.get("key"), data.get("atm_ids") or None,
                                            data.get("start_date"), data.get("end_date"))
                self.send_json({"success": ok, "error": error, "total": total}, 200 if ok else 409)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/vascan/start", "/api/vascan/cancel"):
            try:
                if parsed.path.endswith("/cancel"):
                    ok, error = va_cancel()
                    self.send_json({"success": ok, "error": error}, 200 if ok else 409)
                    return
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length > 500000:
                    raise ValueError("Sorğu çox böyükdür.")
                data = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}
                if not isinstance(data, dict):
                    raise ValueError("Sorğu formatı düzgün deyil.")
                ok, error, run_id = va_start(data.get("atm_ids") or None)
                self.send_json({"success": ok, "error": error, "run_id": run_id}, 200 if ok else 409)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/berpa/start", "/api/berpa/cancel"):
            try:
                if parsed.path.endswith("/cancel"):
                    ok, error = berpa_cancel()
                    self.send_json({"success": ok, "error": error}, 200 if ok else 409)
                    return
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length > 500000:
                    raise ValueError("Sorğu çox böyükdür.")
                data = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}
                if not isinstance(data, dict):
                    raise ValueError("Sorğu formatı düzgün deyil.")
                ok, error, run_id = berpa_start(
                    data.get("atm_ids") or None,
                    bool(data.get("dry_run")),
                    data.get("maps") or None)
                self.send_json({"success": ok, "error": error, "run_id": run_id}, 200 if ok else 409)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/atmcopy/start", "/api/atmcopy/cancel"):
            try:
                if parsed.path.endswith("/cancel"):
                    ok, error = atmcopy_cancel()
                    self.send_json({"success": ok, "error": error}, 200 if ok else 409)
                    return
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length < 1 or length > 100000:
                    raise ValueError("Sorğu ölçüsü düzgün deyil.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(data, dict):
                    raise ValueError("Sorğu formatı düzgün deyil.")
                ok, error = atmcopy_start(data.get("atm"), data.get("disk"),
                                          data.get("source_rel"), data.get("dest"))
                self.send_json({"success": ok, "error": error}, 200 if ok else 409)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/deploy/start", "/api/deploy/cancel"):
            try:
                if parsed.path.endswith("/cancel"):
                    ok, error = deploy_cancel()
                    self.send_json({"success": ok, "error": error}, 200 if ok else 409)
                    return
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length > 2 * 1024 * 1024:
                    raise ValueError("Sorğu çox böyükdür.")
                data = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}
                if not isinstance(data, dict):
                    raise ValueError("Sorğu formatı düzgün deyil.")
                ok, error, run_id = deploy_start(
                    data.get("atm_ids") or [], data.get("source") or "", data.get("dest") or "",
                    bool(data.get("contents_only")), bool(data.get("overwrite", True)))
                self.send_json({"success": ok, "error": error, "run_id": run_id}, 200 if ok else 409)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path == "/api/monitor/thresholds/import":
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length < 1 or length > 30 * 1024 * 1024:
                    raise ValueError("Fayl ölçüsü düzgün deyil (boş və ya çox böyük).")
                body = self.rfile.read(length)
                self.send_json(monitor_import_thresholds(body))
            except ValueError as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/monitor/config/save", "/api/monitor/start", "/api/monitor/stop",
                           "/api/monitor/run-now", "/api/monitor/test-mail", "/api/monitor/thresholds/clear"):
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                data = {}
                if 0 < length <= 500000:
                    try:
                        data = json.loads(self.rfile.read(length).decode("utf-8"))
                    except (ValueError, json.JSONDecodeError):
                        data = {}
                if not isinstance(data, dict):
                    data = {}
                if parsed.path == "/api/monitor/config/save":
                    self.send_json({"success": True, "config": monitor_save_config(data)})
                elif parsed.path == "/api/monitor/thresholds/clear":
                    self.send_json(monitor_clear_thresholds())
                elif parsed.path == "/api/monitor/start":
                    ok, error = monitor_scheduler_start()
                    self.send_json({"success": ok, "error": error}, 200 if ok else 409)
                elif parsed.path == "/api/monitor/stop":
                    ok, error = monitor_scheduler_stop()
                    self.send_json({"success": ok, "error": error}, 200 if ok else 409)
                elif parsed.path == "/api/monitor/run-now":
                    with MONITOR_LOCK:
                        busy = MONITOR_STATE["busy"]
                    if busy:
                        self.send_json({"success": False, "error": "Yoxlama artıq gedir."}, 409)
                    else:
                        threading.Thread(target=monitor_run_check, args=("manual",), daemon=True).start()
                        self.send_json({"success": True})
                else:  # test-mail
                    cfg = monitor_get_config(include_secret=True)
                    if data.get("smtp_pass"):
                        cfg["smtp_pass"] = data["smtp_pass"]
                    for k in ("smtp_host", "smtp_port", "smtp_security", "smtp_user", "mail_from", "mail_to"):
                        if data.get(k) not in (None, ""):
                            cfg[k] = data[k]
                    try:
                        monitor_send_mail(cfg, "ATM Foto Monitorinq — test mail",
                                          "<p>Bu test mesajıdır. SMTP ayarları işləyir.</p>",
                                          "Bu test mesajıdır. SMTP ayarları işləyir.")
                        self.send_json({"success": True})
                    except Exception as exc:
                        self.send_json({"success": False, "error": system_clean_error(exc)}, 400)
            except ValueError as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/jberpa/start", "/api/jberpa/cancel"):
            try:
                if parsed.path.endswith("/cancel"):
                    ok, error = jberpa_cancel()
                    self.send_json({"success": ok, "error": error}, 200 if ok else 409)
                    return
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length > 500000:
                    raise ValueError("Sorğu çox böyükdür.")
                data = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}
                if not isinstance(data, dict):
                    raise ValueError("Sorğu formatı düzgün deyil.")
                ok, error, run_id = jberpa_start(data.get("atm_ids") or None, bool(data.get("dry_run")))
                self.send_json({"success": ok, "error": error, "run_id": run_id}, 200 if ok else 409)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/disk-report/start", "/api/disk-report/cancel"):
            try:
                if parsed.path.endswith("/cancel"):
                    ok, error = disk_report_cancel()
                    self.send_json({"success": ok, "error": error}, 200 if ok else 409)
                    return
                length = int(self.headers.get("Content-Length", "0"))
                if length < 1 or length > 250000:
                    raise ValueError("Disk Report sorğusunun ölçüsü düzgün deyil.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                ok, error, run_id = disk_report_start(data.get("atm_ids", []))
                self.send_json({"success": ok, "error": error, "run_id": run_id}, 200 if ok else 409)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        if parsed.path in ("/api/atms/bulk_start", "/api/atms/bulk_cancel"):
            try:
                if parsed.path.endswith("bulk_start"):
                    atm_ids = None
                    length = int(self.headers.get("Content-Length", "0") or "0")
                    if 0 < length <= 1024 * 1024:
                        try:
                            body = json.loads(self.rfile.read(length).decode("utf-8"))
                            if isinstance(body, dict) and isinstance(body.get("atm_ids"), list):
                                atm_ids = [str(a) for a in body["atm_ids"]][:5000]
                        except (ValueError, TypeError, json.JSONDecodeError):
                            atm_ids = None
                    ok, error = atm_inventory_bulk_start(atm_ids)
                else:
                    ok, error = atm_inventory_bulk_cancel()
                self.send_json({"success": ok, "error": error}, 200 if ok else 409)
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        if parsed.path == "/api/atms/winmap/save":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 1 or length > 8192:
                    raise ValueError("Sorğu ölçüsü düzgün deyil.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                result = atm_winmap_save(data)
                self.send_json(result, 200 if result.get("success") else 400)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        if parsed.path in ("/api/atms/save", "/api/atms/delete", "/api/atms/restore", "/api/atms/connect"):
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 1 or length > 8192:
                    raise ValueError("Sorğu ölçüsü düzgün deyil.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                if parsed.path == "/api/atms/save":
                    result = atm_inventory_save(data)
                elif parsed.path == "/api/atms/delete":
                    result = atm_inventory_soft_delete(data.get("id"))
                elif parsed.path == "/api/atms/restore":
                    result = atm_inventory_restore(data.get("id"))
                else:
                    result = atm_inventory_connect(data.get("id"))
                self.send_json(result, 200 if result.get("success") else 409)
            except (ValueError, TypeError, json.JSONDecodeError, sqlite3.IntegrityError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        if parsed.path == "/api/agent/report":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 1 or length > 262144:
                    raise ValueError("Agent hesabatının ölçüsü düzgün deyil.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                source_ip = self.client_address[0] if self.client_address else ""
                result = agent_report_ingest(data, source_ip)
                self.send_json(result, 200)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        if parsed.path in ("/agent", "/api/agent/simple"):
            # Sadə ATM Agent → server. Sessiya YOX. CPU/RAM/C/D disk/IP.
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length < 1 or length > 262144:
                    raise ValueError("Ölçü düzgün deyil.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                source_ip = self.client_address[0] if self.client_address else ""
                self.send_json(sagent_ingest(data, source_ip), 200)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path == "/api/agent/telemetry":
            # ATM Monitoring Agent → server. Sessiya YOX; per-ATM HMAC imzası ilə autentifikasiya.
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length < 1 or length > 1048576:
                    raise ValueError("Telemetry ölçüsü düzgün deyil.")
                body = self.rfile.read(length)
                atm_id = self.headers.get("X-ATM-ID", "")
                ts = self.headers.get("X-ATM-TS", "")
                sig = self.headers.get("X-ATM-SIG", "")
                ok, err = agent_verify_signature(atm_id, ts, sig, body)
                if not ok:
                    self.send_json({"success": False, "error": err}, 401)
                    return
                source_ip = self.client_address[0] if self.client_address else ""
                result = agent_telemetry_ingest(_text(atm_id, 64), body, source_ip)
                self.send_json(result, 200)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/alerts/config", "/api/alerts/run", "/api/alerts/scheduler"):
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                data = {}
                if length > 0:
                    if length > 16384:
                        raise ValueError("Sorğu çox böyükdür.")
                    data = json.loads(self.rfile.read(length).decode("utf-8"))
                    if not isinstance(data, dict):
                        raise ValueError("Sorğu formatı düzgün deyil.")
                if parsed.path.endswith("/config"):
                    self.send_json(alert_save_config(data))
                elif parsed.path.endswith("/run"):
                    ok, err = alert_run("manual")
                    self.send_json({"success": ok, "error": err}, 200 if ok else 409)
                else:  # scheduler on/off
                    if data.get("on") in (1, True, "1", "true", "on", "yes"):
                        alert_save_config({**alert_get_config(), "enabled": 1})
                        self.send_json({"success": True, "scheduler_on": True})
                    else:
                        alert_save_config({**alert_get_config(), "enabled": 0})
                        self.send_json({"success": True, "scheduler_on": False})
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/srvalert/config", "/api/srvalert/run"):
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                data = {}
                if length > 0:
                    if length > 16384:
                        raise ValueError("Sorğu çox böyükdür.")
                    data = json.loads(self.rfile.read(length).decode("utf-8"))
                    if not isinstance(data, dict):
                        raise ValueError("Sorğu formatı düzgün deyil.")
                if parsed.path.endswith("/config"):
                    self.send_json(srvalert_save_config(data))
                else:
                    ok, err = srvalert_run("manual")
                    self.send_json({"success": ok, "error": err}, 200 if ok else 409)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path == "/api/reports/delete":
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length < 1 or length > 4096:
                    raise ValueError("Sorğu ölçüsü düzgün deyil.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                self.send_json(report_delete(data.get("id")))
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path in ("/api/agent/token/provision", "/api/agent/token/revoke", "/api/agent/token/enable"):
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length < 1 or length > 8192:
                    raise ValueError("Sorğu ölçüsü düzgün deyil.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(data, dict):
                    raise ValueError("Sorğu formatı düzgün deyil.")
                if parsed.path.endswith("/provision"):
                    result = agent_token_provision(data.get("atm_id", ""), data.get("note", ""))
                elif parsed.path.endswith("/enable"):
                    result = agent_token_revoke(data.get("atm_id", ""), enabled=True)
                else:
                    result = agent_token_revoke(data.get("atm_id", ""), enabled=False)
                self.send_json(result, 200 if result.get("success") else 400)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": system_clean_error(exc)}, 500)
            return

        if parsed.path == "/api/atminfo/run":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 1 <= length <= 2048:
                    raise ValueError("Sorgunun olcusu duzgun deyil.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                result = atminfo_collect(data.get("atm", ""), data.get("method", "445"), save=data.get("save", True))
                self.send_json(result, 200 if result.get("success") else 400)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            except Exception as exc:
                self.send_json({"success": False, "error": str(exc)}, 500)
            return

        if parsed.path == "/api/system/start":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 1 <= length <= 2048:
                    raise ValueError("Sorğunun ölçüsü düzgün deyil.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                started, error, atm = start_system_monitor(data.get("atm", ""))
                self.send_json({"success": started, "error": error, "atm": atm},
                               200 if started else 409)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            return


        if parsed.path in ("/api/config/save", "/api/config/delete"):
            try:
                length=int(self.headers.get("Content-Length","0"))
                if length<1 or length>8192:
                    raise ValueError("Sorğu ölçüsü düzgün deyil.")
                data=json.loads(self.rfile.read(length).decode("utf-8"))
                result=(config_save(data) if parsed.path.endswith("save") else config_delete(data))
                self.send_json(result)
            except (ValueError,sqlite3.IntegrityError) as err:
                self.send_json({"success":False,"error":str(err)},400)
            except Exception as err:
                self.send_json({"success":False,"error":str(err)},500)
            return

        if parsed.path == "/api/scan/cancel":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 1 <= length <= 2048:
                    raise ValueError("Scan dayandırma sorğusu düzgün deyil.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                scan_type = str(data.get("scan_type", "")).upper()
                scan_id = int(data.get("scan_id", 0))
                ok, error = cancel_scan(scan_type, scan_id)
                self.send_json({"success": ok, "error": error}, 200 if ok else 409)
            except (ValueError, TypeError) as exc:
                self.send_json({"success": False, "error": str(exc)}, 400)
            return

        if parsed.path == "/api/restart/start":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length > 4096:
                    self.send_json({"success": False, "error": "Sorğu çox böyükdür."}, 413)
                    return
                raw = self.rfile.read(length) if length else b"{}"
                data = json.loads(raw.decode("utf-8"))
                target = data.get("atm", "")
                started, error = start_restart(target)
                self.send_json({
                    "success": error is None,
                    "started": started,
                    "error": error
                }, 200 if error is None else 400)
            except Exception as e:
                self.send_json({"success": False, "error": str(e)}, 400)
            return

        if parsed.path == "/api/archive/start":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length > 4096:
                    self.send_json({"success": False, "error": "Sorğu çox böyükdür."}, 413)
                    return

                raw = self.rfile.read(length) if length else b"{}"
                data = json.loads(raw.decode("utf-8"))
                target = data.get("atm", "")

                started, error = start_archive_scan(target)

                self.send_json({
                    "success": error is None,
                    "started": started,
                    "error": error
                }, 200 if error is None else 400)

            except Exception as e:
                self.send_json({"success": False, "error": str(e)}, 400)

            return

        self.send_json({"success": False, "error": "Endpoint tapılmadı."}, 404)

# ============================================================
# RUN
# ============================================================

def open_browser():
    webbrowser.open("http://localhost:" + str(PORT) + "/")


def seed_default_sources():
    r"""SCAN mənbələri (D / H / D Jurnal / H Jurnal) itibsə bərpa edir.
    Yalnız ÇATIŞMAYAN scan_type-ı əlavə edir — mövcud konfiqə toxunmur.
        D  -> \\172.21.12.77\d$\ATMFILES            (MEDIA)
        DJ -> \\172.21.12.77\d$\JOURNAL_FILES        (TXT)
        H  -> \\172.21.12.77\h$\ATM_GRG_files        (MEDIA)
        HJ -> \\172.21.12.77\h$\ATM_GRG_Journal_files(TXT)"""
    defaults = [
        ("172.21.12.77", "D", "ATMFILES", "D", "MEDIA"),
        ("172.21.12.77", "D", "JOURNAL_FILES", "DJ", "TXT"),
        ("172.21.12.77", "H", "ATM_GRG_files", "H", "MEDIA"),
        ("172.21.12.77", "H", "ATM_GRG_Journal_files", "HJ", "TXT"),
    ]
    con = db_connect()
    try:
        # Tam qurulmuş (IP+disk+folder birləşən) mənbələr — path quran scan_type-lar.
        built = db_source_paths(con)
        added = []
        for ip, letter, name, st, kind in defaults:
            if st in built:
                continue  # artıq tam konfiqurasiya olunub — toxunma
            # IP və disk təmin et
            row = con.execute("SELECT id FROM config_ips WHERE address=?", (ip,)).fetchone()
            ip_id = row[0] if row else con.execute(
                "INSERT INTO config_ips(address) VALUES(?)", (ip,)).lastrowid
            row = con.execute("SELECT id FROM config_disks WHERE ip_id=? AND UPPER(letter)=?",
                              (ip_id, letter)).fetchone()
            disk_id = row[0] if row else con.execute(
                "INSERT INTO config_disks(ip_id,letter) VALUES(?,?)", (ip_id, letter)).lastrowid
            # Bu scan_type üçün 'orphan' (disk/ip itmiş) folder sətri varsa — təmir et (yenidən bağla)
            row = con.execute("SELECT id FROM config_folders WHERE scan_type=?", (st,)).fetchone()
            if row:
                con.execute("UPDATE config_folders SET disk_id=?, name=?, media_kind=? WHERE id=?",
                            (disk_id, name, kind, row[0]))
                added.append(st)
                continue
            # Eyni disk+ad folderi varsa (scan_type-sız) — ona scan_type ver
            row = con.execute("SELECT id FROM config_folders WHERE disk_id=? AND name=?",
                              (disk_id, name)).fetchone()
            if row:
                con.execute("UPDATE config_folders SET scan_type=?, media_kind=? WHERE id=?",
                            (st, kind, row[0]))
                added.append(st)
                continue
            try:
                con.execute("INSERT INTO config_folders(disk_id,name,scan_type,media_kind) VALUES(?,?,?,?)",
                            (disk_id, name, st, kind))
                added.append(st)
            except sqlite3.IntegrityError:
                pass
        if added:
            con.execute("UPDATE config_meta SET revision=revision+1 WHERE id=1")
            con.commit()
        return added
    finally:
        con.close()


if __name__ == "__main__":
    init_db()
    _seeded = seed_default_sources()
    if _seeded:
        print("SCAN mənbələri bərpa edildi:", ", ".join(_seeded))
    refresh_source_cache()
    monitor_autostart()
    alert_autostart()
    srvalert_autostart()

    print()
    print("==========================================")
    print(" BIR SPARK - ATM IDARETME / BACKUP / MONITORING / RESTART")
    print("==========================================")
    print()
    print("Network:")
    for scan_type,label in SCAN_LABELS.items():
        print(label+":", SCAN_SOURCES.get(scan_type,"TƏYİN EDİLMƏYİB"))
    print()
    print("History DB:")
    print(DB_PATH)
    print()
    print("WEB:")
    print("http://localhost:" + str(PORT))
    print()
    print("HTTP texniki request loglari gizledilib.")
    print("CMD-de yalniz vacib SCAN / RESTART loglari gosterilecek.")
    print()

    server = ThreadingHTTPServer(("127.0.0.1", PORT), ATMHandler)
    if os.getenv("ATM_NO_BROWSER", "").strip().lower() not in ("1", "true", "yes", "on"):
        threading.Timer(1, open_browser).start()
    server.serve_forever()
