"use strict";
/*
 * ATM WEB — offline xerite tile yukleyicisi (npm TELEB OLUNMUR, yalniz Node >= 18).
 *
 * Istifade (internet olan komputerde, bir defe):
 *   runtime\node.exe tools\download_tiles.js            -> hesablayir, tesdiq isteyir, yukleyir
 *   runtime\node.exe tools\download_tiles.js --estimate -> yalniz say/hecm hesablayir
 *   runtime\node.exe tools\download_tiles.js --yes      -> sual vermeden yukleyir
 *   runtime\node.exe tools\download_tiles.js --layer satellite   (yalniz bir qat)
 *
 * Yarimciq qalsa yeniden isledin: movcud tile-lar yeniden yuklenmir (resume).
 * Netice: ATM_WEB\map_tiles\{street|satellite|labels}\{z}\{x}\{y}.{ext} + manifest.json
 */

const fs = require("fs");
const path = require("path");
const readline = require("readline");

const ROOT = path.resolve(__dirname, "..");
const CONFIG_PATH = path.join(__dirname, "map-tiles.config.json");
const args = process.argv.slice(2);
const ESTIMATE_ONLY = args.includes("--estimate");
const AUTO_YES = args.includes("--yes") || args.includes("-y");
const ONLY_LAYER = (() => { const i = args.indexOf("--layer"); return i >= 0 ? args[i + 1] : null; })();

if (typeof fetch !== "function") {
  console.error("[XETA] Bu Node versiyasinda fetch yoxdur. Node 18+ lazimdir (sizdeki: " + process.version + ").");
  process.exit(1);
}

const cfg = JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8"));
const OUT = path.resolve(ROOT, cfg.outputDir || "map_tiles");

// ---------- tile math ----------
function lon2x(lon, z) { return Math.floor((lon + 180) / 360 * 2 ** z); }
function lat2y(lat, z) {
  const r = lat * Math.PI / 180;
  return Math.floor((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * 2 ** z);
}
function clampXY(v, z) { return Math.max(0, Math.min(2 ** z - 1, v)); }
function bboxTiles(bbox, z, set) {
  const [minLon, minLat, maxLon, maxLat] = bbox;
  const x0 = clampXY(lon2x(minLon, z), z), x1 = clampXY(lon2x(maxLon, z), z);
  const y0 = clampXY(lat2y(maxLat, z), z), y1 = clampXY(lat2y(minLat, z), z);
  for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) set.add(`${z}/${x}/${y}`);
}
function radiusBbox(lat, lon, meters) {
  const dLat = meters / 111320;
  const dLon = meters / (111320 * Math.cos(lat * Math.PI / 180));
  return [lon - dLon, lat - dLat, lon + dLon, lat + dLat];
}

// ---------- ATM koordinatlari (node:sqlite, Node 22.5+) ----------
function readAtmCoords() {
  const d = cfg.atmDetail || {};
  if (!d.enabled) return [];
  const dbPath = path.resolve(ROOT, d.database || "atm_history.db");
  if (!fs.existsSync(dbPath)) { console.warn("[XEBERDARLIQ] DB tapilmadi, ATM detal tile-lari atlanir:", dbPath); return []; }
  let DatabaseSync;
  try {
    process.removeAllListeners("warning");
    ({ DatabaseSync } = require("node:sqlite"));
  } catch {
    console.warn("[XEBERDARLIQ] node:sqlite yoxdur (Node 22.5+ lazim). ATM etrafi detal tile-lar atlanir.");
    return [];
  }
  const db = new DatabaseSync(dbPath, { readOnly: true });
  try {
    const rows = db.prepare("SELECT atm_id, latitude, longitude FROM atms WHERE is_deleted = 0").all();
    const b = cfg.country.bbox;
    return rows.filter(r => {
      const la = Number(r.latitude), lo = Number(r.longitude);
      return Number.isFinite(la) && Number.isFinite(lo) && la >= b[1] && la <= b[3] && lo >= b[0] && lo <= b[2];
    }).map(r => ({ id: r.atm_id, lat: Number(r.latitude), lon: Number(r.longitude) }));
  } finally { db.close(); }
}

// ---------- tile siyahisi ----------
function buildTileSet(layerMaxZoom, atms) {
  const set = new Set();
  const c = cfg.country;
  for (let z = c.minZoom; z <= Math.min(c.maxZoom, layerMaxZoom); z++) bboxTiles(c.bbox, z, set);
  for (const r of cfg.regions || []) {
    for (let z = c.maxZoom + 1; z <= Math.min(r.maxZoom, layerMaxZoom); z++) bboxTiles(r.bbox, z, set);
  }
  const radius = (cfg.atmDetail && cfg.atmDetail.radiusMeters) || {};
  for (const [zs, m] of Object.entries(radius)) {
    const z = Number(zs);
    if (z > layerMaxZoom || z <= c.maxZoom) continue;
    for (const a of atms) bboxTiles(radiusBbox(a.lat, a.lon, m), z, set);
  }
  return [...set];
}

// ---------- yukleme ----------
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function fetchTile(url, timeoutMs) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: ctl.signal, headers: { "User-Agent": cfg.userAgent, "Accept": "image/*" } });
    if (!res.ok) { const e = new Error("HTTP " + res.status); e.status = res.status; throw e; }
    const ct = res.headers.get("content-type") || "";
    const buf = Buffer.from(await res.arrayBuffer());
    if (!/^image\//i.test(ct) || buf.length < 50) { const e = new Error("Sekil deyil (" + ct + ", " + buf.length + " bayt)"); e.status = 0; throw e; }
    return buf;
  } finally { clearTimeout(t); }
}

async function downloadLayer(name, prov, tiles) {
  const dir = path.join(OUT, name);
  const concurrency = Math.max(1, prov.concurrency || cfg.concurrency || 4);
  const retries = cfg.retries ?? 4;
  const timeoutMs = cfg.timeoutMs || 30000;
  let done = 0, skipped = 0, ok = 0, failed = 0, bytes = 0, consecutiveBlocked = 0, aborted = false;
  const failures = [];
  const started = Date.now();
  let idx = 0;

  const report = () => {
    const el = (Date.now() - started) / 1000;
    const rate = ok / Math.max(el, 1);
    const left = tiles.length - done;
    const eta = rate > 0 ? Math.round(left / rate / 60) : "?";
    process.stdout.write(`\r[${name}] ${done}/${tiles.length}  yeni:${ok} movcud:${skipped} xeta:${failed}  ${(bytes / 1048576).toFixed(1)} MB  ~${eta} deq qalib   `);
  };
  const timer = setInterval(report, 1000);

  async function worker() {
    while (!aborted) {
      const i = idx++;
      if (i >= tiles.length) return;
      const [z, x, y] = tiles[i].split("/");
      const file = path.join(dir, z, x, `${y}.${prov.ext}`);
      try {
        const st = fs.statSync(file);
        if (st.size > 0) { skipped++; done++; continue; }
      } catch {}
      const url = prov.url.replace("{z}", z).replace("{x}", x).replace("{y}", y);
      let lastErr = null;
      for (let attempt = 0; attempt <= retries; attempt++) {
        try {
          const buf = await fetchTile(url, timeoutMs);
          fs.mkdirSync(path.dirname(file), { recursive: true });
          const tmp = file + ".part";
          fs.writeFileSync(tmp, buf);
          fs.renameSync(tmp, file);
          ok++; bytes += buf.length; consecutiveBlocked = 0; lastErr = null;
          break;
        } catch (e) {
          lastErr = e;
          if (e.status === 404) break; // tile movcud deyil (deniz/bos) — tekrar yoxdur
          if (e.status === 403 || e.status === 429) {
            consecutiveBlocked++;
            if (consecutiveBlocked >= 25) {
              aborted = true;
              console.error(`\n[XETA] ${name}: server ardicil ${consecutiveBlocked} defe ${e.status} qaytardi — IP bloklanib/limit asilib.`);
              console.error("       Bir muddet gozleyin ve yeniden isledin (resume olunur), ve ya config-de provider-i deyisin.");
              return;
            }
            await sleep(5000 * (attempt + 1));
          } else {
            await sleep(1000 * (attempt + 1));
          }
        }
      }
      if (lastErr) { failed++; if (failures.length < 50) failures.push(`${tiles[i]} -> ${lastErr.message}`); }
      done++;
    }
  }

  await Promise.all(Array.from({ length: concurrency }, worker));
  clearInterval(timer);
  report();
  process.stdout.write("\n");
  if (failures.length) {
    fs.mkdirSync(OUT, { recursive: true });
    fs.writeFileSync(path.join(OUT, `${name}_errors.log`), failures.join("\n"), "utf8");
    console.log(`[${name}] ${failed} tile yuklenmedi (ilk 50-si: map_tiles\\${name}_errors.log). Yeniden isletmek kifayetdir.`);
  }
  return { ok, skipped, failed, aborted };
}

function countExisting(dir) {
  let n = 0, size = 0, minZ = 99, maxZ = -1;
  if (!fs.existsSync(dir)) return { n, size, minZ: null, maxZ: null };
  for (const z of fs.readdirSync(dir)) {
    const zp = path.join(dir, z);
    if (!/^\d+$/.test(z) || !fs.statSync(zp).isDirectory()) continue;
    let any = false;
    for (const x of fs.readdirSync(zp)) {
      const xp = path.join(zp, x);
      if (!fs.statSync(xp).isDirectory()) continue;
      for (const f of fs.readdirSync(xp)) {
        if (f.endsWith(".part")) continue;
        n++; any = true; size += fs.statSync(path.join(xp, f)).size;
      }
    }
    if (any) { minZ = Math.min(minZ, +z); maxZ = Math.max(maxZ, +z); }
  }
  return { n, size, minZ: maxZ < 0 ? null : minZ, maxZ: maxZ < 0 ? null : maxZ };
}

function writeManifest() {
  const manifest = { generated_at: new Date().toISOString(), bbox: cfg.country.bbox, layers: {} };
  for (const [name, L] of Object.entries(cfg.layers)) {
    const prov = L.providers[L.provider];
    const s = countExisting(path.join(OUT, name));
    if (!s.n) continue;
    manifest.layers[name] = { ext: prov.ext, provider: L.provider, tiles: s.n, bytes: s.size, minZoom: s.minZ, maxZoom: s.maxZ };
  }
  fs.mkdirSync(OUT, { recursive: true });
  fs.writeFileSync(path.join(OUT, "manifest.json"), JSON.stringify(manifest, null, 2), "utf8");
  return manifest;
}

function ask(q) {
  return new Promise(res => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(q, a => { rl.close(); res(a.trim().toLowerCase()); });
  });
}

// Orta tile olculeri (real Azerbaycan numunelerine gore teqribi)
const AVG_KB = { street: 18, satellite: 28, labels: 6 };

async function main() {
  console.log("==================================================");
  console.log("  ATM WEB — OFFLINE XERITE TILE YUKLEYICI");
  console.log("==================================================");
  console.log("Qovluq:", OUT);
  const atms = readAtmCoords();
  console.log(`ATM koordinatlari (detal zoom ucun): ${atms.length}`);

  const plan = [];
  for (const [name, L] of Object.entries(cfg.layers)) {
    if (!L.enabled) continue;
    if (ONLY_LAYER && ONLY_LAYER !== name) continue;
    const prov = L.providers[L.provider];
    if (!prov) { console.error(`[XETA] ${name}: provider '${L.provider}' tapilmadi`); process.exit(1); }
    const maxZ = L.maxZoom ?? 22;
    const tiles = buildTileSet(maxZ, atms);
    const existing = countExisting(path.join(OUT, name)).n;
    plan.push({ name, prov, tiles, existing });
  }
  if (!plan.length) { console.log("Aktiv qat yoxdur."); return; }

  let totalMB = 0;
  console.log("");
  for (const p of plan) {
    const mb = (p.tiles.length * (AVG_KB[p.name] || 20)) / 1024;
    totalMB += mb;
    console.log(`  ${p.name.padEnd(10)} ${String(p.tiles.length).padStart(7)} tile  (~${mb.toFixed(0)} MB)   artiq movcud: ${p.existing}   menbe: ${p.prov.url.split("/")[2]}`);
  }
  console.log(`  CEMI teqribi: ~${(totalMB / 1024).toFixed(2)} GB  (heqiqi olcu +/- 40% ferqlene biler)`);
  console.log("");

  if (ESTIMATE_ONLY) return;
  if (!AUTO_YES) {
    const a = await ask("Yuklemeye baslayaq? (y/n): ");
    if (a !== "y" && a !== "yes" && a !== "h" && a !== "he") { console.log("Legv edildi."); return; }
  }

  let anyAborted = false, anyFailed = false;
  for (const p of plan) {
    console.log(`\n--- ${p.name} (${p.prov.url.split("/")[2]}) ---`);
    const r = await downloadLayer(p.name, p.prov, p.tiles);
    anyAborted ||= r.aborted; anyFailed ||= r.failed > 0;
    writeManifest();
  }
  const m = writeManifest();
  console.log("\n==================================================");
  for (const [n, l] of Object.entries(m.layers)) console.log(`  ${n.padEnd(10)} ${l.tiles} tile, ${(l.bytes / 1048576).toFixed(0)} MB, zoom ${l.minZoom}-${l.maxZoom}`);
  console.log("  manifest:", path.join(OUT, "manifest.json"));
  if (anyAborted || anyFailed) {
    console.log("\n[DIQQET] Yukleme tam bitmedi. Eyni emri yeniden isledin — qalan hisse davam edecek.");
    process.exitCode = 2;
  } else {
    console.log("\n[OK] Hazirdir. ATM_WEB qovlugunu (map_tiles daxil) internetsiz serverə kocure bilersiniz.");
  }
}

main().catch(e => { console.error("\n[XETA]", e && e.stack || e); process.exit(1); });
