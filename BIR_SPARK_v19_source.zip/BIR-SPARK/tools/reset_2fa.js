#!/usr/bin/env node
/* BIR SPARK — 2FA "break-glass" aləti (serverin özündə, yerli olaraq işlədilir).
   Administrator telefonunu itiribsə və sistemə heç bir admin daxil ola bilmirsə:

     node tools\reset_2fa.js admin            → həmin istifadəçinin 2FA açarını silir, kilidi açır, sessiyalarını bağlayır
     node tools\reset_2fa.js admin --list     → (istifadəçi adı vermədən: node tools\reset_2fa.js --list) 2FA vəziyyəti

   Növbəti girişdə istifadəçi QR kodu yenidən skan edəcək.
   Bu skript yalnız serverə fiziki/RDP girişi olan şəxs tərəfindən işlədilə bilər — şəbəkədən çağırılmır.
   Hər istifadə audit jurnalına yazılır. */
"use strict";
const path = require("path");
const fs = require("fs");
let DatabaseSync;
try { ({ DatabaseSync } = require("node:sqlite")); }
catch (e) { console.error("node:sqlite tapılmadı — Node.js 22.13+ lazımdır."); process.exit(2); }

const dbFile = path.join(__dirname, "..", "atm_auth.db");
if (!fs.existsSync(dbFile)) { console.error("atm_auth.db tapılmadı: " + dbFile); process.exit(2); }
const db = new DatabaseSync(dbFile);
const now = () => Math.floor(Date.now() / 1000);
const args = process.argv.slice(2);

const cols = db.prepare("PRAGMA table_info(users)").all().map(c => c.name);
if (!cols.includes("totp_enabled")) { console.error("Bazada 2FA sütunları yoxdur — əvvəlcə serveri yeni versiya ilə bir dəfə işə salın."); process.exit(2); }

if (!args.length || args.includes("--list")) {
  const rows = db.prepare("SELECT username, is_admin, status, totp_enabled, locked_until FROM users ORDER BY id").all();
  for (const r of rows) console.log(`${r.username.padEnd(24)} ${r.is_admin ? "admin " : "      "} 2FA: ${r.totp_enabled ? "aktiv" : "qurulmayıb"}${r.locked_until > now() ? "  [kilidli]" : ""}${r.status ? "" : "  (silinib)"}`);
  if (!args.length) console.log("\nİstifadə: node tools/reset_2fa.js <istifadəçi_adı>");
  process.exit(0);
}

const username = String(args[0]).trim().toLowerCase();
const u = db.prepare("SELECT id, username FROM users WHERE lower(username)=?").get(username);
if (!u) { console.error(`"${username}" adlı istifadəçi tapılmadı.`); process.exit(1); }
const t = now();
db.prepare("UPDATE users SET totp_secret=NULL, totp_enabled=0, totp_last_step=0, totp_enrolled_at=NULL, failed_attempts=0, locked_until=0, updated_at=? WHERE id=?").run(t, u.id);
db.prepare("UPDATE sessions SET revoked_at=?, revoke_reason='mfa_reset_cli' WHERE user_id=? AND revoked_at IS NULL").run(t, u.id);
try {
  const acols = db.prepare("PRAGMA table_info(audit)").all().map(c => c.name);
  const row = { ts: t, type: "admin", module: "users", action: "mfa_reset_cli", detail: `${u.username}: 2FA serverdə CLI ilə sıfırlandı (break-glass)`, username: "server-console", status: 200 };
  const k = Object.keys(row).filter(c => acols.includes(c));
  if (k.length) db.prepare(`INSERT INTO audit(${k.join(",")}) VALUES(${k.map(() => "?").join(",")})`).run(...k.map(c => row[c]));
} catch (e) { /* audit cədvəli fərqlidirsə sıfırlama yenə də keçərlidir */ }
console.log(`OK: "${u.username}" üçün 2FA sıfırlandı. Növbəti girişdə QR kod yenidən göstəriləcək.`);
