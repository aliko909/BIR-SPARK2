#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ATM metadata (Excel) -> atm_history.db  (atms cedveli)
Name, Type(atype), RIM, Region, Sistemdeki unvan, Yerlesdiyi unvan sahelerini
atm_id uzre uygunlasdirir. Movcud ATM-ler YENILENIR; bazada olmayan ATM-ler
(istesen) elave olunur. Koordinat/status yalniz bos olduqda doldurulur.

Istifade:
    python tools\\import_atm_meta.py                 # yalniz movcud ATM-leri yenile
    python tools\\import_atm_meta.py --add-missing   # bazada olmayanlari da elave et
    python tools\\import_atm_meta.py --db C:\\path\\atm_history.db
"""
import os, sys, json, sqlite3
from datetime import datetime

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
db = os.path.join(BASE, "atm_history.db")
meta_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "atm_meta.json")
add_missing = "--add-missing" in sys.argv
if "--db" in sys.argv:
    db = sys.argv[sys.argv.index("--db") + 1]

meta = json.load(open(meta_path, encoding="utf-8"))
con = sqlite3.connect(db)
cols = {r[1] for r in con.execute("PRAGMA table_info(atms)").fetchall()}
need = ["name", "atype", "rim", "region", "sys_address", "phys_address"]
if not set(need).issubset(cols):
    print("DIQQET: atms cedvelinde yeni sutunlar yoxdur. Once serveri (yeni server.py) bir defe isledin ki migration yaransin.")
    sys.exit(1)

now = datetime.now().isoformat(timespec="seconds")
upd = ins = skip = 0
for aid, m in meta.items():
    row = con.execute("SELECT id,latitude,longitude FROM atms WHERE atm_id=? COLLATE NOCASE", (aid,)).fetchone()
    if row:
        con.execute("""UPDATE atms SET name=COALESCE(?,name),atype=COALESCE(?,atype),rim=COALESCE(?,rim),
                       region=COALESCE(?,region),sys_address=COALESCE(?,sys_address),
                       phys_address=COALESCE(?,phys_address),updated_at=? WHERE id=?""",
                    (m["name"], m["atype"], m["rim"], m["region"], m["sys_address"], m["phys_address"], now, row[0]))
        upd += 1
    elif add_missing:
        try:
            lat = float(m["lat"]); lon = float(m["long"])
        except (TypeError, ValueError):
            skip += 1; continue
        con.execute("""INSERT INTO atms(atm_id,latitude,longitude,status,is_deleted,created_at,updated_at,
                       name,atype,rim,region,sys_address,phys_address)
                       VALUES(?,?,?,?,0,?,?,?,?,?,?,?,?)""",
                    (aid, lat, lon, int(m.get("status", 1)), now, now,
                     m["name"], m["atype"], m["rim"], m["region"], m["sys_address"], m["phys_address"]))
        ins += 1
    else:
        skip += 1
con.commit(); con.close()
print(f"Yenilendi: {upd}, elave olundu: {ins}, otuldu: {skip}")
