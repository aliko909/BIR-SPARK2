ATM metadata import (Excel -> DB)
=================================
atm_meta.json Excel-den cixarilib (ATM_ID -> Name, Type, RIM, Region, unvanlar).

1) Once yeni serveri BIR DEFE isled (START.bat) ki, atms cedveline yeni sutunlar
   (name, atype, rim, region, sys_address, phys_address) elave olunsun. Sonra dayandir.
2) Serverin qovlugunda:
      python tools\import_atm_meta.py                 (yalniz movcud ATM-leri yenileyir)
      python tools\import_atm_meta.py --add-missing   (bazada olmayan ATM-leri de elave edir)
3) Serveri yenideni isled. ATM Info-da ad/region/tip gorunecek.

Qeyd: metadata yalniz bos saheleri doldurur / yenileyir; koordinat ve statusa
movcud ATM-lerde toxunmur.
