@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ATM WEB - OFFLINE XERITE HAZIRLIGI
set "NODE_EXE=%~dp0runtime\node.exe"

echo ================================================
echo   ATM WEB - OFFLINE XERITE (KUCE + PEYK) HAZIRLIGI
echo ================================================
echo  Bu fayl INTERNET OLAN komputerde BIR DEFE isledilir.
echo  Kuce, peyk ve ad qatlari map_tiles\ qovluguna yuklenir.
echo  Sonra butun ATM_WEB qovlugunu internetsiz servere kocurun.
echo.

if not exist "%NODE_EXE%" (
  echo [ERROR] runtime\node.exe tapilmadi. Portable Node.js faylarini runtime\ qovluguna qoyun.
  pause
  exit /b 1
)

rem Korporativ proxy varsa (HTTPS_PROXY=http://proxy:port) Node onu istifade etsin
set "NODE_USE_ENV_PROXY=1"

"%NODE_EXE%" "%~dp0tools\download_tiles.js" %*
set "ERR=%ERRORLEVEL%"
echo.
if "%ERR%"=="0" (echo [OK] Xerite hazirdir.) else (echo [DIQQET] Tam bitmedi ^(kod %ERR%^). Bu fayli yeniden isledin - qaldigi yerden davam edir.)
pause
exit /b %ERR%
