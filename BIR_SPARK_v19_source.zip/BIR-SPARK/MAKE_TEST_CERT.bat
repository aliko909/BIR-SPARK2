@echo off
REM TEST ucun self-signed sertifikat yaradir -> certs\server.crt + certs\server.key
REM openssl lazimdir (Git for Windows ile gelir: C:\Program Files\Git\usr\bin\openssl.exe).
setlocal
cd /d "%~dp0"
if not exist certs mkdir certs

set "OPENSSL=openssl"
where openssl >nul 2>&1
if errorlevel 1 (
  if exist "C:\Program Files\Git\usr\bin\openssl.exe" set "OPENSSL=C:\Program Files\Git\usr\bin\openssl.exe"
)
"%OPENSSL%" version >nul 2>&1
if errorlevel 1 (
  echo [XETA] openssl tapilmadi.
  echo   Variant 1: Git for Windows qurun ^(openssl onunla gelir^).
  echo   Variant 2: PowerShell ile yaradin ^(README-ye bax^) ve ya bankin CA sertifikatini certs\ qovluguna qoyun.
  pause
  exit /b 1
)

set /p CN=Server IP / ad [default 172.21.12.80]: 
if "%CN%"=="" set "CN=172.21.12.80"

"%OPENSSL%" req -x509 -newkey rsa:2048 -nodes -days 825 ^
  -keyout certs\server.key -out certs\server.crt ^
  -subj "/CN=%CN%/O=ATM WEB" ^
  -addext "subjectAltName=IP:%CN%,DNS:localhost"

if exist certs\server.crt (
  echo.
  echo [OK] Hazir: certs\server.crt , certs\server.key
  echo      Indi START.bat-i isledin ve "2) Sertifikatli port" secin.
) else (
  echo [XETA] Sertifikat yaradilmadi.
)
pause
endlocal
