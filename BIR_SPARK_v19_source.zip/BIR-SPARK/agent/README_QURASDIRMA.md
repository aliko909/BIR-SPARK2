# ATM Monitoring Agent — quraşdırma və test təlimatı

## 1. Nədir
ATM-lərə quraşdırılan yüngül Windows xidməti. Yalnız **read-only** metrikaları toplayır
(CPU%, RAM, disk doluluq, OS, uptime, hostname, IP) və serverə (172.21.12.80) göndərir.
Hər ATM-in **öz gizli açarı** var; paketlər **HMAC-SHA256 ilə imzalanır**. Server əlçatmaz
olanda məlumat lokal növbədə saxlanılır, bağlantı bərpa olanda göndərilir.

## 2. Faylllar
- `atm_agent.py` — agent (stdlib, XP/7/10).
- `agent.ini` — konfiqurasiya (atm_id, secret, server_url, interval).
- `install_agent.bat` / `uninstall_agent.bat` — xidmət qur/sil (nssm).
- `build_exe.bat` — `atm_agent.exe` yaratmaq (Win7/10).
- `tools/agent_token.py` — SERVERDƏ açar yaratmaq/idarə etmək.
- `nginx/atm_agent.conf` + `nginx/make_test_cert.sh` — HTTPS reverse proxy (443→8080).
- `FIREWALL.md`, `COMPAT_XP_WIN7.md`.

## 3. Serverdə (172.21.12.80) — bir dəfəlik hazırlıq
1. Web proqram işləyir (Node gateway 8080). Yeni versiyanı quraşdırın (telemetry endpoint var).
2. **Reverse proxy (443):**
   - Test sertifikatı: `cd agent/nginx && sh make_test_cert.sh`
   - `atm_agent.conf`-u nginx-ə əlavə edin, `nginx -t && reload`.
   - İstehsalda: daxili CA-dan sertifikat.
3. **Hər ATM üçün açar yaradın:**
   ```
   python tools/agent_token.py provision A0100008
   ```
   Çıxan `SECRET`-i həmin ATM-in `agent.ini`-sinə yazın.

## 4. Test ATM-də (əvvəlcə Windows 10) quraşdırma
1. `agent` qovluğunu ATM-ə kopyalayın.
2. `nssm.exe`-ni https://nssm.cc-dən `agent` qovluğuna qoyun.
3. `agent.ini`-ni açıb doldurun:
   ```
   server_url = https://172.21.12.80
   atm_id     = A0100008
   secret     = <serverdən alınan>
   verify_tls = true
   ca_file    = C:\ATMAgent\atm_server.crt   ; self-signed test sertifikatı (istehsalda boş/CA)
   ```
4. `install_agent.bat`-ı **Administrator** kimi işlədin. Xidmət qurulur və avtomatik başlayır.
5. Yoxlama:
   - Log: `C:\ATMAgent\logs\agent.log` → "Telemetry gonderildi" görünməlidir.
   - Serverdə: web paneldə **Agent Monitoru** bölməsində ATM görünməlidir.
   - CLI: `python tools/agent_token.py list` → `last_seen` dolu olmalıdır.

## 5. Tez test (server quraşdırmadan, lokal)
ATM-də / istənilən maşında:
```
python atm_agent.py --print                 # metrikaları göstərir (göndərmədən)
python atm_agent.py --config agent.ini --once   # bir dəfə topla+göndər
```

## 6. Silmə
`uninstall_agent.bat` (Administrator). Qovluq `C:\ATMAgent` saxlanılır (əl ilə silin).

## 7. Təhlükəsizlik
- Secret heç vaxt şəbəkəyə göndərilmir, loglanmır — yalnız HMAC imzası göndərilir.
- Agent heç bir dəyişiklik etmir, əmr qəbul etmir — yalnız oxuyur və göndərir (tək istiqamət).
- Vaxt möhürü ±5 dəqiqə yoxlanılır (replay-ə qarşı).
