#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
ATM Monitoring Agent  (Cihaz Idareetme Sistemi)
================================================
Yungul, asililiqsiz (yalniz Python standart kitabxanasi) monitorinq agenti.
Windows XP / 7 / 10 uyumlu (f-string istifade olunmur -> Python 3.4+ da islter).

Ne edir:
  - Yalniz READ-ONLY sistem metrikalarini toplayir (CPU / RAM / disk / OS / uptime / hostname / IP).
  - HMAC-SHA256 ile imzalayib servere gonderir:  POST <server>/api/agent/telemetry
  - Server elaqesi kesilse -> lokal novbede (queue.jsonl) saxlayir, elaqe berpa olanda gonderir.
  - Minimal CPU/RAM: sade dovr, interval ile yuxu, kicik yaddas izi.

Autentifikasiya:
  Basliqlar: X-ATM-ID, X-ATM-TS (unix saniye), X-ATM-SIG (hex HMAC-SHA256)
  Imza:      HMAC-SHA256(secret, "<ts>\\n<atm_id>\\n" + body_bytes)
  Secret hec vaxt gonderilmir, loglanmir.

Istifade:
  python atm_agent.py --config agent.ini          # xidmet rejimi (fasilesiz dovr)
  python atm_agent.py --config agent.ini --once    # bir defe topla+gonder (test)
  python atm_agent.py --config agent.ini --print    # metrikalari ekrana yaz (gondermeden)
"""
import sys
import os
import time
import json
import socket
import platform
import hmac
import hashlib
import argparse

try:
    import configparser
except ImportError:  # Python 2 ehtimali (olmamalidir)
    import ConfigParser as configparser

AGENT_VERSION = "1.0.0"
IS_WINDOWS = os.name == "nt"

if IS_WINDOWS:
    import ctypes
    from ctypes import wintypes


# ----------------------------------------------------------------------------
# Loglama (sade, oz-ozune rotasiya edir)
# ----------------------------------------------------------------------------
class Logger(object):
    def __init__(self, path, max_bytes=1048576):
        self.path = path
        self.max_bytes = int(max_bytes or 0)
        if path:
            d = os.path.dirname(path)
            if d and not os.path.isdir(d):
                try:
                    os.makedirs(d)
                except OSError:
                    pass

    def write(self, level, msg):
        line = time.strftime("%Y-%m-%d %H:%M:%S") + "  " + level + "  " + str(msg)
        try:
            sys.stdout.write(line + "\n")
            sys.stdout.flush()
        except Exception:
            pass
        if not self.path:
            return
        try:
            if self.max_bytes and os.path.isfile(self.path) and os.path.getsize(self.path) > self.max_bytes:
                bak = self.path + ".1"
                try:
                    if os.path.isfile(bak):
                        os.remove(bak)
                except OSError:
                    pass
                try:
                    os.rename(self.path, bak)
                except OSError:
                    pass
            f = open(self.path, "a")
            try:
                f.write(line + "\n")
            finally:
                f.close()
        except Exception:
            pass

    def info(self, m):
        self.write("INFO", m)

    def warn(self, m):
        self.write("WARN", m)

    def error(self, m):
        self.write("ERROR", m)


# ----------------------------------------------------------------------------
# Metrika toplama (yalniz READ-ONLY)
# ----------------------------------------------------------------------------
def _primary_ip():
    ip = ""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))  # paket gonderilmir; yalniz marsrut secimi ucun
            ip = s.getsockname()[0]
        finally:
            s.close()
    except Exception:
        try:
            ip = socket.gethostbyname(socket.gethostname())
        except Exception:
            ip = ""
    return ip


def _os_info():
    info = {"os_name": "", "os_version": "", "os_build": "", "os_architecture": ""}
    try:
        info["os_name"] = platform.system() + " " + platform.release()
    except Exception:
        pass
    try:
        v = platform.version()
        info["os_version"] = v
        if "." in v:
            info["os_build"] = v.split(".")[-1]
    except Exception:
        pass
    try:
        arch = platform.machine() or os.environ.get("PROCESSOR_ARCHITECTURE", "")
        low = arch.lower()
        if "64" in low or "amd64" in low:
            info["os_architecture"] = "64-bit"
        elif "86" in low or "32" in low:
            info["os_architecture"] = "32-bit"
        else:
            info["os_architecture"] = arch
    except Exception:
        pass
    if IS_WINDOWS:
        try:
            gv = sys.getwindowsversion()
            info["os_name"] = _win_name(gv) or info["os_name"]
            info["os_build"] = str(gv.build)
            info["os_version"] = "%d.%d.%d" % (gv.major, gv.minor, gv.build)
        except Exception:
            pass
    return info


def _win_name(gv):
    table = {
        (5, 1): "Windows XP", (5, 2): "Windows XP/2003",
        (6, 0): "Windows Vista", (6, 1): "Windows 7",
        (6, 2): "Windows 8", (6, 3): "Windows 8.1",
    }
    if gv.major == 10:
        # 10 ve 11 eyni major; build >= 22000 -> 11
        return "Windows 11" if getattr(gv, "build", 0) >= 22000 else "Windows 10"
    return table.get((gv.major, gv.minor), "Windows %d.%d" % (gv.major, gv.minor))


def _cpu_name():
    if not IS_WINDOWS:
        return platform.processor() or ""
    try:
        import winreg
    except ImportError:
        try:
            import _winreg as winreg
        except ImportError:
            return ""
    try:
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                           r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
        try:
            val, _ = winreg.QueryValueEx(k, "ProcessorNameString")
            return str(val).strip()
        finally:
            winreg.CloseKey(k)
    except Exception:
        return ""


def _ram_bytes():
    """(total, used, free) bayt. Windows: GlobalMemoryStatusEx (XP+)."""
    if IS_WINDOWS:
        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", wintypes.DWORD),
                ("dwMemoryLoad", wintypes.DWORD),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]
        m = MEMORYSTATUSEX()
        m.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
            total = int(m.ullTotalPhys)
            free = int(m.ullAvailPhys)
            return total, total - free, free
    # Qeyri-Windows / xeta
    try:
        import resource  # noqa
    except Exception:
        pass
    return 0, 0, 0


def _disks():
    out = []
    if not IS_WINDOWS:
        try:
            st = os.statvfs("/")
            total = st.f_blocks * st.f_frsize
            free = st.f_bavail * st.f_frsize
            out.append({"name": "/", "label": "", "filesystem": "",
                        "total_bytes": total, "used_bytes": total - free, "free_bytes": free})
        except Exception:
            pass
        return out
    DRIVE_FIXED = 3
    kernel32 = ctypes.windll.kernel32
    buf = ctypes.create_unicode_buffer(512)
    n = kernel32.GetLogicalDriveStringsW(512, buf)
    drives = []
    if n:
        raw = buf[:n]
        drives = [d for d in raw.split("\x00") if d]
    for root in drives:
        try:
            if kernel32.GetDriveTypeW(root) != DRIVE_FIXED:
                continue
            free_b = ctypes.c_ulonglong(0)
            total_b = ctypes.c_ulonglong(0)
            total_free_b = ctypes.c_ulonglong(0)
            ok = kernel32.GetDiskFreeSpaceExW(
                ctypes.c_wchar_p(root),
                ctypes.byref(free_b), ctypes.byref(total_b), ctypes.byref(total_free_b))
            if not ok:
                continue
            total = int(total_b.value)
            free = int(total_free_b.value)
            label = ""
            try:
                vol = ctypes.create_unicode_buffer(256)
                fsn = ctypes.create_unicode_buffer(256)
                kernel32.GetVolumeInformationW(ctypes.c_wchar_p(root), vol, 256,
                                               None, None, None, fsn, 256)
                label = vol.value or ""
                fs = fsn.value or ""
            except Exception:
                fs = ""
            out.append({"name": root.rstrip("\\"), "label": label, "filesystem": fs,
                        "total_bytes": total, "used_bytes": total - free, "free_bytes": free})
        except Exception:
            continue
    return out


def _cpu_percent(sample=0.5):
    """CPU istifade faizi. Windows: GetSystemTimes iki numune (XP+)."""
    if not IS_WINDOWS:
        try:
            a = _read_proc_stat()
            time.sleep(sample)
            b = _read_proc_stat()
            idle = b[0] - a[0]
            total = b[1] - a[1]
            return round(100.0 * (total - idle) / total, 1) if total > 0 else None
        except Exception:
            return None

    class FILETIME(ctypes.Structure):
        _fields_ = [("dwLowDateTime", wintypes.DWORD), ("dwHighDateTime", wintypes.DWORD)]

    def to_int(ft):
        return (ft.dwHighDateTime << 32) | ft.dwLowDateTime

    idle1, kern1, user1 = FILETIME(), FILETIME(), FILETIME()
    idle2, kern2, user2 = FILETIME(), FILETIME(), FILETIME()
    k = ctypes.windll.kernel32
    if not k.GetSystemTimes(ctypes.byref(idle1), ctypes.byref(kern1), ctypes.byref(user1)):
        return None
    time.sleep(sample)
    if not k.GetSystemTimes(ctypes.byref(idle2), ctypes.byref(kern2), ctypes.byref(user2)):
        return None
    idle = to_int(idle2) - to_int(idle1)
    kern = to_int(kern2) - to_int(kern1)
    user = to_int(user2) - to_int(user1)
    total = kern + user  # kernel idle-i daxil edir
    if total <= 0:
        return None
    busy = total - idle
    return round(100.0 * busy / total, 1)


def _read_proc_stat():
    f = open("/proc/stat")
    try:
        parts = f.readline().split()
    finally:
        f.close()
    nums = [int(x) for x in parts[1:]]
    idle = nums[3] + (nums[4] if len(nums) > 4 else 0)
    return idle, sum(nums)


def _uptime_seconds():
    if IS_WINDOWS:
        try:
            k = ctypes.windll.kernel32
            if hasattr(k, "GetTickCount64"):
                k.GetTickCount64.restype = ctypes.c_ulonglong
                return int(k.GetTickCount64() // 1000)
            return int(k.GetTickCount() & 0xFFFFFFFF) // 1000  # XP: 32-bit ms (49 gunden sonra sifirlanir)
        except Exception:
            return None
    try:
        f = open("/proc/uptime")
        try:
            return int(float(f.readline().split()[0]))
        finally:
            f.close()
    except Exception:
        return None


def _cpu_cores():
    log = None
    phys = None
    try:
        log = int(os.environ.get("NUMBER_OF_PROCESSORS", "0")) or None
    except ValueError:
        log = None
    try:
        import multiprocessing
        log = log or multiprocessing.cpu_count()
    except Exception:
        pass
    return phys, log


def collect_metrics(atm_id):
    total_ram, used_ram, free_ram = _ram_bytes()
    phys, logical = _cpu_cores()
    osinfo = _osinfo = _os_info()
    up = _uptime_seconds()
    boot = ""
    if up:
        try:
            boot = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() - up))
        except Exception:
            boot = ""
    rec = {
        "atm_id": atm_id,
        "hostname": socket.gethostname(),
        "ip": _primary_ip(),
        "cpu_name": _cpu_name(),
        "cpu_percent": _cpu_percent(),
        "cpu_cores": phys,
        "cpu_logical": logical,
        "ram_total_bytes": total_ram,
        "ram_used_bytes": used_ram,
        "ram_free_bytes": free_ram,
        "disks": _disks(),
        "uptime_seconds": up,
        "boot_time": boot,
        "agent_version": AGENT_VERSION,
        "collected_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    rec.update(osinfo)
    return rec


# ----------------------------------------------------------------------------
# Gonderme (HMAC + HTTPS/HTTP)
# ----------------------------------------------------------------------------
def _sign(secret, ts, atm_id, body_bytes):
    msg = (str(ts) + "\n" + atm_id + "\n").encode("utf-8") + body_bytes
    return hmac.new(secret.encode("utf-8"), msg, hashlib.sha256).hexdigest()


def _build_conn(server_url, timeout, verify_tls, ca_file, log):
    try:
        from urllib.parse import urlparse
        import http.client as httplib
    except ImportError:
        from urlparse import urlparse
        import httplib
    u = urlparse(server_url)
    host = u.hostname
    is_https = (u.scheme or "https").lower() == "https"
    port = u.port or (443 if is_https else 80)
    if is_https:
        import ssl
        try:
            ctx = ssl.create_default_context()
            if ca_file and os.path.isfile(ca_file):
                ctx.load_verify_locations(ca_file)
            if not verify_tls:
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
            try:
                ctx.minimum_version = ssl.TLSVersion.TLSv1_2  # Python 3.7+
            except Exception:
                pass
            conn = httplib.HTTPSConnection(host, port, timeout=timeout, context=ctx)
        except AttributeError:
            # Cox kohne Python: sade kontekst
            conn = httplib.HTTPSConnection(host, port, timeout=timeout)
    else:
        conn = httplib.HTTPConnection(host, port, timeout=timeout)
    base_path = (u.path or "").rstrip("/")
    return conn, base_path


def send_payload(cfg, log, payload_or_batch):
    body = json.dumps(payload_or_batch, ensure_ascii=False).encode("utf-8")
    ts = int(time.time())
    sig = _sign(cfg["secret"], ts, cfg["atm_id"], body)
    conn, base = _build_conn(cfg["server_url"], cfg["timeout"], cfg["verify_tls"], cfg["ca_file"], log)
    headers = {
        "Content-Type": "application/json",
        "Content-Length": str(len(body)),
        "X-ATM-ID": cfg["atm_id"],
        "X-ATM-TS": str(ts),
        "X-ATM-SIG": sig,
        "User-Agent": "ATM-Agent/" + AGENT_VERSION,
    }
    try:
        conn.request("POST", base + "/api/agent/telemetry", body, headers)
        resp = conn.getresponse()
        raw = resp.read()
        if resp.status == 200:
            return True, raw.decode("utf-8", "replace")
        return False, "HTTP " + str(resp.status) + ": " + raw.decode("utf-8", "replace")[:300]
    except Exception as exc:
        return False, str(exc)
    finally:
        try:
            conn.close()
        except Exception:
            pass


# ----------------------------------------------------------------------------
# Lokal novbe (offline queue)
# ----------------------------------------------------------------------------
def queue_append(cfg, log, payload):
    path = cfg["queue_file"]
    try:
        # novbe hedden boyuksa en kohne setirleri at (FIFO)
        if cfg["queue_max"] and os.path.isfile(path):
            try:
                with open(path) as f:
                    lines = f.readlines()
                if len(lines) >= cfg["queue_max"]:
                    lines = lines[-(cfg["queue_max"] - 1):]
                    with open(path, "w") as f:
                        f.writelines(lines)
            except Exception:
                pass
        with open(path, "a") as f:
            f.write(json.dumps(payload, ensure_ascii=False) + "\n")
        log.warn("Server elcatmaz - qeyd lokal novbeye yazildi: " + path)
    except Exception as exc:
        log.error("Novbeye yazmaq alinmadi: " + str(exc))


def queue_flush(cfg, log, batch_size=200):
    path = cfg["queue_file"]
    if not os.path.isfile(path):
        return
    try:
        with open(path) as f:
            lines = [ln for ln in f.read().splitlines() if ln.strip()]
    except Exception as exc:
        log.error("Novbe oxunmadi: " + str(exc))
        return
    if not lines:
        return
    log.info("Novbede " + str(len(lines)) + " qeyd var - gonderilir...")
    idx = 0
    while idx < len(lines):
        chunk = lines[idx:idx + batch_size]
        try:
            recs = [json.loads(x) for x in chunk]
        except Exception:
            recs = []
        ok, msg = send_payload(cfg, log, {"batch": recs})
        if not ok:
            log.warn("Novbe gonderilmedi (sonra): " + str(msg))
            break
        idx += len(chunk)
    # ugurla gedenleri novbeden sil
    remaining = lines[idx:]
    try:
        if remaining:
            with open(path, "w") as f:
                f.write("\n".join(remaining) + "\n")
            log.info("Novbede " + str(len(remaining)) + " qeyd qaldi.")
        else:
            os.remove(path)
            log.info("Novbe tam gonderildi ve temizlendi.")
    except Exception as exc:
        log.error("Novbe yenilenmedi: " + str(exc))


# ----------------------------------------------------------------------------
# Konfiqurasiya
# ----------------------------------------------------------------------------
def load_config(path):
    cp = configparser.ConfigParser()
    if not os.path.isfile(path):
        raise SystemExit("Konfiqurasiya tapilmadi: " + path)
    cp.read(path)

    def g(key, default=""):
        try:
            return cp.get("agent", key).strip()
        except Exception:
            return default

    def gi(key, default):
        try:
            return int(cp.get("agent", key).strip())
        except Exception:
            return default

    def gb(key, default):
        v = g(key, "").lower()
        if v in ("1", "true", "yes", "on"):
            return True
        if v in ("0", "false", "no", "off"):
            return False
        return default

    cfg = {
        "server_url": g("server_url", "https://172.21.12.80"),
        "atm_id": g("atm_id", ""),
        "secret": g("secret", ""),
        "interval": gi("interval_seconds", 60),
        "verify_tls": gb("verify_tls", True),
        "ca_file": g("ca_file", ""),
        "timeout": gi("timeout_seconds", 20),
        "queue_file": g("queue_file", "queue.jsonl"),
        "queue_max": gi("queue_max", 5000),
        "log_file": g("log_file", "logs/agent.log"),
        "log_max_bytes": gi("log_max_bytes", 1048576),
    }
    # neсbi yollari konfiq faylinin yaninda qebul et
    base = os.path.dirname(os.path.abspath(path))
    for key in ("queue_file", "log_file", "ca_file"):
        v = cfg[key]
        if v and not os.path.isabs(v):
            cfg[key] = os.path.join(base, v)
    if not cfg["atm_id"]:
        raise SystemExit("agent.ini: atm_id boş ola bilmez.")
    if not cfg["secret"]:
        raise SystemExit("agent.ini: secret boş ola bilmez (serverde provision edin).")
    if cfg["interval"] < 10:
        cfg["interval"] = 10
    return cfg


# ----------------------------------------------------------------------------
# Esas dovr
# ----------------------------------------------------------------------------
def run_cycle(cfg, log):
    rec = collect_metrics(cfg["atm_id"])
    # evvelce novbeni bosaltmaga calis (elaqe berpa olubsa)
    queue_flush(cfg, log)
    ok, msg = send_payload(cfg, log, rec)
    if ok:
        log.info("Telemetry gonderildi: CPU=" + str(rec.get("cpu_percent")) +
                 "% RAM=" + str(_pct(rec.get("ram_used_bytes"), rec.get("ram_total_bytes"))) +
                 "% disk=" + str(len(rec.get("disks") or [])))
    else:
        log.warn("Gonderme alinmadi: " + str(msg))
        queue_append(cfg, log, rec)
    return ok


def _pct(used, total):
    try:
        return round(100.0 * used / total, 1) if total else 0
    except Exception:
        return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description="ATM Monitoring Agent")
    ap.add_argument("--config", "-c", default="agent.ini")
    ap.add_argument("--once", action="store_true", help="Bir defe topla+gonder ve cix (test)")
    ap.add_argument("--print", dest="do_print", action="store_true", help="Metrikalari yaz, gonderme")
    args = ap.parse_args(argv)

    if args.do_print:
        print(json.dumps(collect_metrics("TEST"), ensure_ascii=False, indent=2))
        return 0

    cfg = load_config(args.config)
    log = Logger(cfg["log_file"], cfg["log_max_bytes"])
    log.info("ATM Agent " + AGENT_VERSION + " basladi. ATM=" + cfg["atm_id"] +
             " server=" + cfg["server_url"] + " interval=" + str(cfg["interval"]) + "s")

    if args.once:
        run_cycle(cfg, log)
        return 0

    while True:
        try:
            run_cycle(cfg, log)
        except KeyboardInterrupt:
            log.info("Dayandirildi (Ctrl+C).")
            return 0
        except Exception as exc:
            log.error("Dovr xetasi: " + str(exc))
        # yuxu (interval) - dayandirmaya hessas kicik parcalarla
        slept = 0
        while slept < cfg["interval"]:
            try:
                time.sleep(1)
            except KeyboardInterrupt:
                log.info("Dayandirildi.")
                return 0
            slept += 1


if __name__ == "__main__":
    sys.exit(main())
