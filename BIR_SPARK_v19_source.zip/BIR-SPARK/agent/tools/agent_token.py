#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Server tərəfində ATM agent açarlarını idarə etmək üçün CLI.
Serverin host-unda (ATM_WEB qovluğunun yanında) işlədilir — real atm_history.db-yə yazır.

İstifadə:
  python tools/agent_token.py provision A0100008           # yeni açar yarat/rotasiya et (açarı göstərir)
  python tools/agent_token.py list                         # bütün agent açarları
  python tools/agent_token.py revoke A0100008              # deaktiv et
  python tools/agent_token.py enable  A0100008             # yenidən aktiv et
"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(HERE, "..", "..")))  # ATM_WEB
import server  # noqa

def main():
    if len(sys.argv) < 2:
        print(__doc__); return 2
    cmd = sys.argv[1].lower()
    if cmd == "provision":
        if len(sys.argv) < 3: print("atm_id lazimdir"); return 2
        r = server.agent_token_provision(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else "")
        print("ATM:   ", r["atm_id"])
        print("SECRET:", r["secret"])
        print(">> Bu açarı həmin ATM-in agent.ini faylına yazın (secret=...). Yalnız indi göstərilir.")
    elif cmd == "list":
        for t in server.agent_token_list()["tokens"]:
            print("%-16s enabled=%s last_seen=%s ip=%s ver=%s" % (
                t["atm_id"], t["enabled"], t["last_seen"] or "-", t["last_ip"] or "-", t["agent_version"] or "-"))
    elif cmd == "revoke":
        print(server.agent_token_revoke(sys.argv[2], enabled=False))
    elif cmd == "enable":
        print(server.agent_token_revoke(sys.argv[2], enabled=True))
    else:
        print("Naməlum əmr:", cmd); return 2
    return 0

if __name__ == "__main__":
    sys.exit(main())
