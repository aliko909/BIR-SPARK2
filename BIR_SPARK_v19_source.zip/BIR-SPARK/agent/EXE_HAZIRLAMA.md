# ATM-ə yüklənəcək faylı hazırlamaq — 2 yol

ATM-ə Python quraşdırmamaq üçün agenti `atm_agent.exe` şəklində paketləmək olar.
Exe-ni **interneti olan bir Windows maşınında** (server və ya dev box) **bir dəfə** düzəldirsən,
sonra həmin exe-ni bütün ATM-lərə kopyalayırsan — ATM-də Python lazım olmur.

---
## YOL A — EXE paketi (ATM-də Python LAZIM DEYİL)  ← tövsiyə
İnterneti olan bir Windows maşınında:
1. Python 3.8+ qur (python.org, "Add to PATH").
2. `agent` qovluğunu kopyala, içində: **`build_exe.bat`** işlət.
   - `pyinstaller` avtomatik qurulur (internet lazımdır), `atm_agent.exe` yaranır.
   - `package_atm\` qovluğu yığılır: **atm_agent.exe + install_agent.bat + agent.ini**.
3. `nssm.exe`-ni (https://nssm.cc) `package_atm\`-a əlavə et.
4. `package_atm\`-ı ZIP et → **bu, ATM-ə yüklənəcək fayldır**.
5. ATM-də: aç, `agent.ini` doldur (atm_id, secret, server_url), `install_agent.bat` (Administrator).
   installer exe-ni görüb onu xidmət kimi qurur — **Python olmadan işləyir**.

> İnternet yoxdursa: başqa bir internetli maşında `python -m pip download pyinstaller -d wheels`
> ilə offline wheel-ləri yığ, dev boxa köçür, `pip install --no-index --find-links wheels pyinstaller`.

---
## YOL B — Python offline installer (sadə, exe build yoxdur)
Bağlı şəbəkə üçün ən sadəsi: Python-u ATM-lərə **offline** qurmaq (bir dəfə).
1. İnternetli maşında Python installer-i yüklə:
   - Win7/10: `python-3.8.10.exe`  (python.org/downloads)
   - Win XP:  `python-3.4.4.msi`
2. Installer-i ATM-ə köçür, **səssiz qur**:
   - Win10:  `python-3.8.10.exe /quiet InstallAllUsers=1 PrependPath=1`
   - XP:     `msiexec /i python-3.4.4.msi /qn ALLUSERS=1`
   - (Agent yalnız stdlib işlədir → **heç bir pip/paket lazım deyil**.)
3. `ATM_Agent_only.zip`-i aç, `agent.ini` doldur, `install_agent.bat` (Administrator).

---
## Hansını seçim?
- Çox ATM, təkrar quraşdırma → **YOL A** (bir dəfə exe düzəlt, hər yerə kopyala).
- Bir-iki test ATM, tez başlamaq → **YOL B** (Python offline qur).

Hər iki halda `install_agent.bat` eyni işləyir: `atm_agent.exe` varsa onu, yoxdursa `atm_agent.py`-ni (Python) xidmət kimi qurur.
