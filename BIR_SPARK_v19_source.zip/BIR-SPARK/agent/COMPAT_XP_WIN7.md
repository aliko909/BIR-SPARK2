# Windows XP / 7 / 10 uyğunluq və TLS qiymətləndirməsi

## Kod uyğunluğu
- Agent **yalnız Python standart kitabxanasından** istifadə edir (xarici paket yoxdur).
- `f-string` və digər 3.6+ sintaksisi İŞLƏDİLMİR → **Python 3.4+** ilə işləyir.
- Metrikalar `ctypes` + `winreg` ilə (XP-dən bəri mövcud API-lər): `GlobalMemoryStatusEx`,
  `GetDiskFreeSpaceExW`, `GetSystemTimes`, `GetTickCount(64)`.

## Windows 10 / 11
- Python 3.8+ və ya `atm_agent.exe` (PyInstaller). TLS 1.2/1.3 tam dəstəklənir. Problem yoxdur.

## Windows 7
- **SP1 + TLS 1.2 update** (KB3140245 / "Easy Fix") quraşdırılıbsa schannel TLS 1.2 dəstəkləyir.
- Python 3.8 Win7-də işləyir (son rəsmi dəstək: Python 3.8). TLS 1.2 Python-un öz OpenSSL-i ilə işləyir.
- **Tövsiyə:** Win7-də Python 3.8 + `atm_agent.exe`.

## Windows XP — DİQQƏT (TLS problemi)
- XP-nin **schannel-i TLS 1.2 bilmir** (maks TLS 1.0). Lakin bu bizi məhdudlaşdırmır, çünki:
- Agent HTTPS üçün **Python-un öz bundled OpenSSL-indən** istifadə edir (schannel YOX).
  Python **3.4.4** (XP üçün son rəsmi versiya) OpenSSL 1.0.1 ilə gəlir — **TLS 1.2 mümkündür**.
- Yəni: **XP + Python 3.4.4 → server 443-ə TLS 1.2 ilə qoşula bilir**, serverdə köhnə protokol açmadan.

### Əgər XP-də TLS 1.2 alınmasa — köhnə protokol AÇMADAN alternativlər:
1. **stunnel (XP-də)** — ATM-də yüngül `stunnel` client TLS 1.2 tuneli qurur; agent `http://127.0.0.1:<local>`-ə göndərir, stunnel serverə TLS 1.2 ilə ötürür. Serverdə heç nə zəiflədilmir.
2. **Tətbiq səviyyəsində qorunma** — agent onsuz da hər paketi **HMAC-SHA256 ilə imzalayır** (bütövlük + autentifikasiya). Daxili izolyasiya olunmuş ATM VLAN-da TLS terminasiyası ən yaxın proxy-də aparıla bilər; məlumat yalnız oxunabiləndir (gizli deyil), imza isə saxtalaşdırmanı bloklayır.
3. **Köhnə XP-ləri mərhələli əvəzləmə** — təhlükəsizlik baxımından ən doğru yol.

**Nəticə:** XP üçün tövsiyə — Python 3.4.4 + TLS 1.2 (birbaşa). Alınmazsa stunnel. Köhnə protokolları **serverdə aktivləşdirmirik**.
