#!/bin/sh
# TEST üçün self-signed sertifikat (172.21.12.80). İSTEHSALDA daxili CA-dan sertifikat alın.
mkdir -p certs
openssl req -x509 -newkey rsa:2048 -nodes -days 825 \
  -keyout certs/atm_server.key -out certs/atm_server.crt \
  -subj "/CN=172.21.12.80/O=ATM Monitoring" \
  -addext "subjectAltName=IP:172.21.12.80,DNS:172.21.12.80"
echo "Hazir: certs/atm_server.crt , certs/atm_server.key"
echo "Agentin verify_tls=true ile isləməsi ücün atm_server.crt-ni ATM-lərə kopyalayın (agent.ini ca_file=...)."
