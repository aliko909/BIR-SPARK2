@echo off
REM ============================================================
REM  atm_agent.py -> atm_agent.exe  (tek fayl, Python-suz ATM ucun)
REM  BU SKRIPT INTERNETI OLAN bir Windows masininda islenir
REM  (server ve ya dev box). Hazir exe sonra butun ATM-lere kopyalanir.
REM ============================================================
setlocal
where python >nul 2>&1 || (echo [XETA] Python tapilmadi. python.org-dan Python 3.8+ qurun.& goto :end)

echo === PyInstaller yoxlanilir ===
python -c "import PyInstaller" 2>nul || (
  echo PyInstaller qurulur ^(internet lazimdir^)...
  python -m pip install pyinstaller || (echo [XETA] pip ile qurulmadi. Internet/offline-wheel lazimdir.& goto :end)
)

echo === exe hazirlanir ===
python -m PyInstaller --onefile --console --name atm_agent atm_agent.py
if not exist dist\atm_agent.exe (echo [XETA] build alinmadi.& goto :end)

echo === ATM paketi yigilir: package_atm\ ===
if exist package_atm rmdir /S /Q package_atm
mkdir package_atm
copy /Y dist\atm_agent.exe        package_atm\ >nul
copy /Y agent.ini                 package_atm\ >nul
copy /Y install_agent.bat         package_atm\ >nul
copy /Y uninstall_agent.bat       package_atm\ >nul
copy /Y README_QURASDIRMA.md      package_atm\ >nul
if exist nssm.exe copy /Y nssm.exe package_atm\ >nul
echo.
echo === HAZIRDIR ===
echo Butun ATM paketi:  %CD%\package_atm\
echo Icinde: atm_agent.exe (Python lazim DEYIL) + install_agent.bat + agent.ini
echo nssm.exe-ni de package_atm\ qovluguna elave edin (https://nssm.cc).
echo Bu qovlugu ZIP edib butun ATM-lere kopyalayin.
:end
endlocal
