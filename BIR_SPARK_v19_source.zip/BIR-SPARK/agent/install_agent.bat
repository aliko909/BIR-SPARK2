@echo off
REM ============================================================
REM  ATM Monitoring Agent - qurasdirma (Windows Service, nssm)
REM  Administrator kimi islat.
REM ============================================================
setlocal
set SVC=ATMMonitoringAgent
set DEST=C:\ATMAgent
set SRC=%~dp0

echo === ATM Agent qurasdirilir ===

REM 1) Python yoxlanilir
where python >nul 2>&1
if errorlevel 1 (
  echo [XETA] Python tapilmadi. Python 3 qurun ^(Win7/10: 3.8+, Win XP: 3.4.4^) ve PATH-e elave edin.
  echo        Alternativ: build_exe.bat ile atm_agent.exe hazirlayin, bu skript onu istifade eder.
)

REM 2) Qovluq ve fayllar
if not exist "%DEST%" mkdir "%DEST%"
if not exist "%DEST%\logs" mkdir "%DEST%\logs"
copy /Y "%SRC%atm_agent.py" "%DEST%\" >nul
if exist "%SRC%atm_agent.exe" copy /Y "%SRC%atm_agent.exe" "%DEST%\" >nul
if not exist "%DEST%\agent.ini" (
  copy /Y "%SRC%agent.ini" "%DEST%\" >nul
  echo [DIQQET] "%DEST%\agent.ini" faylini acin: atm_id, secret ve server_url yazin!
)

REM 3) nssm (Non-Sucking Service Manager) - XP..10 uyumlu xidmet menecer
set NSSM=%SRC%nssm.exe
if not exist "%NSSM%" (
  echo [XETA] nssm.exe tapilmadi ^(%SRC%^). https://nssm.cc -> nssm.exe-ni bu qovluga qoyun.
  echo        Ve ya asagidaki "sc" alternativine baxin ^(README^).
  goto :end
)

REM 4) Islemis xidmeti sil ^(yenileme^)
"%NSSM%" stop %SVC% >nul 2>&1
"%NSSM%" remove %SVC% confirm >nul 2>&1

REM 5) Xidmeti qur
if exist "%DEST%\atm_agent.exe" (
  "%NSSM%" install %SVC% "%DEST%\atm_agent.exe" "--config" "%DEST%\agent.ini"
) else (
  for /f "delims=" %%P in ('where python') do set PYEXE=%%P
  "%NSSM%" install %SVC% "%PYEXE%" "%DEST%\atm_agent.py" "--config" "%DEST%\agent.ini"
)
"%NSSM%" set %SVC% AppDirectory "%DEST%"
"%NSSM%" set %SVC% DisplayName "ATM Monitoring Agent"
"%NSSM%" set %SVC% Description "ATM telemetriyasini (CPU/RAM/disk) servere gonderir. Yalniz read-only."
"%NSSM%" set %SVC% Start SERVICE_AUTO_START
"%NSSM%" set %SVC% AppStdout "%DEST%\logs\service.out.log"
"%NSSM%" set %SVC% AppStderr "%DEST%\logs\service.err.log"
"%NSSM%" set %SVC% AppRotateFiles 1
"%NSSM%" set %SVC% AppRotateBytes 1048576

REM 6) Basladir
"%NSSM%" start %SVC%
echo === Hazirdir. Xidmet: %SVC% (avtomatik basladi). Log: %DEST%\logs\agent.log ===
:end
endlocal
