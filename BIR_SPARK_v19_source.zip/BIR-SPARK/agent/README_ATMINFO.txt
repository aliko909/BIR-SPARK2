ATM WEB — "ATM Info" MODULU
===========================
Panelde ATM ID yazib port (135 / 445) secirsen; server qosulub ATM haqqinda
CPU, RAM, disk yaddasi, OS ve online statusu getirir. Sifre avtomatik PASSWORD
slotundan tapilir, log/HTTP-ye cixmir.

=====================================================================
445 (SMB)  —  AVTOMATIK DEPLOY
=====================================================================
ATM-e EL ile hec ne atmaq LAZIM DEYIL. Collector fayllarini YALNIZ SERVERDE saxla:
   C:\eco\collect.bat
   C:\eco\collect.ps1
(Bu fayllar zip-de "eco" qovlugunda hazirdir — onu serverin C:\eco-suna kopyala.)

Server her sorguda avtomatik:
   1) ATM-de  C:\Users\Administrator\Documents\.default_80  qovlugunu yoxlayir;
      yoxdursa yaradir.
   2) Serverin C:\eco-dan collect.bat + collect.ps1-i hemin .default_80 qovluguna
      kopyalayir (445 / C$).
   3) collect.bat-i orada PsExec (-s, SYSTEM) ile isledir -> atminfo.json yaranir.
   4) atminfo.json-u 445 ile oxuyur ve panelde gosterir.

Server terefde telb olunur:
   - PsExec64.exe server qovlugunda (artiq komplektde var).
   - PASSWORD1, PASSWORD2, ... environment deyisenleri (Restart/Archive ile eyni).
   - C:\eco qovlugu + icinde collect.bat, collect.ps1.

=====================================================================
135 (WMI/RPC)  —  FAYL LAZIM DEYIL
=====================================================================
Server WMI/DCOM ile birbasa oxuyur. ATM-de hec ne qoymaq lazim deyil.
Mevcud "Sistem Monitoru" ile eyni mexanizm.
QEYD: WMI 135-den sonra RPC dinamik yuksek porta (49152-65535) kecir; firewall
yalniz 135-i acibsa WMI tam islemeye biler — onda 445 sec.

=====================================================================
AYARLAR (server muhit deyiseni, rebuild lazim deyil)
=====================================================================
   ATM_INFO_SRC         serverde collector qovlugu (default: C:\eco)
   ATM_INFO_REMOTE_DIR  ATM-de hedef qovluq
                        (default: C:\Users\Administrator\Documents\.default_80)
   ATM_INFO_FILE        json fayl adi (default: atminfo.json)
   ATM_INFO_FILES       kopyalanacaq fayllar (default: collect.bat,collect.ps1)
   ATM_INFO_BAT_NAME    islenecek bat adi (default: collect.bat)

=====================================================================
ICAZE
=====================================================================
Modul login+icaze+audit-e qosuludur. Icazeler penceresinde:
   atminfo        - modulu gormek (sol menyu)
   atminfo.query  - "Qosul ve oxu" sorgusu
   atminfo.stats  - status/KPI kartlari
   atminfo.disks  - disk cedveli
Her sorgu audit log-a yazilir.

=====================================================================
XETALAR VE HELLERI
=====================================================================
445: "Logon failure: the user has not been granted the requested logon type"
     (PsExec rc=1385)
  Auth ugurludur (sifre dogru), amma hesaba ATM-de proses isletme huququ yoxdur.
  HELL 1 (kodda edilib): PsExec artiq "-s" ile cagirilir -> bat SYSTEM altinda
     islenir. Adeten bu kifayet edir.
  HELL 2 (hele de alinmirsa, ATM-de GPO / secpol.msc):
     - "Allow log on locally" / "Log on as a batch job" -> administrator hesabi.
     - "Deny log on ..." siyahilarindan hemin hesabi cixar.
     - HKLM\...\Policies\System\LocalAccountTokenFilterPolicy = 1 (DWORD).

135: "Access denied" (WMI/DCOM) — tam ATM terefli icaze meselesidir:
     - dcomcnfg -> COM Security -> Access/Launch -> Edit Limits -> administrator
       hesabina Remote Access / Remote Launch / Remote Activation.
     - wmimgmt.msc -> WMI Control -> Security -> Root\CIMV2 -> Remote Enable +
       Enable Account.
     - Firewall: WMI qaydalarina icaze.  LocalAccountTokenFilterPolicy=1.

Qeyd: collect.ps1 ATM-in ozunde LOKAL islenir; xarici kitabxana telb etmir,
kohne Windows (PowerShell 2.0) ucun JSON elle qurulur (ConvertTo-Json lazim deyil).

=====================================================================
MODUL BIRLESDIRME (yeni)
=====================================================================
"Bankomatlar", "Disk Report", "Sistem Monitoru", "Agent Monitoru" modullari
menyudan silinib; funksiyalari ATM Info altinda birlesib:
  - Sol: butun ATM siyahisi (ad, region, tip, status, son CPU/RAM, son yoxlama).
  - ATM-e klik -> sagda drawer: statik melumat + son metrikalar + disk + tarixce.
  - "Qosul ve yoxla" (445/135) -> canli melumat cekilir ve BAZAYA yazilir.
  - "Yeni ATM" -> metadata ile elave; "elave etdikden sonra qosul" secilibse
    derhal qosulub melumati cekir.
  - Tarixce/report: her qosulma atm_info_snapshots cedveline yazilir.
Xeritede markere kliklediyde son CPU/RAM/OS/disk gorunur.

EXCEL METADATA (ad/region/tip/RIM/unvanlar) -> bax: tools\README_IMPORT.txt
Yeni DB cedvelleri (avtomatik migration): atms-e name/atype/rim/region/
sys_address/phys_address + son metrik kesi; atm_info_snapshots (tarixce).
