@echo off
REM ATM Monitoring Agent - silinme. Administrator kimi islat.
setlocal
set SVC=ATMMonitoringAgent
set DEST=C:\ATMAgent
set NSSM=%~dp0nssm.exe
echo === ATM Agent silinir ===
if exist "%NSSM%" (
  "%NSSM%" stop %SVC% >nul 2>&1
  "%NSSM%" remove %SVC% confirm >nul 2>&1
) else (
  sc stop %SVC% >nul 2>&1
  sc delete %SVC% >nul 2>&1
)
echo Xidmet silindi. Qovluq saxlanilir: %DEST%  ^(elle silmek olar^)
echo Konfiqurasiya/loglari saxlamaq isteseniz %DEST%-i silmeyin.
endlocal
