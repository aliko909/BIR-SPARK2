# Firewall / şəbəkə icazə tələbləri

Bütün trafik **daxili bank şəbəkəsindədir** (internetə çıxış yoxdur).

## Agent (ATM) → Server (172.21.12.80)
| İstiqamət | Mənbə | Təyinat | Port | Protokol | Məqsəd |
|-----------|-------|---------|------|----------|--------|
| Outbound  | Hər ATM (172.21.x.x) | 172.21.12.80 | **443/TCP** | HTTPS (TLS 1.2+) | Telemetry göndərmə |
| (Alt.)    | Hər ATM | 172.21.12.80 | 8080/TCP | HTTP | Yalnız reverse proxy YOXDURSA / test |

- Agent **yalnız gedən (outbound)** bağlantı açır. ATM-də gələn port açmağa ehtiyac yoxdur.
- Server tərəfdə **443 inbound** açıq olmalıdır (nginx reverse proxy). 8080 yalnız 127.0.0.1-ə bağlı qalır.

## Server daxili
- nginx (443) → 127.0.0.1:8080 (mövcud Node gateway). 8080 kənardan əlçatan olmamalıdır.

## Tövsiyə
- 443-ü yalnız ATM alt-şəbəkəsindən (172.21.0.0/16 və ya dəqiq ATM VLAN) qəbul edin.
- İstifadə olunmayan portları bağlayın. SSLv3/TLS1.0/1.1 serverdə deaktiv (nginx конfiqində).
