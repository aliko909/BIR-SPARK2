ATM WEB — CLIENT AGENT (push monitor)
=====================================

NƏ EDİR
-------
ATM-in içində işləyən kiçik proqram. Müəyyən intervalla (default 60 saniyə)
serverə JSON hesabat göndərir:
  - CPU: ad, istifadə %, nüvə sayı
  - RAM: ümumi / istifadə / boş / %
  - Windows: ad, versiya, build, 32/64 bit
  - Disklər: hər fixed diskin ümumi/dolu/boş yaddaşı + fayl sistemi
  - hostname, uptime, boot vaxtı

Serverdə bu məlumat SQLite bazasına yazılır və web paneldə
"Agent Monitoru" modulunda görünür.

XARİCİ KİTABXANA TƏLƏB OLUNMUR
------------------------------
Yalnız Python standart kitabxanası + ctypes istifadə olunur (psutil YOX).
Ona görə offline/qapalı ATM mühitində `pip install` lazım deyil.

ENDPOINT
--------
POST http://172.21.12.80:8080/api/agent/report
Content-Type: application/json

QEYD: Server tərəfdə Node frontend indi 0.0.0.0-da dinləyir (bütün
interfeyslər), ona görə ATM-lər 172.21.12.80:8080-ə çata bilir.
Yalnız lokal istəsəniz serverdə:  set ATM_WEB_BIND=127.0.0.1


ADDIMLAR
========

1) EXE QURMAQ (bir dəfə, internetli developer komputerində)
   agent\ qovluğunda:  build_exe.bat
   Nəticə:  agent\dist\atm_agent.exe  (tək fayl, Python tələb etmir)

2) ATM-Ə KÖÇÜRMƏK
   atm_agent.exe  +  atm_id.txt  fayllarını ATM-ə kopyala.
   atm_id.txt içinə HƏMİN ATM-in ID-sini yaz (məs. A0100077).
   Eyni exe bütün ATM-lərdə işləyir — sadəcə atm_id.txt dəyişir.

3) İŞƏ SALMAQ
   a) Sadə yoxlama:   atm_agent.exe   (konsolda loglar görünür)
   b) Avtostart:      install_agent.bat  (Administrator kimi)
      - exe-ni C:\ATM_AGENT-ə kopyalayır
      - komputer açılanda avtomatik işləyən Scheduled Task yaradır
      Silmək:  schtasks /Delete /TN "ATM_WEB_Agent" /F


ATM ID NECƏ TƏYİN OLUNUR (bu sıra ilə)
--------------------------------------
  1) Komanda sətri:   atm_agent.exe A0100077
  2) Mühit dəyişəni:  set ATM_ID=A0100077
  3) Yan fayl:        atm_id.txt
  4) Default:         A0100077  (koddakı DEFAULT_ATM_ID)


AYARLARI DƏYİŞMƏK (mühit dəyişənləri ilə, rebuild lazım deyil)
--------------------------------------------------------------
  set ATM_SERVER_URL=http://172.21.12.80:8080/api/agent/report
  set ATM_SEND_INTERVAL=60        (saniyə)
  set ATM_ID=A0100077


TEST (server işləyərkən, serverin özündə və ya şəbəkədən)
--------------------------------------------------------
  curl -X POST http://172.21.12.80:8080/api/agent/report ^
       -H "Content-Type: application/json" ^
       -d "{\"atm_id\":\"A0100077\",\"os_name\":\"Windows 10\",\"os_architecture\":\"64-bit\"}"

  Sonra web paneldə:  Agent Monitoru modulunu aç.


TƏHLÜKƏSİZLİK QEYDİ
-------------------
Node frontend artıq LAN-dan əlçatandır (0.0.0.0:8080). Bu o deməkdir ki,
web panel də şəbəkədən açıla bilər. Yalnız agent portunu açıq saxlamaq
istəyirsinizsə, serveri firewall ilə məhdudlaşdırın (yalnız ATM
şəbəkəsindən 8080-ə icazə verin) və ya ayrıca port/host konfiqurasiyası
tələb olunarsa deyin, onu da əlavə edək.
