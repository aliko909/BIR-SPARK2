@echo off
REM ATM WEB - collect.bat  (WINDOWS XP ucun collector - eco_xp)
REM ATM-in ozunde isleyir, yaninda atminfo.json yaradir.
REM XP-de PowerShell olmaya biler: evvel PowerShell cehd olunur, olmasa
REM WMI uzerinden isleyen collect_xp.vbs yaradilir ve cscript ile islenir.
setlocal
set "HERE=%~dp0"
set "OUT=%HERE%atminfo.json"

REM (1) PowerShell varsa onu islet (collect.ps1 PS2/XP ile uyghundur)
where powershell >nul 2>&1
if %errorlevel%==0 (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%collect.ps1"
  if exist "%OUT%" exit /b 0
)

REM (2) PowerShell yoxdur -> VBS (WMI) fallback yaradilir
set "VBS=%HERE%collect_xp.vbs"
> "%VBS%" echo Option Explicit
>>"%VBS%" echo Dim fso, f, wmi, col, o, cpuName, cores, loadv, loadc, ramT, ramF, ramU, ramP
>>"%VBS%" echo Dim osCap, osVer, osBuild, arch, host, disksJson, d, t, fr, u, p, nowS
>>"%VBS%" echo Function JS(v): If IsNull(v) Then JS="""""" Else JS=""""" ^& Replace(Replace(CStr(v),"\","\\"),"""","\""") ^& """""": End Function
>>"%VBS%" echo Function JN(v): If IsNull(v) Or v="" Then JN="null" Else JN=CStr(v): End Function
>>"%VBS%" echo Set wmi = GetObject("winmgmts:\\.\root\cimv2")
>>"%VBS%" echo cpuName="" : cores=0 : loadv=0 : loadc=0
>>"%VBS%" echo Set col = wmi.ExecQuery("Select * from Win32_Processor")
>>"%VBS%" echo For Each o in col: If cpuName="" Then cpuName=Trim(o.Name)
>>"%VBS%" echo   If Not IsNull(o.NumberOfLogicalProcessors) Then cores=cores+o.NumberOfLogicalProcessors
>>"%VBS%" echo   If Not IsNull(o.LoadPercentage) Then loadv=loadv+o.LoadPercentage : loadc=loadc+1
>>"%VBS%" echo Next
>>"%VBS%" echo If cores=0 Then cores=1
>>"%VBS%" echo Dim loadAvg : If loadc^>0 Then loadAvg=Int(loadv/loadc) Else loadAvg="null"
>>"%VBS%" echo Set col = wmi.ExecQuery("Select * from Win32_OperatingSystem")
>>"%VBS%" echo For Each o in col
>>"%VBS%" echo   osCap=o.Caption : osVer=o.Version : osBuild=o.BuildNumber
>>"%VBS%" echo   ramT=CDbl(o.TotalVisibleMemorySize)*1024 : ramF=CDbl(o.FreePhysicalMemory)*1024
>>"%VBS%" echo   arch=o.OSArchitecture
>>"%VBS%" echo Next
>>"%VBS%" echo If IsNull(arch) Or arch="" Then arch="32-bit"
>>"%VBS%" echo ramU=ramT-ramF : If ramT^>0 Then ramP=Int(100*ramU/ramT) Else ramP="null"
>>"%VBS%" echo host=CreateObject("WScript.Network").ComputerName
>>"%VBS%" echo disksJson="" : Set col = wmi.ExecQuery("Select * from Win32_LogicalDisk Where DriveType=3")
>>"%VBS%" echo For Each d in col
>>"%VBS%" echo   t=CDbl(d.Size) : fr=CDbl(d.FreeSpace) : u=t-fr : If t^>0 Then p=Int(100*u/t) Else p="null"
>>"%VBS%" echo   If disksJson^<^>"" Then disksJson=disksJson^&","
>>"%VBS%" echo   disksJson=disksJson^&"{""name"":"^&JS(d.DeviceID)^&",""label"":"^&JS(d.VolumeName)^&",""filesystem"":"^&JS(d.FileSystem)^&",""total_bytes"":"^&JN(t)^&",""used_bytes"":"^&JN(u)^&",""free_bytes"":"^&JN(fr)^&",""used_percent"":"^&JN(p)^&"}"
>>"%VBS%" echo Next
>>"%VBS%" echo nowS=Year(Now)^&"-"^&Right("0"^&Month(Now),2)^&"-"^&Right("0"^&Day(Now),2)^&"T"^&Right("0"^&Hour(Now),2)^&":"^&Right("0"^&Minute(Now),2)^&":"^&Right("0"^&Second(Now),2)
>>"%VBS%" echo Set fso=CreateObject("Scripting.FileSystemObject")
>>"%VBS%" echo Set f=fso.CreateTextFile("%OUT%", True)
>>"%VBS%" echo f.Write "{""status"":""online"",""collector"":""collect_xp.vbs"",""collected_at"":"^&JS(nowS)^&",""hostname"":"^&JS(host)^&",""os_name"":"^&JS(osCap)^&",""os_version"":"^&JS(osVer)^&",""os_build"":"^&JS(osBuild)^&",""os_architecture"":"^&JS(arch)^&",""cpu_name"":"^&JS(cpuName)^&",""cpu_cores"":"^&JN(cores)^&",""cpu_percent"":"^&JN(loadAvg)^&",""ram_total_bytes"":"^&JN(ramT)^&",""ram_used_bytes"":"^&JN(ramU)^&",""ram_free_bytes"":"^&JN(ramF)^&",""ram_percent"":"^&JN(ramP)^&",""disks"":["^&disksJson^&"]}"
>>"%VBS%" echo f.Close
cscript //nologo "%VBS%"
exit /b %errorlevel%
