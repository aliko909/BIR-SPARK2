ATM WEB — NODE.JS MODULAR / 100% OFFLINE FINAL

Bu paket internet olmayan Windows server üçün hazırlanıb.

QURULUŞ
1) ZIP-i ATM_WEB qovluğuna çıxart.
2) Səndə olan portable Node.js v24.21.0 faylları runtime\ qovluğunda olmalıdır.
   Düz yol: ATM_WEB\runtime\node.exe
3) PsExec64.exe əvvəlki ATM_WEB qovluğunda varsa saxla/kopyala.
4) START.bat-a iki dəfə klik et.
5) Açılan ünvan: http://localhost:8080/home.html

PORTLAR
- Node frontend/gateway: 127.0.0.1:8080
- Python ATM engine:      127.0.0.1:8081

OFFLINE
- npm install YOXDUR
- Google Maps YOXDUR
- İş vaxtı (START.bat) heç bir xarici tile sorğusu YOXDUR
- CDN/API KEY YOXDUR
- Xəritə: Leaflet 1.9.4 (web/assets/vendor/leaflet, lokal) + lokal tile-lar (map_tiles\)
- Qatlar: Küçə (OpenStreetMap), Peyk (Esri World Imagery), Hibrid (peyk + adlar)
- Tile yoxdursa: sadə Azərbaycan kontur rejimi avtomatik açılır

OFFLINE XƏRİTƏNİ HAZIRLAMAQ (BİR DƏFƏ, İNTERNETLİ KOMPÜTERDƏ)
1) runtime\node.exe yerində olsun.
2) PREPARE_OFFLINE_MAP.bat işlət. Əvvəlcə tile sayı və həcmi göstərilir (y/n).
   Default plan: bütün ölkə zoom 5-12, Bakı/Sumqayıt/Gəncə zoom 15-ə qədər,
   hər ATM ətrafı zoom 17-yə qədər (DB-dən oxunur). ~1.5 GB, ~33 min tile/qat, 12 paralel bağlantı.
3) Yarımçıq qalsa yenidən işlət — qaldığı yerdən davam edir.
4) Bitəndən sonra BÜTÜN ATM_WEB qovluğunu (map_tiles daxil) internetsiz serverə köçür.
5) Yeni ATM əlavə etsən, həmin ATM ətrafının detal tile-ları üçün 1-4 təkrarla.
Ayarlar: tools\map-tiles.config.json (zoom, bölgələr, radius, mənbə).
Yalnız hesablama: PREPARE_OFFLINE_MAP.bat --estimate
Korporativ proxy: set HTTPS_PROXY=http://proxy:port sonra PREPARE_OFFLINE_MAP.bat

MƏNTİQLƏR SAXLANILIB
- Backup Monitor / D-H-Journal scan-ləri
- Scan history / compare
- ATM Restart
- Video Archive / Explorer
- Bankomatlar CRUD + soft delete/status
- Tək və toplu PASSWORD environment discovery
- ATM Xəritəsi + modul keçidləri
- ATM activity history / son əməliyyat
- ATM Sistem Monitoru WMI/RPC + PsExec/SMB fallback

DB
atm_history.db paketdə istifadəçinin göndərdiyi bazanın nüsxəsidir.
Real password DB-yə yazılmır; yalnız PASSWORD1/PASSWORD2/... slot adı saxlanılır.

Portable Node test:
  runtime\node.exe -v
Gözlənilən: v24.21.0
