@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ATM WEB - NODE OFFLINE

set "PATH=C:\ProgramData\Anaconda3;C:\ProgramData\Anaconda3\Library\bin;C:\ProgramData\Anaconda3\DLLs;%PATH%"
set "ATM_PY_PORT=8081"
set "NODE_EXE=%~dp0runtime\node.exe"

rem ===== PORT ve SERTIFIKAT secimi =====
set "ATM_WEB_PORT=8080"
set "ATM_WEB_HTTPS=0"
set "ATM_SCHEME=http"
echo ------------------------------------------------
set /p "ATM_WEB_PORT=WEB port daxil edin [default 8080]: "
if "%ATM_WEB_PORT%"=="" set "ATM_WEB_PORT=8080"
echo.
echo   1^) Sertifikatsiz port  ^(HTTP^)
echo   2^) Sertifikatli port   ^(HTTPS / TLS^)
choice /C 12 /N /M "Port novunu secin [1/2]: "
if errorlevel 2 goto :atm_https
goto :atm_proto_done

:atm_https
set "ATM_WEB_HTTPS=1"
set "ATM_SCHEME=https"
echo.
echo   1^) .pfx fayli      ^(PowerShell / Windows CA - en rahat^)
echo   2^) .crt + .key     ^(PEM - openssl / bankin CA^)
choice /C 12 /N /M "Sertifikat novu [1/2]: "
if errorlevel 2 goto :atm_pem

rem --- PFX ---
set "ATM_WEB_PFX=%~dp0certs\server.pfx"
echo.
set /p "ATM_WEB_PFX=PFX fayli yolu [default certs\server.pfx]: "
if "%ATM_WEB_PFX%"=="" set "ATM_WEB_PFX=%~dp0certs\server.pfx"
set /p "ATM_WEB_PFX_PASS=PFX paroru (yoxdursa Enter): "
if not exist "%ATM_WEB_PFX%" echo [DIQQET] PFX tapilmadi: %ATM_WEB_PFX%  -- server avtomatik HTTP-ye kececek.
goto :atm_proto_done

rem --- PEM (.crt + .key) ---
:atm_pem
set "ATM_WEB_CERT=%~dp0certs\server.crt"
set "ATM_WEB_KEY=%~dp0certs\server.key"
echo.
set /p "ATM_WEB_CERT=Sertifikat fayli (.crt/.pem) [default certs\server.crt]: "
if "%ATM_WEB_CERT%"=="" set "ATM_WEB_CERT=%~dp0certs\server.crt"
set /p "ATM_WEB_KEY=Acar fayli (.key) [default certs\server.key]: "
if "%ATM_WEB_KEY%"=="" set "ATM_WEB_KEY=%~dp0certs\server.key"
if not exist "%ATM_WEB_CERT%" echo [DIQQET] Sertifikat tapilmadi: %ATM_WEB_CERT%  -- server avtomatik HTTP-ye kececek.
if not exist "%ATM_WEB_KEY%"  echo [DIQQET] Acar tapilmadi: %ATM_WEB_KEY%  -- server avtomatik HTTP-ye kececek.

:atm_proto_done
echo ------------------------------------------------
echo [OK] Port: %ATM_WEB_PORT%   Rejim: %ATM_SCHEME%
echo.

cls
echo ================================================
echo   ATM WEB - OFFLINE NODE.JS MODULAR
echo ================================================
echo.

if not exist "%NODE_EXE%" (
  echo [ERROR] Portable Node.js tapilmadi:
  echo         %NODE_EXE%
  echo.
  echo node-v24.21.0-win-x64 qovlugunun DAXILINDEKI fayllari
  echo ATM_WEB\runtime\ qovluguna kocur.
  echo Netice: ATM_WEB\runtime\node.exe olmalidir.
  echo.
  pause
  exit /b 1
)

echo [OK] Portable Node.js:
"%NODE_EXE%" -v
if errorlevel 1 (
  echo [ERROR] runtime\node.exe ishlemir.
  pause
  exit /b 1
)

if not exist "%~dp0server.js" (
  echo [ERROR] server.js tapilmadi.
  pause
  exit /b 1
)
if not exist "%~dp0server.py" (
  echo [ERROR] server.py tapilmadi.
  pause
  exit /b 1
)
if not exist "%~dp0atm_history.db" (
  echo [ERROR] atm_history.db tapilmadi.
  pause
  exit /b 1
)

if exist "C:\ProgramData\Anaconda3\python.exe" (
  set "ATM_PYTHON=C:\ProgramData\Anaconda3\python.exe"
) else (
  where python >nul 2>&1
  if errorlevel 1 (
    echo [ERROR] Python tapilmadi. C:\ProgramData\Anaconda3\python.exe movcud deyil.
    pause
    exit /b 1
  )
  set "ATM_PYTHON=python"
)

echo [OK] Python engine: %ATM_PYTHON%

if exist "%~dp0map_tiles\manifest.json" (
  echo [OK] Offline xerite tile-lari: map_tiles\
) else (
  echo [DIQQET] Offline xerite tile-lari YOXDUR ^(map_tiles\manifest.json^).
  echo          Kuce/peyk xeritesi ucun internetli komputerde PREPARE_OFFLINE_MAP.bat islet.
  echo          Indi yuklemek isteyirsen? Internet lazimdir. 15 saniye cavab olmasa - N.
  choice /C YN /T 15 /D N /M "Yukleyim"
  if not errorlevel 2 (
    set "NODE_USE_ENV_PROXY=1"
    "%NODE_EXE%" "%~dp0tools\download_tiles.js"
  ) else (
    echo          Xerite sade kontur rejiminde acilacaq.
  )
)
echo [OK] Internet / npm install teleb olunmur.
echo [OK] Xerite 100%% lokal/offline fayllardan ishleyir.
echo.
echo WEB:    %ATM_SCHEME%://localhost:%ATM_WEB_PORT%/home.html
echo API:    http://127.0.0.1:%ATM_PY_PORT%  ^(daxili^)
echo.
echo Baglamaq ucun Ctrl+C.
echo.

"%NODE_EXE%" "%~dp0server.js"
set "ERR=%ERRORLEVEL%"
if not "%ERR%"=="0" echo [ERROR] ATM WEB dayandi. ErrorLevel=%ERR%
pause
exit /b %ERR%
