# ATM WEB — Təhlükəsizlik auditi (daxili nəzərdən keçirmə)

Tarix: 2026-11-04. Bu sənəd pentest-ə hazırlıq üçün kodun daxili təhlükəsizlik
nəzərdən keçirilməsinin nəticəsidir: nə yoxlanıldı, nə yaxşı vəziyyətdədir, nə
bərkidildi və deploy üçün tövsiyələr.

---

## 1. Nəticə (xülasə)
Kod bazası təhlükəsizlik baxımından güclü qurulub. Yoxlanılan əsas sinif
zəiflikləri (OWASP Top 10) üzrə **kritik boşluq tapılmadı**. Bu audit zamanı bir
sərtləşdirmə (CSP + əlavə başlıqlar) əlavə olundu. Qalan maddələr **deploy
konfiqurasiyası** ilə bağlıdır (kod zəifliyi deyil).

---

## 2. Autentifikasiya və sessiya  (auth.js) — GÜCLÜ
- **Şifrə hashı:** `scrypt` (N=16384, r=8, p=1), hər şifrəyə təsadüfi 16-baytlıq
  salt, müqayisə `timingSafeEqual` ilə. Düz mətn şifrə heç yerdə saxlanılmır.
- **İstifadəçi sayımına qarşı (enumeration):** mövcud olmayan istifadəçi üçün də
  `DUMMY_HASH` yoxlanılır → cavab vaxtı eyni qalır.
- **JWT:** HS256, açar **təsadüfi 48 bayt** (DB `meta.jwt_secret`), kodda sabit açar
  YOXDUR; imza `timingSafeEqual` ilə yoxlanılır.
- **Access token** qısa ömürlü (15 dəq), **refresh token** təsadüfi 256-bit, bazada
  yalnız **SHA-256 hash**-i saxlanılır, hər istifadədə **rotasiya** olunur; köhnə
  token təkrar işlədilsə sessiya ləğv olunur (reuse detection).
- **Cookie-lər:** `HttpOnly; SameSite=Strict` (+ `Secure`, HTTPS arxasında). SameSite=Strict
  CSRF-ə qarşı güclü müdafiədir.
- **Brute-force:** 5 səhv cəhd → 5 dəqiqə kilid. Status/icazə bağlananda və şifrə
  sıfırlananda bütün sessiyalar dərhal ləğv olunur.
- **Məcburi şifrə dəyişmə** (ilk admin) axını var.

## 3. Avtorizasiya (icazələr) — FAIL-SAFE
- Hər `/api/*` yolu Node gateway-də yoxlanılır, sonra Python-a ötürülür.
- **Siyahıda (ROUTES) olmayan yol yalnız adminə açıqdır** (fail-safe default) —
  yeni endpoint təsadüfən açıq qalmır.
- İstifadəçi/audit idarəetməsi üçün ayrıca açıq yoxlamalar var.
- **Bütün ötürülən sorğular audit-ə yazılır**; log-da şifrə/token/secret sahələri
  `redact()` ilə maskalanır.

## 4. İnjeksiya — TƏMİZ
- **SQL:** parametrli sorğular (`?`). Dinamik qurulan yeganə hissələr — migration
  sütun adları (kod sabitləri) və `?` sayğacı; istifadəçi dəyəri heç vaxt SQL-ə
  birbaşa yapışdırılmır. `UPDATE ... SET` yalnız **whitelist** sütunlardan qurulur.
- **Komanda injeksiyası:** `shell=True`, `os.system`, `os.popen`, `eval`, `exec`
  YOXDUR. Bütün xarici proseslər (robocopy, net use, PsExec) **siyahı arqumentlərlə**
  çağırılır → shell parse olunmur.

## 5. Fayl yolu / traversal — QORUNUR
- **Node statik servis:** `safeJoin()` — URL decode + normalize, `..` rədd, həll
  olunmuş yol kök qovluğun içində olmalıdır. Statik yalnız `web/` qovluğundan
  verilir → `server.py`, `auth.js`, `*.db` **web-dən servis olunmur** (mənbə kod və
  baza açıq deyil).
- **Python fayl əməliyyatları** (explorer / srvmove / backup): `explorer_path()`
  `..`, `:` və kök sərhədindən çıxışı bloklayır; junction/symlink ilə kənara
  yönləndirmə `realpath` müqayisəsi ilə tutulur.
- **srvmove:** mənbə=hədəf və hədəf seçilmiş qovluğun içində olması rədd edilir;
  simvolik linklər atlanır.

## 6. Nəqliyyat və başlıqlar
- TLS dəstəklənir (`certs\` + `ATM_WEB_PFX_PASS` / `ATM_WEB_CA`).
- Təhlükəsizlik başlıqları: `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`,
  `Referrer-Policy: same-origin`.
- **Bu auditdə əlavə olundu:** `Content-Security-Policy` (default-src 'self';
  script/style 'self' 'unsafe-inline'; img 'self' data: blob:; connect 'self';
  object-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'),
  `Permissions-Policy` (camera/mic/geo/payment/usb = qapalı), və HTTPS-də
  `Strict-Transport-Security`. Tətbiq 100% offline (xarici CDN/şrift/skript yoxdur),
  ona görə CSP heç bir funksiyanı qırmır.

## 7. Digər
- **Open redirect:** login `next` parametri yalnız `/home.html...` qəbul edir.
- **Asılılıqlar:** `package.json` → `dependencies: {}` (xarici npm paketi yoxdur) →
  supply-chain riski minimaldır. Yalnız Node daxili modulları + portable Node.
- **Sirlər:** real ATM şifrələri yalnız Windows environment dəyişənlərində
  (PASSWORD1..) saxlanılır; DB/UI/log-a çıxmır.

---

## 8. Deploy tövsiyələri (pentest-dən əvvəl)
Bunlar kod zəifliyi deyil, konfiqurasiya tövsiyələridir:

1. **HTTPS işlət** və `ATM_COOKIE_SECURE=1` təyin et. Node default olaraq bütün
   interfeyslərə (`0.0.0.0:8080`) bağlanır (ATM agent-ləri üçün). HTTPS olmasa,
   şəbəkədə cookie/parol açıq gedə bilər.
2. Agent-lərə ehtiyac yoxdursa `ATM_WEB_BIND=127.0.0.1` ilə yalnız lokala bağla;
   lazımdırsa 8080 portunu yalnız ATM/idarəetmə alt-şəbəkəsinə firewall ilə aç.
3. İlk girişdən sonra `ILK_ADMIN_SIFRE.txt` faylını SİL (README_AUTH-da yazıldığı kimi).
4. **PsExec.exe / PsExec64.exe** — leqal idarəetmə alətidir, amma AV/pentest onu
   "hacktool" kimi işarələyə bilər. Bunu təşkilatın AV allow-list-inə əlavə et və
   izah et ki, ATM sistem monitoru üçün istifadə olunur.
5. `atm_auth.db` (istifadəçilər) və `atm_history.db` (ATM-lər) müntəzəm backup edilsin.
6. (İstəyə görə) scrypt N dəyərini 2^15-ə qaldırmaq olar (maxmem parametri ilə) —
   mövcud 2^14 qəbul edilən həddir.

## 9. Bu auditdə edilən dəyişikliklər
- `server.js`: `Content-Security-Policy`, `Permissions-Policy`, HTTPS-də HSTS əlavə
  olundu (statik/HTML cavablarına). Mövcud başlıqlar `securityHeaders()` funksiyasında
  birləşdirildi.

## 10. 2FA (TOTP) — v19 əlavəsi
- RFC 6238 TOTP (SHA-1, 6 rəqəm, 30 san, ±1 addım), 160-bit sirr, AES-256-GCM ilə şifrəli saxlanır
  (açar `atm_auth.key`, 0600). Sirr audit jurnalına və loglara düşmür.
- Şifrə doğru olduqda sessiya **yaradılmır** — yalnız 5 dəq.lik, tək istifadəlik, IP-yə bağlı
  HttpOnly/SameSite=Strict `atm_mfa` cookie-si verilir. Sessiyalarda `mfa` bayrağı: 2FA-sız sessiya rədd edilir.
- Replay qorunması (`totp_last_step`), brute-force: mərhələ başına 5 cəhd + hesab kilidi (5 dəq.).
- Sıfırla / Yenidən qur / Kilidi aç endpoint-ləri yalnız `is_admin` — server tərəfində yoxlanır.
- Açar faylı silinsə 2FA bypass olmur: şifrəli sirr oxunmadıqda giriş 500 ilə dayanır (admin sıfırlamalıdır).
- Avtomatik test: 39/39 yoxlama keçdi (qeydiyyat, replay, IP bağlılığı, CSRF, lockout, admin-only, audit).

