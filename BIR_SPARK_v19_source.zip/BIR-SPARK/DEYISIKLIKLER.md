# ATM WEB — əlavə olunan dəyişikliklər

Prinsip: parol **axtarılmır/sprey edilmir**. Hər ATM-in PASSWORD slotu DB-dəki
`password_env` sahəsindən birbaşa götürülür (konfiqurasiya məntiqi). Real şifrə
yalnız Windows environment dəyişənlərində qalır, DB/UI/log-a heç vaxt çıxmır.

## 1. Windows növü ↔ PASSWORD slotu ↔ collector
- `atms` cədvəlinə `windows_type` sütunu əlavə olundu (migration avtomatik işləyir).
- Avtomatik qayda (server.py `WIN_TYPE_BY_SLOT`):
  - **XP** → PASSWORD 1, 4, 8
  - **Windows 10** → PASSWORD 3, 6, 10
  - **Windows 7** → PASSWORD 2, 5, 9
- Collector qovluqları (serverdə `C:\` altında olmalıdır):
  - `C:\eco_xp`, `C:\eco_win7`, `C:\eco_win10` — yoxdursa köhnə `C:\eco`-ya düşür.
  - XP üçün `eco_xp\collect.bat` PowerShell olmadıqda WMI/VBS ilə işləyir.
- Qoşulanda ATM-in Windows növünə uyğun collector göndərilir (`_atminfo_445`).

## 2. 445 qoşulma sürəti (57 san → ~5-10 san)
- Tək ATM qoşulmasında bütün slotlar yoxlanmır: DB-dəki `password_env` ilk
  (preferred) sınanır, `password_timeout=6`, `net use` timeout 20→8 san.
- TCP 445 ön-yoxlaması (3 san) onsuz da var — offline ATM tez kəsilir.

## 3. ATM Info — toplu qoşulma (iki siyahılı pəncərə)
- Başlıqda **"Toplu qoşulma"** düyməsi → pəncərə açılır:
  - solda bütün ATM-lər, iki dəfə klik sağa keçirir,
  - ▶▶ hamısını sağa, ◀◀ hamısını sola,
  - "Seçilmişlərə qoşul" → yalnız seçilən ATM-lər üçün uyğun slot tapılıb
    `password_env` + `windows_type` bazaya yazılır (progress + log).
- Backend: `POST /api/atms/bulk_start` artıq `{atm_ids:[...]}` qəbul edir.

## 4. ATM Info — Windows idarəetmə ekranı
- **"Windows idarəetmə"** düyməsi → cədvəl: `ATM ID · Region · PASSWORD · Avtomatik növ · Windows növü (əl ilə)`.
- Əl ilə seçim `POST /api/atms/winmap/save` ilə yadda saxlanır; `GET /api/atms/winmap`.

## 5. Xəritə modulu — aktiv (canlı) göstərmə
- Qoşulub CPU/RAM çəkilmiş ATM (`last_info_ok=1`) markerə kliklədikdə
  **"AKTİV (CANLI)"** + CPU/RAM/OS/Windows növü sətri göstərilir.
- Yan paneldəki "Aktiv (canlı)" sayğacı canlı ATM-ləri sayır.

## 6. Excel import
- `aksejhfboserihnfiowesd.xlsx`-dəki **1277 ATM** bazaya yükləndi
  (ad, region, RİM, sistem/fiziki ünvan). `tools/atm_meta.json` yeniləndi.
- Yenidən import: `python tools\import_atm_meta.py --add-missing`

## 7. PsExec 32/64-bit avtomatik seçimi (rc=6 "not compatible" xətası)
- Səbəb: 32-bit ATM-də (köhnə Win7/XP) 64-bit `PsExec64.exe` PSEXESVC
  xidmətini başlada bilmir → `collect.bat` işləmir, `atminfo.json` yaranmır.
- Həll: `system_find_psexec_for_win(win_type)` Windows növünə görə seçir:
  - **XP / Win7 / bilinməyən** → `PsExec.exe` (32-bit; hər arxitekturada işləyir)
  - **Win10** → `PsExec64.exe`
  - seçilən yoxdursa digərinə avtomatik düşür.
- Hər iki fayl artıq server qovluğundadır: `PsExec.exe` (32-bit) + `PsExec64.exe`.

## 8. Dalğa 2 — kiçik düzəlişlər
- **"Test etmək" modulu silindi** (backend + frontend + PsInfo/PsList binarları).
- **Login səhifəsi:** şifrədən əvvəl böyük **"XOŞ GƏLMİSİNİZ"** yazısı.
- **"Ana səhifə"** və **"ATM Xəritəsi"** başlıqları altındakı izah mətnləri silindi
  (xəritə modulundakı `<p>` izah da götürüldü).
- **Win7/XP timeout düzəlişi:** collect.bat üçün timeout artıq Windows növünə
  görədir — XP/Win7 = 180 san, Win10 = 90 san (əvvəl hamıya 70 san idi, ona görə
  yavaş Win7-lərdə yalançı "70 saniyədə bitmədi" çıxırdı). JSON gözləmə də
  XP/Win7 üçün 30 san-ə qaldırıldı. `ATM_INFO_RUN_TIMEOUT` env ilə dəyişilə bilər.

## 9. Dalğa 3 (v6)
- **Dizayn:** sakit teal-slate palitra, ağ səthlər (tokens.css).
- **Home yenidən:** xəritə + qısa düymələr silindi; DB statistikası + "Son görülən
  işlər" (activity log) + "Son scan nəticələri", hər ikisində CSV.
- **Backup Monitor akordeon** (sidebar başlığına klik → alt bəndlər açılır/bağlanır).
- **Yeni modullar (Backup Monitor altında):**
  - **Video / şəkil** (`videosekil`) — ATM-ə qoşul → DB diskləri → gəz → şəkil/video önizlə + yüklə.
  - **Jurnal** (`jurnal`) — Video Archive-dən ayrıldı; DB diskləri + C$\JOURNAL → TXT/JRN aç + yüklə.
  - Disklər DB-dən (`config_disks`) dinamik gəlir; `GET /api/disks`.
  - Explorer ixtiyari disk üçün genişləndi: `root=disk:<HERF>` → `\\ATM\<HERF>$`.
  - Fayllar: `web/modules/jurnal.html`, `web/modules/videosekil.html`,
    `web/assets/js/backup-browser.js`.
- **ATM Info:** RİM/Ad/Region/ünvan sütunları + Excel/CSV; xəritə popup-da da bu infolar.
- **Xəritə düymələri** ikon + tooltip.
- **i18n (AZ/RU/EN):** ~100 açar; dinamik başlıq da tərcümə olunur.

## Qeyd
- PASSWORD11+ slotları avtomatik qaydada deyil → "Windows idarəetmə"dən əl ilə
  təyin edin, və ya `WIN_TYPE_BY_SLOT`-a əlavə edin.
- `atm_history.db.bak` = import-dan əvvəlki ehtiyat nüsxə.

## 10. Video / Şəkil Server (v9)
- **Yeni bölmə:** Backup Monitor → **"Video / Şəkil Server"** (`videoserver`).
  ATM-ə qoşulmadan, birbaşa backup serverindəki (DB: `config_ips` / `config_disks` /
  `config_folders`, hazırda `\\172.21.12.77\d$\ATMFILES` və `\\172.21.12.77\h$\ATM_GRG_files`)
  `ATM_ID\YYYYMMDD\...` qovluqlarını yoxlayır. Yalnız MEDIA mənbələri; jurnal (TXT) mənbələri daxil deyil.
- **Yoxla:** ATM nömrəsi (+ istəyə bağlı tarix) → hər mənbə üçün paralel:
  qovluq VAR/YOX, tarix folderi sayı, ən son folder, **şəkilli son tarix** (son folder boşdursa
  15 folderə qədər geri baxır), şəkil/video sayı, ölçü, son fayl vaxtı; seçilən tarix folderi VAR/YOX + sayılar.
  Qovluq tapılmasa **oxşar ATM qovluqları** göstərilir (klik → yenidən yoxla).
- **Gəzmə:** tarix folderləri (yenidən köhnəyə, şəkil/video sayı fonda dolur), alt qovluqlar,
  **Siyahı / Qalereya** görünüşü, şəkil önizləmə (← → ilə növbəti/əvvəlki), video (AVI/WMV → ffmpeg), yükləmə.
- **Backend (server.py):** `GET /api/srvmedia/sources|check|stats` + `GET /api/srvmedia/list|text|media|transcode`
  (`root=srv:<MƏNBƏ>:<ATM_ID>`). Mövcud explorer kodu istifadə olunur; yol çıxışı (`..`, junction) bloklanır.
  `/api/srvmedia/*` yalnız `srv:` kökü, `/api/explorer/*` yalnız ATM kökü qəbul edir.
- **İcazələr (auth.js):** yeni `videoserver` modulu — `videoserver.check`, `videoserver.browse`,
  `videoserver.media`. Admin-dən başqa istifadəçilərə İstifadəçilər → İcazələr bölməsindən verilməlidir.
- Fayllar: `web/modules/videoserver.html`, `web/assets/js/server-media.js`, `app.css` (vsv* stilləri).
- Qeyd: serverdə Python prosesinin 77 serverin `d$`/`h$` paylaşımlarına oxuma icazəsi olmalıdır
  (Backup scan-ləri ilə eyni — scan işləyirsə bu bölmə də işləyəcək).

## 11. D Scan — NORMAL kateqoriyası düzəldildi (5 gün qaydası)
- **Problem:** NORMAL yalnız `seçilən tarix ≤ son backup < dünən` olanda verilirdi. Scan adətən
  dünənki tarixlə başladıldığı üçün bu aralıq boş qalırdı → dünəndən köhnə hər şey PROBLEM olurdu
  (son 12 scan-də NORMAL = 0).
- **Yeni qayda (D Scan):**
  - ƏLA — son etibarlı backup dünəndir;
  - NORMAL — son etibarlı backup seçilən tarixdən **ən çox 5 gün əvvəldir** (və ya ondan sonradır);
  - PROBLEM — 5 gündən çox köhnədir və ya backup yoxdur.
- Səbəb sütunu artıq günü yazır: "seçilən tarixdən 3 gün əvvəldir (5 gün limiti daxilində)" /
  "seçilən tarixdən 9 gün köhnədir (NORMAL üçün limit: ...)".
- Backup Monitor-dakı kateqoriya izahları (legend) mənbəyə görə avtomatik dəyişir.
- H, H Jurnal və D Jurnal köhnə qayda ilə qalır. Limiti dəyişmək və ya başqa mənbəyə də vermək:
  `server.py` → `NORMAL_TOLERANCE_DAYS = {"D": 5}` və ya mühit dəyişəni `ATM_NORMAL_DAYS_H=5`.
- Köhnə scan tarixçəsi dəyişdirilmir; yeni qayda növbəti scan-lərdən tətbiq olunur.

## 12. Ağ / Qaranlıq rejim
- Yuxarı paneldə (saatın yanında) **günəş / ay düyməsi** — bir kliklə ağ ↔ qaranlıq rejim.
  Login səhifəsinin altında da "Qaranlıq rejim" düyməsi var.
- Seçim brauzerdə yadda qalır (`localStorage: atm_theme`); səhifə yenilənəndə, yeni tab-da və
  növbəti girişdə eyni rejim açılır, açılışda ağ ekran "yanıb-sönmür". Bir tab-da dəyişəndə digər tab-lar da dəyişir.
- Standart rejim — **ağ** (əvvəlki görünüş dəyişmədən qalır).
- Texniki: `tokens.css`-də `:root[data-theme="dark"]` palitrası (bütün komponentlər token-lərlə işlədiyi üçün avtomatik keçir),
  `assets/ds/theme-dark.css` — birbaşa rəng yazılmış köhnə yerlərin düzəlişi (cədvəl sətirləri, input-lar, xəritə panelləri,
  Windows nişanları), `assets/js/theme.js` — keçid məntiqi. Yeni ikonlar: `i-sun`, `i-moon`.
- Əlavə düzəliş: hər açılışda konsola düşən `loadArchiveConfig` xətası (köhnə Video Archive moduluna aid) aradan qaldırıldı.

## 13. VIDEOARCHIVE Scan (Backup Monitor → VIDEOARCHIVE Scan)
- **Nə edir:** bütün aktiv ATM-lərə (və ya yapışdırılmış siyahıya) paralel qoşulur və hər birində
  `\\ATM_ID\D$\VIDEOARCHIVE\ATM_ID\YYYYMMDD\...` (alt qovluqlar daxil) üzrə **şəkli olan ən son tarixi**
  və **ən son şəklin vaxtını** (LastWriteTime) tapır. Ən son folder boşdursa 30 folderə qədər geri baxır.
- **Kateqoriyalar:** AKTİV (bu gün/dünən) · GECİKİR (2–5 gün) · PROBLEM (5 gündən çox) ·
  ŞƏKİL YOXDUR · VIDEOARCHIVE YOXDUR · QOŞULMADI (şəbəkə/şifrə) · VAXT AŞIMI · XƏTA.
- **Excel hesabatı** (serverdə yaradılır, əlavə paket lazım deyil — `xlsx_lite.py`):
  Xülasə · Bütün ATM-lər (ən son şəkil çəkən yuxarıda) · Diqqət tələb edənlər (ən köhnəsi yuxarıda) · Qoşulmayanlar.
  Rəngli sətirlər, başlıq dondurulub, filtr, tarixlər əsl Excel tarixi.
- **Qoşulma:** DB-dəki `password_env` əvvəl sınanır, sonra digər PASSWORD slotları; şəbəkə xətası/hesab kilidi
  kodlarında (53, 67, 1909 ...) dayanır. Uğurlu slot `atms.password_env`-ə yazılır. Başqa modulun açıq sessiyası (1219)
  pozulmur. Şifrə heç yerdə görünmür.
- **Qoruma:** ATM başına vaxt limiti (300 san), Dayandır düyməsi (yoxlanmışlar saxlanır), eyni anda ikinci scan və
  Disk Report ilə paralel işləmə bloklanır, server dayansa scan "YARIMÇIQ" kimi tarixçədə qalır.
  ATM saatı səhv olub fayl vaxtı gələcəkdədirsə folder tarixi götürülür və qeyd edilir.
  VIDEOARCHIVE-də ATM adlı qovluq yoxdursa və yeganə alt qovluq varsa — o istifadə olunur (qeyd ilə).
- **Tarixçə:** hər scan DB-də (`va_scan_runs`, `va_scan_results`) — "Bax" və "Excel" düymələri.
- **İcazələr:** `vascan` (görmək), `vascan.start` (başlat/dayandır), `vascan.export` (Excel).
- **Ayarlar (mühit dəyişəni, istəyə görə):** `ATM_VA_WORKERS=10` (paralel ATM), `ATM_VA_ATM_TIMEOUT=300`,
  `ATM_VA_LATE_DAYS=5`.
- API: `POST /api/vascan/start|cancel`, `GET /api/vascan/progress|history|detail|excel`.

## 10. Dalğa 4 (v7) — Birbank interfeysi (yeni dizayn)
Məqsəd: rəhbərlikdən ən aşağı işçiyə qədər HAMI üçün asan, rahat, oxunaqlı interfeys.
- **Brend rəngi Birbank qırmızısı** (`#e4002b`) — `tokens.css`-də həm işıq, həm
  qaranlıq rejim üçün `--c-primary` və törəmələri yeniləndi. Fokus/hover/aktiv
  hallar, düymələr, KPI vurğuları, progress-barlar avtomatik qırmızı oldu.
- **Yan menyu artıq TAM YAZILI** — əvvəlki ikon-rail hibrid (desktopда yalnız
  ikonlar, yazısız) LƏĞV olundu. İşçi modul adını həmişə oxuyur → "çətin işləyir"
  problemi aradan qalxdı. Menyu tünd fonlu, aktiv modul qırmızı dolu.
- **Qırmızı başlıq zolağı** (appHeader) — ağ yazılar, şəffaf axtarış qutusu.
- **Təmiz ağ kartlar** — çəhrayı gradient əvəzinə ağ səth + incə kölgə + nazik
  haşiyə; daha oxunaqlı, göz yormayan.
- **Planşet (Galaxy Tab) üçün axıcı sürüşmə** saxlanıldı: məcburi smooth-scroll
  söndürülür, background-attachment:scroll, blur toxunmada söndürülür,
  toxunma hədəfləri 44–52px (`tablet.css`).
- Dəyişən fayllar: `tokens.css`, `theme-lightblue.css` (tam yenidən yazıldı).
- Keş üçün bütün asset versiyaları `?v=32 → ?v=33` (home.html, login.html,
  bootstrap.js). Köhnə server yenilənəndə brauzer yeni CSS-i çəkir.
- **Backend / məntiq / API dəyişməyib** — yalnız görünüş (CSS) yeniləndi.

## 11. Spatial Workspace rejimi tam LƏĞV olundu (v8)
- Əvvəl `app.js`-də spatial avtomatik işə düşürdü ("yeganə rejim") — götürüldü.
  İndi klassik panel yeganə rejimdir.
- Silindi: başlıqdakı "◳ Spatial" düyməsi, `WS.enable()` / `WS.sync()` çağırışları,
  `workspace.js`, `workspace.css` və `workspace-bg.png` (~2 MB) faylları,
  `theme-lightblue.css`-dəki `.wsToggleBtn` stilləri.
- Asset versiyaları `?v=33 → ?v=34` (keş yenilənsin).
- Backend toxunulmayıb.

## 12. Server bölməsi — hər disk üzrə sxematik diaqram (v9)
- Server disk gəzgini modulunun yuxarısına **"Disklərin vəziyyəti"** paneli əlavə
  olundu: hər server diski (D$/H$/M$/F$) üçün donut diaqram (dolu %), status nişanı
  (Normal / Dolur / Kritik), progress-bar və Ümumi / İstifadə / Boş həcm (GB/TB).
- Rəng kodu: yaşıl <70%, sarı 70–90%, qırmızı ≥90%. Əlçatmaz disk üçün xəta göstərilir.
- **Backend:** yeni endpoint `GET /api/srvexp/usage` — hər disk üçün total/used/free/
  percent `GetDiskFreeSpaceExW` ilə `\\IP\<L>$\` paylaşımından paralel oxunur
  (`srvexp_disks_usage()`). Ayrıca parol tələb etmir.
- **Frontend:** `web/modules/server.html` (panel + CSS), `backup-browser.js`
  (`srvRenderDiskCharts()` + "Yenilə" düyməsi).
- Asset versiyaları `?v=34 → ?v=35`.

## 13. ATM Smart Backup Manager — server bölməsində yeni modul (v10)
Server bölməsinə (Əməliyyatlar → "Backup Manager") tam işlək modul əlavə olundu:
serverdəki disklərdə saxlanmış ATM şəkil/jurnal fayllarını tarixə görə hədəf
qovluğa köçürür. Mənbə fayllar HEÇ VAXT dəyişdirilmir/silinmir.

**İş prinsipi:** disk/ATM aşkarla → tarix və ATM seç → Dry Run → backup.

**İmkanlar:**
- Disklərin və ATM ID-lərinin avtomatik aşkarlanması (regex konfiqurasiya edilir;
  lokal sabit disklər + UNC şəbəkə yolları). ATM nümunəsi: A0100010.
- Tarix: tək gün / aralıq / son 7 / son 30 gün. Tarix təyini üsulu: fayl adı,
  alt qovluq adı və ya son dəyişdirilmə tarixi (parametrdən seçilir).
- ATM rejimi: ALL / SELECTED (axtarış, multi-select, hamısını seç, TXT/CSV import).
- Fayl növü: yalnız şəkil / yalnız log / hər ikisi (uzantılar konfiqurasiya edilir).
- Dry Run (önizləmə): köçürmədən əvvəl ATM/fayl/həcm hesabatı.
- Köçürmə engine: paralel işçilər (worker), retry, inkremental (mövcud faylı ötür),
  toqquşma-təhlükəsiz adlandırma, ölçü/SHA-256 yoxlaması, pauza/davam/dayandır.
- Təhlükəsizlik: hədəf mənbə ilə üst-üstə düşə bilməz, boş disk yeri yoxlanır,
  simvolik link dövrləri atlanır, mənbə dəyişdirilmir.
- Canlı Monitor: ümumi progress, cari ATM/fayl, sürət (MB/s), köçürülən həcm,
  qalan fayl, təxmini vaxt (ETA), aktiv işçi sayı, canlı jurnal.
- Tarixçə: SQLite-də (`backup_jobs`) saxlanılır; tam hesabat cədvəli.
- Hədəf struktur: `<Hədəf>\<ATM_ID>\YYYY-MM-DD\Images|Logs\`.

**Texniki:**
- Backend (`server.py`): `bk2_*` funksiyaları + endpoint-lər
  `GET/POST /api/backup/{config,status,history,discover,plan,start,pause,resume,cancel}`.
- İcazə: `server` (oxu) / `server.backup` (köçürmə əməliyyatı) — `auth.js`-ə əlavə olundu.
- Frontend: `web/modules/backupmgr.html` + `web/assets/js/backup-manager.js`;
  `app.js`, `bootstrap.js`, `home.html` modul qeydiyyatı.
- Asset versiyaları `?v=35 → ?v=36`.
- Backend məntiqi nümunə qovluq ağacı ilə test olundu (aşkarlama, tarix filtri,
  köçürmə strukturu, mənbə qorunması, inkremental ötürmə) — hamısı keçdi.

## 14. Server disklər arası köçür / yerini dəyiş (v11)
Server bölməsinə (Əməliyyatlar → "Disklər arası köçür") yeni modul əlavə olundu:
77 serverinin (172.21.12.77) ÖZ diskləri arasında (D$/H$/M$/F$) fayl və qovluqları
kopyalayır və ya köçürür.

**İmkanlar:**
- İkipanelli brauzer: Mənbə (sol) + Hədəf (sağ); hər panel üçün disk seçici,
  qovluq naviqasiyası (breadcrumb + "Yuxarı"), fayl/qovluq ölçüləri.
- Soldan çoxlu seçim (fayl + qovluq, "Hamısını seç"), sağda hədəf qovluğa keçid.
- **Kopyala** (mənbə qorunur) və ya **Köçür** (kopya + mənbəni sil) — move üçün
  təsdiq tələb olunur.
- Toqquşma siyasəti: yeni ad ver / ötür / üzərinə yaz.
- Canlı gedişat: progress, cari element, sürət, ETA, element sayı, uğursuz, jurnal; dayandır.
- Təhlükəsizlik: mənbə==hədəf və hədəf seçilmiş qovluğun içindədirsə rədd edilir;
  boş disk yeri yoxlanır; traversal `explorer_path` ilə qorunur (disk sərhədindən çıxış yox);
  simvolik linklər atlanır.

**Texniki:**
- Backend (`server.py`): `srvmove_*` + endpoint-lər
  `GET /api/srvmove/{disks,list,progress}`, `POST /api/srvmove/{start,cancel}`.
- İcazə: `server` (gəz) / `server.move` (köçür/yerini dəyiş) — `auth.js`-ə əlavə olundu.
- Frontend: `web/modules/srvmove.html` + `web/assets/js/srvmove.js`; modul qeydiyyatı.
- Asset versiyaları `?v=36 → ?v=37`.
- Backend məntiqi test olundu: kopya (mənbə qorunur), köçür (mənbə silinir),
  mənbə==hədəf və içiçə hədəf rədd — hamısı keçdi.

## 15. Disklər arası köçürmə — SÜRƏTLİ engine (robocopy /MT) (v12)
"Çox sürətli" tələbi üçün srvmove engine yenidən quruldu:
- **robocopy /MT** (çoxnüvəli, default 16 axın; `ATM_SRVMOVE_MT` ilə dəyişilir) —
  böyük fayllarda və milyonlarla kiçik faylda qat-qat sürətli. Mövcud layihədə
  robocopy onsuz da istifadə olunur (əlavə asılılıq yox).
- **Avtomatik lokal/UNC** — Python engine elə 77 serverin özündə işləyirsə, UNC
  (`\\IP\L$`) əvəzinə **lokal disk yolları** (D:\→H:\) işlədilir (SMB loopback-dan
  sürətli). Aşkarlama avtomatikdir; `ATM_SRVEXP_LOCAL=1` / `ATM_SRVEXP_REMOTE=1` ilə
  məcbur etmək olar.
- **Təhlükəsiz fallback** — robocopy olmayan mühitdə və ya "yeni ad ver" toqquşma
  siyasətində təhlükəsiz Python köçürməsi işləyir.
- Toqquşma: skip (robocopy `/XC /XN /XO`), overwrite (default), rename (Python).
- Canlı progress robocopy çıxışından oxunur (fayl/bayt); element bitəndə plana snap.
- Mənbə yenə də heç vaxt silinmir (move = kopya bitəndən sonra mənbə silinir).
- Test: yeni engine kopya/köçür/skip — hamısı keçdi (Python yolu). robocopy yolu
  Windows serverdə işləyir.

## 16. Brend: SPARK loqosu (PNG) + BIR SPARK adı (v16)
- Proqramın adı: **BIR SPARK** (giriş, sidebar, boot ekranı, brauzer başlığı, server konsolu).
- Orijinal **SPARK loqosu** (`web/assets/img/spark-logo.png`, 1254×1254 PNG) inteqrasiya olundu:
  - **Giriş səhifəsi:** tam loqo, mərkəzdə, ağ plitədə (hər iki rejimdə təmiz).
  - **Dashboard sidebar:** loqo ağ plitədə (mark) + "BIR SPARK" mətni.
  - Təkrar-istifadəli CSS komponenti: `.sparkLogoPlate` / `.sparkLogoLogin` (components.css).
  - `object-fit: contain` — proporsiya pozulmur; ölçü responsive (mobil/planşet/desktop);
    CSP `img-src 'self'` loqoya icazə verir.
  - Birbank qırmızı palitrası saxlanıldı; loqo CSS ilə yenidən çəkilmədi, orijinal PNG işlədildi.
- Backend / API / funksiya dəyişmədi; yalnız brend varlıqları.
- Asset versiyaları `?v=37 → ?v=38`.

## 17. Yaradıcı giriş (hero) dizaynı (v17)
- Giriş səhifəsi iki hissəli "hero" dizaynına çevrildi: sol — SPARK brend paneli
  (üzən şəffaf loqo + qırmızı işıq/pulse + spark şüaları animasiyası + taqlayn +
  xüsusiyyət çipləri: Backup/Monitorinq/Disk/Təhlükəsizlik); sağ — giriş formu.
- Loqonun şəffaf variantı yaradıldı: `web/assets/img/spark-logo-glow.png` (kənar fon
  edge flood-fill ilə silindi, daxili ağ elementlər qorundu, avtokırpıldı) — tünd/rəngli
  səth üzərində "üzən" premium görünüş üçün.
- Sidebar loqo plitəsinə yüngül qırmızı glow əlavə olundu (brend hissi).
- Tam responsive: desktop iki sütun, planşet/mobil şaquli stack. `prefers-reduced-motion`
  dəstəklənir (animasiyalar sönür). Birbank qırmızı palitrası saxlanıldı.
- Form ID-ləri/funksiyası dəyişmədi; yalnız tərtibat + CSS animasiya.
- Asset versiyaları `?v=38 → ?v=39`.

## 18. Ana səhifə — canlı ATM siyahısı + 2-klik əməliyyat pəncərəsi (v18)
Backend DƏYİŞMƏDİ — hamısı mövcud endpoint-lərin yenidən istifadəsidir.
- **Ana səhifədə "Bütün ATM-lər" cədvəli:** ATM ID, Ad/Region, Əməliyyat sistemi,
  IP, CPU/RAM, online/offline/yoxlanmayıb statusu. Axtarış + status filtri.
- **Toplu qoşulma** birbaşa ana səhifədən başladılır (`bulk_start`/`bulk_progress`);
  canlı progress (cari ATM, qoşuldu/xəta sayı); bitəndən sonra cədvəl statusları yenilənir.
- **IP həll** düyməsi (`resolve-ips`) görünən ATM-lərin IP-lərini gətirir.
- **ATM-ə 2 dəfə klik → əməliyyat pəncərəsi (drawer):**
  - ATM info (status/OS/IP/region/RİM/CPU-RAM/PASSWORD slot/son qoşulma).
  - "Harada axtar?": **ATM-də axtar** (C$ / D$ / E$ disklərini gəz — hər ATM-in
    C$ diskinə giriş) və ya **Serverdə axtar** (server diskləri).
  - Sürətli əməliyyatlar: ATM Info, Sistem məlumatı, Disk hesabatı, Restart —
    müvafiq modulu ATM ID ilə açır.
- Fayllar: `web/modules/home.html` (cədvəl+drawer+CSS), `web/assets/js/home-atms.js`;
  `backup-browser.js`-də `createBrowser` qlobal edildi; `openHome()`-a inicializasiya.
- İcazələr mövcud sxemdən gəlir (bulk → inventory.bulk, ATM disk → archive.connect və s.).
- Asset versiyaları `?v=39 → ?v=40`.

## 19. İki mərhələli təsdiq (2FA / OTP) + admin idarəetməsi (v19)
- **Girişdə OTP məcburidir** (TOTP, RFC 6238 — Google/Microsoft Authenticator, tam offline).
  Şifrədən sonra 6 rəqəmli kod soruşulur; 6-cı rəqəm yazılan kimi avtomatik təsdiqlənir.
- **İlk girişdə qeydiyyat:** QR kod + əl ilə açar göstərilir, istifadəçi skan edib kodu yazır.
  Açar yalnız düzgün kod daxil edildikdən sonra bazaya yazılır (AES-256-GCM ilə şifrəli).
- Təhlükəsizlik: 5 dəq. etibarlı, tək istifadəlik, IP-yə bağlı mərhələ cookie-si (`atm_mfa`);
  eyni kod iki dəfə qəbul edilmir (replay); 5 yanlış kod → hesab 5 dəq. kilidlənir;
  2FA-dan əvvəl heç bir sessiya yaradılmır; köhnə (2FA-sız) sessiyalar etibarsızdır.
- **İstifadəçilər siyahısı:** yeni **2FA** sütunu (Aktiv / Qurulmayıb).
  Yalnız **administrator** üçün düymələr:
  - 📱 **2FA → Sıfırla** — açar silinir, sessiyalar bağlanır; istifadəçi növbəti girişdə özü yenidən qurur.
  - 📱 **2FA → Yenidən qur** — yeni açar yaradılır, QR bir dəfə adminə göstərilir.
  - 🔓 **Kilidi aç** — uğursuz cəhdlərə görə kilidlənmiş hesab.
  Server tərəfində də yoxlanır: admin olmayan (hətta `users.reset` icazəsi olan) 403 alır.
- **Break-glass:** `node tools\reset_2fa.js <istifadəçi>` (serverdə lokal) — admin telefonunu itirəndə.
  Fövqəladə halda 2FA-nı tam söndürmək: `set ATM_2FA=0` (tövsiyə edilmir).
- **Vacib:** `atm_auth.key` faylını `atm_auth.db` ilə birlikdə backup edin (açarsız 2FA sirləri oxunmur
  → hamı üçün 2FA sıfırlanmalı olar). Server saatı düzgün olmalıdır (±30–60 san).
- Fayllar: `auth.js`, `web/login.html`, `web/assets/js/auth-admin.js`, `web/modules/users.html`,
  `web/assets/css/auth.css`, `web/assets/ds/icons.js` (+smartphone/lock-open/copy),
  `web/assets/vendor/qrcode/qrcode.js` (MIT, offline), `tools/reset_2fa.js`.
- Asset versiyaları `?v=40 → ?v=41`.
