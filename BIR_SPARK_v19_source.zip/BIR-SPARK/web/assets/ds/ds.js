/* =====================================================================
   ATM WEB DESIGN SYSTEM — RUNTIME (DS)
   • DS.toast()        — vahid bildiriş sistemi (window.alert da bura yönləndirilir)
   • DS.AppTable       — SƏHİFƏDƏKİ HƏR <table> AVTOMATİK gücləndirilir:
                         sütun tipinə görə filtr, qlobal axtarış, sıralama, səhifələmə,
                         sütun görünüşü, aktiv filtr sayı, "Hamısını təmizlə", boş nəticə.
   Yeni cədvəl üçün heç nə yazmaq lazım deyil: <table><thead>…</thead><tbody>…</tbody></table>
   İstisna: <table data-ds-table="off">.  Sütunu filtrsiz etmək: <th data-filter="none">.
   Sütun tipini məcbur etmək: <th data-type="text|number|date|enum">.
   Mövcud öz filtr sırası olan cədvəllər (<tr class="filters">) toxunulmur — onların
   filtrləri DS toolbar-a qoşulur (aktiv say + təmizlə), məntiq eyni qalır.
   ===================================================================== */
(function(){
'use strict';
const DS = window.DS = window.DS || {};

/* ---------------- TOAST ---------------- */
let host=null;
function toastHost(){ if(!host||!document.body.contains(host)){ host=document.createElement('div'); host.className='ds-toast-host'; host.setAttribute('role','status'); host.setAttribute('aria-live','polite'); document.body.appendChild(host);} return host; }
const ICON={info:'ℹ',success:'✓',danger:'✕',warning:'!'};
DS.toast=function(message,type,timeout){
  type=type||'info';
  const el=document.createElement('div'); el.className='ds-toast ds-toast--'+type;
  el.innerHTML='<span class="ds-toast__icon" aria-hidden="true">'+(ICON[type]||'ℹ')+'</span><span class="ds-toast__msg"></span><button class="ds-toast__close" aria-label="Bağla">×</button>';
  el.querySelector('.ds-toast__msg').textContent=String(message==null?'':message);
  el.querySelector('.ds-toast__close').onclick=()=>el.remove();
  toastHost().appendChild(el);
  const t=timeout==null?(type==='danger'?9000:5000):timeout;
  if(t>0) setTimeout(()=>el.remove(),t);
  return el;
};
function guessType(msg){const s=String(msg||'').toLowerCase();if(/xəta|xeta|error|uğursuz|alınmadı|tapılmadı|olmadı|failed/.test(s))return'danger';if(/uğurlu|hazırdır|saxlanıldı|yadda|tamamlandı|ok\b/.test(s))return'success';if(/seç|daxil et|boş|ən azı|diqqət|xəbərdarlıq/.test(s))return'warning';return'info'}
/* alert() bloklayıcı pəncərə əvəzinə vahid toast */
window.__nativeAlert=window.alert;
window.alert=function(msg){DS.toast(msg,guessType(msg));};

/* ---------------- VALUE PARSING ---------------- */
const norm=s=>String(s==null?'':s).replace(/\s+/g,' ').trim();
const low=s=>norm(s).toLocaleLowerCase('az');
function parseNum(s){
  s=norm(s); if(!s||s==='—'||s==='-')return null;
  const m=s.replace(/\s/g,'').match(/^[^\d\-+]*([-+]?\d+(?:[.,]\d+)?)/); if(!m)return null;
  return parseFloat(m[1].replace(',','.'));
}
function parseDate(s){
  s=norm(s); if(!s)return null; let m;
  if((m=s.match(/(\d{4})[-./](\d{1,2})[-./](\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?/)))return +new Date(+m[1],m[2]-1,+m[3],+(m[4]||0),+(m[5]||0),+(m[6]||0));
  if((m=s.match(/(\d{1,2})[./](\d{1,2})[./](\d{4})(?:[ ,]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/)))return +new Date(+m[3],m[2]-1,+m[1],+(m[4]||0),+(m[5]||0),+(m[6]||0));
  if((m=s.match(/^(\d{4})(\d{2})(\d{2})$/)))return +new Date(+m[1],m[2]-1,+m[3]);
  return null;
}
function cellText(td){ if(!td)return''; const i=td.querySelector('input,select'); return norm(i?(i.value||''):td.textContent); }

/* Filtr ifadəsi:  mətn: "abc" (tərkibində), "^abc" (başlayır), "=abc" (tam)
   rəqəm/tarix: ">5", ">=5", "<5", "<=5", "=5", "5..10" (aralıq), "5" (bərabər / tarixdə həmin gün) */
function matchExpr(raw,val,kind){
  const q=norm(raw); if(!q)return true;
  if(kind==='number'||kind==='date'){
    const P=kind==='number'?parseNum:parseDate;
    const v=P(val); let m;
    if((m=q.match(/^(.+?)\s*\.\.\s*(.+)$/))){const a=P(m[1]),b=P(m[2]);if(v==null)return false;return(a==null||v>=a)&&(b==null||v<=(kind==='date'?b+86399999:b));}
    if((m=q.match(/^(>=|<=|>|<|=)\s*(.+)$/))){const b=P(m[2]);if(b==null)return true;if(v==null)return false;
      switch(m[1]){case'>':return v>(kind==='date'?b+86399999:b);case'>=':return v>=b;case'<':return v<b;case'<=':return v<=(kind==='date'?b+86399999:b);default:return kind==='date'?(v>=b&&v<=b+86399999):v===b;}}
    const b=P(q); if(b!=null){ if(v==null)return false; return kind==='date'?(v>=b&&v<=b+86399999):v===b; }
  }
  const L=low(val),Q=low(q);
  if(Q.startsWith('^'))return L.startsWith(Q.slice(1));
  if(Q.startsWith('='))return L===Q.slice(1);
  return L.includes(Q);
}

/* ---------------- APP TABLE ---------------- */
const PAGE_SIZES=[25,50,100,250,0];
class AppTable{
  constructor(table){
    this.table=table; table.__dsTable=this; table.classList.add('ds-table');
    this.thead=table.tHead; this.tbody=table.tBodies[0];
    this.headRow=this.thead.querySelector('tr.head')||this.thead.rows[0];
    this.headers=[...this.headRow.cells];
    this.native=!!this.thead.querySelector('tr.filters');
    this.sort={col:-1,dir:0}; this.page=0; this.pageSize=100; this.global=''; this.filters={}; this.hiddenCols=new Set(); this.lockedCols=table.__dsLocked||new Set(); this.types=[];
    this.box=table.parentElement; this.busy=false;
    this.buildToolbar(); this.buildFooter(); this.bindSort();
    if(!this.native) this.buildFilterRow(); else this.bindNativeFilters();
    this.observer=new MutationObserver(()=>{ if(!this.busy) this.schedule(true); });
    this.observer.observe(this.tbody,{childList:true});
    this.schedule(true);
  }
  dataRows(){ return [...this.tbody.rows].filter(r=>!r.classList.contains('ds-empty-row') && !(r.cells.length===1 && r.cells[0].colSpan>1)); }
  placeholderRows(){ return [...this.tbody.rows].filter(r=>!r.classList.contains('ds-empty-row') && r.cells.length===1 && r.cells[0].colSpan>1); }
  isActionCol(i){ const h=this.headers[i]; if(!h)return true; if(h.dataset.filter==='none')return true; const t=low(h.textContent); return !t || /əməliyyat|action/.test(t); }
  detectTypes(){
    const rows=this.dataRows().slice(0,300);
    this.types=this.headers.map((h,i)=>{
      if(h.dataset.type) return h.dataset.type;
      if(this.isActionCol(i)) return 'none';
      const vals=rows.map(r=>cellText(r.cells[i])).filter(v=>v&&v!=='—'&&v!=='-');
      if(!vals.length) return this.types[i]&&this.types[i]!=='none'?this.types[i]:'text';
      const dateN=vals.filter(v=>parseDate(v)!=null&&/\d{4}|\d{1,2}[./]\d{1,2}[./]\d{4}/.test(v)).length;
      if(dateN/vals.length>=.8) return 'date';
      const numN=vals.filter(v=>/^[#№~≈]?\s?[-+]?\d+(?:[.,]\d+)?\s*(%|MB|GB|KB|TB|B|san|saniyə|gün|s)?$/i.test(v)).length;
      if(numN/vals.length>=.8) return 'number';
      const uniq=new Set(vals.map(low));
      if(uniq.size<=12 && vals.length>=uniq.size*2) return 'enum';
      return 'text';
    });
  }
  /* toolbar */
  buildToolbar(){
    let bar=this.box.previousElementSibling;
    if(this.native && bar && bar.classList.contains('controls')){ bar.classList.add('ds-table-toolbar'); }
    else { bar=document.createElement('div'); bar.className='ds-table-toolbar'; this.box.parentElement.insertBefore(bar,this.box); }
    this.bar=bar;
    const search=document.createElement('input'); search.type='search'; search.className='ds-table-search'; search.placeholder='Cədvəldə axtar...'; search.setAttribute('aria-label','Cədvəldə axtar');
    search.addEventListener('input',()=>{ this.global=search.value; this.page=0; this.schedule(); });
    this.searchEl=search;
    const count=document.createElement('span'); count.className='ds-filter-count'; count.textContent='Filtr: 0'; this.countEl=count;
    const clear=document.createElement('button'); clear.type='button'; clear.className='ds-btn ds-btn--secondary ds-btn--sm'; clear.textContent='✕ Hamısını təmizlə'; clear.onclick=()=>this.clearAll(); this.clearBtn=clear;
    const colWrap=document.createElement('div'); colWrap.className='ds-colmenu';
    const colBtn=document.createElement('button'); colBtn.type='button'; colBtn.className='ds-btn ds-btn--secondary ds-btn--sm'; colBtn.textContent='▦ Sütunlar'; colBtn.setAttribute('aria-haspopup','true');
    const panel=document.createElement('div'); panel.className='ds-colmenu__panel hidden';
    colBtn.onclick=e=>{e.stopPropagation(); this.renderColMenu(panel); panel.classList.toggle('hidden');};
    document.addEventListener('click',e=>{ if(!colWrap.contains(e.target)) panel.classList.add('hidden'); });
    colWrap.append(colBtn,panel);
    if(this.native){
      // köhnə "Filterləri təmizlə" düyməsi DS təmizləmə ilə əvəz olunur (eyni funksiyanı çağırır)
      const legacy=[...bar.querySelectorAll('button')].find(b=>/clearFilters/.test(b.getAttribute('onclick')||''));
      if(legacy){ this.legacyClear=legacy; legacy.classList.add('hidden'); }
      const title=bar.querySelector('b'); if(title) title.classList.add('ds-title');
      const ref=bar.querySelector('.count');
      bar.insertBefore(search,ref); bar.insertBefore(count,ref); bar.insertBefore(clear,ref); bar.insertBefore(colWrap,ref);
    } else {
      const info=document.createElement('span'); info.className='ds-table-info'; this.infoEl=info;
      bar.append(search,count,clear,colWrap,info);
      if(this.table.dataset.dsSearch==='off'){ search.remove(); /* modulun öz server-axtarışı var */ }
    }
  }
  renderColMenu(panel){
    panel.innerHTML='';
    this.headers.forEach((h,i)=>{ if(this.lockedCols.has(i)) return; /* icazəsi olmayan sütun menyuda görünmür */ const name=norm(h.textContent)||('Sütun '+(i+1));
      const l=document.createElement('label'); const c=document.createElement('input'); c.type='checkbox'; c.checked=!this.hiddenCols.has(i);
      c.onchange=()=>{ c.checked?this.hiddenCols.delete(i):this.hiddenCols.add(i); this.applyColumns(); };
      l.append(c,document.createTextNode(name)); panel.appendChild(l); });
  }
  applyColumns(){
    const set=(cell,i)=>cell&&cell.classList.toggle('ds-col-hidden',this.hiddenCols.has(i)||this.lockedCols.has(i));
    [...this.thead.rows].forEach(r=>[...r.cells].forEach((c,i)=>set(c,i)));
    [...this.tbody.rows].forEach(r=>{ if(r.cells.length>1)[...r.cells].forEach((c,i)=>set(c,i)); });
  }
  buildFooter(){
    const f=document.createElement('div'); f.className='ds-table-footer';
    f.innerHTML='<span class="ds-page-info"></span><div class="ds-pager"><label class="ds-caption">Sətir:</label><select aria-label="Səhifədə sətir sayı"></select><button type="button" class="ds-btn ds-btn--secondary ds-btn--sm" data-p="prev" aria-label="Əvvəlki səhifə">‹</button><span class="ds-page-num"></span><button type="button" class="ds-btn ds-btn--secondary ds-btn--sm" data-p="next" aria-label="Növbəti səhifə">›</button></div>';
    const sel=f.querySelector('select');
    PAGE_SIZES.forEach(n=>{const o=document.createElement('option');o.value=n;o.textContent=n?n:'Hamısı';if(n===this.pageSize)o.selected=true;sel.appendChild(o)});
    sel.onchange=()=>{this.pageSize=+sel.value;this.page=0;this.schedule();};
    f.querySelector('[data-p=prev]').onclick=()=>{if(this.page>0){this.page--;this.schedule();}};
    f.querySelector('[data-p=next]').onclick=()=>{this.page++;this.schedule();};
    this.box.parentElement.insertBefore(f,this.box.nextSibling); this.footer=f;
  }
  bindSort(){
    this.headers.forEach((h,i)=>{ if(this.isActionCol(i)&&!norm(h.textContent))return;
      h.classList.add('ds-sortable'); h.tabIndex=0; h.setAttribute('aria-sort','none');
      const go=()=>{ if(this.sort.col===i){this.sort.dir=this.sort.dir===1?-1:this.sort.dir===-1?0:1;} else {this.sort={col:i,dir:1};}
        this.headers.forEach(x=>{x.classList.remove('ds-sort-asc','ds-sort-desc');x.setAttribute('aria-sort','none');});
        if(this.sort.dir){h.classList.add(this.sort.dir===1?'ds-sort-asc':'ds-sort-desc');h.setAttribute('aria-sort',this.sort.dir===1?'ascending':'descending');}
        this.schedule(); };
      h.addEventListener('click',e=>{ if(e.target.closest('input,select,button'))return; go(); });
      h.addEventListener('keydown',e=>{ if(e.key==='Enter'||e.key===' '){e.preventDefault();go();} });
    });
  }
  /* auto filter row */
  buildFilterRow(){
    this.detectTypes();
    const tr=document.createElement('tr'); tr.className='ds-filter-row'; this.filterRow=tr;
    this.headers.forEach((h,i)=>{ const th=document.createElement('th'); th.dataset.col=i; tr.appendChild(th); });
    this.thead.appendChild(tr); this.renderFilterControls();
  }
  renderFilterControls(){
    if(!this.filterRow)return;
    [...this.filterRow.cells].forEach((th,i)=>{
      const type=this.types[i]; const cur=this.filters[i]||'';
      if(th.dataset.type===type && th.firstChild && type!=='enum') return;
      th.dataset.type=type; th.innerHTML='';
      if(type==='none') return;
      let el;
      if(type==='enum'){
        el=document.createElement('select');
        const vals=[...new Set(this.dataRows().map(r=>cellText(r.cells[i])).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'az'));
        el.innerHTML='<option value="">Hamısı</option>'; vals.forEach(v=>{const o=document.createElement('option');o.value='='+v;o.textContent=v;el.appendChild(o)});
        el.value=cur; if(el.value!==cur){ el.value=''; if(cur) delete this.filters[i]; }
        el.addEventListener('change',()=>this.setFilter(i,el.value,el));
      } else {
        el=document.createElement('input'); el.type='text'; el.value=cur;
        el.placeholder=type==='number'?'>5, <=10, 5..20':type==='date'?'>2026-09-01 / a..b':'Axtar... (^ başlayır, = tam)';
        el.title=type==='number'?'Rəqəm filtri: =5, >5, >=5, <5, <=5, 5..20':type==='date'?'Tarix filtri: 2026-09-30 (həmin gün), >2026-09-01, <2026-09-30, 2026-09-01..2026-09-30':'Mətn filtri: "abc" tərkibində, "^abc" başlayır, "=abc" tam uyğun';
        let t; el.addEventListener('input',()=>{clearTimeout(t);t=setTimeout(()=>this.setFilter(i,el.value,el),140);});
      }
      el.setAttribute('aria-label',norm(this.headers[i].textContent)+' filtri');
      el.classList.toggle('is-active',!!cur);
      th.appendChild(el);
    });
  }
  setFilter(i,v,el){ if(v)this.filters[i]=v; else delete this.filters[i]; if(el)el.classList.toggle('is-active',!!v); this.page=0; this.schedule(); }
  bindNativeFilters(){
    this.nativeInputs=[...this.thead.querySelectorAll('tr.filters input,tr.filters select')];
    this.nativeInputs.forEach(el=>{ el.addEventListener('input',()=>{this.page=0;this.updateCount();}); el.addEventListener('change',()=>{this.page=0;this.updateCount();}); });
  }
  activeCount(){
    let n=Object.keys(this.filters).length+(norm(this.global)?1:0);
    if(this.nativeInputs) n+=this.nativeInputs.filter(e=>norm(e.value)).length;
    return n;
  }
  updateCount(){
    const n=this.activeCount();
    this.countEl.textContent='Filtr: '+n; this.countEl.classList.toggle('is-active',n>0);
    this.clearBtn.disabled=n===0;
    if(this.nativeInputs) this.nativeInputs.forEach(e=>e.classList.toggle('is-active',!!norm(e.value)));
  }
  clearAll(){
    this.filters={}; this.global=''; this.searchEl.value=''; this.page=0;
    if(this.filterRow) this.filterRow.querySelectorAll('input,select').forEach(e=>{e.value='';e.classList.remove('is-active');});
    if(this.native){ if(this.legacyClear) this.legacyClear.click(); else this.nativeInputs.forEach(e=>{e.value='';e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));}); }
    this.schedule();
  }
  schedule(structural){
    if(structural) this.structural=true;
    if(this.raf) return;
    this.raf=requestAnimationFrame(()=>{ this.raf=null; this.apply(); });
  }
  apply(){
    this.busy=true;
    try{
      if(this.structural){ this.structural=false; if(!this.native){ this.detectTypes(); this.renderFilterControls(); } }
      const rows=this.dataRows(), g=low(this.global);
      const fkeys=Object.keys(this.filters);
      let visible=rows.filter(r=>{
        if(g && !low(r.textContent).includes(g)) return false;
        for(const k of fkeys){ if(!matchExpr(this.filters[k],cellText(r.cells[k]),this.types[k])) return false; }
        return true;
      });
      if(this.sort.dir){
        const i=this.sort.col, t=this.types[i]||'text', d=this.sort.dir;
        const key=r=>{const s=cellText(r.cells[i]); if(t==='number')return parseNum(s); if(t==='date')return parseDate(s); return low(s);};
        visible=visible.map((r,idx)=>({r,k:key(r),idx})).sort((a,b)=>{
          if(a.k==null&&b.k==null)return a.idx-b.idx; if(a.k==null)return 1; if(b.k==null)return -1;
          const c=typeof a.k==='string'?a.k.localeCompare(b.k,'az',{numeric:true}):a.k-b.k; return c*d||a.idx-b.idx; }).map(x=>x.r);
        const frag=document.createDocumentFragment(); visible.forEach(r=>frag.appendChild(r));
        rows.filter(r=>!visible.includes(r)).forEach(r=>frag.appendChild(r));
        this.tbody.appendChild(frag);
      }
      const total=visible.length, ps=this.pageSize||total||1, pages=Math.max(1,Math.ceil(total/ps));
      if(this.page>=pages)this.page=pages-1;
      const start=this.pageSize?this.page*ps:0, end=this.pageSize?start+ps:total;
      const show=new Set(visible.slice(start,end));
      rows.forEach(r=>r.classList.toggle('ds-row-hidden',!show.has(r)));
      // boş nəticə
      let empty=this.tbody.querySelector('tr.ds-empty-row');
      const hasPlaceholder=this.placeholderRows().length>0;
      if(rows.length && !total){
        if(!empty){ empty=document.createElement('tr'); empty.className='ds-empty-row'; const td=document.createElement('td'); td.colSpan=this.headers.length; empty.appendChild(td); }
        empty.cells[0].innerHTML='<span class="ds-empty__icon" aria-hidden="true">⌕</span>Filtrə uyğun nəticə tapılmadı. <button type="button" class="ds-btn ds-btn--tertiary ds-btn--sm">Filtrləri təmizlə</button>';
        empty.cells[0].querySelector('button').onclick=()=>this.clearAll();
        this.tbody.appendChild(empty);
      } else if(empty) empty.remove();
      const all=rows.length;
      const info=all?`${total?start+1:0}–${Math.min(end,total)} / ${total}${total!==all?' (cəmi '+all+')':''}`:(hasPlaceholder?'—':'0 sətir');
      this.footer.querySelector('.ds-page-info').textContent=info;
      if(this.infoEl) this.infoEl.textContent=all?`${total} / ${all} sətir`:'';
      this.footer.querySelector('.ds-page-num').textContent=`${this.page+1} / ${pages}`;
      this.footer.querySelector('[data-p=prev]').disabled=this.page<=0;
      this.footer.querySelector('[data-p=next]').disabled=this.page>=pages-1;
      this.footer.classList.toggle('hidden',all===0);
      this.applyColumns(); this.updateCount();
    } finally { this.observer.takeRecords(); this.busy=false; }
  }
}

/* ---------------- ICONIZE: düymələrdəki köhnə simvolları vahid SVG ikonlara çevirir ----------------
   Statik və JS-in sonradan yaratdığı düymələr üçün eyni işləyir. Yeni kodda birbaşa DS.icon() istifadə et. */
const GLYPHS={'⟳':t=>/restart/i.test(t)?'power':'refresh-cw','↻':()=>'scan-line','↺':()=>'rotate-ccw','▶':()=>'play','■':()=>'square','⚡':()=>'plug-zap',
 '＋':()=>'plus','✎':()=>'pencil','⌫':()=>'trash-2','⌁':()=>'plug-zap','⇩':()=>'download','⌖':()=>'locate-fixed','↗':()=>'arrow-up-right',
 '◈':()=>'monitor-cog','✓':()=>'circle-check','✕':()=>'x','◷':()=>'history','▣':()=>'folder-open','←':()=>'chevron-left',
 '▥':t=>/disk/i.test(t)?'hard-drive':'monitor-cog','▤':t=>/video|arxiv|archive/i.test(t)?'film':'file-text'};
function iconizeEl(el){
  if(el.__dsIconized||!window.DS.icon) return;
  const tn=[...el.childNodes].find(n=>n.nodeType===3&&n.nodeValue.trim()); if(!tn) return;
  const txt=tn.nodeValue.replace(/^\s+/,''); const g=[...txt][0]; const fn=GLYPHS[g]; if(!fn) return;
  const rest=txt.slice(g.length).replace(/^\s+/,'');
  if(tn!==[...el.childNodes].find(n=>n.nodeType===3?n.nodeValue.trim():n.nodeType===1)) return; // glyph ilk məzmun olmalıdır
  const span=document.createElement('span'); span.innerHTML=DS.icon(fn(el.textContent)); const svg=span.firstChild;
  el.insertBefore(svg,tn); tn.nodeValue=rest; el.__dsIconized=true;
}
DS.iconize=function(root){ (root||document).querySelectorAll('button,.menuBtn').forEach(iconizeEl); };

DS.AppTable=AppTable;
/* İcazə sistemi: sütunları istifadəçi üçün kilidli-gizli edir (Sütunlar menyusundan geri açmaq olmur) */
DS.lockColumns=function(table,set){ table.__dsLocked=set; if(table.__dsTable){ table.__dsTable.lockedCols=set; table.__dsTable.applyColumns(); } };
DS.enhanceTables=function(root){
  (root||document).querySelectorAll('table').forEach(t=>{
    if(t.__dsTable||t.dataset.dsTable==='off'||!t.tHead||!t.tBodies[0]||!t.parentElement) return;
    if(t.closest('.leaflet-container')) return;
    try{ new AppTable(t); }catch(e){ console.error('[DS] AppTable', e); }
  });
};
function boot(){
  DS.enhanceTables(); DS.iconize();
  let pend=false;
  new MutationObserver(muts=>{
    let tbl=false, btn=false;
    for(const m of muts){
      if(m.type==='characterData'){ const p=m.target.parentElement; if(p&&p.closest('button')){ const b=p.closest('button'); b.__dsIconized=false; btn=true; } continue; }
      for(const n of m.addedNodes){
        if(n.nodeType===3){ const b=n.parentElement&&n.parentElement.closest('button'); if(b){ b.__dsIconized=false; btn=true; } continue; }
        if(n.nodeType!==1) continue;
        if(n.tagName==='TABLE'||n.querySelector('table')) tbl=true;
        if(n.tagName==='BUTTON'||n.querySelector('button')) btn=true;
      }
    }
    if(tbl) DS.enhanceTables();
    if(btn&&!pend){ pend=true; requestAnimationFrame(()=>{ pend=false; DS.iconize(); }); }
  }).observe(document.body,{childList:true,subtree:true,characterData:true});
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true}); else boot();
})();
