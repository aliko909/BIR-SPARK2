/* Server disklər arası köçür / yerini dəyiş — frontend.
   77 serverinin öz diskləri arasında (srvdisk:) fayl/qovluq kopyala və ya köçür.
   Backend: /api/srvmove/{disks,list,start,progress,cancel}. */
(function () {
'use strict';
const $ = id => document.getElementById(id);
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const toast = (m, t) => { if (window.DS && DS.toast) DS.toast(m, t || 'info'); };

let inited = false, pollTimer = null;
const SRC = { disk: '', rel: '' }, DST = { disk: '', rel: '' };
let selected = new Set();

async function jget(url) {
  const r = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), { cache: 'no-store' });
  let d = {}; try { d = await r.json(); } catch (e) {}
  return d;
}
async function jpost(url, body) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}), cache: 'no-store' });
  let d = {}; try { d = await r.json(); } catch (e) {}
  return d;
}
function fmtSize(b) {
  if (b == null || isNaN(b)) return '—'; b = Number(b);
  const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0;
  while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
  return (i < 2 ? Math.round(b) : b.toFixed(2)) + ' ' + u[i];
}
function fmtEta(s) {
  if (s == null || !isFinite(s)) return '—'; s = Math.round(s);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
  return (h ? h + 's ' : '') + (h || m ? m + 'd ' : '') + (s % 60) + 'san';
}
const icon = n => '<svg class="ds-icon" aria-hidden="true"><use href="#i-' + n + '"/></svg>';

/* ---------- disks ---------- */
async function loadDisks() {
  const d = await jget('/api/srvmove/disks');
  if (!d.success) { toast(d.error || 'Disklər alınmadı', 'danger'); return; }
  if (d.server) $('smServerIp').textContent = d.server;
  const letters = (d.disks || []).map(x => x.letter);
  const opts = letters.map(L => '<option value="' + esc(L) + '">' + esc(L) + '$</option>').join('');
  $('smSrcDisk').innerHTML = opts; $('smDstDisk').innerHTML = opts;
  SRC.disk = letters[0] || 'D'; SRC.rel = '';
  DST.disk = letters[1] || letters[0] || 'D'; DST.rel = '';
  $('smSrcDisk').value = SRC.disk; $('smDstDisk').value = DST.disk;
  browse('src'); browse('dst');
}

/* ---------- browse ---------- */
function crumb(pane) {
  const S = pane === 'src' ? SRC : DST;
  const parts = S.rel ? S.rel.split('\\').filter(Boolean) : [];
  let acc = '';
  const links = ['<a data-rel="">' + esc(S.disk) + '$</a>'];
  parts.forEach(p => { acc = acc ? acc + '\\' + p : p; links.push('<span>\\</span><a data-rel="' + esc(acc) + '">' + esc(p) + '</a>'); });
  const host = $(pane === 'src' ? 'smSrcCrumb' : 'smDstCrumb');
  host.innerHTML = links.join('');
  host.querySelectorAll('a').forEach(a => a.onclick = () => { S.rel = a.dataset.rel; if (pane === 'src') selected.clear(); browse(pane); });
}
async function browse(pane) {
  const S = pane === 'src' ? SRC : DST;
  const listEl = $(pane === 'src' ? 'smSrcList' : 'smDstList');
  listEl.innerHTML = '<div class="ds-caption" style="padding:10px"><span class="ds-spinner"></span> Yüklənir...</div>';
  crumb(pane);
  if (pane === 'dst') $('smDstHere').textContent = DST.disk + '$\\' + (DST.rel || '');
  const d = await jget('/api/srvmove/list?disk=' + encodeURIComponent(S.disk) + '&rel=' + encodeURIComponent(S.rel));
  if (!d.success) { listEl.innerHTML = '<div class="ds-alert ds-alert--danger" style="margin:10px">' + esc(d.error || 'Alınmadı') + '</div>'; return; }
  const ents = d.entries || [];
  if (!ents.length) { listEl.innerHTML = '<div class="ds-caption" style="padding:12px">Qovluq boşdur.</div>'; if (pane === 'src') updateSrcCount(); return; }
  listEl.innerHTML = ents.map(e => {
    const ic = e.kind === 'folder' ? 'folder' : 'file-text';
    const meta = e.kind === 'folder' ? 'qovluq' : (e.size_display || '');
    const chk = pane === 'src' ? '<input type="checkbox" data-name="' + esc(e.name) + '"' + (selected.has(e.name) ? ' checked' : '') + '>' : '';
    return '<div class="smItem ' + e.kind + '" data-name="' + esc(e.name) + '" data-kind="' + e.kind + '">'
      + chk + '<span class="smIco">' + icon(ic) + '</span>'
      + '<span class="smName" data-nav="' + (e.kind === 'folder' ? '1' : '') + '">' + esc(e.name) + '</span>'
      + '<span class="smMeta">' + esc(meta) + '</span></div>';
  }).join('');
  // navigation (folder name click)
  listEl.querySelectorAll('.smItem.folder .smName').forEach(nm => nm.onclick = () => {
    const name = nm.closest('.smItem').dataset.name;
    S.rel = S.rel ? S.rel + '\\' + name : name;
    if (pane === 'src') selected.clear();
    browse(pane);
  });
  if (pane === 'src') {
    listEl.querySelectorAll('input[data-name]').forEach(cb => cb.onchange = () => {
      cb.checked ? selected.add(cb.dataset.name) : selected.delete(cb.dataset.name);
      updateSrcCount();
    });
    $('smSrcAll').checked = false;
    updateSrcCount();
  }
}
function updateSrcCount() { $('smSrcCount').textContent = 'Seçilmiş: ' + selected.size; }

/* ---------- start / control ---------- */
async function start() {
  if (!selected.size) { toast('Soldan ən azı bir element seçin.', 'warning'); return; }
  const op = (document.querySelector('input[name="smOp"]:checked') || {}).value || 'copy';
  const conflict = $('smConflict').value;
  if (SRC.disk === DST.disk && (SRC.rel || '') === (DST.rel || '')) { toast('Mənbə və hədəf eyni qovluqdur.', 'warning'); return; }
  const verb = op === 'move' ? 'KÖÇÜRÜLSÜN (mənbədən silinəcək)' : 'kopyalansın';
  if (!confirm(selected.size + ' element ' + verb + '?\n\nMənbə: ' + SRC.disk + '$\\' + (SRC.rel || '')
    + '\nHədəf: ' + DST.disk + '$\\' + (DST.rel || ''))) return;
  $('smStart').disabled = true; $('smMsg').textContent = 'Başladılır...';
  const d = await jpost('/api/srvmove/start', {
    src_disk: SRC.disk, src_rel: SRC.rel, dst_disk: DST.disk, dst_rel: DST.rel,
    items: [...selected], op, conflict,
  });
  $('smStart').disabled = false; $('smMsg').textContent = '';
  if (!d.success) { toast(d.error || 'Başlamadı', 'danger'); return; }
  toast((op === 'move' ? 'Köçürmə' : 'Kopya') + ' başladı: ' + (d.info ? d.info.files_total + ' fayl' : ''), 'success');
  $('smProgPanel').classList.remove('hidden');
  $('smProgPanel').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  startPoll();
}
async function cancel() { if (confirm('Dayandırılsın?')) { const d = await jpost('/api/srvmove/cancel', {}); if (!d.success) toast(d.error || '', 'warning'); } }

function startPoll() { if (pollTimer) return; poll(); pollTimer = setInterval(poll, 1000); }
function stopPoll() { if (pollTimer) { clearInterval(pollTimer); pollTimer = null; } }
async function poll() {
  const d = await jget('/api/srvmove/progress');
  if (!d.success) return;
  const s = d.state;
  const pct = s.bytes_total ? Math.min(100, Math.round(s.bytes_done * 100 / s.bytes_total))
            : (s.files_total ? Math.round(s.files_done * 100 / s.files_total) : 0);
  $('smProgBar').style.width = pct + '%'; $('smProgPct').textContent = pct + '%';
  $('smPhase').textContent = s.running ? ((s.op === 'move' ? 'Köçürülür' : 'Kopyalanır')) : (s.status || '—');
  $('smCur').textContent = s.current || '—';
  $('smSpeed').textContent = s.speed_bps ? fmtSize(s.speed_bps) + '/s' : '—';
  $('smDone').textContent = (s.files_done || 0) + ' / ' + (s.files_total || 0) + '  (' + fmtSize(s.bytes_done) + ')';
  $('smEta').textContent = fmtEta(s.eta_sec);
  $('smItems').textContent = (s.items_done || 0) + ' / ' + (s.items_total || 0);
  $('smFailed').textContent = s.failed_items || 0;
  $('smLog').textContent = (s.logs || []).join('\n'); $('smLog').scrollTop = $('smLog').scrollHeight;
  $('smCancel').disabled = !s.running;
  if (!s.running && s.finished) {
    stopPoll();
    toast('Əməliyyat bitdi: ' + (s.status || ''), s.failed_items ? 'warning' : 'success');
    browse('src'); browse('dst'); // move sonrası mənbə dəyişib
  }
}

/* ---------- init ---------- */
window.srvMoveInit = function () {
  if (!inited) {
    inited = true;
    $('smSrcDisk').onchange = () => { SRC.disk = $('smSrcDisk').value; SRC.rel = ''; selected.clear(); browse('src'); };
    $('smDstDisk').onchange = () => { DST.disk = $('smDstDisk').value; DST.rel = ''; browse('dst'); };
    $('smSrcRefresh').onclick = () => browse('src');
    $('smDstRefresh').onclick = () => browse('dst');
    $('smSrcUp').onclick = () => { if (SRC.rel) { SRC.rel = SRC.rel.split('\\').slice(0, -1).join('\\'); selected.clear(); browse('src'); } };
    $('smDstUp').onclick = () => { if (DST.rel) { DST.rel = DST.rel.split('\\').slice(0, -1).join('\\'); browse('dst'); } };
    $('smSrcAll').onchange = e => {
      const boxes = $('smSrcList').querySelectorAll('input[data-name]');
      boxes.forEach(cb => { cb.checked = e.target.checked; cb.checked ? selected.add(cb.dataset.name) : selected.delete(cb.dataset.name); });
      updateSrcCount();
    };
    $('smStart').onclick = start;
    $('smCancel').onclick = cancel;
  }
  loadDisks().catch(() => {});
  jget('/api/srvmove/progress').then(d => { if (d.success && d.state && d.state.running) { $('smProgPanel').classList.remove('hidden'); startPoll(); } }).catch(() => {});
};
})();
