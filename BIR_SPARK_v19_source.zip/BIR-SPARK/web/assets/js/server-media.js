/* Cihaz İdarəetmə Sistemi — Video / Şəkil Server.
   Backup serverindəki (DB: config_ips / config_disks / config_folders) ATM qovluqlarını yoxlayır:
     \\<IP>\<disk>$\<FOLDER>\<ATM_ID>\YYYYMMDD\fayllar
   ATM-ə qoşulma lazım deyil. Yalnız baxış / yükləmə. */
(function () {
'use strict';
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const IMG_EXT = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'];
const VID_EXT = ['.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm', '.mpeg', '.mpg', '.m4v', '.3gp', '.ts', '.mts', '.m2ts'];
const TEXT_EXT = ['.txt', '.jrn', '.log', '.csv'];
const NATIVE_VID = ['.mp4', '.m4v', '.webm', '.ogg', '.ogv'];
const GRID_PAGE = 120;
const ic = (name, cls) => `<svg class="ds-icon${cls ? ' ' + cls : ''}" aria-hidden="true"><use href="#i-${name}"/></svg>`;
const kindOf = ext => { ext = (ext || '').toLowerCase(); return IMG_EXT.includes(ext) ? 'img' : VID_EXT.includes(ext) ? 'vid' : TEXT_EXT.includes(ext) ? 'text' : 'other'; };
const toast = (m, t) => { if (window.DS && DS.toast) DS.toast(m, t || 'info'); };
const qs = o => Object.keys(o).map(k => encodeURIComponent(k) + '=' + encodeURIComponent(o[k])).join('&');
async function getJson(url) {
  const r = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), { cache: 'no-store' });
  let d = null; try { d = await r.json(); } catch (e) { /* */ }
  if (!r.ok || !d || d.success === false) throw new Error((d && d.error) || ('HTTP ' + r.status));
  return d;
}

const S = {
  inited: false, sources: [], atm: '', date: '', result: null,
  src: '', label: '', base: '', rel: '', entries: [], view: 'list', gridLimit: GRID_PAGE,
  files: [], current: -1, statsToken: 0, statsCache: {}
};
const $ = id => document.getElementById(id);
const rootKey = () => 'srv:' + S.src + ':' + S.atm;
const mediaUrl = rel => '/api/srvmedia/media?' + qs({ root: rootKey(), rel });
const transUrl = rel => '/api/srvmedia/transcode?' + qs({ root: rootKey(), rel, t: Date.now() });

/* ---------------- Mənbələr ---------------- */
async function loadSources() {
  const box = $('vsvSources');
  try {
    const d = await getJson('/api/srvmedia/sources');
    S.sources = d.sources || [];
    box.innerHTML = S.sources.length
      ? '<span>Yoxlanılacaq server qovluqları:</span> ' + S.sources.map(s => `<span class="vsvSrcTag">${ic('hard-drive')}<b>${esc(s.label)}</b><code>${esc(s.path)}</code></span>`).join('')
      : '<span class="vsvWarn">DB-də media mənbəyi (IP / disk / folder) yoxdur — Backup Monitor ayarlarından əlavə et.</span>';
  } catch (e) { box.innerHTML = '<span class="vsvWarn">Mənbələr alınmadı: ' + esc(e.message) + '</span>'; }
}

/* ---------------- Yoxlama ---------------- */
async function check(atmOverride) {
  const atmEl = $('vsvAtm'), btn = $('vsvCheckBtn');
  if (atmOverride) atmEl.value = atmOverride;
  const atm = (atmEl.value || '').trim().toUpperCase();
  atmEl.value = atm;
  if (!/^[A-Z0-9._-]{1,64}$/.test(atm)) { toast('ATM nömrəsini düzgün yaz.', 'warning'); atmEl.focus(); return; }
  S.atm = atm; S.date = $('vsvDate').value || '';
  btn.disabled = true; btn.querySelector('span').textContent = 'Yoxlanılır...';
  $('vsvBrowser').style.display = 'none';
  $('vsvResults').innerHTML = `<div class="panel vsvLoading"><span class="ds-spinner"></span> ${esc(atm)} — serverdə axtarılır...</div>`;
  try {
    const d = await getJson('/api/srvmedia/check?' + qs({ atm, date: S.date }));
    S.result = d;
    renderResults(d);
    // ATM yalnız bir mənbədə tapılıbsa, onu avtomatik aç
    const found = d.sources.filter(s => s.atm_exists);
    if (found.length === 1) openSource(found[0].src);
  } catch (e) {
    $('vsvResults').innerHTML = `<div class="panel"><div class="ds-alert ds-alert--danger">Xəta: ${esc(e.message)}</div></div>`;
  } finally {
    btn.disabled = false; btn.querySelector('span').textContent = 'Yoxla';
  }
}

function statLine(st) {
  if (!st) return '';
  return `<div class="vsvStatRow">
    <span class="vsvPill vsvPill--img">${ic('eye')}${st.images} şəkil</span>
    <span class="vsvPill vsvPill--vid">${ic('film')}${st.videos} video</span>
    ${st.txt ? `<span class="vsvPill">${ic('file-text')}${st.txt} txt</span>` : ''}
    ${st.other ? `<span class="vsvPill">${st.other} digər</span>` : ''}
    <span class="vsvPill">${esc(st.size_display)}</span>
    ${st.last_time ? `<span class="vsvPill">${ic('clock')}son fayl ${esc(st.last_display)}</span>` : ''}
    ${st.truncated ? '<span class="vsvPill">ilk 50 000 fayl sayıldı</span>' : ''}
  </div>`;
}

function renderResults(d) {
  const any = d.any_found;
  const head = `<div class="vsvSummary ${any ? 'is-ok' : 'is-bad'}">
      ${ic(any ? 'circle-check' : 'circle-x', 'ds-icon--lg')}
      <div><b>${esc(d.atm)}</b> — ${any ? 'serverdə tapıldı: ' + d.found_in.map(esc).join(', ') : 'heç bir server qovluğunda tapılmadı'}
      <div class="ds-caption">${d.sources.length} mənbə yoxlanıldı · ${d.duration} san${d.date ? ' · seçilən tarix: ' + esc(d.date.split('-').reverse().join('.')) : ''}</div></div>
    </div>`;
  const cards = d.sources.map(s => {
    let badge, body = '';
    if (s.error && !s.root_ok) {
      badge = '<span class="ds-badge ds-badge--warning">XƏTA</span>';
      body = `<div class="vsvMsg vsvWarn">${esc(s.error)}</div>`;
    } else if (!s.atm_exists) {
      badge = '<span class="ds-badge ds-badge--danger">QOVLUQ YOXDUR</span>';
      body = `<div class="vsvMsg">Bu mənbədə <b>${esc(d.atm)}</b> adlı qovluq yoxdur.</div>`
        + (s.similar.length ? `<div class="vsvSimilar"><span class="ds-caption">Oxşar qovluqlar:</span> ${s.similar.map(n => `<button type="button" class="vsvChip" data-atm="${esc(n)}">${esc(n)}</button>`).join('')}</div>` : '');
    } else {
      const lst = s.latest_stats, lm = s.last_media, lms = lm && lm.stats;
      const latestEmpty = s.latest && (!lst || !lst.media);
      badge = !s.date_count ? '<span class="ds-badge ds-badge--warning">TARİX FOLDERİ YOXDUR</span>'
        : lm ? '<span class="ds-badge ds-badge--success">ŞƏKİL / VİDEO VAR</span>'
        : '<span class="ds-badge ds-badge--danger">ŞƏKİL / VİDEO TAPILMADI</span>';
      const ago = n => n == null ? '' : n === 0 ? 'bu gün' : n === 1 ? 'dünən' : n + ' gün əvvəl';
      body = `<div class="ds-stats vsvStats">
          <div class="ds-stat"><span class="ds-stat__label">Tarix folderi</span><b class="ds-stat__value">${s.date_count}</b><span class="ds-caption">${s.latest ? 'son: ' + esc(s.latest.display) + (latestEmpty ? ' (boş)' : '') : ''}</span></div>
          <div class="ds-stat ${!lm ? 'ds-stat--danger' : lm.delay_days > 1 ? 'ds-stat--warning' : 'ds-stat--success'}"><span class="ds-stat__label">Şəkilli son tarix</span><b class="ds-stat__value">${lm ? esc(lm.display) : '—'}</b><span class="ds-caption">${lm ? esc(ago(lm.delay_days)) : 'son ' + Math.min(s.date_count, 15) + ' folderdə yoxdur'}</span></div>
          <div class="ds-stat ${lms && lms.images ? 'ds-stat--success' : 'ds-stat--danger'}"><span class="ds-stat__label">Şəkil</span><b class="ds-stat__value">${lms ? lms.images : 0}</b><span class="ds-caption">${lm ? esc(lm.display) : ''}</span></div>
          <div class="ds-stat ${lms && lms.videos ? 'ds-stat--success' : ''}"><span class="ds-stat__label">Video</span><b class="ds-stat__value">${lms ? lms.videos : 0}</b><span class="ds-caption">${lm ? esc(lm.display) : ''}</span></div>
        </div>`;
      if (latestEmpty && lm) body += `<div class="ds-caption vsvMsg">${ic('info')} Ən son folder (${esc(s.latest.display)}) hələ boşdur — rəqəmlər şəkil/video olan son tarix üzrədir.</div>`;
      if (lms) body += statLine(lms);
      if (s.selected) {
        const sel = s.selected;
        const st = sel.stats;
        const ok = sel.exists && st && st.total > 0;
        body += `<div class="vsvSel ${ok ? 'is-ok' : 'is-bad'}">${ic(ok ? 'circle-check' : 'circle-x')}
          <div><b>${esc(sel.display)}</b> folderi: ${sel.exists ? (st && st.total ? 'VAR' : 'VAR, amma boşdur') : 'YOXDUR'}
          ${st ? statLine(st) : ''}</div>
          ${sel.exists ? `<button type="button" class="ds-btn ds-btn--secondary ds-btn--sm" data-open="${esc(s.src)}" data-rel="${esc(sel.name)}">${ic('folder-open')}Aç</button>` : ''}</div>`;
      }
      if (s.loose_files || s.other_folders.length) {
        body += `<div class="ds-caption vsvMsg">${s.other_folders.length ? 'Tarixsiz qovluq: ' + s.other_folders.slice(0, 8).map(esc).join(', ') + (s.other_folders.length > 8 ? '…' : '') + '. ' : ''}${s.loose_files ? 'ATM qovluğunda birbaşa ' + s.loose_files + ' fayl.' : ''}</div>`;
      }
      body += `<div class="vsvCardActions">
          <button type="button" class="ds-btn ds-btn--primary ds-btn--sm" data-open="${esc(s.src)}" data-rel="">${ic('folder-open')}Qovluğu aç</button>
          ${lm ? `<button type="button" class="ds-btn ds-btn--secondary ds-btn--sm" data-open="${esc(s.src)}" data-rel="${esc(lm.name)}" data-view="grid">${ic('eye')}${esc(lm.display)} şəkilləri</button>` : ''}
        </div>`;
    }
    return `<div class="panel vsvCard">
        <div class="vsvCardHead">${ic('hard-drive')}<b>${esc(s.label)}</b>${badge}</div>
        <code class="vsvPath">${esc(s.atm_path)}</code>
        ${body}
      </div>`;
  }).join('');
  const host = $('vsvResults');
  host.innerHTML = head + '<div class="vsvCards">' + cards + '</div>';
  host.querySelectorAll('.vsvChip').forEach(b => b.onclick = () => check(b.dataset.atm));
  host.querySelectorAll('[data-open]').forEach(b => b.onclick = () => openSource(b.dataset.open, b.dataset.rel || '', b.dataset.view));
}

/* ---------------- Brauzer ---------------- */
function openSource(src, rel, view) {
  const s = (S.result && S.result.sources || []).find(x => x.src === src);
  if (!s) return;
  S.src = src; S.label = s.label; S.base = s.atm_path; S.statsCache = {};
  if (view) setView(view);
  $('vsvBrowser').style.display = 'block';
  openDir(rel || '');
  $('vsvBrowser').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function openDir(rel) {
  S.rel = rel; S.gridLimit = GRID_PAGE; S.statsToken++;
  $('vsvFilter').value = '';
  renderCrumbs();
  $('vsvList').innerHTML = '<div class="bfNote"><span class="ds-spinner"></span> Oxunur...</div>';
  $('vsvCount').textContent = '—';
  try {
    const d = await getJson('/api/srvmedia/list?' + qs({ root: rootKey(), rel }));
    S.entries = d.entries || [];
    // Tarix folderləri ən yenidən köhnəyə
    S.entries.sort((a, b) => (a.kind !== b.kind) ? (a.kind === 'folder' ? -1 : 1)
      : (a.kind === 'folder' && /^\d{8}$/.test(a.name) && /^\d{8}$/.test(b.name)) ? b.name.localeCompare(a.name)
      : a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));
    const imgs = S.entries.filter(e => e.kind === 'file' && kindOf(e.ext) === 'img').length;
    const vids = S.entries.filter(e => e.kind === 'file' && kindOf(e.ext) === 'vid').length;
    $('vsvCount').textContent = `${d.folder_count} qovluq · ${d.file_count} fayl (${imgs} şəkil, ${vids} video)` + (d.truncated ? ' · ilk 10 000' : '');
    // Fayl varsa və şəkil çoxdursa qalereya daha rahatdır, amma istifadəçinin seçimini saxlayırıq
    render();
    loadFolderStats();
  } catch (e) {
    S.entries = [];
    $('vsvList').innerHTML = '<div class="bfNote">Xəta: ' + esc(e.message) + '</div>';
  }
}

function renderCrumbs() {
  const parts = S.rel ? S.rel.split(/[\\/]/).filter(Boolean) : [];
  let acc = [];
  const crumbs = [`<button type="button" data-rel="">${ic('server')}${esc(S.label)} · ${esc(S.atm)}</button>`]
    .concat(parts.map(p => { acc.push(p); const r = acc.join('\\'); return `<span>›</span><button type="button" data-rel="${esc(r)}">${esc(/^\d{8}$/.test(p) ? p.slice(6, 8) + '.' + p.slice(4, 6) + '.' + p.slice(0, 4) : p)}</button>`; }));
  const el = $('vsvCrumbs');
  el.innerHTML = crumbs.join('') + `<code class="vsvPath vsvPath--small">${esc(S.base + (S.rel ? '\\' + S.rel : ''))}</code>`;
  el.querySelectorAll('button[data-rel]').forEach(b => b.onclick = () => openDir(b.dataset.rel));
}

function filtered() {
  const q = ($('vsvFilter').value || '').trim().toLowerCase();
  return S.entries.filter(e => !q || e.name.toLowerCase().includes(q));
}

function render() {
  const items = filtered();
  const folders = items.filter(e => e.kind === 'folder');
  const files = items.filter(e => e.kind === 'file');
  S.files = files.filter(e => e.previewable);
  const list = $('vsvList');
  if (!items.length) { list.innerHTML = '<div class="bfNote">Bu qovluqda uyğun element yoxdur.</div>'; return; }
  let html = folders.map(e => {
    const isDate = /^\d{8}$/.test(e.name);
    const label = isDate ? e.name.slice(6, 8) + '.' + e.name.slice(4, 6) + '.' + e.name.slice(0, 4) : e.name;
    const st = S.statsCache[e.rel];
    return `<div class="bfRow bfFolder vsvFolder" data-rel="${esc(e.rel)}">${ic(isDate ? 'calendar' : 'folder-open')}
      <span class="bfName">${esc(label)}${isDate ? ` <small class="vsvRaw">${esc(e.name)}</small>` : ''}</span>
      <span class="vsvFStats" data-stats="${esc(e.rel)}">${st ? folderStatsHtml(st) : '<span class="vsvDots">···</span>'}</span></div>`;
  }).join('');
  if (S.view === 'grid') {
    const media = files.filter(e => ['img', 'vid'].includes(kindOf(e.ext)));
    const rest = files.filter(e => !['img', 'vid'].includes(kindOf(e.ext)));
    const shown = media.slice(0, S.gridLimit);
    if (media.length) {
      html += '<div class="vsvThumbs">' + shown.map(e => {
        const k = kindOf(e.ext);
        return `<button type="button" class="vsvThumb" data-rel="${esc(e.rel)}" title="${esc(e.name)} · ${esc(e.size_display)} · ${esc(e.modified)}">
          ${k === 'img' ? `<img loading="lazy" src="${mediaUrl(e.rel)}" alt="">` : `<span class="vsvThumbVid">${ic('play')}<small>${esc(e.ext.slice(1).toUpperCase())}</small></span>`}
          <span class="vsvThumbName">${esc(e.name)}</span></button>`;
      }).join('') + '</div>';
      if (media.length > shown.length) html += `<div class="vsvMore"><button type="button" class="ds-btn ds-btn--secondary ds-btn--sm" id="vsvMoreBtn">Daha ${Math.min(GRID_PAGE, media.length - shown.length)} göstər (${media.length - shown.length} qalıb)</button></div>`;
    }
    html += rest.map(fileRow).join('');
  } else {
    html += files.map(fileRow).join('');
  }
  list.innerHTML = html;
  list.querySelectorAll('.vsvFolder').forEach(r => r.onclick = () => openDir(r.dataset.rel));
  list.querySelectorAll('.bfFile, .vsvThumb').forEach(r => r.onclick = e => {
    if (e.target.closest('.bfDl')) return;
    const idx = S.files.findIndex(f => f.rel === r.dataset.rel);
    if (idx >= 0) preview(idx); else toast('Bu fayl web-də önizlənmir.', 'warning');
  });
  list.querySelectorAll('.bfDl').forEach(b => b.onclick = e => { e.stopPropagation(); download(S.entries.find(x => x.rel === b.dataset.rel)); });
  const more = $('vsvMoreBtn'); if (more) more.onclick = () => { S.gridLimit += GRID_PAGE; render(); };
  markCurrent();
}

function fileRow(e) {
  const k = kindOf(e.ext);
  const icon = k === 'img' ? 'eye' : k === 'vid' ? 'film' : 'file-text';
  const dl = e.previewable ? `<button class="bfDl" title="Yüklə" data-rel="${esc(e.rel)}">${ic('download')}</button>` : '<span class="ds-caption" title="Web-də dəstəklənmir">—</span>';
  return `<div class="bfRow bfFile" data-rel="${esc(e.rel)}">${ic(icon)}<span class="bfName">${esc(e.name)}</span><span class="bfSize">${esc(e.modified)}</span><span class="bfSize">${esc(e.size_display)}</span>${dl}</div>`;
}

function folderStatsHtml(st) {
  if (st.error) return '<span class="vsvDots" title="' + esc(st.error) + '">!</span>';
  if (!st.total) return '<span class="vsvPill vsvPill--empty">boş</span>';
  return `<span class="vsvPill vsvPill--img" title="Şəkil">${ic('eye')}${st.images}</span><span class="vsvPill vsvPill--vid" title="Video">${ic('film')}${st.videos}</span>`
    + (st.txt + st.other ? `<span class="vsvPill" title="Digər">+${st.txt + st.other}</span>` : '');
}

// Görünən qovluqların şəkil/video sayını ardıcıl doldur (ən yenidən başlayaraq, 60 qovluğa qədər)
async function loadFolderStats() {
  const token = S.statsToken;
  const folders = S.entries.filter(e => e.kind === 'folder').slice(0, 60);
  for (const f of folders) {
    if (token !== S.statsToken) return;
    if (S.statsCache[f.rel]) continue;
    let st;
    try { st = (await getJson('/api/srvmedia/stats?' + qs({ src: S.src, atm: S.atm, folder: f.rel }))).stats; }
    catch (e) { st = { error: e.message }; }
    if (token !== S.statsToken) return;
    S.statsCache[f.rel] = st;
    const cell = document.querySelector(`#vsvList [data-stats="${CSS.escape(f.rel)}"]`);
    if (cell) cell.innerHTML = folderStatsHtml(st);
  }
}

/* ---------------- Önizləmə ---------------- */
function markCurrent() {
  const cur = S.files[S.current];
  document.querySelectorAll('#vsvList .is-current').forEach(x => x.classList.remove('is-current'));
  if (!cur) return;
  const el = document.querySelector(`#vsvList [data-rel="${CSS.escape(cur.rel)}"]:not(.bfDl)`);
  if (el) el.classList.add('is-current');
}

async function preview(idx) {
  const f = S.files[idx]; if (!f) return;
  S.current = idx;
  $('vsvPvTitle').textContent = f.name;
  $('vsvPvMeta').textContent = `${idx + 1} / ${S.files.length} · ${f.size_display} · ${f.modified}`;
  $('vsvPrev').disabled = idx <= 0; $('vsvNext').disabled = idx >= S.files.length - 1; $('vsvDl').disabled = false;
  markCurrent();
  const box = $('vsvPreview');
  const k = kindOf(f.ext);
  try {
    if (k === 'img') {
      box.innerHTML = `<a href="${mediaUrl(f.rel)}" target="_blank" rel="noopener" title="Yeni pəncərədə aç"><img class="bfImg" src="${mediaUrl(f.rel)}" alt=""></a>`;
    } else if (k === 'vid') {
      const native = NATIVE_VID.includes(f.ext.toLowerCase());
      box.innerHTML = (native ? '' : '<div class="bfNote">AVI/WMV serverdə MP4-ə çevrilir (ffmpeg) — başlaması bir neçə saniyə çəkə bilər.</div>')
        + `<video class="bfVid" src="${native ? mediaUrl(f.rel) : transUrl(f.rel)}" controls autoplay muted></video>`;
    } else if (k === 'text') {
      box.innerHTML = '<div class="bfNote">Açılır...</div>';
      const r = await getJson('/api/srvmedia/text?' + qs({ root: rootKey(), rel: f.rel }));
      box.innerHTML = '<pre class="bfTextView">' + esc(r.text || '(boş)') + '</pre>' + (r.truncated ? '<div class="ds-caption">· ilk 1 MB göstərilir</div>' : '');
    } else {
      box.innerHTML = '<div class="bfNote">Bu fayl web-də önizlənmir.</div>';
    }
  } catch (e) { box.innerHTML = '<div class="bfNote">Xəta: ' + esc(e.message) + '</div>'; }
}

async function download(f) {
  if (!f || !f.previewable) return;
  try {
    if (kindOf(f.ext) === 'text') {
      const r = await getJson('/api/srvmedia/text?' + qs({ root: rootKey(), rel: f.rel }));
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([r.text || ''], { type: 'text/plain;charset=utf-8;' }));
      a.download = f.name; document.body.appendChild(a); a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); a.remove();
    } else {
      const a = document.createElement('a');
      a.href = mediaUrl(f.rel); a.download = S.atm + '_' + f.name;
      document.body.appendChild(a); a.click(); a.remove();
    }
    toast(f.name + ' yüklənir...', 'success');
  } catch (e) { toast('Yüklənmədi: ' + e.message, 'danger'); }
}

function setView(v) {
  S.view = v === 'grid' ? 'grid' : 'list';
  document.querySelectorAll('#vsvBrowser .vsvSeg button').forEach(b => b.classList.toggle('is-active', b.dataset.view === S.view));
}

/* ---------------- Init ---------------- */
function init() {
  if (S.inited) { $('vsvAtm').focus(); return; }
  S.inited = true;
  $('vsvAtm').addEventListener('keydown', e => { if (e.key === 'Enter') check(); });
  $('vsvDate').addEventListener('keydown', e => { if (e.key === 'Enter') check(); });
  $('vsvFilter').addEventListener('input', () => { S.gridLimit = GRID_PAGE; render(); });
  $('vsvReload').onclick = () => { S.statsCache = {}; openDir(S.rel); };
  $('vsvPrev').onclick = () => preview(S.current - 1);
  $('vsvNext').onclick = () => preview(S.current + 1);
  $('vsvDl').onclick = () => download(S.files[S.current]);
  document.querySelectorAll('#vsvBrowser .vsvSeg button').forEach(b => b.onclick = () => { setView(b.dataset.view); render(); });
  document.addEventListener('keydown', e => {
    const mod = $('videoServerModule');
    if (!mod || mod.classList.contains('hidden') || $('vsvBrowser').style.display === 'none') return;
    if (/^(INPUT|TEXTAREA|SELECT)$/.test((e.target && e.target.tagName) || '')) return;
    if (e.key === 'ArrowRight' && S.current < S.files.length - 1) { e.preventDefault(); preview(S.current + 1); }
    else if (e.key === 'ArrowLeft' && S.current > 0) { e.preventDefault(); preview(S.current - 1); }
  });
  loadSources();
  $('vsvAtm').focus();
}

window.videoServerInit = init;
window.videoServerCheck = () => check();
})();
