/* =====================================================================
   ATM WEB — İDARƏETMƏ UI: İstifadəçilər + İcazələr + Audit log
   ===================================================================== */
(function () {
'use strict';
const A = window.AtmAuth, el = A.el;
const Admin = window.AtmAdmin = {};
let users = [], auditTimer = null, auditOffset = 0, auditTotal = 0;
const $ = id => document.getElementById(id);
const pad = n => String(n).padStart(2, '0');
function fmt(ts) { if (!ts) return '—'; const d = new Date(ts * 1000); return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`; }
function badge(text, kind) { return el('span', { class: 'ds-badge ds-badge--dot ds-badge--' + kind, text }); }
function toastErr(e) { DS.toast(String(e.message || e), 'danger'); }
function iconBtn(icon, title, act, onclick, cls) { return el('button', { type: 'button', class: 'ds-btn ds-btn--sm ds-btn--icon ' + (cls || 'ds-btn--secondary'), title, 'aria-label': title, 'data-act': act, onclick, html: DS.icon(icon) }); }

Admin.open = function (m) { if (m === 'users') loadUsers(); else { auditOffset = 0; loadAudit(); } };
Admin.stop = function () { clearInterval(auditTimer); auditTimer = null; const c = $('auditAuto'); if (c) c.checked = false; };

/* ============================ İSTİFADƏÇİLƏR ============================ */
async function loadUsers() {
  try {
    const r = await fetch('/api/users', { cache: 'no-store' }); const d = await r.json();
    if (!d.success) throw new Error(d.error || 'Yüklənmədi');
    users = d.users; renderUsers();
  } catch (e) { toastErr(e); }
}
Admin.loadUsers = loadUsers;
function renderUsers() {
  $('usrStatTotal').textContent = users.length;
  $('usrStatActive').textContent = users.filter(u => u.status && u.login_allowed).length;
  $('usrStatBlocked').textContent = users.filter(u => u.status && !u.login_allowed).length;
  $('usrStatDeleted').textContent = users.filter(u => !u.status).length;
  $('usrNew').classList.toggle('perm-hidden', !A.can('users.create'));
  const showDeleted = $('usrShowDeleted').checked;
  const body = $('usersTable'); body.replaceChildren();
  const list = users.filter(u => showDeleted || u.status);
  if (!list.length) { body.append(el('tr', {}, [el('td', { colspan: 12, text: 'İstifadəçi tapılmadı.' })])); return; }
  list.forEach((u, i) => {
    const me = u.id === A.me.user.id, lockedAdmin = u.is_admin && !A.me.user.is_admin;
    const sw = el('input', { type: 'checkbox', class: 'ds-switch', 'aria-label': 'Sistemə giriş icazəsi', title: 'Sistemə giriş icazəsi' });
    sw.checked = u.login_allowed; sw.disabled = !u.status || me || lockedAdmin || !A.can('users.edit');
    sw.addEventListener('change', async () => {
      try { await A.post('/api/users/access', { id: u.id, login_allowed: sw.checked }); DS.toast(u.username + ': giriş icazəsi ' + (sw.checked ? 'verildi' : 'ləğv edildi'), 'success'); A.track('click', 'users', 'login_access_toggle', u.username + ' → ' + sw.checked); }
      catch (e) { toastErr(e); }
      loadUsers();
    });
    const acts = el('div', { class: 'ds-row-actions' });
    if (!lockedAdmin) {
      if (A.can('users.edit') && u.status) acts.append(iconBtn('pencil', 'Düzəliş et', 'user-edit', () => userForm(u)));
      if (A.can('users.perms') && u.status) acts.append(iconBtn('shield-check', 'İcazələr', 'user-perms', () => permsDialog(u)));
      if (A.can('users.reset') && u.status) acts.append(iconBtn('key-round', 'Şifrəni sıfırla', 'user-reset', () => resetDialog(u)));
      if (A.me.user.is_admin && u.status) acts.append(iconBtn('smartphone', '2FA (OTP) idarəetməsi — yalnız administrator', 'user-2fa', () => mfaDialog(u)));
      if (A.me.user.is_admin && u.locked) acts.append(iconBtn('lock-open', 'Kilidi aç', 'user-unlock', () => unlockUser(u), 'ds-btn--success'));
      if (A.can('users.sessions') && u.sessions) acts.append(iconBtn('power', 'Aktiv sessiyaları bitir', 'user-sessions', () => revokeSessions(u)));
      if (A.can('users.delete') && !me) acts.append(u.status ? iconBtn('trash-2', 'Sil (status = false)', 'user-delete', () => setStatus(u, false), 'ds-btn--danger') : iconBtn('rotate-ccw', 'Bərpa et (status = true)', 'user-restore', () => setStatus(u, true), 'ds-btn--success'));
    }
    const tr = el('tr', { class: u.status ? '' : 'is-deleted' }, [
      el('td', { text: i + 1 }),
      el('td', {}, [el('b', { class: 'mono', text: u.username }), me ? el('span', { class: 'ds-caption', text: ' (siz)' }) : null]),
      el('td', { text: (u.first_name + ' ' + u.last_name).trim() }),
      el('td', { text: u.position || '—' }),
      el('td', { class: 'mono', text: u.phone || '—' }),
      el('td', {}, [u.status ? badge('Aktiv', 'success') : badge('Silinib', 'danger')]),
      el('td', {}, [sw, u.locked ? el('span', { class: 'ds-caption', text: ' müvəqqəti kilidli' }) : null]),
      el('td', {}, [u.is_admin ? badge('Administrator', 'warning') : badge(u.perms.allow.filter(k => !k.includes('.')).length + ' modul', 'neutral')]),
      el('td', {}, [u.mfa_enabled ? badge('Aktiv', 'success') : badge('Qurulmayıb', 'neutral')]),
      el('td', { class: 'mono', text: fmt(u.last_login_at) }),
      el('td', { text: u.sessions || '0' }),
      el('td', {}, [acts]),
    ]);
    body.append(tr);
  });
}
function userForm(u) {
  const isNew = !u; u = u || { login_allowed: true };
  const f = {
    username: el('input', { value: u.username || '', autocomplete: 'off', placeholder: 'məs. a.mammadov', maxlength: 32 }),
    first_name: el('input', { value: u.first_name || '', maxlength: 60 }), last_name: el('input', { value: u.last_name || '', maxlength: 60 }),
    position: el('input', { value: u.position || '', maxlength: 80, placeholder: 'məs. ATM mühəndisi' }), phone: el('input', { value: u.phone || '', maxlength: 30, placeholder: '+994 50 000 00 00', inputmode: 'tel' }),
    password: el('input', { type: 'text', autocomplete: 'off', placeholder: 'Boş saxlasanız avtomatik yaradılır' }),
    login_allowed: el('input', { type: 'checkbox', class: 'ds-switch' }), is_admin: el('input', { type: 'checkbox', class: 'ds-switch' }),
  };
  f.login_allowed.checked = !!u.login_allowed; f.is_admin.checked = !!u.is_admin;
  const err = el('div', { class: 'ds-alert ds-alert--danger hidden' });
  const body = el('div', { class: 'ds-form authFormGrid' }, [
    A.field('İstifadəçi adı', f.username, '3–32 simvol: latın hərfi, rəqəm, nöqtə, _ və -'),
    isNew ? A.field('Müvəqqəti şifrə', f.password, 'İlk girişdə istifadəçi şifrəni dəyişməlidir.') : el('div'),
    A.field('Ad', f.first_name), A.field('Soyad', f.last_name), A.field('Vəzifə', f.position), A.field('Telefon nömrəsi', f.phone),
    el('label', { class: 'ds-inline-field' }, [f.login_allowed, el('span', { text: 'Sistemə giriş icazəsi var' })]),
    A.me.user.is_admin ? el('label', { class: 'ds-inline-field' }, [f.is_admin, el('span', { text: 'Administrator (bütün icazələr)' })]) : el('div'),
    err,
  ]);
  A.modal(isNew ? 'Yeni istifadəçi' : 'İstifadəçi: ' + u.username, body, [{ label: 'Ləğv et' }, { label: 'Yadda saxla', cls: 'ds-btn--primary', act: isNew ? 'user-create-save' : 'user-edit-save', onclick: async close => {
    err.classList.add('hidden');
    try {
      const d = await A.post('/api/users/save', { id: u.id, username: f.username.value, first_name: f.first_name.value, last_name: f.last_name.value, position: f.position.value, phone: f.phone.value, password: f.password.value, login_allowed: f.login_allowed.checked, is_admin: f.is_admin.checked });
      close(); await loadUsers();
      if (d.temp_password) showPassword(f.username.value, d.temp_password);
      else DS.toast(isNew ? 'İstifadəçi yaradıldı. İndi icazələrini təyin edin.' : 'Yadda saxlandı.', 'success');
      if (isNew && !f.is_admin.checked && A.can('users.perms')) { const nu = users.find(x => x.id === d.id); if (nu && !d.temp_password) permsDialog(nu); }
    } catch (e) { err.textContent = e.message; err.classList.remove('hidden'); }
  } }]);
}
function showPassword(username, pw) {
  const code = el('code', { class: 'authTempPw', text: pw });
  const body = el('div', { class: 'ds-form' }, [
    el('p', { text: `"${username}" üçün müvəqqəti şifrə. Bu şifrə yalnız bir dəfə göstərilir — indi istifadəçiyə çatdırın.` }), code,
    el('p', { class: 'ds-help', text: 'İstifadəçi ilk girişdə şifrəni dəyişməyə məcbur ediləcək.' })]);
  A.modal('Müvəqqəti şifrə', body, [{ label: 'Kopyala', onclick: () => { navigator.clipboard && navigator.clipboard.writeText(pw).then(() => DS.toast('Kopyalandı', 'success'), () => {}); } }, { label: 'Bağla', cls: 'ds-btn--primary' }]);
}
function resetDialog(u) {
  const pw = el('input', { type: 'text', autocomplete: 'off', placeholder: 'Boş saxlasanız avtomatik yaradılır' });
  const err = el('div', { class: 'ds-alert ds-alert--danger hidden' });
  const body = el('div', { class: 'ds-form' }, [
    el('p', { text: `"${u.username}" istifadəçisinin şifrəsi sıfırlanacaq, bütün aktiv sessiyaları bağlanacaq və ilk girişdə yeni şifrə təyin etməsi tələb olunacaq.` }),
    A.field('Yeni müvəqqəti şifrə', pw, 'Ən azı 8 simvol, ən azı bir hərf və bir rəqəm.'), err]);
  A.modal('Şifrəni sıfırla', body, [{ label: 'Ləğv et' }, { label: 'Sıfırla', cls: 'ds-btn--danger', act: 'user-reset-confirm', onclick: async close => {
    try { const d = await A.post('/api/users/reset-password', { id: u.id, password: pw.value }); close(); loadUsers(); if (d.temp_password) showPassword(u.username, d.temp_password); else DS.toast('Şifrə sıfırlandı.', 'success'); }
    catch (e) { err.textContent = e.message; err.classList.remove('hidden'); }
  } }]);
}
/* ---------------- 2FA (OTP) — yalnız administrator ---------------- */
function mfaQrPanel(username, d) {
  const qr = el('div', { class: 'mfaQr', role: 'img', 'aria-label': '2FA QR kodu' });
  if (typeof window.qrcode === 'function') { const q = window.qrcode(0, 'M'); q.addData(d.otpauth_uri); q.make(); qr.innerHTML = q.createSvgTag({ cellSize: 4, margin: 2, scalable: true }); }
  else qr.textContent = 'QR kitabxanası yüklənmədi — açarı əl ilə daxil edin.';
  const key = String(d.secret || '').replace(/(.{4})/g, '$1 ').trim();
  return el('div', { class: 'mfaSecretPanel' }, [
    el('p', { text: `"${username}" üçün yeni 2FA açarı yaradıldı. İstifadəçi bu QR kodu öz autentifikator tətbiqində skan etməlidir (köhnə kod artıq işləmir).` }),
    qr,
    A.field('Hesab', el('div', { class: 'mfaAccount', text: (d.issuer || 'BIR SPARK') + ' · ' + username })),
    A.field('Əl ilə açar', el('code', { class: 'mfaKey', text: key })),
    el('div', { class: 'mfaWarn', text: 'Bu açar yalnız indi göstərilir və heç yerdə açıq saxlanmır. Pəncərəni bağladıqdan sonra yenidən görmək mümkün deyil.' })]);
}
function mfaDialog(u) {
  if (!A.me.user.is_admin) return;
  const on = !!u.mfa_enabled, err = el('div', { class: 'ds-alert ds-alert--danger hidden' });
  const fail = e => { err.textContent = e.message; err.classList.remove('hidden'); };
  const body = el('div', { class: 'ds-form' }, [
    el('p', {}, [el('b', { text: u.username }), el('span', { text: ' — 2FA vəziyyəti: ' }), on ? badge('Aktiv', 'success') : badge('Qurulmayıb', 'neutral'),
      on && u.mfa_enrolled_at ? el('span', { class: 'ds-caption', text: ' · qurulub: ' + fmt(u.mfa_enrolled_at) }) : null]),
    el('ul', { class: 'mfaSteps' }, [
      el('li', {}, [el('b', { text: 'Sıfırla' }), el('span', { text: ' — açar silinir, aktiv sessiyalar bağlanır. İstifadəçi növbəti girişdə QR kodu özü yenidən skan edəcək (telefonu itəndə/dəyişəndə).' })]),
      el('li', {}, [el('b', { text: 'Yenidən qur' }), el('span', { text: ' — dərhal yeni açar yaradılır və QR burada göstərilir; administrator onu istifadəçiyə şəxsən təqdim edir. Köhnə kod dərhal etibarsız olur.' })])]),
    err]);
  A.modal('2FA (OTP) — ' + u.username, body, [
    { label: 'Bağla' },
    { label: 'Sıfırla', cls: 'ds-btn--danger', act: 'user-2fa-reset', onclick: async close => {
      if (!await A.confirm('2FA sıfırlansın?', `"${u.username}" üçün 2FA açarı silinsin? Bütün aktiv sessiyaları bağlanacaq və növbəti girişdə QR kodu yenidən skan etməli olacaq.`, 'Sıfırla', true)) return;
      try { await A.post('/api/users/mfa/reset', { id: u.id }); close(); DS.toast(u.username + ': 2FA sıfırlandı.', 'success'); A.track('click', 'users', 'mfa_reset', u.username); loadUsers(); } catch (e) { fail(e); }
    } },
    { label: 'Yenidən qur', cls: 'ds-btn--primary', act: 'user-2fa-rebuild', onclick: async close => {
      if (!await A.confirm('2FA yenidən qurulsun?', `"${u.username}" üçün yeni açar yaradılsın? Köhnə autentifikator kodu dərhal işləməyəcək və aktiv sessiyaları bağlanacaq.`, 'Yenidən qur', true)) return;
      try {
        const d = await A.post('/api/users/mfa/rebuild', { id: u.id }); close(); loadUsers(); A.track('click', 'users', 'mfa_rebuild', u.username);
        const panel = mfaQrPanel(u.username, d);
        A.modal('Yeni 2FA açarı — ' + u.username, panel, [{ label: 'Açarı kopyala', onclick: () => { navigator.clipboard && navigator.clipboard.writeText(d.secret).then(() => DS.toast('Kopyalandı', 'success'), () => {}); } }, { label: 'Hazırdır', cls: 'ds-btn--primary', onclick: c => { panel.replaceChildren(); d.secret = d.otpauth_uri = ''; c(); } }]);
      } catch (e) { fail(e); }
    } }]);
}
async function unlockUser(u) {
  if (!A.me.user.is_admin) return;
  if (!await A.confirm('Kilidi aç', `"${u.username}" uğursuz cəhdlərə görə müvəqqəti kilidlənib. Kilid indi açılsın?`, 'Kilidi aç')) return;
  try { await A.post('/api/users/unlock', { id: u.id }); DS.toast(u.username + ': kilid açıldı.', 'success'); } catch (e) { toastErr(e); }
  loadUsers();
}
async function setStatus(u, status) {
  const ok = await A.confirm(status ? 'İstifadəçini bərpa et' : 'İstifadəçini sil', status ? `"${u.username}" bərpa olunsun? (status = true)` : `"${u.username}" silinsin? Hesab bazada qalır (status = false), amma sistemə girə bilməyəcək və aktiv sessiyaları dərhal bağlanacaq.`, status ? 'Bərpa et' : 'Sil', !status);
  if (!ok) return;
  try { await A.post('/api/users/status', { id: u.id, status }); DS.toast(status ? 'Bərpa olundu.' : 'Silindi.', 'success'); } catch (e) { toastErr(e); }
  loadUsers();
}
async function revokeSessions(u) {
  if (!await A.confirm('Sessiyaları bitir', `"${u.username}" istifadəçisinin ${u.sessions} aktiv sessiyası bağlansın? Yenidən daxil olmalı olacaq.`, 'Bitir', true)) return;
  try { await A.post('/api/users/sessions/revoke', { id: u.id }); DS.toast('Sessiyalar bağlandı.', 'success'); } catch (e) { toastErr(e); }
  loadUsers();
}

/* ---------------- İcazələr pəncərəsi ---------------- */
function permsDialog(u) {
  const allow = new Set(u.perms.allow || []);
  const hide = JSON.parse(JSON.stringify(u.perms.hideCols || {}));
  const tables = A.tableCatalog();
  const body = el('div', { class: 'permsBody' });
  const boxes = [];   // {key, input, module}
  const colBoxes = []; // {table, col, input, module}
  function sync() {
    A.catalog.forEach(m => {
      const on = boxes.find(b => b.key === m.key).input.checked;
      boxes.filter(b => b.module === m.key && b.key !== m.key).forEach(b => { b.input.disabled = !on; });
      colBoxes.filter(c => c.module === m.key).forEach(c => { c.input.disabled = !on; });
      const card = body.querySelector(`[data-module="${m.key}"]`); if (card) card.classList.toggle('is-off', !on);
    });
  }
  const mk = (key, label, module, strong) => {
    const input = el('input', { type: 'checkbox', class: strong ? 'ds-switch' : '' }); input.checked = allow.has(key);
    input.addEventListener('change', sync); boxes.push({ key, input, module });
    return el('label', { class: 'permItem' + (strong ? ' permItem--module' : '') }, [input, el('span', { text: label })]);
  };
  if (u.is_admin) body.append(el('div', { class: 'ds-alert ds-alert--warning', text: 'Bu istifadəçi administratordur — aşağıdakı seçimlərdən asılı olmayaraq bütün icazələrə malikdir. Seçimlər admin hüququ götürülərsə qüvvəyə minir.' }));
  const copy = el('select', { 'aria-label': 'İcazələri kopyala' }, [el('option', { value: '', text: 'Başqa istifadəçidən kopyala…' })].concat(users.filter(x => x.id !== u.id && x.status).map(x => el('option', { value: x.id, text: x.username + ' — ' + x.first_name + ' ' + x.last_name }))));
  copy.addEventListener('change', () => {
    const src = users.find(x => String(x.id) === copy.value); if (!src) return;
    const sa = new Set(src.perms.allow); boxes.forEach(b => { b.input.checked = sa.has(b.key); });
    colBoxes.forEach(c => { c.input.checked = !((src.perms.hideCols || {})[c.table] || []).includes(c.col); });
    sync(); copy.value = '';
  });
  body.append(el('div', { class: 'permsToolbar' }, [
    el('button', { type: 'button', class: 'ds-btn ds-btn--secondary ds-btn--sm', text: 'Hamısını seç', onclick: () => { boxes.forEach(b => b.input.checked = true); colBoxes.forEach(c => c.input.checked = true); sync(); } }),
    el('button', { type: 'button', class: 'ds-btn ds-btn--secondary ds-btn--sm', text: 'Hamısını sil', onclick: () => { boxes.forEach(b => b.input.checked = false); sync(); } }),
    el('button', { type: 'button', class: 'ds-btn ds-btn--secondary ds-btn--sm', text: 'Yalnız baxış', title: 'Bütün modulları göstər, əməliyyat düymələrini bağla', onclick: () => { boxes.forEach(b => { const isMod = b.key === b.module; const adminMod = b.module === 'users' || b.module === 'audit'; b.input.checked = !adminMod && (isMod || /\.block\.|\.stats$|\.history$|\.detail$|\.browse$|\.journal$|\.media$|\.search$/.test(b.key)); }); sync(); } }),
    copy]));
  A.catalog.forEach(m => {
    const items = el('div', { class: 'permGrid' }, m.items.map(it => mk(it.key, it.label, m.key)));
    const card = el('section', { class: 'permCard', 'data-module': m.key }, [
      el('div', { class: 'permCard__head' }, [mk(m.key, m.label, m.key, true), el('span', { class: 'ds-caption', text: 'modulu görür · sol menyuda göstərilir' })]),
      m.items.length ? el('div', { class: 'permSub', text: 'Əməliyyatlar və bloklar' }) : null, m.items.length ? items : null]);
    tables.filter(t => t.module === m.key).forEach(t => {
      const hidden = new Set(hide[t.key] || []);
      card.append(el('div', { class: 'permSub', text: 'Cədvəl sütunları — ' + t.label }));
      card.append(el('div', { class: 'permGrid permGrid--cols' }, t.cols.map(c => {
        const input = el('input', { type: 'checkbox' }); input.checked = !hidden.has(c);
        colBoxes.push({ table: t.key, col: c, input, module: m.key });
        return el('label', { class: 'permItem' }, [input, el('span', { text: c })]);
      })));
    });
    body.append(card);
  });
  sync();
  A.modal('İcazələr — ' + u.username + ' (' + u.first_name + ' ' + u.last_name + ')', body, [{ label: 'Ləğv et' }, { label: 'İcazələri yadda saxla', cls: 'ds-btn--primary', act: 'user-perms-save', onclick: async close => {
    const hideCols = {};
    colBoxes.forEach(c => { if (!c.input.checked) (hideCols[c.table] = hideCols[c.table] || []).push(c.col); });
    try { await A.post('/api/users/perms', { id: u.id, perms: { allow: boxes.filter(b => b.input.checked).map(b => b.key), hideCols } }); close(); DS.toast('İcazələr yadda saxlandı. İstifadəçidə ən geci 1 dəqiqəyə tətbiq olunur.', 'success'); loadUsers(); }
    catch (e) { toastErr(e); }
  } }], true);
}

/* ============================ AUDİT ============================ */
const TYPE = { auth: ['Giriş / çıxış', 'info'], admin: ['İdarəetmə', 'warning'], api: ['Server əməliyyatı', 'success'], denied: ['Rədd edildi', 'danger'], nav: ['Keçid', 'neutral'], click: ['Klik', 'neutral'] };
function moduleLabel(k) { const m = A.catalog.find(x => x.key === k); return m ? m.label : (k || '—'); }
function auditQuery() {
  const q = new URLSearchParams();
  const v = id => $(id).value.trim();
  if (v('auditUser')) q.set('user_id', v('auditUser'));
  if (v('auditType')) q.set('type', v('auditType'));
  if (v('auditModuleSel')) q.set('module', v('auditModuleSel'));
  if (v('auditFrom')) q.set('from', v('auditFrom'));
  if (v('auditTo')) q.set('to', v('auditTo'));
  if (v('auditSearch')) q.set('q', v('auditSearch'));
  return q;
}
async function loadAudit() {
  const size = Number($('auditSize').value) || 100;
  const q = auditQuery(); q.set('limit', size); q.set('offset', auditOffset);
  try {
    const r = await fetch('/api/audit?' + q, { cache: 'no-store' }); const d = await r.json();
    if (!d.success) throw new Error(d.error || 'Yüklənmədi');
    auditTotal = d.total;
    const us = $('auditUser');
    if (us.options.length <= 1) d.users.forEach(u => us.append(el('option', { value: u.id, text: u.username + ' — ' + u.first_name + ' ' + u.last_name })));
    const ms = $('auditModuleSel');
    if (ms.options.length <= 1) A.catalog.forEach(m => ms.append(el('option', { value: m.key, text: m.label })));
    const body = $('auditTable'); body.replaceChildren();
    if (!d.rows.length) body.append(el('tr', {}, [el('td', { colspan: 8, text: 'Qeyd tapılmadı.' })]));
    d.rows.forEach(x => {
      const t = TYPE[x.type] || [x.type, 'neutral'];
      body.append(el('tr', {}, [
        el('td', { class: 'mono', text: fmt(x.ts) }), el('td', {}, [el('b', { text: x.username || '—' })]),
        el('td', {}, [badge(t[0], t[1])]), el('td', { text: moduleLabel(x.module) }),
        el('td', { class: 'mono', text: x.action || '—' }), el('td', { class: 'auditDetail', text: x.detail || '', title: x.detail || '' }),
        el('td', { class: 'mono', text: x.status == null ? '—' : x.status }), el('td', { class: 'mono', text: x.ip || '—' })]));
    });
    const from = d.total ? auditOffset + 1 : 0, to = Math.min(auditOffset + size, d.total);
    $('auditInfo').textContent = `${from}–${to} / ${d.total}`;
    $('auditPrev').disabled = auditOffset <= 0; $('auditNext').disabled = to >= d.total;
    $('auditExport').classList.toggle('perm-hidden', !A.can('audit.export'));
  } catch (e) { toastErr(e); }
}
Admin.loadAudit = loadAudit;

function bind() {
  if (!$('usersModule')) return;
  $('usrNew').addEventListener('click', () => userForm(null));
  $('usrRefresh').addEventListener('click', loadUsers);
  $('usrShowDeleted').addEventListener('change', renderUsers);
  let t;
  const reload = () => { auditOffset = 0; loadAudit(); };
  ['auditUser', 'auditType', 'auditModuleSel', 'auditFrom', 'auditTo', 'auditSize'].forEach(id => $(id).addEventListener('change', reload));
  $('auditSearch').addEventListener('input', () => { clearTimeout(t); t = setTimeout(reload, 300); });
  $('auditRefresh').addEventListener('click', loadAudit);
  $('auditClear').addEventListener('click', () => { ['auditUser', 'auditType', 'auditModuleSel', 'auditFrom', 'auditTo', 'auditSearch'].forEach(id => $(id).value = ''); reload(); });
  $('auditPrev').addEventListener('click', () => { auditOffset = Math.max(0, auditOffset - (Number($('auditSize').value) || 100)); loadAudit(); });
  $('auditNext').addEventListener('click', () => { auditOffset += Number($('auditSize').value) || 100; loadAudit(); });
  $('auditAuto').addEventListener('change', e => { clearInterval(auditTimer); auditTimer = e.target.checked ? setInterval(() => { if (auditOffset === 0 && !document.hidden) loadAudit(); }, 10000) : null; });
  $('auditExport').addEventListener('click', () => { window.location.href = '/api/audit/export?' + auditQuery(); });
}
Admin.bind = bind;
})();
