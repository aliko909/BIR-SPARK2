/* ATM WEB — Toplu qoşulma (iki siyahılı seçici) + Windows idarəetmə (bankomatId · PASSWORD · Windows növü).
   Qeyd: real şifrə heç vaxt göndərilmir/göstərilmir; yalnız PASSWORD slot etiketi və Windows növü. */
(function () {
'use strict';
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const toast = (m, t) => { try { DS.toast(m, t || 'info'); } catch (e) { /* no-op */ } };

/* ---- bir dəfəlik CSS ---- */
(function injectCss() {
  if (document.getElementById('atmBulkCss')) return;
  const s = document.createElement('style'); s.id = 'atmBulkCss';
  s.textContent = `
  .atmBulkOv{position:fixed;inset:0;background:rgba(10,14,22,.55);z-index:9000;display:flex;align-items:center;justify-content:center}
  .atmBulkWin{background:var(--ds-surface,#fff);color:var(--ds-text,#111);width:min(980px,96vw);max-height:92vh;border-radius:14px;
    box-shadow:0 20px 60px rgba(0,0,0,.35);display:flex;flex-direction:column;overflow:hidden}
  .atmBulkHd{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid rgba(128,128,128,.25)}
  .atmBulkHd h3{margin:0;font-size:17px}
  .atmBulkBody{padding:14px 18px;overflow:auto}
  .atmBulkDual{display:grid;grid-template-columns:1fr auto 1fr;gap:12px;align-items:stretch}
  .atmBulkCol{display:flex;flex-direction:column;border:1px solid rgba(128,128,128,.3);border-radius:10px;min-height:340px}
  .atmBulkCol h4{margin:0;padding:8px 10px;font-size:13px;border-bottom:1px solid rgba(128,128,128,.25);display:flex;justify-content:space-between}
  .atmBulkCol input.s{margin:8px;padding:6px 8px;border:1px solid rgba(128,128,128,.4);border-radius:7px}
  .atmBulkList{list-style:none;margin:0;padding:4px;overflow:auto;flex:1;max-height:48vh}
  .atmBulkList li{padding:6px 9px;border-radius:6px;cursor:pointer;font-size:13px;display:flex;justify-content:space-between;gap:8px}
  .atmBulkList li:hover{background:rgba(80,120,255,.12)}
  .atmBulkList li .mono{font-family:ui-monospace,monospace}
  .atmBulkList li small{opacity:.6}
  .atmBulkMid{display:flex;flex-direction:column;justify-content:center;gap:8px}
  .atmBulkMid button{min-width:52px}
  .atmBulkFt{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 18px;border-top:1px solid rgba(128,128,128,.25)}
  .atmBulkProg{height:8px;background:rgba(128,128,128,.25);border-radius:6px;overflow:hidden;flex:1;margin:0 10px}
  .atmBulkProg i{display:block;height:100%;width:0;background:#2e7d32;transition:width .3s}
  .atmBulkLog{font-family:ui-monospace,monospace;font-size:12px;background:rgba(128,128,128,.1);border-radius:8px;padding:8px;margin-top:10px;max-height:150px;overflow:auto;white-space:pre-wrap}
  .atmWinTbl{width:100%;border-collapse:collapse;font-size:13px}
  .atmWinTbl th,.atmWinTbl td{padding:6px 8px;border-bottom:1px solid rgba(128,128,128,.2);text-align:left}
  .atmWinTbl select{padding:4px 6px;border:1px solid rgba(128,128,128,.4);border-radius:6px}
  .atmWinBadge{padding:2px 8px;border-radius:20px;font-size:11px;background:rgba(128,128,128,.2)}
  .atmWinBadge.xp{background:#fde4b5}.atmWinBadge.win7{background:#cfe3ff}.atmWinBadge.win10{background:#cdeccd}`;
  document.head.appendChild(s);
})();

function overlay(win) {
  const ov = document.createElement('div'); ov.className = 'atmBulkOv';
  ov.appendChild(win); document.body.appendChild(ov);
  ov.addEventListener('mousedown', e => { if (e.target === ov) ov.remove(); });
  return ov;
}

/* ============================================================
   TOPLU QOŞULMA — iki siyahılı seçici
   ============================================================ */
let available = [];   // {id, atm_id, name, region}
let selected = [];    // atm_id-lər
let bulkTimer = null;

window.atmBulkOpen = async function () {
  let rows = [];
  try {
    const r = await fetch('/api/atms?state=visible&t=' + Date.now(), { cache: 'no-store' });
    const d = await r.json(); if (!d.success) throw new Error(d.error || 'Yüklənmədi');
    rows = (d.rows || []).filter(x => !x.is_deleted);
  } catch (e) { toast(String(e.message || e), 'danger'); return; }

  selected = [];
  available = rows.map(x => ({ id: x.id, atm_id: x.atm_id, name: x.name || '', region: x.region || '' }));

  const win = document.createElement('div'); win.className = 'atmBulkWin';
  win.innerHTML = `
    <div class="atmBulkHd"><h3>Toplu qoşulma — ATM seçimi</h3>
      <button class="ds-btn ds-btn--secondary ds-btn--icon" type="button" aria-label="Bağla" id="atmBulkClose">✕</button></div>
    <div class="atmBulkBody">
      <p class="ds-caption" style="margin:0 0 10px">Solda bütün ATM-lər. Birini <b>iki dəfə</b> kliklə sağa keçir; ortadakı düymələrlə hamısını keçir. Sağdakı seçilmişlər üçün uyğun PASSWORD slotu tapılıb bazaya (password_env + Windows növü) yazılacaq.</p>
      <div class="atmBulkDual">
        <div class="atmBulkCol">
          <h4><span>Mövcud ATM-lər</span><span id="atmBulkAvailN" class="ds-caption">0</span></h4>
          <input class="s" id="atmBulkSearchA" placeholder="ATM ID / ad / region axtar...">
          <ul class="atmBulkList" id="atmBulkAvail"></ul>
        </div>
        <div class="atmBulkMid">
          <button class="ds-btn ds-btn--secondary" id="atmBulkAllRight" title="Hamısını sağa">▶▶</button>
          <button class="ds-btn ds-btn--secondary" id="atmBulkAllLeft" title="Hamısını sola">◀◀</button>
        </div>
        <div class="atmBulkCol">
          <h4><span>Seçilmiş (qoşulacaq)</span><span id="atmBulkSelN" class="ds-caption">0</span></h4>
          <input class="s" id="atmBulkSearchS" placeholder="Seçilmişlərdə axtar...">
          <ul class="atmBulkList" id="atmBulkSel"></ul>
        </div>
      </div>
      <div class="atmBulkProgWrap" style="display:flex;align-items:center;margin-top:12px">
        <span class="ds-caption" id="atmBulkStat">Hazır</span>
        <div class="atmBulkProg"><i id="atmBulkBar"></i></div>
        <span class="ds-caption" id="atmBulkPct">0%</span>
      </div>
      <div class="atmBulkLog" id="atmBulkLogBox" style="display:none"></div>
    </div>
    <div class="atmBulkFt">
      <span class="ds-caption">⚠ Yalnız PASSWORD slot etiketi işlənir, real şifrə göstərilmir.</span>
      <span>
        <button class="ds-btn ds-btn--secondary" id="atmBulkCancel" type="button" disabled>Dayandır</button>
        <button class="ds-btn ds-btn--primary" id="atmBulkStart" type="button">Seçilmişlərə qoşul</button>
      </span>
    </div>`;
  const ov = overlay(win);
  const $ = id => win.querySelector(id);
  $('#atmBulkClose').onclick = () => { if (bulkTimer) clearInterval(bulkTimer); ov.remove(); };

  function render() {
    const qa = ($('#atmBulkSearchA').value || '').trim().toUpperCase();
    const qs = ($('#atmBulkSearchS').value || '').trim().toUpperCase();
    const selSet = new Set(selected);
    const av = available.filter(x => !selSet.has(x.atm_id) &&
      (!qa || (x.atm_id + ' ' + x.name + ' ' + x.region).toUpperCase().includes(qa)));
    const sv = available.filter(x => selSet.has(x.atm_id) &&
      (!qs || (x.atm_id + ' ' + x.name + ' ' + x.region).toUpperCase().includes(qs)));
    const li = x => `<li data-atm="${esc(x.atm_id)}"><span class="mono">${esc(x.atm_id)}</span><small>${esc(x.region || x.name || '')}</small></li>`;
    $('#atmBulkAvail').innerHTML = av.map(li).join('') || '<li class="ds-caption">—</li>';
    $('#atmBulkSel').innerHTML = sv.map(li).join('') || '<li class="ds-caption">Hələ seçilməyib</li>';
    $('#atmBulkAvailN').textContent = av.length;
    $('#atmBulkSelN').textContent = selected.length;
  }
  $('#atmBulkAvail').addEventListener('dblclick', e => { const li = e.target.closest('li[data-atm]'); if (li) { selected.push(li.dataset.atm); render(); } });
  $('#atmBulkSel').addEventListener('dblclick', e => { const li = e.target.closest('li[data-atm]'); if (li) { selected = selected.filter(a => a !== li.dataset.atm); render(); } });
  $('#atmBulkAllRight').onclick = () => {
    const qa = ($('#atmBulkSearchA').value || '').trim().toUpperCase();
    const selSet = new Set(selected);
    available.forEach(x => { if (!selSet.has(x.atm_id) && (!qa || (x.atm_id + ' ' + x.name + ' ' + x.region).toUpperCase().includes(qa))) selected.push(x.atm_id); });
    render();
  };
  $('#atmBulkAllLeft').onclick = () => { selected = []; render(); };
  $('#atmBulkSearchA').oninput = render; $('#atmBulkSearchS').oninput = render;
  render();

  $('#atmBulkStart').onclick = async () => {
    if (!selected.length) { toast('Ən azı bir ATM seçin.', 'warning'); return; }
    $('#atmBulkStart').disabled = true;
    try {
      const r = await fetch('/api/atms/bulk_start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ atm_ids: selected.slice() }) });
      const d = await r.json();
      if (!d.success) { toast(d.error || 'Başlamadı', 'danger'); $('#atmBulkStart').disabled = false; return; }
      $('#atmBulkCancel').disabled = false; $('#atmBulkLogBox').style.display = 'block';
      pollBulk($, ov);
    } catch (e) { toast(String(e.message || e), 'danger'); $('#atmBulkStart').disabled = false; }
  };
  $('#atmBulkCancel').onclick = async () => {
    try { await fetch('/api/atms/bulk_cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); } catch (e) {}
  };
};

function pollBulk($, ov) {
  if (bulkTimer) clearInterval(bulkTimer);
  bulkTimer = setInterval(async () => {
    try {
      const r = await fetch('/api/atms/bulk_progress?t=' + Date.now(), { cache: 'no-store' });
      const d = await r.json();
      const st = d.state || d;
      const pct = Number(st.percent || 0);
      $('#atmBulkBar').style.width = pct + '%'; $('#atmBulkPct').textContent = pct + '%';
      $('#atmBulkStat').textContent = (st.running ? 'İşləyir · ' : (st.finished ? 'Bitdi · ' : '')) +
        (st.current_atm ? st.current_atm + ' · ' : '') + `${st.processed || 0}/${st.total || 0} · uğur ${st.success_count || 0} · xəta ${st.failed_count || 0}`;
      if (Array.isArray(st.logs)) $('#atmBulkLogBox').textContent = st.logs.slice(-40).join('\n');
      if (st.finished && !st.running) {
        clearInterval(bulkTimer); bulkTimer = null;
        $('#atmBulkStart').disabled = false; $('#atmBulkCancel').disabled = true;
        toast('Toplu qoşulma bitdi.', 'success');
        if (window.atmInfoLoadList) window.atmInfoLoadList();
      }
    } catch (e) { /* növbəti tick */ }
  }, 1000);
}

/* ============================================================
   WINDOWS İDARƏETMƏ — bankomatId · PASSWORD slotu · Windows növü
   ============================================================ */
window.atmWinmapOpen = async function () {
  let data;
  try {
    const r = await fetch('/api/atms/winmap?state=visible&t=' + Date.now(), { cache: 'no-store' });
    data = await r.json(); if (!data.success) throw new Error(data.error || 'Yüklənmədi');
  } catch (e) { toast(String(e.message || e), 'danger'); return; }

  const types = data.win_types || [{ code: 'XP', label: 'Windows XP' }, { code: 'WIN7', label: 'Windows 7' }, { code: 'WIN10', label: 'Windows 10' }];
  const badge = t => { t = String(t || '').toUpperCase(); const lbl = ({ XP: 'Windows XP', WIN7: 'Windows 7', WIN10: 'Windows 10' })[t] || '—'; const cls = t === 'XP' ? 'xp' : t === 'WIN7' ? 'win7' : t === 'WIN10' ? 'win10' : ''; return `<span class="atmWinBadge ${cls}">${esc(lbl)}</span>`; };

  const win = document.createElement('div'); win.className = 'atmBulkWin';
  win.innerHTML = `
    <div class="atmBulkHd"><h3>Windows idarəetmə — PASSWORD slotu ↔ Windows növü</h3>
      <button class="ds-btn ds-btn--secondary ds-btn--icon" id="atmWinClose" aria-label="Bağla">✕</button></div>
    <div class="atmBulkBody">
      <p class="ds-caption" style="margin:0 0 6px">PASSWORD slotundan Windows növü avtomatik təxmin olunur; lazım olsa əl ilə dəyişin. Qoşulma zamanı həmin növə uyğun collector (eco_xp / eco_win7 / eco_win10) göndərilir.</p>
      <p class="ds-caption" style="margin:0 0 10px">Avtomatik qayda: <b>XP</b>=PASSWORD 1,4,8 · <b>Win10</b>=PASSWORD 3,6,10 · <b>Win7</b>=PASSWORD 2,5,9</p>
      <input class="s" id="atmWinSearch" placeholder="ATM ID / region axtar..." style="width:100%;padding:7px 9px;border:1px solid rgba(128,128,128,.4);border-radius:8px;margin-bottom:8px">
      <div style="max-height:56vh;overflow:auto">
        <table class="atmWinTbl"><thead><tr><th>ATM ID</th><th>Region</th><th>PASSWORD</th><th>Avtomatik</th><th>Windows növü (əl ilə)</th><th></th></tr></thead>
        <tbody id="atmWinRows"></tbody></table>
      </div>
    </div>
    <div class="atmBulkFt"><span class="ds-caption" id="atmWinStat">${(data.rows || []).length} ATM</span>
      <button class="ds-btn ds-btn--primary" id="atmWinCloseBtn">Bağla</button></div>`;
  const ov = overlay(win);
  const $ = id => win.querySelector(id);
  $('#atmWinClose').onclick = $('#atmWinCloseBtn').onclick = () => ov.remove();

  function draw() {
    const q = ($('#atmWinSearch').value || '').trim().toUpperCase();
    const rows = (data.rows || []).filter(x => !q || (x.atm_id + ' ' + (x.region || '')).toUpperCase().includes(q));
    $('#atmWinRows').innerHTML = rows.map(x => {
      const eff = x.windows_type || x.derived_type || '';
      const opts = ['<option value="">— (avtomatik)</option>'].concat(
        types.map(t => `<option value="${t.code}"${(x.windows_type || '').toUpperCase() === t.code ? ' selected' : ''}>${esc(t.label)}</option>`)).join('');
      return `<tr data-atm="${esc(x.atm_id)}">
        <td class="mono"><b>${esc(x.atm_id)}</b></td>
        <td>${esc(x.region || '—')}</td>
        <td class="mono">${esc(x.password_env || '—')}</td>
        <td>${badge(x.derived_type)}</td>
        <td><select class="atmWinSel">${opts}</select></td>
        <td><span class="ds-caption atmWinSaved">${x.windows_type ? '✔ əl ilə' : (eff ? 'avto' : '')}</span></td>
      </tr>`;
    }).join('') || '<tr><td colspan="6" class="ds-caption">ATM tapılmadı.</td></tr>';
  }
  $('#atmWinSearch').oninput = draw;
  $('#atmWinRows').addEventListener('change', async e => {
    const sel = e.target.closest('select.atmWinSel'); if (!sel) return;
    const tr = sel.closest('tr'); const atm = tr.dataset.atm;
    try {
      const r = await fetch('/api/atms/winmap/save', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ atm_id: atm, windows_type: sel.value }) });
      const d = await r.json(); if (!d.success) throw new Error(d.error);
      const row = (data.rows || []).find(x => x.atm_id === atm); if (row) row.windows_type = sel.value || null;
      tr.querySelector('.atmWinSaved').textContent = sel.value ? '✔ əl ilə' : 'avto';
      toast(atm + ' → ' + (sel.value || 'avtomatik'), 'success');
    } catch (err) { toast(String(err.message || err), 'danger'); }
  });
  draw();
};
})();
