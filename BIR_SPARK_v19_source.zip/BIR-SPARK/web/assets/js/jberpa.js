/* Cihaz İdarəetmə Sistemi — Journal Bərpası.
   ATM-də olub serverdə olmayan C$ jurnal YYYYMMDD qovluqlarını serverə köçürür.
   ATM: C$\Journal | C$\JOURNAL\Journal  ->  Server: d$\JOURNAL_FILES\ATM_ID
   Backend: /api/jberpa/config|start|cancel|progress|history|detail|excel */
(function () {
'use strict';
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = id => document.getElementById(id);
const toast = (m, t) => { if (window.DS && DS.toast) DS.toast(m, t || 'info'); };
const can = key => { try { return !window.AtmAuth || typeof AtmAuth.can !== 'function' || AtmAuth.can(key); } catch (e) { return true; } };

const CATS = ['BƏRPA OLUNDU', 'YALNIZ YOXLAMA', 'QİSMƏN', 'ÇATIŞMAYAN YOXDUR', 'MƏNBƏ YOXDUR', 'QOŞULMADI', 'SERVER XƏTA', 'XƏTA', 'DAYANDIRILDI'];
const BADGE = {
  'BƏRPA OLUNDU': 'success', 'YALNIZ YOXLAMA': 'info', 'QİSMƏN': 'warning',
  'ÇATIŞMAYAN YOXDUR': 'neutral', 'MƏNBƏ YOXDUR': 'neutral', 'QOŞULMADI': 'neutral',
  'SERVER XƏTA': 'danger', 'XƏTA': 'danger', 'DAYANDIRILDI': 'neutral'
};

const S = {
  inited: false, runId: null, running: false, results: [], since: 0, timer: null,
  filter: 'ALL', query: '', polling: false, viewingHistory: false,
};

async function api(url, opts) {
  const r = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), Object.assign({ cache: 'no-store' }, opts || {}));
  let d = null;
  try { d = await r.json(); } catch (e) { /* */ }
  if (!r.ok || !d || d.success === false) throw new Error((d && d.error) || ('HTTP ' + r.status));
  return d;
}

/* ---------- format ---------- */
function fmtDT(iso) {
  if (!iso) return '—';
  const m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?/.exec(iso);
  return m ? `${m[3]}.${m[2]}.${m[1]} ${m[4]}:${m[5]}` : esc(iso);
}
function fmtBytes(n) {
  n = Number(n || 0);
  const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return (i === 0 ? n : n.toFixed(1)) + ' ' + u[i];
}
function fmtDur(sec) {
  sec = Number(sec || 0);
  if (sec < 60) return Math.round(sec) + ' san';
  const m = Math.floor(sec / 60), s = Math.round(sec % 60);
  return m < 60 ? `${m} dəq ${s} san` : `${Math.floor(m / 60)} saat ${m % 60} dəq`;
}
function cmp(a, b) {
  const rank = r => (r.missing_count || 0) > 0 ? 0 : 1;
  const ra = rank(a), rb = rank(b);
  if (ra !== rb) return ra - rb;
  if ((b.missing_count || 0) !== (a.missing_count || 0)) return (b.missing_count || 0) - (a.missing_count || 0);
  return String(a.atm_id).localeCompare(String(b.atm_id), undefined, { numeric: true, sensitivity: 'base' });
}

/* ---------- render ---------- */
function counts(list) { const c = {}; list.forEach(r => { c[r.status] = (c[r.status] || 0) + 1; }); return c; }
function renderStats(snap) {
  const c = counts(S.results);
  const total = snap ? snap.total : '—';
  const processed = snap ? snap.processed : S.results.length;
  const restored = snap ? snap.restored_total : S.results.reduce((a, r) => a + (r.restored_count || 0), 0);
  const files = snap ? snap.files_total : S.results.reduce((a, r) => a + (r.files_copied || 0), 0);
  const bytes = snap ? snap.bytes_total : S.results.reduce((a, r) => a + (r.bytes_copied || 0), 0);
  const failed = snap ? snap.failed_total : S.results.reduce((a, r) => a + (r.failed_count || 0), 0);
  $('jbProcessed').textContent = processed + ' / ' + total;
  $('jbRestored').textContent = restored || 0;
  $('jbFiles').textContent = files || 0;
  $('jbBytes').textContent = fmtBytes(bytes);
  $('jbFailed').textContent = failed || 0;
  $('jbNoConn').textContent = c['QOŞULMADI'] || 0;
}
function renderChips() {
  const c = counts(S.results);
  const items = [['ALL', 'Hamısı', S.results.length]].concat(CATS.filter(k => c[k]).map(k => [k, k, c[k]]));
  if (S.filter !== 'ALL' && !c[S.filter]) S.filter = 'ALL';
  $('jbChips').innerHTML = items.map(([k, label, n]) =>
    `<button type="button" class="vaChip${S.filter === k ? ' is-active' : ''}" data-k="${esc(k)}">${esc(label)} <b>${n}</b></button>`).join('');
  $('jbChips').querySelectorAll('.vaChip').forEach(b => b.onclick = () => { S.filter = b.dataset.k; renderChips(); renderTable(); });
}
let renderQueued = false;
function renderTable() {
  if (renderQueued) return;
  renderQueued = true;
  requestAnimationFrame(() => {
    renderQueued = false;
    const q = S.query.trim().toLowerCase();
    const rows = S.results.filter(r => (S.filter === 'ALL' || r.status === S.filter) &&
      (!q || [r.atm_id, r.name, r.region].some(v => String(v || '').toLowerCase().includes(q))));
    const tb = $('jbTable');
    if (!rows.length) {
      tb.innerHTML = `<tr><td colspan="14" class="vaEmpty">${S.results.length ? 'Filtrə uyğun nəticə yoxdur.' : (S.running ? 'Nəticələr gəldikcə burada görünəcək...' : 'Hələ nəticə yoxdur.')}</td></tr>`;
    } else {
      tb.innerHTML = rows.map((r, i) => {
        let note = r.error || '';
        if (r.failed_folders && r.failed_folders.length) {
          note = (note ? note + ' | ' : '') + 'Uğursuz: ' + r.failed_folders.slice(0, 4).map(x => `${x.name} (${x.error})`).join('; ');
        }
        const fol = (r.restored_folders && r.restored_folders.length) ? ' title="' + esc(r.restored_folders.join(', ')) + '"' : '';
        const tick = v => v ? '<span class="ds-badge ds-badge--success">bəli</span>' : '<span class="vaMuted">yox</span>';
        return `<tr class="vaRow vaRow--${BADGE[r.status] || 'neutral'}">
          <td>${i + 1}</td>
          <td><b class="vaAtm">${esc(r.atm_id)}</b></td>
          <td class="vaName" title="${esc(r.name)}">${esc(r.name || '—')}</td>
          <td><span class="ds-badge ds-badge--${BADGE[r.status] || 'neutral'}">${esc(r.status)}</span></td>
          <td>${tick(r.src1_found)}</td>
          <td>${tick(r.src2_found)}</td>
          <td>${r.atm_folder_count == null ? '—' : r.atm_folder_count}</td>
          <td>${r.server_folder_count == null ? '—' : r.server_folder_count}</td>
          <td><b${fol}>${r.missing_count == null ? '—' : r.missing_count}</b></td>
          <td>${r.restored_count || 0}</td>
          <td>${r.failed_count || 0}</td>
          <td>${r.files_copied || 0}</td>
          <td class="vaMono">${fmtBytes(r.bytes_copied)}</td>
          <td class="vaNote" title="${esc(note)}">${esc(note || '')}</td></tr>`;
      }).join('');
    }
    $('jbTableFoot').textContent = rows.length === S.results.length ? `${rows.length} ATM` : `${rows.length} / ${S.results.length} ATM göstərilir`;
  });
}
function renderAll(snap) { renderStats(snap); renderChips(); renderTable(); }

function setRunning(running) {
  S.running = running;
  const mayStart = can('jberpa.start');
  $('jbStartBtn').classList.toggle('hidden', running || !mayStart);
  $('jbStopBtn').classList.toggle('hidden', !running || !mayStart);
  $('jbStopBtn').disabled = false;
  $('jbExcelBtn').disabled = !S.runId || running || !S.results.length;
  $('jbExcelBtn').classList.toggle('hidden', !can('jberpa.export'));
}

/* ---------- progress ---------- */
function applySnapshot(d) {
  if (!d.run_id) return false;
  if (S.runId !== d.run_id || S.viewingHistory) {
    if (!d.running && S.viewingHistory) return false;
    S.runId = d.run_id; S.results = []; S.since = 0; S.viewingHistory = false;
  }
  (d.new_results || []).forEach(r => S.results.push(r));
  S.since = d.next_index || S.since;
  S.results.sort(cmp);
  const pct = Math.max(0, Math.min(100, Number(d.percent || 0)));
  $('jbFill').style.width = pct + '%';
  $('jbPercent').textContent = pct.toFixed(1).replace('.0', '') + '%';
  $('jbRunBadge').textContent = 'Bərpa #' + d.run_id;
  $('jbCurrent').textContent = (d.current_atms || []).slice(0, 6).join(', ') + ((d.current_atms || []).length > 6 ? ' …' : '') || '—';
  const logBox = $('jbLog');
  const stick = logBox.scrollTop + logBox.clientHeight >= logBox.scrollHeight - 20;
  logBox.textContent = (d.logs || []).join('\n') || '—';
  if (stick) logBox.scrollTop = logBox.scrollHeight;
  const mode = d.dry_run ? 'yalnız yoxlama' : 'bərpa';
  if (d.running) {
    $('jbState').textContent = d.cancel_requested ? 'Dayandırılır...' : 'Əməliyyat gedir (' + mode + ')...';
    $('jbMeta').textContent = `${d.processed} / ${d.total} ATM · paralel ${d.workers} · başlama ${fmtDT(d.started_at)}`;
  } else {
    $('jbState').textContent = d.error ? 'Xəta ilə bitdi' : d.cancel_requested ? 'Dayandırıldı' : 'Tamamlandı';
    $('jbMeta').textContent = d.error ? d.error : `${d.processed} / ${d.total} ATM · ${d.restored_total} qovluq bərpa · ${fmtDT(d.started_at)} → ${fmtDT(d.finished_at)}`;
  }
  setRunning(!!d.running);
  renderAll(d);
  return !!d.running;
}

async function poll() {
  if (S.polling) return;
  S.polling = true;
  try {
    const d = await api('/api/jberpa/progress?since=' + (S.viewingHistory ? 0 : S.since));
    const running = applySnapshot(d);
    if (!running && S.timer) {
      clearInterval(S.timer); S.timer = null;
      jberpaLoadHistory();
      if (!S.viewingHistory && S.results.length) toast('Journal Bərpası bitdi — Excel hesabatını yükləyə bilərsən.', 'success');
    }
    if (running && !S.timer) S.timer = setInterval(poll, 1500);
    return d;
  } catch (e) { /* müvəqqəti şəbəkə xətası */ }
  finally { S.polling = false; }
}

/* ---------- config/paths ---------- */
async function loadConfig() {
  try {
    const d = await api('/api/jberpa/config');
    if (d.active_atm_count != null) $('jbAllCount').textContent = '(' + d.active_atm_count + ')';
    const c = d.config || {};
    const atm = (c.atm_paths || []).map((p, i) => `${i + 1}) ${esc(p)}`).join('  ·  ');
    $('jbPaths').innerHTML = `ATM: ${atm || '—'}<br>Server: ${esc(c.server_path || '—')}${c.available ? '' : ' (konfiqdə yoxdur!)'}`;
  } catch (e) { $('jbPaths').textContent = 'Yollar alınmadı: ' + e.message; }
}

/* ---------- actions ---------- */
function parseList(text) {
  const seen = new Set(), out = [];
  String(text || '').split(/[\s,;]+/).forEach(x => {
    const a = x.trim().toUpperCase();
    if (/^[A-Z0-9._-]{1,64}$/.test(a) && !seen.has(a)) { seen.add(a); out.push(a); }
  });
  return out;
}
async function start() {
  const scope = (document.querySelector('input[name="jbScope"]:checked') || {}).value;
  let ids = null;
  if (scope === 'list') {
    ids = parseList($('jbList').value);
    if (!ids.length) { toast('Siyahıya ən azı bir ATM ID yaz.', 'warning'); $('jbList').focus(); return; }
  }
  const dry = $('jbDry').checked;
  if (!dry) {
    const scopeTxt = ids ? `${ids.length} ATM` : 'BÜTÜN aktiv ATM-lər';
    if (!confirm(`${scopeTxt} üzrə çatışmayan jurnal qovluqları serverə KÖÇÜRÜLƏCƏK.\n\nDavam edilsin?`)) return;
  }
  const btn = $('jbStartBtn'); btn.disabled = true;
  try {
    const d = await api('/api/jberpa/start', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.assign({ dry_run: dry }, ids ? { atm_ids: ids } : {}))
    });
    S.runId = d.run_id; S.results = []; S.since = 0; S.viewingHistory = false; S.filter = 'ALL';
    renderAll(null);
    toast('Əməliyyat #' + d.run_id + ' başladı.', 'success');
    await poll();
    if (!S.timer) S.timer = setInterval(poll, 1500);
  } catch (e) {
    toast('Başlamadı: ' + e.message, 'danger');
  } finally { btn.disabled = false; }
}
async function stop() {
  $('jbStopBtn').disabled = true;
  try { await api('/api/jberpa/cancel', { method: 'POST' }); toast('Dayandırılır — işləyən köçürmə bitən kimi dayanacaq.', 'info'); }
  catch (e) { toast(e.message, 'warning'); $('jbStopBtn').disabled = false; }
}
async function excel(runId) {
  if (!can('jberpa.export')) { toast('Excel yükləmək üçün icazən yoxdur.', 'warning'); return; }
  runId = runId || S.runId;
  if (!runId) { toast('Əvvəl əməliyyat et və ya tarixçədən seç.', 'warning'); return; }
  try {
    const r = await fetch('/api/jberpa/excel?id=' + encodeURIComponent(runId) + '&t=' + Date.now(), { cache: 'no-store' });
    const type = r.headers.get('Content-Type') || '';
    if (!r.ok || type.includes('json')) {
      let msg = 'HTTP ' + r.status; try { msg = (await r.json()).error || msg; } catch (e) { /* */ }
      throw new Error(msg);
    }
    const blob = await r.blob();
    const cd = r.headers.get('Content-Disposition') || '';
    const m = /filename="?([^";]+)"?/i.exec(cd);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = m ? m[1] : `Journal_Berpasi_${runId}.xlsx`;
    document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
    toast('Excel hazırdır: ' + a.download, 'success');
  } catch (e) { toast('Excel yüklənmədi: ' + e.message, 'danger'); }
}
async function openRun(runId) {
  try {
    const d = await api('/api/jberpa/detail?id=' + encodeURIComponent(runId));
    const run = d.run || {};
    S.runId = run.id; S.viewingHistory = true; S.filter = 'ALL';
    S.results = (d.results || []).slice().sort(cmp);
    const st = { COMPLETED: 'Tamamlandı', CANCELLED: 'Dayandırılıb', FAILED: 'Xəta ilə bitdi', RUNNING: 'Gedir...' }[run.status] || run.status;
    $('jbState').textContent = st + ' · tarixçə' + (run.dry_run ? ' (yalnız yoxlama)' : '');
    $('jbMeta').textContent = `${run.checked_count} / ${run.selected_count} ATM · ${run.restored_total || 0} qovluq bərpa · ${fmtDT(run.started_at)} → ${fmtDT(run.finished_at)}`;
    $('jbRunBadge').textContent = 'Bərpa #' + run.id;
    $('jbFill').style.width = '100%'; $('jbPercent').textContent = '100%';
    $('jbCurrent').textContent = '—';
    renderAll({ total: run.selected_count, processed: run.checked_count, restored_total: run.restored_total, files_total: run.files_total, bytes_total: run.bytes_total, failed_total: run.failed_total });
    setRunning(S.running);
    $('jbExcelBtn').disabled = !S.results.length;
  } catch (e) { toast('Açılmadı: ' + e.message, 'danger'); }
}
async function loadHistory() {
  const tb = $('jbHistory');
  try {
    const d = await api('/api/jberpa/history?limit=50');
    const runs = d.runs || [];
    if (!runs.length) { tb.innerHTML = '<tr><td colspan="11" class="vaEmpty">Hələ əməliyyat edilməyib.</td></tr>'; return runs; }
    const stAz = { COMPLETED: ['TAMAMLANDI', 'success'], CANCELLED: ['DAYANDIRILDI', 'warning'], RUNNING: ['İŞLƏYİR', 'info'], FAILED: ['XƏTA', 'danger'] };
    tb.innerHTML = runs.map(r => {
      const [t, c] = stAz[r.status] || [r.status, 'neutral'];
      return `<tr class="${r.id === S.runId ? 'selected' : ''}">
        <td><b>#${r.id}</b></td><td>${fmtDT(r.started_at)}</td>
        <td>${r.dry_run ? 'Yoxlama' : 'Bərpa'}</td>
        <td><span class="ds-badge ds-badge--${c}">${esc(t)}</span></td>
        <td>${r.checked_count} / ${r.selected_count}</td><td>${r.restored_total || 0}</td><td>${r.failed_total || 0}</td>
        <td>${r.files_total || 0}</td><td>${fmtBytes(r.bytes_total)}</td><td>${r.status === 'RUNNING' ? '—' : esc(fmtDur(r.duration_seconds))}</td>
        <td class="vaHistActs"><button type="button" class="btnGray ds-btn--sm" data-open="${r.id}">Bax</button>
          ${can('jberpa.export') ? `<button type="button" class="btnGreen ds-btn--sm" data-xl="${r.id}" ${r.status === 'RUNNING' || !r.checked_count ? 'disabled' : ''}>Excel</button>` : ''}</td></tr>`;
    }).join('');
    tb.querySelectorAll('[data-open]').forEach(b => b.onclick = () => openRun(Number(b.dataset.open)));
    tb.querySelectorAll('[data-xl]').forEach(b => b.onclick = () => excel(Number(b.dataset.xl)));
    return runs;
  } catch (e) {
    tb.innerHTML = `<tr><td colspan="11" class="vaEmpty">Tarixçə alınmadı: ${esc(e.message)}</td></tr>`;
    return [];
  }
}

async function init() {
  if (!S.inited) {
    S.inited = true;
    document.querySelectorAll('input[name="jbScope"]').forEach(r => r.onchange = () => {
      $('jbList').classList.toggle('hidden', r.value !== 'list' || !r.checked);
      if (r.value === 'list' && r.checked) $('jbList').focus();
    });
  }
  await loadConfig();
  const d = await poll();
  const runs = await loadHistory();
  if (d && !d.run_id && !S.results.length && runs.length) {
    const last = runs.find(r => r.checked_count > 0);
    if (last) await openRun(last.id);
  }
}

window.jberpaInit = init;
window.jberpaStart = start;
window.jberpaStop = stop;
window.jberpaExcel = () => excel();
window.jberpaLoadHistory = loadHistory;
})();
