/* BIR SPARK — Ana səhifə ATM siyahısı + toplu qoşulma + əməliyyat pəncərəsi (2 klik).
   Mövcud endpoint-lərdən istifadə edir (backend dəyişmir):
   /api/atms, /api/atms/bulk_start, /api/atms/bulk_progress, /api/atms/resolve-ips,
   /api/archive/start (ATM C$/D$), /api/srvexp/* (server). */
(function () {
'use strict';
var $ = function (id) { return document.getElementById(id); };
var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]); }); };
var toast = function (m, t) { if (window.DS && DS.toast) DS.toast(m, t || 'info'); };

var HA = { rows: [], ip: {}, bulkTimer: null, inited: false, cur: null, atmBrowser: null, srvBrowser: null, mode: 'atm' };

function statusOf(r) {
  if (r.last_info_ok === 1 || r.last_connection_ok === 1) return 'on';
  if (r.last_connection_at || r.last_info_at || r.last_connection_ok === 0) return 'off';
  return 'unk';
}
function statusLabel(s) { return s === 'on' ? 'Online' : s === 'off' ? 'Offline' : 'Yoxlanmayıb'; }

async function loadAtms() {
  var body = $('haBody');
  try {
    var r = await fetch('/api/atms?state=visible&t=' + Date.now(), { cache: 'no-store' });
    var d = await r.json();
    if (!d.success) throw new Error(d.error || 'Alınmadı');
    HA.rows = d.rows || [];
    render();
  } catch (e) { body.innerHTML = '<tr><td colspan="6" class="haEmpty">Siyahı alınmadı: ' + esc(e.message || e) + '</td></tr>'; }
}

function filtered() {
  var q = ($('haSearch').value || '').trim().toUpperCase();
  var f = $('haFilter').value;
  return HA.rows.filter(function (r) {
    if (f !== 'all' && statusOf(r) !== f) return false;
    if (!q) return true;
    return (r.atm_id || '').toUpperCase().indexOf(q) >= 0
      || (r.region || '').toUpperCase().indexOf(q) >= 0
      || (r.name || '').toUpperCase().indexOf(q) >= 0
      || (r.last_os_name || '').toUpperCase().indexOf(q) >= 0;
  });
}

function render() {
  var list = filtered();
  $('haCount').textContent = list.length + ' / ' + HA.rows.length + ' ATM';
  if (!list.length) { $('haBody').innerHTML = '<tr><td colspan="6" class="haEmpty">Uyğun ATM yoxdur.</td></tr>'; return; }
  var cap = list.slice(0, 600); // performans: ilk 600 sətir
  $('haBody').innerHTML = cap.map(function (r) {
    var s = statusOf(r);
    var cpu = (r.last_cpu_percent != null && r.last_info_ok === 1) ? Math.round(r.last_cpu_percent) + '% / ' + Math.round(r.last_ram_percent || 0) + '%' : '—';
    var ip = HA.ip[(r.atm_id || '').toUpperCase()] || '—';
    var reg = esc(r.region || '—') + (r.name ? '<div class="ds-caption" style="font-size:10px">' + esc(r.name) + '</div>' : '');
    return '<tr data-atm="' + esc(r.atm_id) + '">'
      + '<td class="haAtmId">' + esc(r.atm_id) + '</td>'
      + '<td>' + reg + '</td>'
      + '<td>' + esc(r.last_os_name || '—') + '</td>'
      + '<td class="haMono">' + esc(ip) + '</td>'
      + '<td>' + cpu + '</td>'
      + '<td><span class="haStatus ' + s + '"><span class="d"></span>' + statusLabel(s) + '</span></td></tr>';
  }).join('') + (list.length > 600 ? '<tr><td colspan="6" class="haEmpty">... yalnız ilk 600 göstərilir, axtarışdan istifadə et.</td></tr>' : '');
  var sel = null;
  $('haBody').querySelectorAll('tr[data-atm]').forEach(function (tr) {
    tr.onclick = function () { $('haBody').querySelectorAll('tr.is-sel').forEach(function (x) { x.classList.remove('is-sel'); }); tr.classList.add('is-sel'); };
    tr.ondblclick = function () { openDrawer(tr.dataset.atm); };
  });
}

/* ---------- IP həll ---------- */
async function resolveVisibleIps() {
  var list = filtered().slice(0, 300).map(function (r) { return r.atm_id; }).filter(Boolean);
  if (!list.length) return;
  var btn = $('haResolveIp'); btn.disabled = true;
  try {
    var r = await fetch('/api/atms/resolve-ips?atms=' + encodeURIComponent(list.join(',')) + '&t=' + Date.now(), { cache: 'no-store' });
    var d = await r.json();
    if (d && d.ips) { Object.keys(d.ips).forEach(function (k) { HA.ip[k.toUpperCase()] = d.ips[k]; }); render(); toast('IP-lər həll olundu.', 'success'); }
  } catch (e) { toast('IP həll alınmadı.', 'warning'); }
  finally { btn.disabled = false; }
}

/* ---------- Toplu qoşulma ---------- */
async function bulkStart() {
  if (!confirm('Aktiv bütün ATM-lərdə qoşulma (PASSWORD slotları) yoxlanacaq. Bu uzun çəkə bilər. Başlayaq?')) return;
  try {
    var r = await fetch('/api/atms/bulk_start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    var d = await r.json();
    if (!r.ok || !d.success) throw new Error(d.error || 'Başlamadı');
    $('haBulkBar').classList.remove('hidden');
    bulkPoll(); if (!HA.bulkTimer) HA.bulkTimer = setInterval(bulkPoll, 1200);
  } catch (e) { toast(e.message || e, 'danger'); }
}
async function bulkStop() {
  try { await fetch('/api/atms/bulk_cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); } catch (e) {}
}
async function bulkPoll() {
  try {
    var r = await fetch('/api/atms/bulk_progress?t=' + Date.now(), { cache: 'no-store' });
    var d = await r.json(); if (!d.success) return;
    $('haBulkState').textContent = d.running ? 'İŞLƏYİR' : (d.finished ? (d.cancel_requested ? 'DAYANDIRILIB' : 'TAMAMLANIB') : 'Gözləyir');
    $('haBulkCur').textContent = d.current_atm || '—';
    $('haBulkOk').textContent = d.success_count || 0;
    $('haBulkFail').textContent = d.failed_count || 0;
    $('haBulkProc').textContent = d.processed || 0;
    $('haBulkTotal').textContent = d.total || 0;
    var pct = Math.max(0, Math.min(100, Number(d.percent || 0)));
    $('haBulkFill').style.width = pct + '%';
    $('haBulk').disabled = !!d.running;
    $('haBulkStop').classList.toggle('hidden', !d.running);
    if (!d.running && HA.bulkTimer) { clearInterval(HA.bulkTimer); HA.bulkTimer = null; loadAtms(); }
    else if (d.running && (d.processed % 10 === 0)) { loadAtms(); } // ara-sıra cədvəli yenilə
  } catch (e) {}
}

/* ---------- Əməliyyat pəncərəsi (drawer) ---------- */
function openDrawer(atm) {
  var r = HA.rows.find(function (x) { return (x.atm_id || '').toUpperCase() === String(atm).toUpperCase(); });
  if (!r) return;
  HA.cur = r;
  $('haDrAtm').textContent = r.atm_id;
  $('haDrSub').textContent = (r.name || '') + (r.region ? ' · ' + r.region : '');
  var s = statusOf(r);
  var ip = HA.ip[(r.atm_id || '').toUpperCase()] || '—';
  $('haDrInfo').innerHTML =
    cell('Status', '<span class="haStatus ' + s + '"><span class="d"></span>' + statusLabel(s) + '</span>')
    + cell('Əməliyyat sistemi', esc(r.last_os_name || '—'))
    + cell('IP', '<span class="haMono">' + esc(ip) + '</span>')
    + cell('Region', esc(r.region || '—'))
    + cell('RİM', esc(r.rim || '—'))
    + cell('CPU / RAM', (r.last_info_ok === 1 ? Math.round(r.last_cpu_percent || 0) + '% / ' + Math.round(r.last_ram_percent || 0) + '%' : '—'))
    + cell('PASSWORD slot', esc(r.password_env || '—'))
    + cell('Son qoşulma', esc((r.last_connection_at || '—').replace('T', ' ')));
  $('haDrawerOverlay').classList.remove('hidden');
  $('haDrawer').classList.remove('hidden');
  setMode('atm');
  // IP yoxdursa fonda həll et
  if (ip === '—') resolveOne(r.atm_id);
}
function cell(label, val) { return '<div class="cell"><span>' + esc(label) + '</span><b>' + val + '</b></div>'; }
async function resolveOne(atm) {
  try {
    var r = await fetch('/api/atms/resolve-ips?atms=' + encodeURIComponent(atm) + '&t=' + Date.now(), { cache: 'no-store' });
    var d = await r.json(); var ip = d && d.ips && d.ips[String(atm).toUpperCase()];
    if (ip) { HA.ip[String(atm).toUpperCase()] = ip; if (HA.cur && HA.cur.atm_id === atm) openDrawer(atm); }
  } catch (e) {}
}
function closeDrawer() {
  $('haDrawer').classList.add('hidden'); $('haDrawerOverlay').classList.add('hidden');
  $('haDrBrowse').innerHTML = ''; HA.atmBrowser = null; HA.srvBrowser = null;
}
function setMode(mode) {
  HA.mode = mode;
  document.querySelectorAll('.haModeBtn').forEach(function (b) { b.classList.toggle('is-active', b.dataset.mode === mode); });
  var host = $('haDrBrowse');
  host.innerHTML = '<div id="haBrowseInner"></div>';
  if (!window.createBrowser) { host.innerHTML = '<div class="ds-alert">Browser modulu yüklənmədi.</div>'; return; }
  if (mode === 'atm') {
    HA.atmBrowser = window.createBrowser({ root: 'haBrowseInner', forceDisks: ['C', 'D', 'E'], kind: 'media' });
    // ATM-i avtomatik doldur + qoşul
    setTimeout(function () {
      var inp = host.querySelector('.bfAtm'), btn = host.querySelector('.bfConnectBtn');
      if (inp) inp.value = HA.cur.atm_id;
      if (btn) btn.click();
    }, 50);
  } else {
    HA.srvBrowser = window.createBrowser({ root: 'haBrowseInner', mode: 'server', endpoint: 'srvexp', kind: 'media' });
    // server rejimi: disklər dərhal yüklənir; axtarış qutusuna ATM ID yaz (kömək üçün)
    setTimeout(function () { var se = host.querySelector('.bfSearch'); if (se) se.placeholder = HA.cur.atm_id + ' qovluğunu axtar...'; }, 60);
  }
}
function quickAction(act) {
  var atm = HA.cur && HA.cur.atm_id; if (!atm) return;
  closeDrawer();
  var top = $('topATM'); if (top) top.value = atm;
  if (act === 'atminfo') {
    if (typeof openModule === 'function') openModule('atminfo');
    var s = $('aiSearch'); if (s) s.value = atm;
    if (typeof atmInfoLoadList === 'function') atmInfoLoadList();
  } else if (act === 'system') {
    if (typeof openModule === 'function') openModule('system');
    var si = $('sysATM'); if (si) { si.value = atm; si.focus(); }
  } else if (act === 'restart') {
    if (typeof openModule === 'function') openModule('restart');
    var ri = $('restartATM'); if (ri) { ri.value = atm; ri.focus(); }
  } else if (act === 'diskreport') {
    if (typeof openModule === 'function') openModule('diskreport');
  }
}

/* ---------- init ---------- */
window.homeAtmsInit = function () {
  if (!HA.inited) {
    HA.inited = true;
    $('haSearch').oninput = render;
    $('haFilter').onchange = render;
    $('haRefresh').onclick = loadAtms;
    $('haResolveIp').onclick = resolveVisibleIps;
    $('haBulk').onclick = bulkStart;
    $('haBulkStop').onclick = bulkStop;
    $('haDrClose').onclick = closeDrawer;
    $('haDrawerOverlay').onclick = closeDrawer;
    document.querySelectorAll('.haModeBtn').forEach(function (b) { b.onclick = function () { setMode(b.dataset.mode); }; });
    document.querySelectorAll('.haActBtn').forEach(function (b) { b.onclick = function () { quickAction(b.dataset.act); }; });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('haDrawer').classList.contains('hidden')) closeDrawer(); });
  }
  loadAtms();
  // davam edən toplu qoşulma varsa göstər
  fetch('/api/atms/bulk_progress?t=' + Date.now(), { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (d) {
    if (d && d.success && d.running) { $('haBulkBar').classList.remove('hidden'); bulkPoll(); if (!HA.bulkTimer) HA.bulkTimer = setInterval(bulkPoll, 1200); }
  }).catch(function () {});
};
})();
