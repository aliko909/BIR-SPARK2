/* =====================================================================
   ATM WEB — AUTH CLIENT
   - bütün /api sorğularına CSRF başlığı əlavə edir, 401-də refresh token ilə səssiz yeniləyir
   - /api/me-dən istifadəçi + icazələri alır və UI-a tətbiq edir (menyu, modul, düymə, blok, sütun)
   - naviqasiya və klikləri audit üçün serverə göndərir
   Qeyd: UI-da gizlətmə rahatlıq üçündür; əsl qoruma serverdədir (auth.js ROUTES).
   ===================================================================== */
(function () {
'use strict';
const A = window.AtmAuth = { me: null, current: 'home' };
const nativeFetch = window.fetch.bind(window);
const HDR = { 'X-Requested-With': 'atm-web' };
const bc = ('BroadcastChannel' in window) ? new BroadcastChannel('atm-auth') : null;
let refreshing = null, refreshTimer = null, nextRefreshAt = 0, leaving = false;

function toLogin(q) { if (leaving) return; leaving = true; location.replace('/login.html' + (q || '')); }
if (bc) bc.onmessage = e => { if (e.data === 'logout') toLogin(); else if (e.data === 'perms') A.reload(); };

function apiPath(input) {
  const u = typeof input === 'string' ? input : (input && input.url) || '';
  try { const x = new URL(u, location.href); return x.origin === location.origin && x.pathname.startsWith('/api/') ? x.pathname : null; } catch (e) { return null; }
}
function scheduleRefresh(ttl) {
  clearTimeout(refreshTimer);
  const ms = Math.max(5, (ttl || 900) - 60) * 1000;
  nextRefreshAt = Date.now() + ms;
  refreshTimer = setTimeout(() => doRefresh(), ms);
}
/* 'ok' | 'denied' (sessiya bitib) | 'error' (şəbəkə/server problemi — login-ə atmırıq) */
function doRefresh() {
  if (refreshing) return refreshing;
  const run = async () => {
    try {
      const r = await nativeFetch('/api/auth/refresh', { method: 'POST', headers: HDR, cache: 'no-store' });
      if (r.status === 401) return 'denied';
      if (!r.ok) return 'error';
      scheduleRefresh(A.me ? A.me.access_ttl : 900);
      return 'ok';
    } catch (e) { return 'error'; }
  };
  refreshing = (navigator.locks ? navigator.locks.request('atm-auth-refresh', run) : run()).catch(() => 'error').finally(() => { refreshing = null; });
  return refreshing;
}
A.refresh = doRefresh;

let reloadPending = null;
window.fetch = async function (input, init) {
  const p = apiPath(input);
  if (!p) return nativeFetch(input, init);
  init = Object.assign({}, init);
  const h = new Headers(init.headers || (input instanceof Request ? input.headers : undefined));
  h.set('X-Requested-With', 'atm-web'); init.headers = h;
  let r = await nativeFetch(input, init);
  if (r.status === 401 && !p.startsWith('/api/auth/')) {
    const st = await doRefresh();
    if (st === 'ok') r = await nativeFetch(input, init);
    else if (st === 'denied') toLogin();
  } else if (r.status === 403) {
    r.clone().json().then(d => {
      if (d && d.code === 'PASSWORD_CHANGE_REQUIRED') toLogin('?change=1');
      else if (d && d.code === 'FORBIDDEN' && !reloadPending) reloadPending = setTimeout(() => { reloadPending = null; A.reload(); }, 1500);
    }).catch(() => {});
  }
  return r;
};

/* ---------------- me / can ---------------- */
A.can = function (key) {
  const me = A.me; if (!me) return false;
  if (me.user.is_admin) return true;
  return A.allow.has(key) && A.allow.has(key.split('.')[0]);
};
function setMe(d) { A.me = d; A.allow = new Set(d.perms.allow || []); A.catalog = d.catalog || []; }
A.init = async function () {
  const r = await fetch('/api/me', { cache: 'no-store' });
  if (!r.ok) { toLogin(); throw new Error('Sessiya yoxdur.'); }
  const d = await r.json();
  if (d.user.must_change_password) { toLogin('?change=1'); throw new Error('Şifrə dəyişdirilməlidir.'); }
  setMe(d);
  scheduleRefresh(d.access_expires_at - d.server_time);
  document.addEventListener('visibilitychange', () => { if (!document.hidden && Date.now() >= nextRefreshAt) doRefresh(); });
  return d;
};
A.reload = async function () {
  try {
    const r = await fetch('/api/me', { cache: 'no-store' }); if (!r.ok) return;
    const d = await r.json(); const before = JSON.stringify(A.me && [A.me.perms, A.me.user]);
    setMe(d);
    if (before !== JSON.stringify([d.perms, d.user])) { applyPerms(); renderUserChip(); if (A.current !== 'home' && !A.can(A.current)) openFirstAllowed(); }
  } catch (e) {}
};

/* ---------------- İcazələrin UI-a tətbiqi ---------------- */
const orig = {};          // bloklanmış funksiyaların orijinalları
const HIDE = 'perm-hidden';
function denied() { if (window.DS && DS.toast) DS.toast('Bu əməliyyat üçün icazəniz yoxdur.', 'danger', 4000); }
function deniedFns() {
  const set = new Set();
  A.catalog.forEach(m => m.items.forEach(it => { if (it.fns && !A.can(it.key)) it.fns.forEach(f => set.add(f)); }));
  // eyni funksiya icazəli başqa bir açarda da varsa bloklama
  A.catalog.forEach(m => m.items.forEach(it => { if (it.fns && A.can(it.key)) it.fns.forEach(f => set.delete(f)); }));
  return set;
}
function allFns() { const s = new Set(); A.catalog.forEach(m => m.items.forEach(it => (it.fns || []).forEach(f => s.add(f)))); return s; }
function moduleKeyOf(mod, tab) { return mod === 'backup' && tab === 'history' ? 'history' : mod; }
function onclickInfo(el) {
  const src = el.getAttribute('onclick') || '';
  let m = /openModule\(\s*'(\w+)'(?:\s*,\s*'(\w+)')?/.exec(src);
  if (m) return { module: moduleKeyOf(m[1], m[2]) };
  m = /homeJump\(\s*'(\w+)'/.exec(src);
  if (m) return { module: m[1], fn: 'homeJump' };
  m = /^\s*(?:if\s*\([^)]*\))?\s*([A-Za-z_$][\w$]*)\s*\(/.exec(src);
  return { fn: m ? m[1] : '' };
}
let denySet = new Set();
function scanDom() {
  document.querySelectorAll('[onclick]').forEach(el => {
    if (el.closest('#usersModule,#auditModule,.authModal')) return;
    const info = onclickInfo(el);
    const hide = (info.module && info.module !== 'home' && !A.can(info.module)) || (info.fn && denySet.has(info.fn));
    if (hide) { el.classList.add(HIDE); el.dataset.permScan = '1'; }
    else if (el.dataset.permScan) { el.classList.remove(HIDE); delete el.dataset.permScan; }
  });
  applyColumnLocks();
}
function norm(s) { return String(s || '').replace(/\s+/g, ' ').trim(); }
function headerCells(t) { const row = t.tHead && (t.tHead.querySelector('tr.head') || t.tHead.rows[0]); return row ? [...row.cells] : []; }
A.tableKey = function (t) { const b = t.tBodies[0]; return (b && b.id) || t.id || ''; };
function applyColumnLocks() {
  const hide = A.me.user.is_admin ? {} : (A.me.perms.hideCols || {});
  document.querySelectorAll('#moduleHost table').forEach(t => {
    if (t.dataset.permCols === 'off' || t.closest('.leaflet-container')) return;
    const key = A.tableKey(t); if (!key) return;
    const names = new Set((hide[key] || []).map(norm));
    const idx = new Set(); headerCells(t).forEach((h, i) => { if (names.has(norm(h.textContent))) idx.add(i); });
    const sig = [...idx].join(',');
    if (t.dataset.permLocked === sig && (!t.__dsTable || t.__dsTable.lockedCols === t.__dsLocked)) return;
    t.dataset.permLocked = sig;
    if (window.DS && DS.lockColumns) DS.lockColumns(t, idx);
  });
}
/* İcazə idarəetmə pəncərəsi üçün: səhifədəki bütün cədvəllər və sütunları */
A.tableCatalog = function () {
  const map = { homeModule: 'home', atmInventoryModule: 'inventory', atmMapModule: 'map', diskReportModule: 'diskreport', backupModule: 'backup', restartModule: 'restart', archiveModule: 'archive', systemModule: 'system', agentModule: 'agent', atmInfoModule: 'atminfo' };
  const out = [];
  document.querySelectorAll('#moduleHost table').forEach(t => {
    if (t.dataset.permCols === 'off' || t.closest('.leaflet-container')) return;
    const key = A.tableKey(t); if (!key) return;
    const host = t.closest('#moduleHost > *'); let module = host ? map[host.id] : null; if (!module) return;
    if (module === 'backup' && t.closest('#historyTab')) module = 'history';
    const cols = headerCells(t).map(h => norm(h.textContent)).filter(Boolean);
    const box = t.closest('.panel,.ds-card,section,details') || t.parentElement;
    const title = box && box.querySelector('.ds-title,.sectionTitle,h3,b');
    out.push({ key, module, label: norm(title && title.textContent).replace(/—.*$/, '').trim() || key, cols });
  });
  return out;
};
function applyPerms() {
  const me = A.me; if (!me) return;
  // sol menyu
  A.catalog.forEach(m => (m.menu || []).forEach(id => { const el = document.getElementById(id); if (el) el.classList.toggle(HIDE, !A.can(m.key)); }));
  document.querySelectorAll('#sidebar .sidebarTitle').forEach(t => {
    let any = false;
    for (let n = t.nextElementSibling; n && !n.classList.contains('sidebarTitle'); n = n.nextElementSibling) {
      const items = n.matches('.menuBtn') ? [n] : [...n.querySelectorAll('.menuBtn')];
      if (items.some(b => !b.classList.contains(HIDE) && !b.closest('.' + HIDE))) any = true;
    }
    t.classList.toggle(HIDE, !any);
  });
  // bloklar / selektorlar
  A.catalog.forEach(m => m.items.forEach(it => (it.sel || []).forEach(sel => {
    let els = []; try { els = document.querySelectorAll(sel); } catch (e) {}
    els.forEach(el => el.classList.toggle(HIDE, !A.can(it.key)));
  })));
  // funksiyaların bloklanması (düymə gizlənsə belə konsoldan / başqa yoldan çağırılmasın)
  denySet = deniedFns();
  allFns().forEach(fn => {
    if (denySet.has(fn)) { if (typeof window[fn] === 'function' && !orig[fn]) { orig[fn] = window[fn]; window[fn] = function () { denied(); }; } }
    else if (orig[fn]) { window[fn] = orig[fn]; delete orig[fn]; }
  });
  scanDom();
}
A.applyPerms = applyPerms;

/* ---------------- Naviqasiya qoruyucuları ---------------- */
const ADMIN = { users: { id: 'usersModule', menu: 'menuUsers', title: 'İstifadəçilər', sub: 'İstifadəçi hesabları · giriş icazəsi · şifrə sıfırlama · modul və sütun icazələri' },
                audit: { id: 'auditModule', menu: 'menuAudit', title: 'Audit log', sub: 'Kim, nə vaxt, hansı modula girdi və nə etdi' } };
function hideAdmin() { Object.values(ADMIN).forEach(a => document.getElementById(a.id)?.classList.add('hidden')); document.getElementById('noAccessPanel')?.classList.add('hidden'); if (window.AtmAdmin) AtmAdmin.stop(); }
function firstAllowed() { const m = A.catalog.find(x => A.can(x.key)); return m ? m.key : null; }
function openFirstAllowed() {
  const k = firstAllowed();
  if (!k) { baseOpen('__none__'); hideAdmin(); document.getElementById('noAccessPanel')?.classList.remove('hidden'); document.getElementById('pageTitle').textContent = 'İcazə yoxdur'; document.getElementById('pageSubtitle').textContent = ''; return; }
  if (k === 'home') window.openHome(); else if (k === 'history') window.openModule('backup', 'history'); else window.openModule(k);
}
let baseOpen = () => {}, baseHome = () => {};
function installGuards() {
  baseOpen = window.openModule; baseHome = window.openHome; const baseTab = window.showTab;
  window.openHome = function () {
    if (!A.can('home')) { denied(); return; }
    hideAdmin(); A.current = 'home'; track('nav', 'home', 'open', 'Ana səhifə'); return baseHome.apply(this, arguments);
  };
  window.openModule = function (module, tab, close) {
    if (module === 'home') return window.openHome();
    const key = moduleKeyOf(module, tab);
    if (!A.can(key)) { denied(); track('nav', key, 'denied', 'icazəsiz keçid cəhdi'); return; }
    if (ADMIN[module]) {
      const a = ADMIN[module];
      baseOpen('__none__', 'live', close !== false); hideAdmin();
      document.getElementById(a.id).classList.remove('hidden');
      document.getElementById('pageTitle').textContent = a.title; document.getElementById('pageSubtitle').textContent = a.sub;
      if (typeof window.setMenuActive === 'function') setMenuActive(a.menu);
      A.current = module; track('nav', module, 'open', a.title);
      if (window.AtmAdmin) AtmAdmin.open(module);
      window.scrollTo({ top: 0, behavior: 'instant' });
      return;
    }
    hideAdmin(); A.current = key; track('nav', key, 'open', '');
    return baseOpen.call(this, module, tab === undefined ? 'live' : tab, close === undefined ? true : close);
  };
  if (typeof baseTab === 'function') window.showTab = function (tab) {
    if (tab === 'history' && !A.can('history')) { denied(); return; }
    if (tab === 'live' && !A.can('backup')) { if (A.can('history')) return baseTab.call(this, 'history'); denied(); return; }
    A.current = tab === 'history' ? 'history' : 'backup';
    return baseTab.apply(this, arguments);
  };
}

/* ---------------- Audit izləmə ---------------- */
let queue = [], flushTimer = null;
function track(type, module, action, detail) {
  queue.push({ type, module: module || A.current, action: String(action || '').slice(0, 120), detail: String(detail || '').slice(0, 200) });
  if (queue.length >= 20) flush(); else if (!flushTimer) flushTimer = setTimeout(flush, 4000);
}
function flush() {
  clearTimeout(flushTimer); flushTimer = null;
  if (!queue.length || leaving) return;
  const events = queue; queue = [];
  nativeFetch('/api/audit/track', { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, HDR), body: JSON.stringify({ events }), keepalive: true }).catch(() => {});
}
A.track = track;
document.addEventListener('click', e => {
  if (!A.me) return;
  const t = e.target instanceof Element ? e.target : null; if (!t) return;
  // icazəsiz modula aparan mənbə sətirləri
  if (t.closest('#homeSources button') && !A.can('backup')) { e.stopPropagation(); e.preventDefault(); denied(); return; }
  const el = t.closest('button,a,summary,[onclick],[role=button]'); if (!el) return;
  const info = el.hasAttribute('onclick') ? onclickInfo(el) : {};
  const action = info.fn || (info.module ? 'openModule:' + info.module : '') || el.id || el.dataset.act || 'click';
  let detail = norm(el.textContent).slice(0, 80) || el.getAttribute('title') || el.getAttribute('aria-label') || '';
  const tr = el.closest('tbody tr');
  if (tr && tr.cells.length > 1) detail += ' [sətir: ' + norm(tr.cells[1].textContent).slice(0, 40) + ']';
  track('click', A.current, action, detail);
}, true);
window.addEventListener('pagehide', flush);

/* ---------------- İstifadəçi paneli (yuxarı sağ) ---------------- */
function el(tag, attrs, kids) {
  const n = document.createElement(tag);
  for (const k in (attrs || {})) { const v = attrs[k]; if (v == null || v === false) continue; if (k === 'class') n.className = v; else if (k === 'text') n.textContent = v; else if (k.startsWith('on')) n.addEventListener(k.slice(2), v); else if (k === 'html') n.innerHTML = v; else n.setAttribute(k, v === true ? '' : v); }
  (kids || []).forEach(c => { if (c != null) n.append(c); });
  return n;
}
A.el = el;
function renderUserChip() {
  const u = A.me.user, row = document.querySelector('.appHeaderRow'); if (!row) return;
  document.getElementById('userChip')?.remove();
  const full = (u.first_name + ' ' + u.last_name).trim() || u.username;
  const initials = ((u.first_name[0] || '') + (u.last_name[0] || '') || u.username.slice(0, 2)).toUpperCase();
  const menu = el('div', { class: 'userMenu hidden', role: 'menu' }, [
    el('div', { class: 'userMenu__head' }, [el('b', { text: full }), el('small', { text: '@' + u.username + (u.is_admin ? ' · Administrator' : '') }), u.position ? el('small', { text: u.position }) : null, u.phone ? el('small', { text: u.phone }) : null]),
    el('button', { class: 'ds-btn ds-btn--secondary', type: 'button', 'data-act': 'change-password', onclick: () => { menu.classList.add('hidden'); A.changePasswordDialog(); }, html: DS.icon('key-round') + '<span>Şifrəni dəyiş</span>' }),
    el('button', { class: 'ds-btn ds-btn--secondary userMenu__out', type: 'button', 'data-act': 'logout', onclick: () => A.logout(), html: DS.icon('power') + '<span>Çıxış</span>' }),
  ]);
  const chip = el('div', { id: 'userChip', class: 'userChip' }, [
    el('button', { class: 'userChip__btn', type: 'button', 'aria-haspopup': 'true', 'data-act': 'user-menu', onclick: e => { e.stopPropagation(); menu.classList.toggle('hidden'); } }, [
      el('span', { class: 'userChip__avatar', text: initials }),
      el('span', { class: 'userChip__text' }, [el('b', { text: full }), el('small', { text: u.position || (u.is_admin ? 'Administrator' : u.username) })]),
    ]), menu]);
  row.appendChild(chip);
  document.addEventListener('click', e => { if (!chip.contains(e.target)) menu.classList.add('hidden'); });
}
A.logout = async function () {
  flush();
  try { await nativeFetch('/api/auth/logout', { method: 'POST', headers: HDR }); } catch (e) {}
  if (bc) bc.postMessage('logout');
  toLogin();
};
A.modal = function (title, body, buttons, wide) {
  const overlay = el('div', { class: 'ds-modal-overlay authModal' });
  const close = () => overlay.remove();
  const foot = el('div', { class: 'ds-modal__foot' });
  (buttons || []).forEach(b => foot.append(el('button', { type: 'button', class: 'ds-btn ' + (b.cls || 'ds-btn--secondary'), text: b.label, 'data-act': b.act || 'modal-btn', onclick: () => b.onclick ? b.onclick(close) : close() })));
  const box = el('div', { class: 'ds-modal' + (wide ? ' ds-modal--wide' : ''), role: 'dialog', 'aria-modal': 'true' }, [
    el('div', { class: 'ds-modal__head' }, [el('h3', { text: title }), el('button', { class: 'ds-btn ds-btn--secondary ds-btn--icon', type: 'button', 'aria-label': 'Bağla', onclick: close, html: DS.icon('x') })]),
    el('div', { class: 'ds-modal__body' }, [body]), foot]);
  overlay.append(box);
  overlay.addEventListener('mousedown', e => { if (e.target === overlay) close(); });
  overlay.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
  document.body.append(overlay);
  const first = box.querySelector('input,select,textarea'); if (first) first.focus();
  return { overlay, close };
};
A.confirm = function (title, message, okLabel, danger) {
  return new Promise(resolve => {
    const m = A.modal(title, el('p', { class: 'authConfirmText', text: message }), [
      { label: 'Ləğv et', onclick: c => { c(); resolve(false); } },
      { label: okLabel || 'Təsdiq et', cls: danger ? 'ds-btn--danger' : 'ds-btn--primary', onclick: c => { c(); resolve(true); } }]);
    m.overlay.querySelector('.ds-btn--icon').addEventListener('click', () => resolve(false));
  });
};
A.field = function (label, input, help) { return el('div', { class: 'ds-field' }, [el('label', { class: 'ds-label', text: label }), input, help ? el('span', { class: 'ds-help', text: help }) : null]); };
A.post = async function (url, body) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
  let d = {}; try { d = await r.json(); } catch (e) {}
  if (!r.ok || !d.success) throw new Error(d.error || ('HTTP ' + r.status));
  return d;
};
A.changePasswordDialog = function () {
  const cur = el('input', { type: 'password', autocomplete: 'current-password' }), n1 = el('input', { type: 'password', autocomplete: 'new-password' }), n2 = el('input', { type: 'password', autocomplete: 'new-password' });
  const err = el('div', { class: 'ds-alert ds-alert--danger hidden' });
  const body = el('div', { class: 'ds-form' }, [A.field('Cari şifrə', cur), A.field('Yeni şifrə', n1, 'Ən azı 8 simvol, ən azı bir hərf və bir rəqəm.'), A.field('Yeni şifrə (təkrar)', n2), err]);
  A.modal('Şifrəni dəyiş', body, [{ label: 'Ləğv et' }, { label: 'Yadda saxla', cls: 'ds-btn--primary', act: 'change-password-save', onclick: async close => {
    err.classList.add('hidden');
    if (n1.value !== n2.value) { err.textContent = 'Yeni şifrələr üst-üstə düşmür.'; err.classList.remove('hidden'); return; }
    try { await A.post('/api/auth/change-password', { current: cur.value, password: n1.value }); close(); DS.toast('Şifrə dəyişdirildi. Digər cihazlardakı sessiyalar bağlandı.', 'success'); }
    catch (e) { err.textContent = e.message; err.classList.remove('hidden'); }
  } }]);
};

/* ---------------- app.js yükləndikdən sonra ---------------- */
A.afterAppLoad = function () {
  installGuards();
  renderUserChip();
  applyPerms();
  let pend = null;
  new MutationObserver(() => { if (!pend) pend = setTimeout(() => { pend = null; scanDom(); }, 120); }).observe(document.getElementById('moduleHost'), { childList: true, subtree: true });
  const ipTreeEl = document.getElementById('ipTree');
  if (ipTreeEl) new MutationObserver(() => applyPermsMenu()).observe(ipTreeEl, { childList: true });
  if (!A.can('home')) openFirstAllowed(); else A.current = 'home';
  document.documentElement.classList.remove('auth-pending');
  setInterval(() => { if (!document.hidden) A.reload(); }, 60000);
  track('nav', A.current, 'session_open', 'Səhifə açıldı');
};
function applyPermsMenu() { const t = document.getElementById('ipTree'); if (t) t.classList.toggle(HIDE, !A.can('backup')); }
})();
