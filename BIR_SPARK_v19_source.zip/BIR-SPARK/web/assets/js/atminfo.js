/* ATM WEB — ATM Info modulu: siyahi + sag drawer (detal/connect/tarixce). */
(function () {
'use strict';
const $ = id => document.getElementById(id);
const A = () => window.AtmAuth;
let rows = [], current = null, busy = false, searchTimer = null, lastSnapshots = {};

/* ---------- formatlar ---------- */
function fmtBytes(n) { n = Number(n); if (!Number.isFinite(n) || n < 0) return '—'; const u = ['B','KB','MB','GB','TB']; let i = 0; while (n >= 1024 && i < u.length-1) { n /= 1024; i++; } return (i >= 3 ? n.toFixed(1) : Math.round(n)) + ' ' + u[i]; }
function fmtUptime(s) { s = Number(s); if (!Number.isFinite(s) || s <= 0) return '—'; const d = Math.floor(s/86400), h = Math.floor(s%86400/3600), m = Math.floor(s%3600/60); return (d ? d+' gün ' : '') + h + ' saat ' + m + ' dəq'; }
function pct(v) { v = Number(v); return Number.isFinite(v) ? v : null; }
function esc(s) { return String(s == null ? '' : s); }
function dt(s) { if (!s) return '—'; const d = new Date(String(s).replace(' ', 'T')); if (isNaN(d)) return esc(s); const p = n => String(n).padStart(2,'0'); return `${p(d.getDate())}.${p(d.getMonth()+1)}.${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`; }
function setBar(id, v) { const el = $(id); if (!el) return; const p = pct(v); el.style.width = (p == null ? 0 : Math.min(100, Math.max(0, p))) + '%'; el.classList.toggle('high', p != null && p >= 85); }
function text(id, v) { const el = $(id); if (el) el.textContent = (v == null || v === '') ? '—' : v; }

/* ---------- siyahi ---------- */
window.atmInfoInit = function () { atmInfoLoadList(); };
window.atmInfoSearchDebounced = function () { clearTimeout(searchTimer); searchTimer = setTimeout(atmInfoLoadList, 300); };

window.atmInfoLoadList = async function () {
  const state = ($('aiState') && $('aiState').value) || 'visible';
  const q = ($('aiSearch') && $('aiSearch').value || '').trim();
  try {
    const r = await fetch('/api/atms?state=' + encodeURIComponent(state) + '&query=' + encodeURIComponent(q) + '&t=' + Date.now(), { cache: 'no-store' });
    const d = await r.json();
    if (!d.success) throw new Error(d.error || 'Yüklənmədi');
    rows = d.rows || [];
    renderList(d.stats);
    if (current) { const u = rows.find(x => Number(x.id) === Number(current.id)); if (u) current = u; }
  } catch (e) { DS.toast(String(e.message || e), 'danger'); }
};
function renderList(stats) {
  $('aiCount').textContent = rows.length + ' ATM';
  const online = rows.filter(x => x.last_info_ok === 1).length;
  const offline = rows.filter(x => x.last_info_ok === 0).length;
  text('aiStatTotal', stats ? stats.total : rows.length);
  text('aiStatActive', stats ? stats.active : rows.filter(x => x.status === 1 && x.is_deleted === 0).length);
  text('aiStatOnline', online); text('aiStatOffline', offline);
  text('aiStatPw', stats ? stats.password_found : rows.filter(x => x.password_env).length);
  const body = $('aiListRows'); body.replaceChildren();
  if (!rows.length) { const tr = document.createElement('tr'); tr.innerHTML = '<td colspan="13">ATM tapılmadı.</td>'; body.appendChild(tr); return; }
  rows.forEach((x, i) => {
    const tr = document.createElement('tr'); tr.className = 'atmInfoRow' + (current && Number(current.id) === Number(x.id) ? ' is-sel' : '');
    tr.dataset.id = x.id;
    const statusBadge = x.is_deleted ? '<span class="ds-badge ds-badge--dot ds-badge--danger">Silinib</span>' : (x.status ? '<span class="ds-badge ds-badge--dot ds-badge--success">Aktiv</span>' : '<span class="ds-badge ds-badge--dot ds-badge--warning">Deaktiv</span>');
    const cpu = pct(x.last_cpu_percent), ram = pct(x.last_ram_percent);
    const okDot = x.last_info_ok === 1 ? '<i class="aiDot ok"></i>' : (x.last_info_ok === 0 ? '<i class="aiDot fail"></i>' : '<i class="aiDot unk"></i>');
    tr.innerHTML =
      '<td>' + (i + 1) + '</td>' +
      '<td><b class="mono">' + esc(x.atm_id) + '</b></td>' +
      '<td class="aiIp mono" data-atm="' + esc(x.atm_id) + '">…</td>' +
      '<td>' + esc(x.name || '—') + '</td>' +
      '<td>' + esc(x.region || '—') + '</td>' +
      '<td>' + esc(x.rim || '—') + '</td>' +
      '<td>' + esc(x.atype || '—') + '</td>' +
      '<td>' + esc(x.sys_address || '—') + '</td>' +
      '<td>' + esc(x.phys_address || '—') + '</td>' +
      '<td>' + statusBadge + '</td>' +
      '<td>' + (cpu == null ? '—' : cpu + '%') + '</td>' +
      '<td>' + (ram == null ? '—' : ram + '%') + '</td>' +
      '<td>' + okDot + ' ' + dt(x.last_info_at) + '</td>';
    body.appendChild(tr);
  });
  resolveIpsInto(body, rows.map(x => x.atm_id));
}

/* ATM IP-lərini toplu həll edib cədvələ yazır (gethostbyname, serverdə cache) */
function resolveIpsInto(scopeEl, atmIds) {
  const cells = scopeEl.querySelectorAll('.aiIp[data-atm]');
  if (!cells.length) return;
  const ids = Array.from(new Set(atmIds.map(a => String(a || '').toUpperCase()).filter(Boolean)));
  fetch('/api/atms/resolve-ips?atms=' + encodeURIComponent(ids.join(',')) + '&t=' + Date.now(), { cache: 'no-store' })
    .then(r => r.json()).then(d => {
      const ips = (d && d.ips) || {};
      cells.forEach(c => { const ip = ips[String(c.dataset.atm).toUpperCase()]; c.textContent = ip || '—'; });
    }).catch(() => { cells.forEach(c => { c.textContent = '—'; }); });
}

/* ---------- Excel/CSV report (RİM, Ad, Region, ünvanlar daxil) ---------- */
window.atmInfoExportCSV = function () {
  if (!rows.length) { DS.toast('Report üçün sətir yoxdur.', 'warning'); return; }
  const head = ['ATM ID', 'Ad', 'Region', 'RİM', 'Tip', 'Sistemdəki ünvan', 'Yerləşdiyi ünvan',
    'Latitude', 'Longitude', 'PASSWORD slotu', 'Windows növü', 'Status',
    'Son CPU %', 'Son RAM %', 'OS', 'Son info', 'Son qoşulma'];
  const lines = [head];
  rows.forEach(x => lines.push([
    x.atm_id, x.name || '', x.region || '', x.rim || '', x.atype || '',
    x.sys_address || '', x.phys_address || '', x.latitude ?? '', x.longitude ?? '',
    x.password_env || '', x.windows_type || '',
    x.is_deleted ? 'Silinib' : (x.status ? 'Aktiv' : 'Deaktiv'),
    pct(x.last_cpu_percent) ?? '', pct(x.last_ram_percent) ?? '', x.last_os_name || '',
    x.last_info_at || '', x.last_connection_at || ''
  ]));
  const csv = '﻿' + lines.map(r => r.map(v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"').join(';')).join('\r\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'ATM_INFO_REPORT_' + new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-') + '.csv';
  document.body.appendChild(a); a.click(); URL.revokeObjectURL(a.href); a.remove();
  if (window.DS) DS.toast(rows.length + ' ATM report-a yazıldı.', 'success');
};
document.addEventListener('click', function (e) {
  const tr = e.target.closest && e.target.closest('#aiListRows tr.atmInfoRow');
  if (!tr || e.target.closest('button,a,input,select')) return;
  atmInfoOpenRow(Number(tr.dataset.id));
});

/* ---------- drawer ---------- */
window.atmInfoOpenRow = function (id) {
  const row = rows.find(x => Number(x.id) === Number(id)); if (!row) return;
  current = row;
  $('atmInfoDrawer').classList.remove('hidden');
  $('atmInfoDrawerOverlay').classList.remove('hidden');
  document.querySelectorAll('#aiListRows tr').forEach(t => t.classList.toggle('is-sel', Number(t.dataset.id) === Number(id)));
  text('aiDrawerId', row.atm_id); text('aiDrawerName', row.name || '');
  $('aiDelBtn').textContent = ''; const di = document.createElement('span');
  $('aiDelBtn').innerHTML = row.is_deleted ? DS.icon('rotate-ccw') + '<span>Bərpa et</span>' : DS.icon('trash-2') + '<span>Sil</span>';
  $('aiDrawerState').className = 'atmInfoState'; $('aiDrawerState').textContent = 'Qoşulma üçün "Qoşul və yoxla".';
  atmInfoTab('info');
  renderStatic(row);
  renderSnapshot(null);
  // serverdən son online snapshot-u çək
  fetch('/api/atminfo/latest?atm=' + encodeURIComponent(row.atm_id) + '&t=' + Date.now(), { cache: 'no-store' })
    .then(r => r.json()).then(d => { if (d.success && current && current.atm_id === d.atm && d.snapshot) renderSnapshot(d.snapshot, true); }).catch(() => {});
  if (A()) A().track('click', 'atminfo', 'open_atm', row.atm_id);
};
window.atmInfoCloseDrawer = function () { $('atmInfoDrawer').classList.add('hidden'); $('atmInfoDrawerOverlay').classList.add('hidden'); current = null; document.querySelectorAll('#aiListRows tr').forEach(t => t.classList.remove('is-sel')); };
window.atmInfoTab = function (which) {
  document.querySelectorAll('.atmInfoTab').forEach(b => b.classList.toggle('is-active', b.dataset.tab === which));
  $('aiTabInfo').classList.toggle('hidden', which !== 'info');
  $('aiTabHist').classList.toggle('hidden', which !== 'hist');
  if (which === 'hist') atmInfoLoadHistory();
};
function kv(label, value, mono) { return '<div class="atmInfoKvRow"><span>' + esc(label) + '</span><b' + (mono ? ' class="mono"' : '') + '>' + esc(value == null || value === '' ? '—' : value) + '</b></div>'; }
function renderStatic(row) {
  $('aiStatic').innerHTML =
    kv('ATM ID', row.atm_id, true) + kv('Ad', row.name) + kv('Region', row.region) + kv('Tip', row.atype) +
    kv('RİM', row.rim) + kv('Sistemdəki ünvan', row.sys_address) + kv('Yerləşdiyi ünvan', row.phys_address) +
    kv('Latitude', row.latitude, true) + kv('Longitude', row.longitude, true) +
    kv('Status', row.is_deleted ? 'Silinib' : (row.status ? 'Aktiv' : 'Deaktiv')) +
    kv('PASSWORD slotu', row.password_env) +
    kv('Son qoşulma', dt(row.last_connection_at)) + kv('Son info yoxlaması', dt(row.last_info_at));
}
function renderSnapshot(x, fromDb) {
  const card = $('aiStatusCard'); card.classList.remove('ds-stat--success', 'ds-stat--danger');
  if (!x) {
    text('aiStatusVal', '—'); text('aiCpuVal', '—'); text('aiRamVal', '—'); setBar('aiCpuBar', 0); setBar('aiRamBar', 0);
    $('aiSys').innerHTML = '<div class="atmInfoKvRow"><span>Məlumat yoxdur</span><b>— hələ qoşulma olmayıb —</b></div>';
    $('aiDiskRows').innerHTML = '<tr><td colspan="7">Məlumat yoxdur.</td></tr>'; $('aiSnapWhen').textContent = '';
    return;
  }
  card.classList.add('ds-stat--success'); text('aiStatusVal', 'Online');
  const cpu = pct(x.cpu_percent), ram = pct(x.ram_percent);
  text('aiCpuVal', cpu == null ? '—' : cpu + '%'); setBar('aiCpuBar', cpu);
  text('aiRamVal', ram == null ? '—' : ram + '%'); setBar('aiRamBar', ram);
  $('aiSnapWhen').textContent = (fromDb ? 'bazadan · ' : '') + dt(x.collected_at) + (x.method ? ' · port ' + x.method : '');
  $('aiSys').innerHTML =
    kv('Hostname', x.hostname) + kv('Əməliyyat sistemi', x.os_name) +
    kv('Versiya / build', [x.os_version, x.os_build].filter(Boolean).join(' · ')) + kv('Arxitektura', x.os_architecture) +
    kv('CPU', x.cpu_name) + kv('Nüvə sayı', x.cpu_cores) +
    kv('RAM', (x.ram_total_bytes ? fmtBytes(x.ram_total_bytes) : '—')) +
    kv('Uptime', fmtUptime(x.uptime_seconds)) + kv('Boot vaxtı', x.boot_time);
  const disks = Array.isArray(x.disks) ? x.disks : [];
  const body = $('aiDiskRows'); body.innerHTML = '';
  if (!disks.length) { body.innerHTML = '<tr><td colspan="7">Disk məlumatı yoxdur.</td></tr>'; return; }
  disks.forEach(d => {
    const up = pct(d.used_percent);
    const tr = document.createElement('tr');
    tr.innerHTML = '<td>' + esc(d.name) + '</td><td>' + esc(d.label || '—') + '</td><td>' + esc(d.filesystem || '—') + '</td>' +
      '<td>' + fmtBytes(d.total_bytes) + '</td><td>' + fmtBytes(d.used_bytes) + '</td><td>' + fmtBytes(d.free_bytes) + '</td>' +
      '<td class="' + (up != null && up >= 85 ? 'aiHigh' : '') + '">' + (up == null ? '—' : up + '%') + '</td>';
    body.appendChild(tr);
  });
}

/* ---------- connect ---------- */
window.atmInfoConnect = async function () {
  if (!current || busy) return;
  const atm = current.atm_id, method = ($('aiMethod').value === '135') ? '135' : '445';
  busy = true; const btn = $('aiConnectBtn'); btn.disabled = true; btn.setAttribute('aria-busy', 'true');
  const st = $('aiDrawerState'); st.className = 'atmInfoState is-loading';
  st.textContent = atm + ' → port ' + method + ' ilə qoşulur...' + (method === '445' ? ' (collect.bat → atminfo.json)' : ' (WMI/RPC)');
  try {
    const r = await fetch('/api/atminfo/run', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ atm, method }) });
    const d = await r.json();
    if (!d.success) { st.className = 'atmInfoState is-off'; st.textContent = 'XƏTA · ' + (d.error || ('HTTP ' + r.status)); }
    else if (!d.online) { st.className = 'atmInfoState is-off'; st.textContent = 'OFLAYN · ' + (d.error || 'ATM cavab vermir') + (d.detail ? ' — ' + d.detail : ''); renderSnapshot(null); }
    else {
      st.className = 'atmInfoState is-on'; st.textContent = 'ONLINE · port ' + (d.method || method) + ' · ' + (d.password_env || '') + ' · ' + (d.latency_ms != null ? d.latency_ms + ' ms' : '');
      const snap = d.data || {}; snap.collected_at = snap.collected_at; snap.method = d.method || method;
      renderSnapshot(snap);
    }
    atmInfoLoadList();
    if ($('aiTabHist') && !$('aiTabHist').classList.contains('hidden')) atmInfoLoadHistory();
  } catch (e) { st.className = 'atmInfoState is-off'; st.textContent = 'Server xətası: ' + (e.message || e); }
  finally { busy = false; btn.disabled = false; btn.removeAttribute('aria-busy'); }
};

/* ---------- tarixce ---------- */
window.atmInfoLoadHistory = async function () {
  if (!current) return;
  const body = $('aiHistRows'); body.innerHTML = '<tr><td colspan="6">Yüklənir...</td></tr>';
  try {
    const r = await fetch('/api/atminfo/history?atm=' + encodeURIComponent(current.atm_id) + '&limit=100&t=' + Date.now(), { cache: 'no-store' });
    const d = await r.json(); if (!d.success) throw new Error(d.error);
    body.innerHTML = '';
    if (!d.rows.length) { body.innerHTML = '<tr><td colspan="6">Tarixçə yoxdur.</td></tr>'; return; }
    d.rows.forEach(x => {
      const tr = document.createElement('tr'); tr.className = 'atmInfoHistRow'; tr.dataset.snap = x.id; tr.style.cursor = x.online ? 'pointer' : 'default';
      const res = x.online ? '<span class="ds-badge ds-badge--dot ds-badge--success">Online</span>' : '<span class="ds-badge ds-badge--dot ds-badge--danger" title="' + esc(x.error || '') + '">Oflayn</span>';
      tr.innerHTML = '<td class="mono">' + dt(x.collected_at) + '</td><td>' + esc(x.method || '—') + '</td><td>' + res + '</td>' +
        '<td>' + (pct(x.cpu_percent) == null ? '—' : x.cpu_percent + '%') + '</td><td>' + (pct(x.ram_percent) == null ? '—' : x.ram_percent + '%') + '</td><td>' + esc(x.os_name || '—') + '</td>';
      if (x.online) tr.addEventListener('click', () => atmInfoViewSnapshot(x.id));
      body.appendChild(tr);
    });
  } catch (e) { body.innerHTML = '<tr><td colspan="6">Xəta: ' + esc(e.message || e) + '</td></tr>'; }
};
window.atmInfoViewSnapshot = async function (id) {
  try {
    const r = await fetch('/api/atminfo/snapshot?id=' + encodeURIComponent(id) + '&t=' + Date.now(), { cache: 'no-store' });
    const d = await r.json(); if (!d.success) throw new Error(d.error);
    atmInfoTab('info'); renderSnapshot(d.snapshot, true);
    $('aiDrawerState').className = 'atmInfoState'; $('aiDrawerState').textContent = 'Tarixçədən seçilmiş qeyd: ' + dt(d.snapshot.collected_at);
  } catch (e) { DS.toast(String(e.message || e), 'danger'); }
};

/* ---------- add / edit / delete ---------- */
function atmForm(row) {
  const a = A(), el = a.el, isNew = !row; row = row || { status: 1 };
  const f = {
    atm_id: el('input', { value: row.atm_id || '', autocomplete: 'off', placeholder: 'A0100077', maxlength: 40 }),
    name: el('input', { value: row.name || '', maxlength: 160 }),
    region: el('input', { value: row.region || '', maxlength: 160 }),
    atype: el('input', { value: row.atype || '', maxlength: 160, placeholder: 'Region_filial / DTX ...' }),
    rim: el('input', { value: row.rim || '', maxlength: 160 }),
    latitude: el('input', { value: row.latitude != null ? row.latitude : '', type: 'number', step: 'any', placeholder: '40.4093' }),
    longitude: el('input', { value: row.longitude != null ? row.longitude : '', type: 'number', step: 'any', placeholder: '49.8671' }),
    sys_address: el('input', { value: row.sys_address || '', maxlength: 160 }),
    phys_address: el('input', { value: row.phys_address || '', maxlength: 160 }),
    status: el('input', { type: 'checkbox', class: 'ds-switch' }),
  };
  f.status.checked = row.status !== 0;
  const connect = el('input', { type: 'checkbox', class: 'ds-switch' }); if (isNew) connect.checked = true;
  const err = el('div', { class: 'ds-alert ds-alert--danger hidden' });
  const body = el('div', { class: 'ds-form authFormGrid' }, [
    a.field('ATM ID', f.atm_id), a.field('Ad', f.name), a.field('Region', f.region), a.field('Tip', f.atype),
    a.field('RİM', f.rim), a.field('Latitude', f.latitude), a.field('Longitude', f.longitude),
    a.field('Sistemdəki ünvan', f.sys_address), a.field('Yerləşdiyi ünvan', f.phys_address),
    el('label', { class: 'ds-inline-field' }, [f.status, el('span', { text: 'Aktiv ATM' })]),
    isNew ? el('label', { class: 'ds-inline-field' }, [connect, el('span', { text: 'Əlavə etdikdən sonra dərhal qoşul və məlumatı çək' })]) : el('div'),
    err,
  ]);
  a.modal(isNew ? 'Yeni ATM' : 'ATM: ' + row.atm_id, body, [{ label: 'Ləğv et' }, { label: 'Yadda saxla', cls: 'ds-btn--primary', act: isNew ? 'atm-create' : 'atm-edit', onclick: async close => {
    err.classList.add('hidden');
    const payload = { id: row.id || 0 };
    Object.keys(f).forEach(k => { payload[k] = (k === 'status') ? f.status.checked : f[k].value; });
    try {
      const d = await a.post('/api/atms/save', payload);
      close();
      await atmInfoLoadList();
      const saved = (d.row && d.row.id) ? rows.find(x => Number(x.id) === Number(d.row.id)) : null;
      if (saved) atmInfoOpenRow(saved.id);
      DS.toast(isNew ? 'ATM əlavə olundu.' : 'Yadda saxlandı.', 'success');
      if (isNew && connect.checked && saved) { current = saved; setTimeout(atmInfoConnect, 200); }
    } catch (e) { err.textContent = e.message; err.classList.remove('hidden'); }
  } }]);
}
window.atmInfoOpenNew = function () { atmForm(null); };
window.atmInfoOpenEdit = function () { if (current) atmForm(current); };
window.atmInfoDeleteCurrent = async function () {
  if (!current) return; const a = A(), row = current;
  if (row.is_deleted) {
    try { await a.post('/api/atms/restore', { id: row.id }); DS.toast('Bərpa olundu.', 'success'); await atmInfoLoadList(); atmInfoOpenRow(row.id); } catch (e) { DS.toast(e.message, 'danger'); }
    return;
  }
  if (!await a.confirm('ATM sil', '"' + row.atm_id + '" silinsin? (soft delete — bazada qalır, status = silinib)', 'Sil', true)) return;
  try { await a.post('/api/atms/delete', { id: row.id }); DS.toast('Silindi.', 'success'); atmInfoCloseDrawer(); atmInfoLoadList(); } catch (e) { DS.toast(e.message, 'danger'); }
};
window.atmInfoDelete = window.atmInfoDeleteCurrent;
window.atmInfoRestore = window.atmInfoDeleteCurrent;
})();
