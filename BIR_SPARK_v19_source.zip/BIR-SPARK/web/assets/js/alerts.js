/* Xəbərdarlıqlar (Alerts) — avtomatik şəkil/jurnal/backup yoxlaması.
   Modul UI + qlobal bildiriş (yan menyu badge + toast proqram işləyərkən).
   Backend: /api/alerts/* */
(function () {
'use strict';
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = id => document.getElementById(id);
const toast = (m, t) => { if (window.DS && DS.toast) DS.toast(m, t || 'info'); };

async function api(url, opts) {
  const r = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), Object.assign({ cache: 'no-store' }, opts || {}));
  let d = null; try { d = await r.json(); } catch (e) {}
  if (!r.ok || !d || d.success === false) throw new Error((d && d.error) || ('HTTP ' + r.status));
  return d;
}
function fmtDT(iso) {
  if (!iso) return '—';
  const m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})/.exec(iso);
  return m ? `${m[3]}.${m[2]}.${m[1]} ${m[4]}:${m[5]}` : esc(iso);
}
const KIND_BADGE = { IMAGE: 'danger', JOURNAL: 'danger', BACKUP: 'warning', CONN: 'neutral', IMAGE_OLD: 'warning', JOURNAL_OLD: 'warning' };
const A = { alerts: [], inited: false, progTimer: null };

/* ---------- Modul ---------- */
window.alertsInit = function () {
  A.inited = true;
  alertsLoadConfig();
  alertsLoad();
  alertsPollProgress(true);
  srvAlertLoadConfig();
  srvAlertPoll(true);
};
window.alertsExcel = function () {
  window.location = '/api/alerts/excel?status=all&t=' + Date.now();
};

/* ---------- Server (77) backup xəbərdarlığı ---------- */
async function srvAlertLoadConfig() {
  try {
    const d = await api('/api/srvalert/config'); const c = d.config || {};
    if ($('saEnabled')) {
      $('saEnabled').value = String(c.enabled ? 1 : 0);
      $('saInterval').value = c.interval_minutes || 180;
      $('saMaxDays').value = c.max_days != null ? c.max_days : 2;
      $('saMail').checked = !!c.mail_on;
    }
  } catch (e) {}
}
window.srvAlertSaveConfig = async function () {
  const body = { enabled: $('saEnabled').value === '1' ? 1 : 0,
    interval_minutes: parseInt($('saInterval').value, 10) || 180,
    max_days: parseInt($('saMaxDays').value, 10), mail_on: $('saMail').checked ? 1 : 0 };
  try {
    await api('/api/srvalert/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    toast('Server yoxlama parametrləri saxlanıldı.', 'success'); srvAlertPoll(true);
  } catch (e) { toast(String(e.message || e), 'danger'); }
};
window.srvAlertRun = async function () {
  $('saRunBtn').disabled = true;
  try { await api('/api/srvalert/run', { method: 'POST' }); toast('Server (77) yoxlaması başladı — bitəndə Excel Bildirişlərə düşəcək.', 'info'); srvAlertPoll(true); }
  catch (e) { toast(String(e.message || e), 'danger'); }
  finally { setTimeout(() => { $('saRunBtn').disabled = false; }, 1500); }
};
function srvAlertApply(s) {
  const sm = s.last_summary || {};
  if ($('saTotal')) {
    $('saTotal').textContent = sm.total != null ? sm.total : '—';
    $('saProblem').textContent = sm.problem != null ? sm.problem : '—';
    $('saOk').textContent = sm.ok != null ? sm.ok : '—';
    $('saProg').textContent = s.busy ? ((s.processed || 0) + ' / ' + (s.total || 0)) : (s.busy === false ? 'hazır' : '—');
  }
  if ($('saState')) $('saState').textContent = s.scheduler_on ? '● Avtomatik AKTİVDİR' : '○ söndürülüb';
  if ($('saLastRun')) $('saLastRun').textContent = s.last_run ? ('Son: ' + fmtDT(s.last_run)) : '';
}
function srvAlertPoll(immediate) {
  if (A.saTimer) { clearInterval(A.saTimer); A.saTimer = null; }
  const tick = async () => {
    if (!$('alertsModule') || $('alertsModule').classList.contains('hidden')) { clearInterval(A.saTimer); A.saTimer = null; return; }
    try { srvAlertApply(await api('/api/srvalert/summary')); } catch (e) {}
  };
  if (immediate) tick();
  A.saTimer = setInterval(tick, 3000);
}
async function alertsLoadConfig() {
  try {
    const d = await api('/api/alerts/config');
    const c = d.config || {};
    $('alEnabled').value = String(c.enabled ? 1 : 0);
    $('alInterval').value = c.interval_minutes || 180;
    $('alImgDays').value = c.image_max_days != null ? c.image_max_days : 2;
    $('alJrnDays').value = c.journal_max_days != null ? c.journal_max_days : 2;
    $('alChkImg').checked = !!c.check_images;
    $('alChkJrn').checked = !!c.check_journals;
    $('alChkSrv').checked = !!c.check_server;
    $('alMail').checked = !!c.mail_on;
  } catch (e) {}
}
window.alertsSaveConfig = async function () {
  const body = {
    enabled: $('alEnabled').value === '1' ? 1 : 0,
    interval_minutes: parseInt($('alInterval').value, 10) || 180,
    image_max_days: parseInt($('alImgDays').value, 10),
    journal_max_days: parseInt($('alJrnDays').value, 10),
    check_images: $('alChkImg').checked ? 1 : 0,
    check_journals: $('alChkJrn').checked ? 1 : 0,
    check_server: $('alChkSrv').checked ? 1 : 0,
    mail_on: $('alMail').checked ? 1 : 0,
  };
  try {
    await api('/api/alerts/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    toast('Parametrlər yadda saxlanıldı.', 'success');
    alertsPollProgress(true);
  } catch (e) { toast(String(e.message || e), 'danger'); }
};
window.alertsRunNow = async function () {
  $('alRunBtn').disabled = true;
  try {
    await api('/api/alerts/run', { method: 'POST' });
    toast('Yoxlama başladı — bütün aktiv ATM-lər yoxlanılır.', 'info');
    $('alProgCard').style.display = '';
    alertsPollProgress(true);
  } catch (e) { toast(String(e.message || e), 'danger'); }
  finally { setTimeout(() => { $('alRunBtn').disabled = false; }, 1500); }
};
window.alertsLoad = async function () {
  try {
    const status = ($('alFilter') && $('alFilter').value) || 'active';
    const d = await api('/api/alerts/list?status=' + status);
    A.alerts = d.alerts || [];
    alertsRenderTable();
  } catch (e) {}
};
window.alertsRenderTable = function () {
  const tb = $('alTable'); if (!tb) return;
  const rows = A.alerts;
  if (!rows.length) { tb.innerHTML = '<tr><td colspan="8" class="vaEmpty">Xəbərdarlıq yoxdur — hər şey qaydasındadır.</td></tr>'; $('alTableFoot').textContent = ''; return; }
  tb.innerHTML = rows.map((a, i) =>
    `<tr${a.status === 'resolved' ? ' style="opacity:.55"' : ''}><td>${i + 1}</td><td class="mono">${esc(a.atm_id)}</td>`
    + `<td><span class="ds-badge ds-badge--${KIND_BADGE[a.kind] || 'neutral'}">${esc(a.kind_label || a.kind)}</span></td>`
    + `<td>${a.severity === 'problem' ? '<b style="color:var(--c-danger)">PROBLEM</b>' : 'xəbərdarlıq'}</td>`
    + `<td>${esc(a.message || '')}</td><td>${fmtDT(a.first_seen)}</td><td>${fmtDT(a.last_seen)}</td>`
    + `<td>${a.status === 'active' ? 'aktiv' : 'həll olunub'}</td></tr>`
  ).join('');
  const active = rows.filter(r => r.status === 'active').length;
  $('alTableFoot').textContent = `${rows.length} sətir · aktiv: ${active}`;
};
function alertsApplySummary(s) {
  const by = s.by_kind || {};
  if ($('alCntTotal')) {
    $('alCntTotal').textContent = s.active_total || 0;
    $('alCntImage').textContent = (by.IMAGE || 0) + (by.IMAGE_OLD || 0);
    $('alCntJournal').textContent = (by.JOURNAL || 0) + (by.JOURNAL_OLD || 0);
    $('alCntBackup').textContent = by.BACKUP || 0;
    $('alCntConn').textContent = by.CONN || 0;
  }
  if ($('alSchedState')) $('alSchedState').textContent = s.scheduler_on ? '● Avtomatik yoxlama AKTİVDİR' : '○ Avtomatik yoxlama söndürülüb';
  if ($('alLastRun')) $('alLastRun').textContent = s.last_run ? ('Son yoxlama: ' + fmtDT(s.last_run)) : '';
  const card = $('alProgCard');
  if (card) {
    if (s.busy) {
      card.style.display = '';
      const pct = s.total ? Math.round(100 * s.processed / s.total) : 0;
      $('alProgFill').style.width = pct + '%';
      $('alProgPct').textContent = pct + '%';
      $('alProgCount').textContent = (s.processed || 0) + ' / ' + (s.total || 0);
      $('alProgBadge').textContent = 'İŞLƏYİR';
      $('alProgState').textContent = 'ATM-lər yoxlanılır...';
    } else {
      $('alProgBadge').textContent = 'HAZIR';
      if (card.style.display !== 'none') setTimeout(() => { if (!A.lastBusy) card.style.display = 'none'; }, 1200);
    }
  }
  A.lastBusy = s.busy;
}
function alertsPollProgress(immediate) {
  if (A.progTimer) { clearInterval(A.progTimer); A.progTimer = null; }
  const tick = async () => {
    try {
      const s = await api('/api/alerts/summary');
      if (!$('alertsModule') || $('alertsModule').classList.contains('hidden')) { clearInterval(A.progTimer); A.progTimer = null; return; }
      alertsApplySummary(s);
      if (!s.busy && A.wasBusy) alertsLoad();  // yoxlama bitdi → cədvəli yenilə
      A.wasBusy = s.busy;
    } catch (e) {}
  };
  if (immediate) tick();
  A.progTimer = setInterval(tick, 2500);
}

/* ---------- Bildirişlər (hesabat qutusu) ---------- */
const MODULE_LABEL = { alerts: 'ATM Xəbərdarlıq', server77: 'Server (77)', vascan: 'VIDEOARCHIVE', cmp: 'Müqayisə', ajscan: 'ATM Jurnal', monitor: 'Foto Monitorinq', diskreport: 'Disk Report' };
function fmtSize(b) { b = Number(b || 0); return b < 1024 ? b + ' B' : b < 1048576 ? (b / 1024).toFixed(0) + ' KB' : (b / 1048576).toFixed(1) + ' MB'; }
window.notifInit = function () { notifLoad(); };
window.notifLoad = async function () {
  const tb = $('notifTable'); if (!tb) return;
  try {
    const d = await api('/api/reports/list');
    const rows = d.reports || [];
    if (!rows.length) { tb.innerHTML = '<tr><td colspan="7" class="vaEmpty">Hələ hesabat yoxdur. Scan/yoxlama etdikcə Excel-lər buraya düşəcək.</td></tr>'; $('notifFoot').textContent = ''; return; }
    tb.innerHTML = rows.map((r, i) =>
      `<tr><td>${i + 1}</td><td><span class="ds-badge ds-badge--neutral">${esc(MODULE_LABEL[r.module] || r.module)}</span></td>`
      + `<td>${esc(r.title || r.filename)}</td><td class="ds-caption">${esc(r.summary || '')}</td>`
      + `<td>${fmtDT(r.created_at)}</td><td>${fmtSize(r.size_bytes)}</td>`
      + `<td style="white-space:nowrap"><button type="button" class="ds-btn ds-btn--sm btnGreen" onclick="notifDownload(${r.id})"><svg class="ds-icon" style="width:14px;height:14px"><use href="#i-download"/></svg>Yüklə</button> `
      + `<button type="button" class="ds-btn ds-btn--sm" onclick="notifDelete(${r.id})">Sil</button></td></tr>`
    ).join('');
    $('notifFoot').textContent = rows.length + ' hesabat';
  } catch (e) { tb.innerHTML = '<tr><td colspan="7" class="vaEmpty">Xəta: ' + esc(e.message || e) + '</td></tr>'; }
};
window.notifDownload = function (id) { window.location = '/api/reports/download?id=' + id + '&t=' + Date.now(); };
window.notifDelete = async function (id) {
  try { await api('/api/reports/delete', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) }); notifLoad(); }
  catch (e) { toast(String(e.message || e), 'danger'); }
};

/* ---------- Qlobal bildiriş (proqram işləyərkən) ---------- */
/* Yan menyu düyməsində badge + yeni problem olanda toast. Hansı səhifədə olmasından asılı deyil. */
const G = { last: null, timer: null };
function globalBadge(n) {
  const btn = document.getElementById('menuAlerts');
  if (!btn) return;
  let b = btn.querySelector('.alBadge');
  if (!b) { b = document.createElement('span'); b.className = 'alBadge'; btn.appendChild(b); }
  if (n > 0) { b.textContent = n > 99 ? '99+' : String(n); b.style.display = ''; }
  else b.style.display = 'none';
}
async function globalTick() {
  try {
    const s = await api('/api/alerts/summary');
    const n = s.active_problem || 0;
    globalBadge(n);
    if (G.last != null && n > G.last) {
      toast((n - G.last) + ' yeni xəbərdarlıq — şəkil/jurnal yoxdur. "Xəbərdarlıqlar" bölməsinə baxın.', 'danger');
    }
    G.last = n;
  } catch (e) {}
}
function startGlobalAlerts() {
  if (G.timer) return;
  globalTick();
  G.timer = setInterval(globalTick, 30000);  // hər 30 saniyə
}
// app yüklənəndən bir az sonra başlat
if (document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(startGlobalAlerts, 4000);
else window.addEventListener('DOMContentLoaded', () => setTimeout(startGlobalAlerts, 4000));
})();
