// Landing page: all source and scan measurements come from existing API/database.
let homeHistoryToken=0;
const ALL_MODULE_IDS=['backupModule','restartModule','archiveModule','systemModule','atmInventoryModule','diskReportModule','atmMapModule','agentModule','atmInfoModule','vaScanModule','videosekilModule','videoServerModule','jurnalModule','berpaModule','jberpaModule','monitorModule','deployModule','serverModule','atmCopyModule','cmpModule','ajScanModule','alertsModule','notifModule','sAgentModule','autoBkModule'];
function openHome(){
  ALL_MODULE_IDS.forEach(id=>document.getElementById(id)?.classList.add('hidden'));
  if(typeof hideSectionTabs==='function')hideSectionTabs();
  if(typeof agentStopAuto==='function')agentStopAuto();
  document.getElementById('homeModule').classList.remove('hidden');
  document.getElementById('pageTitle').textContent='Ana səhifə';
  document.getElementById('pageSubtitle').textContent='';
  setMenuActive('menuHome');toggleSidebar(false);
  homeCCGreet();renderHomeSources();refreshHomeHistory();homeLoadStats();homeLoadActivity();
  if(typeof homeAtmsInit==='function')homeAtmsInit();
  window.scrollTo({top:0,behavior:'instant'});
}
/* ---- Ana səhifə (Command Center): salamlama, tarix, sağlamlıq halqası ---- */
function homeCCGreet(){
  try{
    const h=new Date().getHours();
    const greet=h<12?'Sabahınız xeyir':h<18?'Gününüz xeyir':'Axşamınız xeyir';
    let name='';
    try{const u=window.AtmAuth&&AtmAuth.me&&AtmAuth.me.user;if(u)name=(u.first_name||'').trim()||u.username||'';}catch(e){}
    const g=document.getElementById('homeGreeting');
    if(g)g.innerHTML=name?esc(greet)+', <em>'+esc(name)+'</em>':esc(greet);
    const dc=document.getElementById('homeDateChip');
    if(dc)dc.textContent=new Date().toLocaleDateString('az-AZ',{day:'2-digit',month:'long',year:'numeric',weekday:'short'});
  }catch(e){}
}
function homeCCRing(total,ok,fail,unk,inactive){
  const act=ok+fail+unk;
  const pct=act>0?Math.round(100*ok/act):0;
  const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v};
  set('homeRingPct',(act>0?pct:0)+'%');
  const sub=document.getElementById('homeRingSub');
  if(sub)sub.textContent=act>0?(pct>=85?'şəbəkə sağlamdır':pct>=60?'diqqət tələb edir':'problemli'):'məlumat yoxdur';
  set('homeOkPct',act>0?Math.round(100*ok/act)+'%':'—');
  set('homeFailPct',act>0?Math.round(100*fail/act)+'%':'—');
  const sc=document.getElementById('homeSrcCountChip');
  if(sc)sc.textContent=Object.keys(typeof SCAN_PATHS!=='undefined'?SCAN_PATHS:{}).length||'0';
  // Radar / halqa SVG
  const svg=document.getElementById('homeRingSvg');if(!svg)return;
  const NS='http://www.w3.org/2000/svg',cx=160,cy=160,R=132,C=2*Math.PI*R;
  const el=(n,a)=>{const e=document.createElementNS(NS,n);for(const k in a)e.setAttribute(k,a[k]);return e};
  svg.replaceChildren();
  [48,86,120].forEach(r=>svg.appendChild(el('circle',{cx,cy,r,fill:'none',stroke:'#2a3a52','stroke-width':1,'stroke-dasharray':'2 5'})));
  const defs=el('defs',{});const gr=el('radialGradient',{id:'homeSweep',cx:'50%',cy:'50%',r:'50%'});
  gr.appendChild(el('stop',{offset:'0%','stop-color':'#46c08a','stop-opacity':'0'}));
  gr.appendChild(el('stop',{offset:'100%','stop-color':'#46c08a','stop-opacity':'.26'}));
  defs.appendChild(gr);svg.appendChild(defs);
  svg.appendChild(el('path',{d:`M${cx},${cy} L${cx+R*Math.cos(-0.7)},${cy+R*Math.sin(-0.7)} A${R},${R} 0 0 1 ${cx+R*Math.cos(-0.2)},${cy+R*Math.sin(-0.2)} Z`,fill:'url(#homeSweep)'}));
  svg.appendChild(el('circle',{cx,cy,r:R,fill:'none',stroke:'#1d2838','stroke-width':10}));
  const frac=act>0?ok/act:0;
  const prog=el('circle',{cx,cy,r:R,fill:'none',stroke:'#46c08a','stroke-width':10,'stroke-linecap':'round','stroke-dasharray':C,'stroke-dashoffset':C*(1-frac),transform:`rotate(-90 ${cx} ${cy})`});
  prog.style.filter='drop-shadow(0 0 8px #46c08a88)';svg.appendChild(prog);
  if(act>0&&fail>0){const ff=fail/act;
    svg.appendChild(el('circle',{cx,cy,r:R,fill:'none',stroke:'#e8705f','stroke-width':10,'stroke-dasharray':C,'stroke-dashoffset':-C*(frac),transform:`rotate(-90 ${cx} ${cy})`,opacity:.9,'pathLength':C,style:`stroke-dasharray:${C*ff} ${C}`}));}
  // Node-lar (ATM parkı) — görünən say qədər (limit 40), rəng OK/fail nisbətinə görə
  const nShow=Math.min(40,Math.max(10,act||18));let seed=total||7;const rnd=()=>{seed=(seed*9301+49297)%233280;return seed/233280};
  const nFail=act>0?Math.round(nShow*fail/act):0,nUnk=act>0?Math.round(nShow*unk/act):0;
  for(let i=0;i<nShow;i++){const ang=rnd()*Math.PI*2,rad=18+rnd()*106;const x=cx+rad*Math.cos(ang),y=cy+rad*Math.sin(ang);
    const c=i<nFail?'#f0907f':i<nFail+nUnk?'#eab968':'#5fd0a0';const dot=el('circle',{cx:x,cy:y,r:i<nFail?3.3:2.5,fill:c});
    dot.style.filter=`drop-shadow(0 0 5px ${c})`;svg.appendChild(dot);}
}
function homeJump(which){
  const atm=(document.getElementById('topATM').value||'').trim().toUpperCase();
  openModule(which);
  const input=document.getElementById(which==='archive'?'archiveATM':which==='restart'?'restartATM':'sysATM');
  if(input){if(atm)input.value=atm;input.focus();}
}
function renderHomeSources(){
 const holder=document.getElementById('homeSources'),keys=Object.keys(SCAN_PATHS);
 holder.replaceChildren();document.getElementById('homeSourceCount').textContent=keys.length+' mənbə';
 if(!keys.length){holder.textContent='DB-də aktiv scan mənbəsi tapılmadı.';return;}
 for(const key of keys){
   const btn=document.createElement('button');btn.className='homeSourceRow';
   const icon=document.createElement('span');icon.className='sourceIcon';icon.innerHTML=DS.icon(SOURCE_KINDS[key]==='TXT'?'file-text':'hard-drive');
   const info=document.createElement('span');info.className='sourceText';
   const name=document.createElement('strong');name.textContent=SCAN_NAMES[key]||key;
   const path=document.createElement('small');path.textContent=SCAN_PATHS[key];
   info.append(name,path);const arrow=document.createElement('span');arrow.className='sourceArrow';arrow.innerHTML=DS.icon('chevron-right');
   btn.append(icon,info,arrow);btn.addEventListener('click',()=>openScan(key));holder.append(btn);
 }
}
async function refreshHomeHistory(){
 const holder=document.getElementById('homeRecent');if(!holder)return;
 const token=++homeHistoryToken,keys=Object.keys(SCAN_PATHS);
 holder.replaceChildren();
 if(!keys.length){holder.textContent='Scan mənbələri yüklənməyib.';return;}
 const msg=document.createElement('div');msg.className='homeEmpty';msg.textContent='Son scan nəticələri oxunur...';holder.append(msg);
 const rows=await Promise.all(keys.map(async key=>{
   try{
     const res=await fetch('/api/history?scan_type='+encodeURIComponent(key)+'&limit=1&t='+Date.now(),{cache:'no-store'});
     if(!res.ok)throw Error('HTTP '+res.status);
     const data=await res.json();return {key,scan:data.success?(data.scans||[])[0]:null};
   }catch(e){return {key,error:true};}
 }));
 if(token!==homeHistoryToken)return;holder.replaceChildren();
 window.homeHistoryRows=rows.filter(x=>x.scan).map(x=>Object.assign({source:SCAN_NAMES[x.key]||x.key},x.scan));
 try{const chip=document.getElementById('homeLastScanChip');
   if(chip){const ds=window.homeHistoryRows.map(r=>r.started_at).filter(Boolean).sort();
     const last=ds.length?ds[ds.length-1]:null;chip.textContent=last?last.replace('T',' ').slice(0,16):'—';}}catch(e){}
 rows.forEach(({key,scan,error})=>{
   const btn=document.createElement('button');btn.className='homeRecentRow';
   const icon=document.createElement('span');icon.className='sourceIcon';icon.innerHTML=DS.icon('history');
   const info=document.createElement('span');info.className='sourceText';
   const name=document.createElement('strong');name.textContent=SCAN_NAMES[key]||key;
   const small=document.createElement('small');small.textContent=error?'Tarixçə oxunmadı':scan?('Scan #'+scan.id+' • '+(scan.started_at||'').replace('T',' ')+' • '+scan.status):'Hələ scan aparılmayıb';
   info.append(name,small);
   if(scan){const stat=document.createElement('span');stat.className='homeStatsLine';
     const a=document.createElement('span');a.textContent='ATM '+scan.checked+'/'+scan.total_atm;
     const b=document.createElement('span');b.className='good';b.textContent='ƏLA '+scan.excellent;
     const c=document.createElement('span');c.className='bad';c.textContent='PROBLEM '+scan.problem;
     stat.append(a,b,c);info.append(stat);
   }
   const arrow=document.createElement('span');arrow.className='sourceArrow';arrow.innerHTML=DS.icon('chevron-right');btn.append(icon,info,arrow);
   btn.addEventListener('click',()=>{if(SCAN_PATHS[key])openScan(key);openModule('backup','history');document.getElementById('historyScanType').value=key;changeHistoryType(key);});
   holder.append(btn);
 });
}
function updateTopClock(){const e=document.getElementById('topClock');if(e)e.textContent=new Date().toLocaleString('az-AZ',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});}

// IP -> disk -> folder: all authoritative values come from SQLite.
async function loadConfig(){
  try{
    const r=await fetch('/api/config?t='+Date.now());const d=await r.json();
    if(!d.success)throw Error(d.error||'Konfiqurasiya oxunmadı');
    applyConfig(d);
  }catch(e){const box=document.getElementById('ipTree');if(box){box.textContent='DB oxunmadı: '+String(e);}}
}
async function pollConfig(){
  if(document.hidden)return;  // fon tabında şəbəkə sorğusu etmə
  try{const r=await fetch('/api/config?t='+Date.now());const d=await r.json();if(d.success&&d.revision!==configState.revision)applyConfig(d);}catch(e){}
}
function applyConfig(d){
  const previous=activeScanType||(()=>{try{return sessionStorage.getItem('atm_active_scan_type')||'';}catch(e){return '';}})();
  configState=d;
  for(const key of Object.keys(SCAN_PATHS))delete SCAN_PATHS[key];
  for(const key of Object.keys(SCAN_NAMES))delete SCAN_NAMES[key];
  Object.assign(SCAN_PATHS,d.paths||{});
  Object.assign(SCAN_NAMES,d.scan_labels||{});
  for(const key of Object.keys(SOURCE_KINDS))delete SOURCE_KINDS[key];
  Object.assign(SOURCE_KINDS,d.source_kinds||{});
  if(activeScanType)setTimeout(()=>updateCategoryLegend(activeScanType),0);
  for(const key of Object.keys(HISTORY_PATHS))delete HISTORY_PATHS[key];
  Object.assign(HISTORY_PATHS,SCAN_PATHS);
  const availableTypes=[...new Set([...(d.history_types||[]),...Object.keys(SCAN_PATHS)])];
  const historySelect=document.getElementById('historyScanType');
  const selectedHistory=historySelect.value||historyScanType;
  historySelect.innerHTML='';
  for(const type of availableTypes){
    const opt=document.createElement('option');opt.value=type;
    opt.textContent=SCAN_NAMES[type]||('Köhnə '+type+' Scan (tarixçə)');
    historySelect.appendChild(opt);
    if(!HISTORY_PATHS[type])HISTORY_PATHS[type]='';
  }
  if(availableTypes.includes(selectedHistory))historySelect.value=selectedHistory;
  else if(availableTypes.length)historySelect.value=availableTypes[0];
  historyScanType=historySelect.value;
  renderConfigTree();
  if(!SCAN_PATHS[previous]){
    const first=Object.keys(SCAN_PATHS)[0];
    if(first){activeScanType=first;document.getElementById('scanSourceLabel').textContent=SCAN_NAMES[first]||first;document.getElementById('scanSourcePath').textContent=SCAN_PATHS[first]||'-';renderHomeSources();if(!document.getElementById('homeModule').classList.contains('hidden'))refreshHomeHistory();return;}
    activeScanType='';
    document.getElementById('scanButton').disabled=true;
    document.getElementById('scanSourcePath').innerText='DB-də scan mənbəyi tapılmadı';
    document.getElementById('pageSubtitle').innerText='SQLite bazasında scan mənbələri yoxdur.';
    document.getElementById('currentAction').innerText='Konfiqurasiya gözlənilir.';
    return;
  }
  document.getElementById('scanButton').disabled=false;
  setLastDateHeader(previous);
  document.getElementById('scanSourceLabel').innerText=SCAN_NAMES[previous]||previous;
  document.getElementById('scanSourcePath').innerText=SCAN_PATHS[previous]||'-';
  document.getElementById('scanFileHint').innerText=previous==='DJ'?
    'D Jurnal: ATM ID → Journal varsa onun, yoxdursa ATM-in içindəki BÜTÜN JRN/TXT faylları adındakı YYYYMMDD tarixə görə yoxlanılır. Date Modified istifadə edilmir.':
    (isJournal(previous)?'Yoxlama: IP → disk → folder → ATM ID → YYYYMMDD → TXT faylları.':
    'Yoxlama: IP → disk → folder → ATM ID → YYYYMMDD → JPG və video faylları.');
  if(!document.getElementById('backupModule').classList.contains('hidden') &&
     !document.getElementById('liveTab').classList.contains('hidden')){
    document.getElementById('pageSubtitle').innerText=SCAN_PATHS[previous];
  }
  if(!document.getElementById('homeModule').classList.contains('hidden')){renderHomeSources();refreshHomeHistory();}
  else if(!document.getElementById('backupModule').classList.contains('hidden')&&currentSection&&SECTIONS[currentSection])setMenuActive(SECTIONS[currentSection].menu);
}
function isJournal(t){return t==='DJ'||t==='HJ'||SOURCE_KINDS[t]==='TXT'}
function setLastDateHeader(scanType){
  document.querySelectorAll('#liveTab .lastDateColumn').forEach(el=>{
    el.textContent=scanType==='DJ'?'Ən son faylın adındakı tarix':'Son tarix folderi';
  });
  document.querySelectorAll('#liveTab .mediaTimeColumn').forEach(el=>{
    el.textContent=scanType==='DJ'?'Backup tarixi (fayl adı)':'Son media vaxtı';
  });
}


function renderConfigTree(){
  // Scan mənbələri artıq yan menyuda yox, SCAN bölməsinin səhifə-içi tablarındadır.
  // Konfiq dəyişəndə SCAN bölməsi açıqdırsa, tabları (flicker olmadan) yenilə.
  if(currentSection!=='scan'&&currentSection!=='jurnalscan')return;
  const sig=(currentSection==='jurnalscan'?jurnalScanTabs():scanSectionTabs()).map(t=>t.key+(t.disabled?'!':'')).join('|');
  if(sig!==scanTabsSig)renderSectionTabs(currentSection,currentSubKey);
}

const SCAN_PATHS={};
const SCAN_NAMES={};
const SOURCE_KINDS={};
let configState={ips:[],disks:[],folders:[],revision:0,paths:{}};
let treeOpenIps=new Set(),treeOpenDisks=new Set();
const HISTORY_PATHS={};
let activeScanType='';
let historyScanType='';
let liveRequestEpoch=0;
let ownedScans=new Map(); // all scans started by this browser tab
function rememberOwnedScan(scanType,scanId){
  ownedScans.set(scanType,scanId);
  try{sessionStorage.setItem('atm_running_scans',JSON.stringify([...ownedScans]));}catch(e){}
}
function forgetOwnedScan(scanType,scanId){
  if(ownedScans.get(scanType)===scanId)ownedScans.delete(scanType);
  try{sessionStorage.setItem('atm_running_scans',JSON.stringify([...ownedScans]));}catch(e){}
}
async function cancelLeftoverScansOnLoad(){
  // If pagehide beacon was lost during Ctrl+F5, retry using this tab's scan IDs.
  let previous=[];
  try{previous=JSON.parse(sessionStorage.getItem('atm_running_scans')||'[]');}catch(e){}
  if(!Array.isArray(previous)||!previous.length)return;
  await Promise.allSettled(previous.map(async pair=>{
    const [scan_type,scan_id]=pair;
    if(typeof scan_type!=='string'||!Number.isInteger(scan_id))return;
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),2500);
    try{
      await fetch('/api/scan/cancel',{method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({scan_type,scan_id}),signal:controller.signal});
    }catch(e){}finally{clearTimeout(timer);}
  }));
  try{sessionStorage.removeItem('atm_running_scans');}catch(e){}
}

let historyRequestEpoch=0;
let currentResults=[];
let lastResultIndex=0;
let pollTimer=null;
let historyScans=[];
let historyResults=[];
let selectedHistoryScan=null;

function sendScanCancelOnExit(){
  // One tab may have launched D, H and Jurnal scans independently.
  // Only this tab's scans are cancelled on refresh/close.
  for(const [scan_type,scan_id] of ownedScans){
    const data=JSON.stringify({scan_type,scan_id});
    try{
      if(navigator.sendBeacon && navigator.sendBeacon('/api/scan/cancel',
        new Blob([data],{type:'text/plain;charset=UTF-8'})))continue;
    }catch(e){}
    try{fetch('/api/scan/cancel',{method:'POST',headers:{'Content-Type':'application/json'},
      body:data,keepalive:true,cache:'no-store'}).catch(()=>{});}catch(e){}
  }
}
window.addEventListener('pagehide',sendScanCancelOnExit);
async function stopScan(){
  const id=Number(document.getElementById('currentScanId').textContent);
  if(!activeScanType||!id)return;
  document.getElementById('scanStopButton').disabled=true;
  document.getElementById('currentAction').textContent='Dayandırma sorğusu göndərilir...';
  try{
    const r=await fetch('/api/scan/cancel',{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({scan_type:activeScanType,scan_id:id})});
    const d=await r.json();
    if(!d.success)throw Error(d.error||'Dayandırma alınmadı');
    forgetOwnedScan(activeScanType,id);
    document.getElementById('currentAction').textContent='Scan dayandırılır...';
    startPolling();
  }catch(e){document.getElementById('currentAction').textContent=String(e);
    document.getElementById('scanStopButton').disabled=false;}
}

function localDateString(d){const y=d.getFullYear();const m=String(d.getMonth()+1).padStart(2,'0');const day=String(d.getDate()).padStart(2,'0');return `${y}-${m}-${day}`}
let restartPollTimer=null;
let archivePollTimer=null;
let archivePollInFlight=false;
let archivePollFailures=0;
let archiveRequestGeneration=0;
function archiveStopPolling(){
  if(archivePollTimer){clearInterval(archivePollTimer);archivePollTimer=null;}
  archivePollFailures=0;
  archivePollInFlight=false;
}
function archiveEnableButton(){
  exEl('archiveButton').disabled=false;
  exEl('archiveButton').textContent='ATM-ə qoşul';
}
async function atmAppInit(){
  const d=new Date();d.setDate(d.getDate()-7);
  document.getElementById('selectedDate').value=localDateString(d);
  updateTopClock();setInterval(updateTopClock,30000);
  openHome();
  await cancelLeftoverScansOnLoad();
  await loadConfig();
  renderHomeSources();refreshHomeHistory();loadRestartConfig();loadArchiveConfig();
  setInterval(pollConfig,8000);
  // Tab yenidən görünəndə ləng gözləməsin: dərhal yenilə
  document.addEventListener('visibilitychange',()=>{if(!document.hidden){try{pollConfig();}catch(e){}try{if(pollTimer)getProgress();}catch(e){}}});
  const route=new URLSearchParams(location.search).get('module');
  if(route){
    const allowed=new Set(['home','backup','history','restart','archive','system','inventory','diskreport','map','agent','videoserver','vascan','berpa','jberpa','monitor','deploy','server','backupmgr','srvmove','atmcopy']);
    if(allowed.has(route)){
      if(route==='history')openModule('backup','history');
      else if(route!=='home')openModule(route);
    }
  }
  // Spatial Workspace rejimi ləğv olundu — klassik panel yeganə rejimdir.
}
if(document.readyState==='complete'){setTimeout(atmAppInit,0);}else{window.addEventListener('load',atmAppInit,{once:true});}

function toggleSidebar(force){
  const side=document.getElementById('sidebar'),overlay=document.getElementById('menuOverlay');
  const open=typeof force==='boolean'?force:!side.classList.contains('open');
  side.classList.toggle('open',open);overlay.classList.toggle('show',open);
}
function setMenuActive(id){document.querySelectorAll('#sidebar .active').forEach(x=>x.classList.remove('active'));document.getElementById(id)?.classList.add('active')}

/* ===== SƏHİFƏ-İÇİ BÖLMƏ TABLARI (SCAN / Video-Şəkil / Bərpa / Diaqnostika) ===== */
const SECTION_MEMBERS=new Set(['backup','vascan','jurnal','videosekil','videoserver','berpa','jberpa','atminfo','system','diskreport','atmcopy','cmp','ajscan','autobk','monitor','agent','sagent','notif','alerts','server','restart']);
let currentSection=null,currentSubKey=null,inSectionNav=false,scanTabsSig='',lastScanWarn=0;

function hideSectionTabs(){
  currentSection=null;currentSubKey=null;scanTabsSig='';
  const el=document.getElementById('sectionTabs');
  if(el){el.classList.add('hidden');el.replaceChildren();}
}
function scanSectionTabs(){
  // Backup & Yoxlama: yalnız şəkil backup-ı — D/H, digər şəkil mənbələri, VIDEOARCHIVE, Video/Şəkil.
  const known=[['D','D Scan'],['H','H Scan']];
  const tabs=[];
  for(const [k,label] of known){
    const configured=Boolean(SCAN_PATHS[k]);
    tabs.push({key:'scan:'+k,label:(SCAN_NAMES[k]||label),icon:'scan-line',disabled:!configured,
      title:configured?SCAN_PATHS[k]:(label+': DB-də IP/disk/folder mənbəsi yoxdur'),open:()=>openScan(k)});
  }
  for(const k of Object.keys(SCAN_PATHS)){
    if(k==='D'||k==='H'||k==='DJ'||k==='HJ')continue;   // DJ/HJ artıq Jurnal Scan-dadır
    tabs.push({key:'scan:'+k,label:(SCAN_NAMES[k]||k),icon:'scan-line',title:SCAN_PATHS[k],open:()=>openScan(k)});
  }
  tabs.push({key:'vascan',label:'VIDEOARCHIVE',icon:'scan-line',open:()=>openModule('vascan')});
  tabs.push({key:'videosekil',label:'Video/Şəkil (ATM)',icon:'film',open:()=>openModule('videosekil')});
  tabs.push({key:'videoserver',label:'Video/Şəkil (Server)',icon:'server',open:()=>openModule('videoserver')});
  return tabs;
}
function jurnalScanTabs(){
  // Jurnal Scan: bütün jurnal yoxlamaları + scan tarixçəsi bir yerdə.
  const tabs=[];
  for(const [k,label] of [['DJ','D Scan Jurnal'],['HJ','H Scan Jurnal']]){
    const configured=Boolean(SCAN_PATHS[k]);
    tabs.push({key:'scan:'+k,label:(SCAN_NAMES[k]||label),icon:'file-text',disabled:!configured,
      title:configured?SCAN_PATHS[k]:(label+': DB-də mənbə yoxdur'),open:()=>openScan(k)});
  }
  tabs.push({key:'jurnal',label:'Jurnal (ATM)',icon:'file-text',open:()=>openModule('jurnal')});
  tabs.push({key:'ajscan',label:'ATM Jurnal Scan',icon:'file-text',open:()=>openModule('ajscan')});
  tabs.push({key:'history',label:'Scan Tarixçəsi',icon:'history',open:()=>openModule('backup','history')});
  return tabs;
}
const SECTIONS={
  // 1) Backup & Yoxlama — bütün scan/backup/müqayisə bir yerdə (tablar scanSectionTabs-dadır)
  scan:{menu:'menuBackup',title:'Backup & Yoxlama',build:scanSectionTabs},
  // 2) Jurnal Scan — bütün jurnal yoxlamaları + tarixçə
  jurnalscan:{menu:'menuJurnalScan',title:'Jurnal Scan',build:jurnalScanTabs},
  // 3) Monitorinq & Diaqnostika — cihazın canlı vəziyyəti (Avtomatik Backup da buradadır)
  monitor:{menu:'menuMonitorG',title:'Monitorinq & Diaqnostika',tabs:[
    {key:'monitor',label:'Foto Monitorinq',icon:'activity',open:()=>openModule('monitor')},
    {key:'autobk',label:'Avtomatik Backup',icon:'refresh-cw',open:()=>openModule('autobk')},
    {key:'system',label:'Sistem Monitoru',icon:'monitor-cog',open:()=>openModule('system')},
    {key:'agent',label:'Agent (HMAC)',icon:'gauge',open:()=>openModule('agent')},
    {key:'sagent',label:'Agent (sadə)',icon:'gauge',open:()=>openModule('sagent')},
    {key:'atminfo',label:'ATM Info',icon:'server',perm:'atminfo',open:()=>openModule('atminfo')},
    {key:'diskreport',label:'Disk Report',icon:'hard-drive',open:()=>openModule('diskreport')}]},
  // 3) Əməliyyatlar — ATM-ə təsir edən əməllər
  ops:{menu:'menuOps',title:'Əməliyyatlar',tabs:[
    {key:'deploy',label:'Folder Göndər',icon:'arrow-up-right',open:()=>openModule('deploy')},
    {key:'atmcopy',label:'Fayl Köçür',icon:'arrow-up-right',open:()=>openModule('atmcopy')},
    {key:'berpa',label:'Qovluq Bərpası',icon:'refresh-cw',open:()=>openModule('berpa')},
    {key:'jberpa',label:'Journal Bərpası',icon:'file-text',open:()=>openModule('jberpa')},
    {key:'restart',label:'ATM Restart',icon:'power',open:()=>openModule('restart')},
    {key:'server',label:'Server',icon:'server',open:()=>openModule('server')},
    {key:'backupmgr',label:'Backup Manager',icon:'hard-drive',perm:'server',open:()=>openModule('backupmgr')},
    {key:'srvmove',label:'Disklər arası köçür',icon:'arrow-up-right',perm:'server',open:()=>openModule('srvmove')}]},
  // 4) Hesabatlar — bütün hesabat və xəbərdarlıqlar
  reports:{menu:'menuReports',title:'Hesabatlar',tabs:[
    {key:'notif',label:'Bildirişlər',icon:'file-text',open:()=>openModule('notif')},
    {key:'alerts',label:'Xəbərdarlıqlar',icon:'triangle-alert',open:()=>openModule('alerts')}]},
};
function sectionTabsList(key){
  const sec=SECTIONS[key];if(!sec)return[];
  let tabs=sec.build?sec.build():sec.tabs.slice();
  tabs=tabs.filter(t=>!t.perm||typeof AtmAuth==='undefined'||typeof AtmAuth.can!=='function'||AtmAuth.can(t.perm));
  return tabs;
}
function activateSubTab(key,t){
  inSectionNav=true;
  try{t.open();}finally{inSectionNav=false;}
  currentSection=key;currentSubKey=t.key;
  setMenuActive(SECTIONS[key].menu);
  renderSectionTabs(key,t.key);
}
function renderSectionTabs(key,activeKey){
  const el=document.getElementById('sectionTabs');if(!el)return;
  const sec=SECTIONS[key];const tabs=sectionTabsList(key);
  const parts=['<span class="sectionTabTitle">'+esc(sec.title)+'</span>'];
  tabs.forEach(t=>{
    const cls='sectionTab'+(t.key===activeKey?' is-active':'')+(t.disabled?' is-disabled':'');
    parts.push('<button type="button" class="'+cls+'" data-k="'+esc(t.key)+'" title="'+esc(t.title||t.label)+'">'+DS.icon(t.icon)+'<span>'+esc(t.label)+'</span></button>');
  });
  el.innerHTML=parts.join('');
  el.classList.remove('hidden');
  if(key==='scan'||key==='jurnalscan')scanTabsSig=tabs.map(t=>t.key+(t.disabled?'!':'')).join('|');
  el.querySelectorAll('.sectionTab').forEach(b=>{
    const t=tabs.find(x=>x.key===b.dataset.k);if(!t)return;
    b.onclick=async()=>{
      if(t.disabled){
        // Boz (mənbəsiz) scan tabı: konfiqi yenidən yüklə — server mənbəni avtomatik bərpa edə bilər
        if(typeof loadConfig==='function'){try{await loadConfig();}catch(e){}}
        const fresh=(sec.build?sec.build():sec.tabs).find(x=>x.key===t.key);
        if(fresh&&!fresh.disabled){activateSubTab(key,fresh);return;}
        renderSectionTabs(key,currentSubKey);
        const now=Date.now();if((fresh&&fresh.title||t.title)&&now-lastScanWarn>5000){lastScanWarn=now;alert((fresh&&fresh.title)||t.title);}
        return;
      }
      activateSubTab(key,t);
    };
  });
}
function openSection(key,subKey){
  const sec=SECTIONS[key];if(!sec)return;
  const tabs=sectionTabsList(key);if(!tabs.length)return;
  let active=(subKey&&tabs.find(t=>t.key===subKey&&!t.disabled))?subKey:null;
  if(!active){const first=tabs.find(t=>!t.disabled)||tabs[0];active=first.key;}
  const t=tabs.find(x=>x.key===active);
  activateSubTab(key,t);
  toggleSidebar(false);
  window.scrollTo({top:0,behavior:'instant'});
}
window.openSection=openSection;

function openModule(module,tab='live',close=true){
  if(module==='home'){openHome();return;}
  if(!inSectionNav&&typeof hideSectionTabs==='function')hideSectionTabs();
  document.getElementById('homeModule').classList.add('hidden');
  const backup=module==='backup',restart=module==='restart',archive=module==='archive',system=module==='system',inventory=module==='inventory',diskreport=module==='diskreport',map=module==='map',agent=module==='agent',atminfo=module==='atminfo';
  document.getElementById('backupModule').classList.toggle('hidden',!backup);
  document.getElementById('restartModule').classList.toggle('hidden',!restart);
  document.getElementById('archiveModule')?.classList.toggle('hidden',!archive);
  document.getElementById('systemModule').classList.toggle('hidden',!system);
  document.getElementById('atmInventoryModule').classList.toggle('hidden',!inventory);
  document.getElementById('diskReportModule').classList.toggle('hidden',!diskreport);
  document.getElementById('atmMapModule').classList.toggle('hidden',!map);
  document.getElementById('agentModule').classList.toggle('hidden',!agent);
  document.getElementById('atmInfoModule')?.classList.toggle('hidden',!atminfo);
  const videosekil=module==='videosekil',jurnal=module==='jurnal',videoserver=module==='videoserver',vascan=module==='vascan',berpa=module==='berpa',jberpa=module==='jberpa',monitor=module==='monitor',deploy=module==='deploy';
  document.getElementById('vaScanModule')?.classList.toggle('hidden',!vascan);
  document.getElementById('berpaModule')?.classList.toggle('hidden',!berpa);
  document.getElementById('jberpaModule')?.classList.toggle('hidden',!jberpa);
  document.getElementById('monitorModule')?.classList.toggle('hidden',!monitor);
  document.getElementById('deployModule')?.classList.toggle('hidden',!deploy);
  const server=module==='server',atmcopy=module==='atmcopy',cmp=module==='cmp',ajscan=module==='ajscan',alerts=module==='alerts',notif=module==='notif',backupmgr=module==='backupmgr',srvmove=module==='srvmove';
  document.getElementById('serverModule')?.classList.toggle('hidden',!server);
  document.getElementById('backupMgrModule')?.classList.toggle('hidden',!backupmgr);
  document.getElementById('srvMoveModule')?.classList.toggle('hidden',!srvmove);
  document.getElementById('atmCopyModule')?.classList.toggle('hidden',!atmcopy);
  document.getElementById('cmpModule')?.classList.toggle('hidden',!cmp);
  document.getElementById('ajScanModule')?.classList.toggle('hidden',!ajscan);
  const sagent=module==='sagent',autobk=module==='autobk';
  document.getElementById('alertsModule')?.classList.toggle('hidden',!alerts);
  document.getElementById('notifModule')?.classList.toggle('hidden',!notif);
  document.getElementById('sAgentModule')?.classList.toggle('hidden',!sagent);
  document.getElementById('autoBkModule')?.classList.toggle('hidden',!autobk);
  document.getElementById('videosekilModule')?.classList.toggle('hidden',!videosekil);
  document.getElementById('videoServerModule')?.classList.toggle('hidden',!videoserver);
  document.getElementById('jurnalModule')?.classList.toggle('hidden',!jurnal);
  if(!agent&&typeof agentStopAuto==='function')agentStopAuto();

  if(backup){
    document.getElementById('pageTitle').innerText=tab==='history'?'ATM Scan Tarixçəsi':(SCAN_NAMES[activeScanType]||'ATM Backup Monitor')+' — ATM Monitor';
    document.getElementById('pageSubtitle').innerText=tab==='history'?('D/H/Jurnal üzrə ayrı tarixçə və müqayisə'):(SCAN_PATHS[activeScanType]||'Path təyin edilməyib');
    setMenuActive(tab==='history'?'menuHistory':'menuScan_'+activeScanType);
    document.getElementById('menuScanGroup')?.classList.add('active');
    showTab(tab);
  }else if(restart){
    document.getElementById('pageTitle').innerText='ATM Restart';
    document.getElementById('pageSubtitle').innerText='PASSWORD1–PASSWORD7 + NET USE / Windows shutdown ilə restart modulu';
    setMenuActive('menuRestart');
    loadRestartConfig();pollRestart();
  }else if(archive){
    document.getElementById('pageTitle').innerText='ATM File Explorer / Video Archive';
    document.getElementById('pageSubtitle').innerText='D$ naviqator · ən son VIDEOARCHIVE · C$ JOURNAL önizləmə';
    setMenuActive('menuArchive');
    loadArchiveConfig();pollArchive();
  }else if(system){
    document.getElementById('pageTitle').innerText='ATM Sistem Monitoru';
    document.getElementById('pageSubtitle').innerText='WMI/RPC · CPU · RAM · disk · OS · hostname · IP · MAC · network';
    setMenuActive('menuSystem');
    pollSystem();
  }else if(inventory){
    document.getElementById('pageTitle').innerText='Bankomatlar';
    document.getElementById('pageSubtitle').innerText='ATM ID · koordinatlar · status · PASSWORD environment slotu · toplu qoşulma';
    setMenuActive('menuInventory');
    loadAtmInventory();pollAtmBulkProgress(true);
  }else if(diskreport){
    document.getElementById('pageTitle').innerText='Disk Yaddaş Reportu';
    document.getElementById('pageSubtitle').innerText='Seçilmiş aktiv ATM-lər · C:/D: doluluq · giriş statusu · CSV · SQLite tarixçə';
    setMenuActive('menuDiskReport');
    pollDiskReport(true);loadDiskReportHistory();
  }else if(map){
    document.getElementById('pageTitle').innerText='ATM Xəritəsi';
    document.getElementById('pageSubtitle').innerText='';
    setMenuActive('menuMap');
    loadAtmMap();
  }else if(agent){
    document.getElementById('pageTitle').innerText='Agent Monitoru';
    document.getElementById('pageSubtitle').innerText='ATM agent (exe) push hesabatları · CPU · RAM · Windows · 32/64 bit · disk yaddaşı';
    setMenuActive('menuAgent');
    agentStartAuto();
  }else if(atminfo){
    document.getElementById('pageTitle').innerText='ATM Info';
    document.getElementById('pageSubtitle').innerText='ATM ID · 445 ilə qoşulma · collect.bat · atminfo.json · CPU · RAM · disk · sistem';
    setMenuActive('menuAtmInfo');
    if(typeof atmInfoInit==='function')atmInfoInit();
  }else if(videosekil){
    document.getElementById('pageTitle').innerText='Video / şəkil';
    document.getElementById('pageSubtitle').innerText='';
    setMenuActive('menuVideoSekil');
    if(typeof videosekilInit==='function')videosekilInit();
  }else if(videoserver){
    document.getElementById('pageTitle').innerText='Video / Şəkil Server';
    document.getElementById('pageSubtitle').innerText='Backup serverində ATM qovluqları · şəkil / video yoxlaması';
    setMenuActive('menuVideoServer');
    document.getElementById('menuBackup')?.classList.add('active');
    if(typeof videoServerInit==='function')videoServerInit();
  }else if(vascan){
    document.getElementById('pageTitle').innerText='VIDEOARCHIVE Scan';
    document.getElementById('pageSubtitle').innerText='Bütün ATM-lər · \\\\ATM_ID\\D$\\VIDEOARCHIVE\\ATM_ID · son şəkil · Excel hesabatı';
    setMenuActive('menuVaScan');
    document.getElementById('menuBackup')?.classList.add('active');
    if(typeof vaScanInit==='function')vaScanInit();
  }else if(berpa){
    document.getElementById('pageTitle').innerText='Qovluq Bərpası';
    document.getElementById('pageSubtitle').innerText='ATM-də var, serverdə yox olan YYYYMMDD qovluqlarını serverə köçürür · Excel hesabatı';
    setMenuActive('menuBerpa');
    document.getElementById('menuBackup')?.classList.add('active');
    if(typeof berpaInit==='function')berpaInit();
  }else if(jberpa){
    document.getElementById('pageTitle').innerText='Journal Bərpası';
    document.getElementById('pageSubtitle').innerText='ATM C$ jurnal (Journal / JOURNAL\\Journal) → serverdə çatışmayan YYYYMMDD qovluqları · Excel hesabatı';
    setMenuActive('menuJberpa');
    document.getElementById('menuBackup')?.classList.add('active');
    if(typeof jberpaInit==='function')jberpaInit();
  }else if(monitor){
    document.getElementById('pageTitle').innerText='ATM Foto Monitorinq';
    document.getElementById('pageSubtitle').innerText='Hər ATM üçün maks saat həddi · avtomatik VIDEOARCHIVE yoxlaması · işləməyən ATM-lərə mail';
    setMenuActive('menuMonitor');
    document.getElementById('menuBackup')?.classList.add('active');
    if(typeof monitorInit==='function')monitorInit();
  }else if(deploy){
    document.getElementById('pageTitle').innerText='ATM-ə Folder Göndər';
    document.getElementById('pageSubtitle').innerText='Seçilmiş qovluğu siyahıdakı ATM-lərin təyinat yoluna (admin desktopu) köçürür';
    setMenuActive('menuDeploy');
    document.getElementById('menuBackup')?.classList.add('active');
    if(typeof deployInit==='function')deployInit();
  }else if(server){
    document.getElementById('pageTitle').innerText='Server disk gəzgini';
    document.getElementById('pageSubtitle').innerText='172.21.12.77 serverinin diskləri (D$/H$/M$/F$) · gəz · önizlə · yüklə';
    setMenuActive('menuServer');
    if(typeof serverInit==='function')serverInit();
  }else if(backupmgr){
    document.getElementById('pageTitle').innerText='ATM Smart Backup Manager';
    document.getElementById('pageSubtitle').innerText='Serverdəki disklərdən ATM şəkil/jurnal fayllarını tarixə görə hədəf qovluğa köçür';
    setMenuActive('menuServer');
    if(typeof backupMgrInit==='function')backupMgrInit();
  }else if(srvmove){
    document.getElementById('pageTitle').innerText='Disklər arası köçür / yerini dəyiş';
    document.getElementById('pageSubtitle').innerText='77 serverinin öz diskləri arasında (D$/H$/M$/F$) fayl/qovluq kopyala və ya köçür';
    setMenuActive('menuServer');
    if(typeof srvMoveInit==='function')srvMoveInit();
  }else if(atmcopy){
    document.getElementById('pageTitle').innerText='ATM Fayl Köçür';
    document.getElementById('pageSubtitle').innerText='ATM C$/D$ diskindən qovluğu seçilmiş təyinata köçür';
    setMenuActive('menuDiag');
    if(typeof atmCopyInit==='function')atmCopyInit();
  }else if(cmp){
    document.getElementById('pageTitle').innerText='Müqayisə (eyniləşdirmə)';
    document.getElementById('pageSubtitle').innerText='ATM görüntü/jurnal faylları 172.21.12.77 server backup-ı ilə · ad+ölçü+tarix · Excel';
    setMenuActive('menuScanGroup');
    if(typeof cmpInit==='function')cmpInit();
  }else if(ajscan){
    document.getElementById('pageTitle').innerText='ATM Jurnal Scan';
    document.getElementById('pageSubtitle').innerText='\\\\ATM_ID\\C$\\JOURNAL və C$\\Mobilpay\\LOG · sonuncu tarix · Excel';
    setMenuActive('menuScanGroup');
    if(typeof ajScanInit==='function')ajScanInit();
  }else if(alerts){
    document.getElementById('pageTitle').innerText='Xəbərdarlıqlar';
    document.getElementById('pageSubtitle').innerText='Avtomatik şəkil/jurnal/backup yoxlaması · bütün aktiv ATM-lər · bildiriş';
    setMenuActive('menuAlerts');
    if(typeof alertsInit==='function')alertsInit();
  }else if(notif){
    document.getElementById('pageTitle').innerText='Bildirişlər';
    document.getElementById('pageSubtitle').innerText='Yaradılmış bütün Excel hesabatları — ATM/Server xəbərdarlıqları və scan nəticələri';
    setMenuActive('menuNotif');
    if(typeof notifInit==='function')notifInit();
  }else if(sagent){
    document.getElementById('pageTitle').innerText='ATM Agent (sadə)';
    document.getElementById('pageSubtitle').innerText='Agentlərin göndərdiyi CPU / RAM / C / D disk / IP — hər ATM öz ID-si qarşısında';
    setMenuActive('menuSAgent');
    if(typeof sAgentInit==='function')sAgentInit();
  }else if(autobk){
    document.getElementById('pageTitle').innerText='Avtomatik Backup';
    document.getElementById('pageSubtitle').innerText='Serverdə backup yoxdursa ATM-dən avtomatik köçürmə · robocopy · Excel hesabat';
    setMenuActive('menuAutoBk');
    if(typeof autoBkInit==='function')autoBkInit();
  }else if(jurnal){
    document.getElementById('pageTitle').innerText='Jurnal';
    document.getElementById('pageSubtitle').innerText='';
    setMenuActive('menuJurnal');
    if(typeof jurnalInit==='function')jurnalInit();
  }
  if(close)toggleSidebar(false);
}
function updateCategoryLegend(scanType){
  const tol=Number(((configState||{}).normal_tolerance||{})[scanType]||0);
  const n=document.getElementById('legendNormal'),p=document.getElementById('legendProblem');
  if(n)n.textContent=tol>0?('NORMAL · seçilən tarixdən ≤ '+tol+' gün əvvəl → dünən'):'NORMAL · seçilən tarix → dünən';
  if(p)p.textContent=tol>0?('PROBLEM · seçilən tarixdən '+tol+' gündən çox əvvəl / yoxdur'):'PROBLEM · tarixdən əvvəl / yoxdur';
}
function openScan(scanType){
  if(!Object.prototype.hasOwnProperty.call(SCAN_PATHS,scanType))return;
  updateCategoryLegend(scanType);
  if(pollTimer){clearInterval(pollTimer);pollTimer=null;}
  activeScanType=scanType;
  try{sessionStorage.setItem('atm_active_scan_type',scanType);}catch(e){}
  setLastDateHeader(scanType);
  document.getElementById('scanButton').disabled=false;
  document.getElementById('scanStopButton').disabled=true;
  liveRequestEpoch++;
  currentResults=[];lastResultIndex=0;
  document.getElementById('currentTable').innerHTML='';
  document.getElementById('scanSourceLabel').innerText=SCAN_NAMES[scanType];
  document.getElementById('scanSourcePath').innerText=SCAN_PATHS[scanType]||'Path təyin edilməyib';
  (function(){
    const mb=document.getElementById('missDateBtn'),mp=document.getElementById('missDatePanel');
    const show=(scanType==='D'||scanType==='H');
    if(mb){mb.style.display=show?'':'none';
      const lbl=document.getElementById('missDateBtnLabel');
      if(lbl)lbl.textContent=show?('Çatışmayan tarixlər ('+(scanType==='D'?'D disk':'H disk')+')'):'Çatışmayan tarixləri tap';}
    if(mp&&!(window.missDateState&&window.missDateState.running))mp.style.display='none';
  })();
  document.getElementById('scanFileHint').innerText=scanType==='DJ'?
    'D Jurnal: ATM ID → Journal varsa onun, yoxdursa ATM-in içindəki BÜTÜN JRN/TXT faylları adındakı YYYYMMDD tarixə görə yoxlanılır. Date Modified istifadə edilmir.':
    (isJournal(scanType)?'Yoxlama: mənbə → ATM ID → YYYYMMDD → TXT faylları.':
    'Yoxlama: mənbə → ATM ID → YYYYMMDD → JPG və video faylları.');
  document.getElementById('selectedDate').value ||= localDateString(new Date(Date.now()-7*86400000));
  resetLive();
  document.getElementById('currentScanId').innerText='-';
  document.getElementById('currentATM').innerText='-';
  document.getElementById('currentPath').innerText=SCAN_PATHS[scanType];
  document.getElementById('currentAction').innerText='Bu mənbə üçün scan gözlənilir.';
  document.getElementById('logBox').innerText='';
  clearFilters('c');
  refreshFilterOptions(currentResults,'c');
  openModule('backup','live');
  checkExistingProgress();
}
/* ---------- Çatışmayan tarix scan (D/H server qovluqları) ---------- */
window.missDateState={running:false,timer:null,key:null};
window.openMissDate=function(){
  const key=activeScanType;
  if(key!=='D'&&key!=='H'){alert('Bu yalnız D və H mənbəsi üçün işləyir.');return;}
  const panel=document.getElementById('missDatePanel');if(panel)panel.style.display='';
  const title=document.getElementById('missDateTitle');if(title)title.textContent=(key==='D'?'D disk (ATMFILES)':'H disk (ATM_GRG_files)');
  // Default interval: son 30 gün
  const s=document.getElementById('mdStart'),e=document.getElementById('mdEnd');
  if(e&&!e.value)e.value=localDateString(new Date());
  if(s&&!s.value)s.value=localDateString(new Date(Date.now()-29*86400000));
  if(panel)panel.scrollIntoView({behavior:'auto',block:'nearest'});
};
window.startMissDate=async function(){
  const key=activeScanType;
  if(key!=='D'&&key!=='H'){alert('Bu yalnız D və H mənbəsi üçün işləyir.');return;}
  const sd=(document.getElementById('mdStart')||{}).value||'';
  const ed=(document.getElementById('mdEnd')||{}).value||'';
  if(!sd||!ed){alert('Başlanğıc və bitmə tarixini seç.');return;}
  const panel=document.getElementById('missDatePanel');if(panel)panel.style.display='';
  const tbody=document.getElementById('missDateTable');if(tbody)tbody.innerHTML='<tr><td colspan="8" class="vaEmpty">Başladılır...</td></tr>';
  const title=document.getElementById('missDateTitle');if(title)title.textContent=(key==='D'?'D disk (ATMFILES)':'H disk (ATM_GRG_files)');
  try{
    const r=await fetch('/api/missdate/start',{method:'POST',headers:{'Content-Type':'application/json','x-requested-with':'atm-web'},body:JSON.stringify({key,start_date:sd,end_date:ed})});
    const d=await r.json();
    if(!r.ok||!d.success)throw new Error(d.error||('HTTP '+r.status));
    window.missDateState.running=true;window.missDateState.key=key;
    const rb=document.getElementById('missDateRunBtn');if(rb)rb.style.display='none';
    const sb=document.getElementById('missDateStopBtn');if(sb)sb.style.display='';
    const eb=document.getElementById('missDateExcelBtn');if(eb)eb.style.display='none';
    _missDatePoll();
    if(window.missDateState.timer)clearInterval(window.missDateState.timer);
    window.missDateState.timer=setInterval(_missDatePoll,1500);
  }catch(e){alert('Başlamadı: '+(e.message||e));}
};
window.missDateCancel=async function(){
  try{await fetch('/api/missdate/cancel',{method:'POST',headers:{'x-requested-with':'atm-web'}});}catch(e){}
};
window.missDateExcel=function(){window.open('/api/missdate/excel?t='+Date.now(),'_blank');};
async function _missDatePoll(){
  try{
    const r=await fetch('/api/missdate/progress?t='+Date.now(),{cache:'no-store'});
    const d=await r.json();
    if(!d||d.success===false)return;
    _missDateRender(d);
    if(!d.running&&d.finished){
      window.missDateState.running=false;
      if(window.missDateState.timer){clearInterval(window.missDateState.timer);window.missDateState.timer=null;}
      const rb=document.getElementById('missDateRunBtn');if(rb)rb.style.display='';
      const sb=document.getElementById('missDateStopBtn');if(sb)sb.style.display='none';
      const eb=document.getElementById('missDateExcelBtn');if(eb&&(d.results||[]).length)eb.style.display='';
    }
  }catch(e){}
}
function _missDateRender(d){
  const pct=d.percent||0;
  const bar=document.getElementById('missDateBar');if(bar)bar.style.width=pct+'%';
  const pt=document.getElementById('missDateProgressText');
  const rng=(d.start_date&&d.end_date)?(' · '+d.start_date+' → '+d.end_date):'';
  if(pt)pt.textContent=(d.running?'İşləyir':(d.finished?'Tamamlandı':'—'))+rng+' · '+(d.processed||0)+' / '+(d.total||0)+(d.error?(' · XƏTA: '+d.error):'');
  const pp=document.getElementById('missDatePercent');if(pp)pp.textContent=pct+'%';
  const c=d.counts||{};
  const set=(id,v)=>{const el=document.getElementById(id);if(el)el.textContent=v||0;};
  set('mdFull',c.full);set('mdPartial',c.partial);set('mdNone',c.none);set('mdUncheck',c.uncheck);
  const tb=document.getElementById('missDateTable');if(!tb)return;
  const rows=d.results||[];
  if(!rows.length){tb.innerHTML='<tr><td colspan="8" class="vaEmpty">'+(d.running?'Yoxlanılır...':'Nəticə yoxdur.')+'</td></tr>';return;}
  tb.innerHTML=rows.map(r=>{
    const cat=r.category||'';
    const badge=cat==='TAM'?'ds-badge--success':(cat==='QİSMƏN'?'ds-badge--warning':(cat==='YOX'?'ds-badge--danger':'ds-badge--neutral'));
    const hot=cat==='YOX'||cat==='QİSMƏN';
    const miss=(r.missing||[]);
    const missTxt=miss.length>12?(miss.slice(0,12).join(', ')+' … (+'+(miss.length-12)+')'):miss.join(', ');
    return '<tr'+(cat==='YOX'?' style="background:rgba(220,38,38,.06)"':'')+'>'+
      '<td class="mono"><b>'+esc(r.atm_id)+'</b></td>'+
      '<td>'+esc(r.name||'—')+'</td><td>'+esc(r.region||'—')+'</td>'+
      '<td><span class="ds-badge ds-badge--dot '+badge+'">'+esc(cat)+'</span></td>'+
      '<td>'+(r.present||0)+'</td><td>'+(r.expected||0)+'</td>'+
      '<td><b style="color:'+(hot?'var(--c-danger)':'inherit')+'">'+(r.missing_count||0)+'</b></td>'+
      '<td class="mono" style="font-size:12px">'+esc(missTxt||(r.error||'—'))+'</td></tr>';
  }).join('');
}

function changeHistoryType(scanType){
  if(!Object.prototype.hasOwnProperty.call(HISTORY_PATHS,scanType))return;
  historyScanType=scanType;
  historyRequestEpoch++;
  document.getElementById('historyDetail').classList.add('hidden');
  document.getElementById('compareContent').innerHTML='<div class="notice">Tarixçə yüklənir...</div>';
  loadHistory();
}
function showTab(tab){
  document.getElementById('liveTab').classList.toggle('hidden',tab!=='live');
  document.getElementById('historyTab').classList.toggle('hidden',tab!=='history');
  document.querySelectorAll('#ipTree .menuBtn').forEach(btn=>btn.classList.toggle('active',tab==='live'&&btn.id==='menuScan_'+activeScanType));
  document.getElementById('menuHistory')?.classList.toggle('active',tab==='history');
  if(tab==='history'){
    historyScanType=activeScanType;
    document.getElementById('historyScanType').value=historyScanType;
    loadHistory();
  }
}

async function loadRestartConfig(){
  try{
    const r=await fetch('/api/restart/config?t='+Date.now());
    const d=await r.json();
    const ci=document.getElementById('restartCredentialInfo');
    ci.innerText=d.configured_count?`${d.configured_count} slot (${d.configured_slots.join(', ')})`:'PASSWORD tapılmadı';
    ci.className=d.configured_count?'statusGood':'statusBad';
    const mi=document.getElementById('restartMethodInfo');
    if(mi){mi.innerText=d.method||'NET USE + shutdown';mi.className='statusGood';}
  }catch(e){console.log(e)}
}
async function startRestart(){
  const atm=document.getElementById('restartATM').value.trim();
  if(!atm){alert('ATM ID daxil et.');return}
  if(!confirm(`${atm} bankomatına RESTART əmri göndərilsin?`))return;

  const btn=document.getElementById('restartButton');
  const res=document.getElementById('restartResult');
  const log=document.getElementById('restartLogBox');

  btn.disabled=true;
  btn.innerText='Başladılır...';
  res.className='hidden';
  res.innerText='';

  // Server cavab verməmişdən əvvəl də istifadəçi ekranda prosesin başladığını görsün.
  document.getElementById('restartTarget').innerText=atm;
  document.getElementById('restartUser').innerText='administrator';
  document.getElementById('restartAttempt').innerText='Hazırlanır...';
  document.getElementById('restartElapsed').innerText='0 saniyə';
  document.getElementById('restartNetwork').innerText='Yoxlanılır...';
  document.getElementById('restartErrorCode').innerText='-';
  document.getElementById('restartAction').innerText='Restart sorğusu serverə göndərilir...';
  document.getElementById('restartStarted').innerText=new Date().toLocaleString();
  document.getElementById('restartFinished').innerText='-';
  log.innerText='Restart sorğusu göndərilir...\nATM: '+atm+'\nUser: administrator\nPASSWORD1-PASSWORD7 yoxlanmağa hazırlanır...';

  // Polling-i POST cavabından əvvəl başlat ki, backend state dərhal ekrana düşsün.
  if(restartPollTimer)clearInterval(restartPollTimer);
  restartPollTimer=setInterval(pollRestart,400);
  pollRestart();

  try{
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),8000);
    const r=await fetch('/api/restart/start',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({atm}),
      signal:controller.signal
    });
    clearTimeout(timer);
    const d=await r.json();
    if(!d.success){
      if(restartPollTimer){clearInterval(restartPollTimer);restartPollTimer=null}
      alert(d.error||'Restart başladılmadı.');
      btn.disabled=false;
      btn.innerText='ATM-i Restart et';
      document.getElementById('restartAction').innerText=d.error||'Restart başladılmadı.';
      return;
    }
    pollRestart();
  }catch(e){
    if(restartPollTimer){clearInterval(restartPollTimer);restartPollTimer=null}
    btn.disabled=false;
    btn.innerText='ATM-i Restart et';
    const msg=(e.name==='AbortError')?'Server 8 saniyə ərzində cavab vermədi.':String(e);
    document.getElementById('restartAction').innerText=msg;
    log.innerText+='\n'+msg;
    alert(msg);
  }
}
async function pollRestart(){
  try{const r=await fetch('/api/restart/progress?t='+Date.now());const d=await r.json();if(!d.success)return;
    document.getElementById('restartTarget').innerText=d.target||'-';
    document.getElementById('restartUser').innerText=d.username||'administrator';
    document.getElementById('restartAttempt').innerText=d.attempt_label?`${d.attempt_label} (sınaq ${d.attempt})`:'-';
    document.getElementById('restartElapsed').innerText=(d.attempt_elapsed||0)+' saniyə';
    const net=document.getElementById('restartNetwork');
    if(d.network_ok===true){net.innerText='Credential / network OK';net.className='statusGood';}
    else if(d.network_ok===false){net.innerText='Credential / network problemi';net.className='statusBad';}
    else{net.innerText='Yoxlanılır...';net.className='mono';}
    document.getElementById('restartErrorCode').innerText=(d.last_error_code===null||d.last_error_code===undefined)?'-':d.last_error_code;
    document.getElementById('restartAction').innerText=d.current_action||'-';
    document.getElementById('restartStarted').innerText=fmtDateTime(d.started_at);document.getElementById('restartFinished').innerText=fmtDateTime(d.finished_at);
    const log=document.getElementById('restartLogBox');log.innerText=(d.logs&&d.logs.length)?d.logs.join('\n'):'Restart əmri gözlənilir...';log.scrollTop=log.scrollHeight;
    const restartBtn=document.getElementById('restartButton');
    restartBtn.disabled=!!d.running;
    restartBtn.innerText=d.running?'Yoxlanılır...':'ATM-i Restart et';
    const res=document.getElementById('restartResult');
    if(d.finished){if(restartPollTimer){clearInterval(restartPollTimer);restartPollTimer=null}res.className='restartResult '+(d.success?'ok':'fail');res.innerText=d.success?`${d.target}: restart əmri uğurla göndərildi${d.matched_password_slot?' (PASSWORD'+d.matched_password_slot+')':''}.`:`Restart alınmadı: ${d.error||'naməlum xəta'}`}
  }catch(e){console.log(e)}
}


let exRoot='d',exRel='',exEntries=[],exLatestFiles=[],exConnectedATM='',exRequestId=0;
const exEl=id=>document.getElementById(id);
const exUrl=(route,root,rel)=>'/api/explorer/'+route+'?'+new URLSearchParams({root,rel}).toString();
function exShowError(message){exEl('archiveError').className='exError';exEl('archiveError').textContent=message;}
async function exGet(url, timeoutMs=15000, allowInProgress=false){
  const ctrl=new AbortController();
  const stop=setTimeout(()=>ctrl.abort(),timeoutMs);
  try{
    const r=await fetch(url,{cache:'no-store',signal:ctrl.signal});
    const data=await r.json();
    if(!r.ok||(!allowInProgress&&!data.success)||(allowInProgress&&data.request_ok===false))throw Error(data.error||('HTTP '+r.status));
    return data;
  }catch(e){
    if(e.name==='AbortError')throw Error('Server '+Math.round(timeoutMs/1000)+' saniyə ərzində cavab vermədi.');
    throw e;
  }finally{clearTimeout(stop);}
}
function exMakeRow(item,root){
  const btn=document.createElement('button');btn.className='exItem';
  const icon=document.createElement('span');icon.textContent=item.kind==='folder'?'📁':(item.ext==='.jrn'||item.ext==='.txt'?'▤':(/jpg|jpeg|png|bmp|gif|webp/.test(item.ext)?'▧':'▷'));
  const name=document.createElement('span');name.className='exFileName';name.textContent=item.rel||item.name;
  const mod=document.createElement('span');mod.className='exMini';mod.textContent=item.modified||'';
  const size=document.createElement('span');size.className='exMini';size.textContent=item.size_display||'—';
  btn.append(icon,name,mod,size);
  btn.title=item.kind==='folder'?'Qovluğu aç':(item.previewable?'Fayla bax':'Bu faylın önizləməsi dəstəklənmir');
  btn.disabled=item.kind==='file'&&!item.previewable;
  btn.onclick=()=>item.kind==='folder'?openExplorer(root,item.rel):previewExplorer(root,item);
  return btn;
}
function exListRender(box,rows,root,empty){
 box.replaceChildren();
 if(!rows.length){const el=document.createElement('div');el.className='exNotice';el.textContent=empty;box.append(el);return;}
 let shown=0;
 const more=document.createElement('button');more.className='btnGray';more.style.margin='10px';
 const renderChunk=()=>{
   more.remove();const part=document.createDocumentFragment();
   const next=Math.min(rows.length,shown+250);
   while(shown<next){part.append(exMakeRow(rows[shown],root));shown++;}
   box.append(part);
   if(shown<rows.length){more.textContent='Daha çox fayl göstər ('+shown+' / '+rows.length+')';box.append(more);}
 };
 more.onclick=renderChunk;renderChunk();
}
async function loadArchiveConfig(){
  if(!exEl('archiveCredentialInfo'))return; // köhnə Video Archive modulu artıq yoxdur
  try{const d=await exGet('/api/archive/config?t='+Date.now());
    exEl('archiveCredentialInfo').textContent=d.configured_count?`${d.configured_count} PASSWORD slotu hazırdır`:'PASSWORD1–7 tapılmadı';
  }catch(e){exEl('archiveCredentialInfo').textContent=String(e);}
}
async function startArchiveScan(){
  const atm=exEl('archiveATM').value.trim().toUpperCase();
  if(!/^[A-Z0-9._-]{1,64}$/.test(atm)){
    exShowError('ATM ID-ni düzgün daxil et.');return;
  }
  const generation=++archiveRequestGeneration;
  archiveStopPolling();
  archivePollFailures=0;
  exConnectedATM='';exRequestId++;
  exEl('exWorkspace').classList.add('hidden');
  exEl('archiveButton').disabled=true;
  exEl('archiveButton').textContent='Qoşulur...';
  exEl('archiveError').className='hidden';
  exEl('exConnection').textContent=atm+' — bağlantı yoxlanılır';
  exEl('archiveLogBox').textContent='ATM: '+atm+'\nAdministrator ilə qoşulma başladılır...';
  const ctrl=new AbortController();
  const timer=setTimeout(()=>ctrl.abort(),10000);
  try{
    const r=await fetch('/api/archive/start',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({atm}),signal:ctrl.signal
    });
    const d=await r.json();
    if(generation!==archiveRequestGeneration)return;
    if(!r.ok||!d.success)throw Error(d.error||'Bağlantı başlamadı');
    archivePollTimer=setInterval(pollArchive,1200);
    await pollArchive();
  }catch(e){
    if(generation!==archiveRequestGeneration)return;
    archiveStopPolling();archiveEnableButton();
    const msg=e.name==='AbortError'
      ? 'Server 10 saniyə ərzində start sorğusuna cavab vermədi.'
      : String(e);
    exShowError('Bağlantı başlamadı: '+msg+' Yeni ATM ID ilə yenidən yoxlaya bilərsən.');
    exEl('exConnection').textContent=atm+' — bağlantı alınmadı';
  }finally{clearTimeout(timer);}
}
async function pollArchive(){
  if(archivePollInFlight)return;
  const generation=archiveRequestGeneration;
  archivePollInFlight=true;
  try{
    const d=await exGet('/api/archive/progress?t='+Date.now(),7000,true);
    if(generation!==archiveRequestGeneration)return;
    archivePollFailures=0;
    exEl('archiveLogBox').textContent=(d.logs||[]).join('\n')||'ATM ID gözlənilir...';
    exEl('archiveLogBox').scrollTop=exEl('archiveLogBox').scrollHeight;
    exEl('exConnection').textContent=(d.target||'ATM')+' — '+(d.current_action||'gözlənilir');
    exEl('archiveButton').disabled=!!d.running;
    exEl('archiveButton').textContent=d.running?'Yoxlanılır...':'ATM-ə qoşul';
    if(d.finished){
      archiveStopPolling();archiveEnableButton();
      if(!d.success){exShowError(d.error||'Bağlantı alınmadı. Başqa ATM ID yoxlaya bilərsən.');return;}
      if(exConnectedATM!==d.target){
        exConnectedATM=d.target;
        exEl('exWorkspace').classList.remove('hidden');
        exEl('exConnection').textContent=d.target+' — qoşuldu (PASSWORD'+(d.matched_password_slot||'?')+')';
        exEl('archiveError').className='hidden';
        // Qovluq skanı bağlantını bloklamır: üç əməliyyat ayrı request-lərdə işləyir.
        openExplorer('d','');openLatestArchive();
      }
    }
  }catch(e){
    if(generation!==archiveRequestGeneration)return;
    archivePollFailures++;
    if(archivePollFailures>=3){
      archiveStopPolling();archiveEnableButton();
      exEl('exConnection').textContent='Serverdən cavab alınmır';
      exShowError('Server 3 dəfə ardıcıl cavab vermədi: '+String(e)+
        '. Düymə yenidən aktivdir. localhost:8080 açılmırsa START.bat pəncərəsindəki xətaya bax.');
    }else{
      exShowError('Bağlantı statusu oxunmadı (cəhd '+archivePollFailures+'/3): '+String(e));
    }
  }finally{archivePollInFlight=false;}
}
function renderExplorerEntries(){
 const filter=exEl('exSearch').value.trim().toLocaleLowerCase();
 exListRender(exEl('exBrowserItems'),exEntries.filter(e=>e.name.toLocaleLowerCase().includes(filter)),exRoot,'Bu qovluqda uyğun fayl və folder tapılmadı.');
}
async function openExplorer(root='d',rel=''){
 if(!exConnectedATM)return exShowError('Əvvəl ATM-ə qoşul.');
 const request=++exRequestId;exRoot=root;exRel=rel;exEl('exCurrentPath').textContent='Qovluq oxunur...';
 exEl('exTabD')?.classList.toggle('exActive',root==='d');exEl('exTabJournal')?.classList.toggle('exActive',root==='journal');
 exEl('exBrowserItems').textContent='Yüklənir...';
 try{const d=await exGet(exUrl('list',root,rel));if(request!==exRequestId)return;
  exEntries=d.entries||[];exEl('exCurrentPath').textContent=d.path;
  exEl('exBrowseCount').textContent=d.folder_count+' qovluq · '+d.file_count+' fayl'+(d.truncated?' · ilk 10000 göstərilir':'');
  exEl('exBack').disabled=!rel;renderExplorerEntries();
 }catch(e){if(request===exRequestId){exEntries=[];exEl('exCurrentPath').textContent='—';exShowError('Qovluq açılmadı: '+String(e));exEl('exBrowserItems').textContent=String(e);}}
}
function explorerUp(){const parts=exRel.split(/[\\/]/).filter(Boolean);parts.pop();openExplorer(exRoot,parts.join('\\'));}
function reloadExplorer(){openExplorer(exRoot,exRel);}
function renderLatestFiles(){
 const q=exEl('exLatestSearch').value.trim().toLocaleLowerCase();
 exListRender(exEl('exLatestItems'),exLatestFiles.filter(f=>f.rel.toLocaleLowerCase().includes(q)),'d','Son tarix folderində uyğun fayl yoxdur.');
}
async function openLatestArchive(){
 if(!exConnectedATM)return exShowError('Əvvəl ATM-ə qoşul.');
 exEl('exTabLatest').classList.add('exActive');exEl('exLatestItems').textContent='Son tarix qovluğunun faylları oxunur...';
 try{const d=await exGet('/api/explorer/latest?t='+Date.now(),90000);exLatestFiles=d.files||[];
 exEl('exLatestPath').textContent=d.path;
 exEl('exLatestCount').textContent='Tarix: '+d.date_folder+' · '+d.files.length+' fayl · '+d.folder_count+' alt qovluq'+(d.truncated?' · ilk 10000 göstərilir':'')+(d.errors?' · '+d.errors+' fayl oxunmadı':'');
 renderLatestFiles();
 // Sol naviqator da avtomatik olaraq son tarix folderinə keçir.
 await openExplorer('d',d.rel);
 }catch(e){exShowError('Son VIDEOARCHIVE alınmadı: '+String(e));exEl('exLatestItems').textContent=String(e);}
}
async function openJournal(showPreview=true){
 if(!exConnectedATM)return exShowError('Əvvəl ATM-ə qoşul.');
 try{const d=await exGet('/api/explorer/journal?t='+Date.now());
  exEl('exJournalPath').textContent=d.path;
  exEl('exJournalResult').textContent=d.latest?('Son fayl: '+d.latest.name+' · Fayl adı tarixi: '+d.latest.date+' · Ölçü: '+d.latest.size_display+' · Cəmi tarixli jurnal: '+d.count):'YYYYMMDD.jrn / YYYYMMDD.txt adlı jurnal tapılmadı.';
  if(showPreview){await openExplorer('journal','');if(d.latest)await previewExplorer('journal',d.latest);}
 }catch(e){exEl('exJournalResult').textContent=String(e);if(showPreview)exShowError('Jurnal oxunmadı: '+String(e));}
}
async function previewExplorer(root,item){
 const title=exEl('exPreviewTitle'),meta=exEl('exPreviewMeta'),box=exEl('exPreview');
 title.textContent=item.name;meta.textContent=(root==='d'?'D$':'C$ / JOURNAL')+' · '+item.size_display+' · '+item.modified;
 box.replaceChildren();const msg=document.createElement('div');msg.className='exNotice';msg.textContent='Fayl açılır...';box.append(msg);
 const url=exUrl('media',root,item.rel);const ext=item.ext.toLowerCase();
 try{
  if(['.txt','.jrn','.log','.csv'].includes(ext)){
   const d=await exGet(exUrl('text',root,item.rel));box.replaceChildren();const pre=document.createElement('pre');pre.textContent=d.text;box.append(pre);
   if(d.truncated){const note=document.createElement('div');note.className='exNotice';note.textContent='Fayl 1 MB-dan böyükdür: yalnız ilk 1 MB göstərilir.';box.prepend(note);}
  }else if(['.jpg','.jpeg','.png','.gif','.webp','.bmp'].includes(ext)){
   box.replaceChildren();const img=document.createElement('img');img.alt=item.name;img.onerror=()=>exShowError('Şəkil göstərilmədi. Faylın formatını və bağlantını yoxla.');img.src=url;box.append(img);
  }else{
   // AVI/WMV/MKV və s. brauzerdə birbaşa oynamır -> serverdə ffmpeg ilə MP4 axınına çevrilir.
   const native=['.mp4','.m4v','.webm','.ogg','.ogv'].includes(ext);
   const vurl=native?url:exUrl('transcode',root,item.rel);
   box.replaceChildren();
   if(!native){const note=document.createElement('div');note.className='exNotice';note.textContent='AVI/WMV serverdə MP4-ə çevrilir (ffmpeg) — başlaması bir neçə saniyə çəkə bilər. İrəli-geri sarımaq məhduddur.';box.append(note);}
   const video=document.createElement('video');video.controls=true;video.preload='metadata';video.playsInline=true;
   video.onerror=()=>exShowError(native?'Video açılmadı.':'Video çevrilmədi. Serverdə ffmpeg.exe var? (server qovluğuna qoy)');video.src=vurl;box.append(video);
  }
 }catch(e){box.textContent=String(e);exShowError('Fayl oxunmadı: '+String(e));}
}

async function checkExistingProgress(){
  const scanType=activeScanType,epoch=liveRequestEpoch;
  try{
    const r=await fetch('/api/progress?scan_type='+scanType+'&since=0&t='+Date.now());
    const d=await r.json();
    if(scanType!==activeScanType||epoch!==liveRequestEpoch||!d.success)return;
    currentResults=d.results||[];
    lastResultIndex=d.next_index||0;
    if(d.selected_date)document.getElementById('selectedDate').value=d.selected_date;
    updateProgressUI(d);
    refreshFilterOptions(currentResults,'c');applyCurrentFilters();
    document.getElementById('scanButton').disabled=!!d.running;
    document.getElementById('scanStopButton').disabled=!d.running||!!d.cancel_requested;
    if(d.running)startPolling();
  }catch(e){console.log(e)}
}

async function startScan(){
  const selectedDate=document.getElementById('selectedDate').value;
  if(!selectedDate){alert('Tarix seç.');return}
  const scanType=activeScanType,epoch=++liveRequestEpoch;
  currentResults=[];lastResultIndex=0;
  document.getElementById('currentTable').innerHTML='';
  resetLive();clearFilters('c');
  document.getElementById('scanButton').disabled=true;
  document.getElementById('scanStopButton').disabled=true;
  try{
    const r=await fetch('/api/start?date='+encodeURIComponent(selectedDate)+'&scan_type='+scanType+'&t='+Date.now());
    const d=await r.json();
    if(scanType!==activeScanType||epoch!==liveRequestEpoch)return;
    if(!d.success){alert(d.error);document.getElementById('scanButton').disabled=false;return}
    document.getElementById('currentScanId').innerText=d.scan_id||'-';
    rememberOwnedScan(scanType,Number(d.scan_id));
    document.getElementById('scanStopButton').disabled=false;
    startPolling();getProgress();
  }catch(e){
    if(scanType===activeScanType&&epoch===liveRequestEpoch){
      alert(e);document.getElementById('scanButton').disabled=false;
    }
  }
}

function startPolling(){if(pollTimer)clearInterval(pollTimer);pollTimer=setInterval(getProgress,900)}
let _liveRenderAt=0,_livePending=false;
async function getProgress(){
  if(document.hidden)return;  // fon tabında poll etmə (qayıdanda davam edir)
  const scanType=activeScanType,epoch=liveRequestEpoch,fromIndex=lastResultIndex;
  try{
    const r=await fetch('/api/progress?scan_type='+scanType+'&since='+fromIndex+'&t='+Date.now());
    const d=await r.json();
    if(scanType!==activeScanType||epoch!==liveRequestEpoch||!d.success)return;
    updateProgressUI(d);
    document.getElementById('scanStopButton').disabled=!d.running||!!d.cancel_requested;
    const finished=d.finished&&!d.running;
    if(d.results&&d.results.length){
      // Ignore older overlapping polls; do not append duplicate rows.
      if(fromIndex===lastResultIndex){
        currentResults.push(...d.results);lastResultIndex=d.next_index;_livePending=true;
      }
    }
    // Ağır cədvəl render-ini throttle et: ən çox ~900ms-də bir (bitəndə mütləq).
    const now=Date.now();
    if(_livePending&&(finished||now-_liveRenderAt>=900)){
      _liveRenderAt=now;_livePending=false;
      refreshFilterOptions(currentResults,'c');applyCurrentFilters();
    }
    if(finished){
      if(pollTimer)clearInterval(pollTimer);pollTimer=null;
      document.getElementById('scanButton').disabled=false;
      document.getElementById('scanStopButton').disabled=true;
      forgetOwnedScan(scanType,Number(d.scan_id));
    }
  }catch(e){console.log(e)}
}

function updateProgressUI(d){
  if(d.scan_type!==activeScanType)return;
  document.getElementById('scanSourceLabel').innerText=SCAN_NAMES[d.scan_type]||d.scan_type;
  document.getElementById('scanSourcePath').innerText=d.source_path||SCAN_PATHS[activeScanType];
  const pct=d.percent||0;
  document.getElementById('progressBar').style.width=pct+'%';
  document.getElementById('progressPercent').innerText=pct+'%';
  document.getElementById('progressText').innerText=(d.processed_atms||0)+' / '+(d.total_atms||0)+' ATM';
  document.getElementById('remainingText').innerText='Qalıb: '+Math.max(0,(d.total_atms||0)-(d.processed_atms||0));
  document.getElementById('currentScanId').innerText=d.scan_id||'-';
  document.getElementById('currentATM').innerText=d.current_atm||'-';
  document.getElementById('currentPath').innerText=d.current_path||d.source_path||'-';
  document.getElementById('currentAction').innerText=d.cancel_requested?(d.current_action||'Scan dayandırılır...'):(d.error?('XƏTA: '+d.error):(d.current_action||'-'));
  updateSummary(d.summary||{});
  const log=document.getElementById('logBox');
  log.innerText=(d.logs||[]).join('\n');log.scrollTop=log.scrollHeight;
  if(d.error)document.getElementById('currentAction').innerText='XƏTA: '+d.error;
}

function updateSummary(s){
  document.getElementById('totalATM').innerText=s.total_atm||0;document.getElementById('checkedATM').innerText=s.checked||0;document.getElementById('excellentATM').innerText=s.excellent||0;document.getElementById('normalATM').innerText=s.normal||0;document.getElementById('problemATM').innerText=s.problem||0;document.getElementById('mediaCount').innerText=s.total_media||0;document.getElementById('mediaDetail').innerText='JPG '+(s.total_images||0)+' / Video '+(s.total_videos||0)+' / TXT '+(s.total_txt||0)
}
function resetLive(){['totalATM','checkedATM','excellentATM','normalATM','problemATM','mediaCount'].forEach(id=>document.getElementById(id).innerText='0');document.getElementById('mediaDetail').innerText='JPG 0 / Video 0 / TXT 0';document.getElementById('progressBar').style.width='0%';document.getElementById('progressPercent').innerText='0%';document.getElementById('progressText').innerText='Scan başladılır...';document.getElementById('remainingText').innerText='-'}

function numericMatch(value,expr){if(value===null||value===undefined)return false;expr=String(expr).replace(/\s/g,'');if(!expr)return true;let n;if(expr.startsWith('>=')){n=parseFloat(expr.slice(2));return value>=n}if(expr.startsWith('<=')){n=parseFloat(expr.slice(2));return value<=n}if(expr.startsWith('>')){n=parseFloat(expr.slice(1));return value>n}if(expr.startsWith('<')){n=parseFloat(expr.slice(1));return value<n}if(expr.startsWith('=')){n=parseFloat(expr.slice(1));return value===n}n=parseFloat(expr);return isNaN(n)?true:value===n}
function v(id){return document.getElementById(id).value.trim()}
function filterResults(data,p){
  const atm=v(p+'ATM').toLowerCase(),cat=v(p+'Category'),y=v(p+'Yesterday'),backup=v(p+'Backup'),delay=v(p+'Delay'),jpg=v(p+'JPG'),video=v(p+'Video'),txt=v(p+'TXT'),total=v(p==='h'?'hTotalNum':p+'Total'),media=v(p+'MediaTime').toLowerCase(),latest=v(p+'Latest'),journalName=v(p+'JournalName').toLowerCase(),reason=v(p+'Reason').toLowerCase();
  return data.filter(x=>{
    if(atm&&!String(x.atm).toLowerCase().includes(atm))return false;if(cat&&x.category!==cat)return false;if(y&&x.yesterday_state!==y)return false;if(backup&&x.last_valid_backup!==backup)return false;if(delay&&!numericMatch(x.delay_days,delay))return false;if(jpg&&!numericMatch(x.images,jpg))return false;if(video&&!numericMatch(x.videos,video))return false;if(txt&&!numericMatch(x.txt||0,txt))return false;if(total&&!numericMatch(x.total,total))return false;if(media&&!String(x.last_media_time).toLowerCase().includes(media))return false;if(latest&&x.latest_date_folder!==latest)return false;if(journalName&&!String(x.latest_journal_filename||'').toLowerCase().includes(journalName))return false;if(reason&&!String(x.reason).toLowerCase().includes(reason))return false;return true
  })
}
function applyCurrentFilters(){const f=filterResults(currentResults,'c');renderResults(f,'currentTable');document.getElementById('currentCount').innerText=f.length+' nəticə'}
function applyHistoryFilters(){const f=filterResults(historyResults,'h');renderResults(f,'historyDetailTable');document.getElementById('historyDetailCount').innerText=f.length+' nəticə'}
function clearFilters(p){['ATM','Category','Yesterday','Backup','Delay','JPG','Video','TXT','MediaTime','Latest','JournalName','Reason'].forEach(s=>{const e=document.getElementById(p+s);if(e)e.value=''});const totalId=p==='h'?'hTotalNum':p+'Total';const t=document.getElementById(totalId);if(t)t.value='';if(p==='c')applyCurrentFilters();else applyHistoryFilters()}
function refreshFilterOptions(data,p){fillSelect(p+'Backup',data.map(x=>x.last_valid_backup));fillSelect(p+'Latest',data.map(x=>x.latest_date_folder))}
function fillSelect(id,values){const s=document.getElementById(id);if(!s)return;const old=s.value;const unique=[...new Set(values.filter(x=>x&&x!=='-'))].sort((a,b)=>b.localeCompare(a));s.innerHTML='<option value="">Hamısı</option>';unique.forEach(x=>{const o=document.createElement('option');o.value=x;o.textContent=x;s.appendChild(o)});if(unique.includes(old))s.value=old}
function esc(x){const d=document.createElement('div');d.innerText=x??'';return d.innerHTML}
function renderResults(items,tbodyId){
  const tb=document.getElementById(tbodyId);tb.innerHTML='';items.forEach((x,i)=>{
    const tr=document.createElement('tr');if(x.category==='PROBLEM')tr.className='problemRow';if(x.category==='EXCELLENT')tr.className='excellentRow';const cat=x.category==='EXCELLENT'?'ƏLA':x.category;const ycls=x.yesterday_state==='VAR'?'yVAR':x.yesterday_state==='BOŞ'?'yBOŞ':x.yesterday_state==='XƏTA'?'yXƏTA':'yYOX';const delay=x.delay_days===null||x.delay_days===undefined?'-':x.delay_days+' gün';
    tr.innerHTML=`<td>${i+1}</td><td class="atmBlue">${esc(x.atm)}</td><td><span class="badge ${x.category}">${cat}</span></td><td class="${ycls}">${esc(x.yesterday_state)}</td><td>${esc(x.last_valid_backup)}</td><td>${delay}</td><td>${x.images||0}</td><td>${x.videos||0}</td><td>${x.txt||0}</td><td><b>${x.total||0}</b></td><td>${esc(x.last_media_time)}</td><td>${esc(x.latest_date_folder)}</td><td>${esc(x.latest_journal_filename||'-')}</td><td>${esc(x.reason)}</td>`;tb.appendChild(tr)
  })
}

async function loadHistory(){
  const scanType=historyScanType,epoch=++historyRequestEpoch;
  document.getElementById('historyScanType').value=scanType;
  try{
    const r=await fetch('/api/history?scan_type='+scanType+'&limit=1000&t='+Date.now());
    const d=await r.json();
    if(scanType!==historyScanType||epoch!==historyRequestEpoch||!d.success)return;
    historyScans=d.scans||[];
    document.getElementById('historyDetail').classList.add('hidden');
    renderHistoryList();populateCompareSelects();
    document.getElementById('compareContent').innerHTML='<div class="notice">Bu mənbə üzrə müqayisə üçün iki scan seç.</div>';
    if(historyScans.length){viewHistory(historyScans[0].id)}
    if(historyScans.length>=2){
      document.getElementById('compareNew').value=String(historyScans[0].id);
      document.getElementById('compareOld').value=String(historyScans[1].id);
      compareSelected();
    }
  }catch(e){console.log(e)}
}
function fmtDateTime(v){if(!v)return '-';return v.replace('T',' ')}
function renderHistoryList(){
  const tb=document.getElementById('historyTable');tb.innerHTML='';historyScans.forEach(s=>{const tr=document.createElement('tr');tr.id='scanRow'+s.id;tr.onclick=()=>viewHistory(s.id);tr.innerHTML=`<td><b>#${s.id}</b></td><td><b>${esc(s.scan_type||'D')} Scan</b></td><td>${fmtDateTime(s.started_at)}</td><td>${fmtDateTime(s.finished_at)}</td><td><span class="badge ${s.status}">${s.status}</span></td><td>${esc(s.selected_date)}</td><td>${s.checked}/${s.total_atm}</td><td>${s.excellent}</td><td>${s.normal}</td><td><b>${s.problem}</b></td><td>${s.total_media}</td><td>${Number(s.duration_seconds||0).toFixed(1)} s</td><td><button class="mini" onclick="event.stopPropagation();viewHistory(${s.id})">Bax</button></td>`;tb.appendChild(tr)})
}
function populateCompareSelects(){
  ['compareOld','compareNew'].forEach(id=>{const s=document.getElementById(id);s.innerHTML='';historyScans.forEach(x=>{const o=document.createElement('option');o.value=x.id;o.textContent=`${x.scan_type||'D'} #${x.id} | ${fmtDateTime(x.started_at)} | P:${x.problem}`;s.appendChild(o)})})
}
async function viewHistory(id){
  const requestedType=historyScanType,epoch=historyRequestEpoch;
  try{
    document.querySelectorAll('.historyTable tr.selected').forEach(x=>x.classList.remove('selected'));
    const row=document.getElementById('scanRow'+id);if(row)row.classList.add('selected');
    const r=await fetch('/api/history_detail?id='+id+'&t='+Date.now());
    const d=await r.json();
    if(requestedType!==historyScanType||epoch!==historyRequestEpoch)return;
    if(!d.success){alert(d.error);return}
    if((d.scan.scan_type||'D')!==historyScanType)return;

    selectedHistoryScan=d.scan;
    document.querySelectorAll('#historyTab .lastDateColumn').forEach(el=>{el.textContent=d.scan.scan_type==='DJ'?'Ən son faylın adındakı tarix':'Son tarix folderi'});
    document.querySelectorAll('#historyTab .mediaTimeColumn').forEach(el=>{el.textContent=d.scan.scan_type==='DJ'?'Backup tarixi (fayl adı)':'Son media vaxtı'});
    historyResults=d.results||[];
    document.getElementById('historyDetail').classList.remove('hidden');

    const total=Number(d.scan.total_atm||0);
    const checked=Number(d.scan.checked||0);
    const pct=total>0?Math.min(100,Math.round((checked/total)*1000)/10):0;

    document.getElementById('historyDetailTitle').innerText='Tarixçə Dashboard — Scan #'+d.scan.id;
    document.getElementById('historyDetailMeta').innerHTML='Bu ekran scan zamanı gördüyün dashboard-un saxlanmış snapshot versiyasıdır.';
    document.getElementById('hProgressText').innerText=checked+' / '+total+' ATM yoxlanılıb';
    document.getElementById('hHistoryStatus').innerHTML='Status: <b>'+esc(d.scan.status)+'</b>';
    document.getElementById('hProgressBar').style.width=pct+'%';
    document.getElementById('hProgressPercent').innerText=pct+'%';
    document.getElementById('hScanId').innerText='#'+d.scan.id;
    document.getElementById('hScanType').innerText=SCAN_NAMES[d.scan.scan_type||'D']||d.scan.scan_type;
    document.getElementById('hSourcePath').innerText=d.scan.source_path||HISTORY_PATHS[d.scan.scan_type||'D'];
    document.getElementById('hStartedAt').innerText=fmtDateTime(d.scan.started_at);
    document.getElementById('hFinishedAt').innerText=fmtDateTime(d.scan.finished_at);
    document.getElementById('hSelectedDate').innerText=d.scan.selected_date||'-';
    document.getElementById('hYesterdayDate').innerText=d.scan.yesterday||'-';
    document.getElementById('hDuration').innerText=Number(d.scan.duration_seconds||0).toFixed(1)+' saniyə';

    document.getElementById('hTotal').innerText=total;
    document.getElementById('hChecked').innerText=checked;
    document.getElementById('hExcellent').innerText=d.scan.excellent||0;
    document.getElementById('hNormal').innerText=d.scan.normal||0;
    document.getElementById('hProblem').innerText=d.scan.problem||0;
    document.getElementById('hMedia').innerText=d.scan.total_media||0;
    document.getElementById('hMediaDetail').innerText='JPG '+(d.scan.total_images||0)+' / Video '+(d.scan.total_videos||0)+' / TXT '+(d.scan.total_txt||0);

    refreshFilterOptions(historyResults,'h');
    clearFilters('h');
    applyHistoryFilters();
    document.getElementById('historyDetail').scrollIntoView({behavior:'smooth',block:'start'});
  }catch(e){alert(e)}
}

async function compareSelected(){
  const oldId=document.getElementById('compareOld').value,newId=document.getElementById('compareNew').value;if(!oldId||!newId||oldId===newId){document.getElementById('compareContent').innerHTML='<div class="notice">İki fərqli scan seç.</div>';return}
  try{const r=await fetch('/api/compare?old_id='+oldId+'&new_id='+newId+'&t='+Date.now());const d=await r.json();if(!d.success){alert(d.error);return}const delta=d.problem_delta;const deltaTxt=delta<0?Math.abs(delta)+' azalıb':delta>0?delta+' artıb':'dəyişməyib';const cls=delta<0?'pos':delta>0?'neg':'neutral';document.getElementById('compareContent').innerHTML=`
    <div class="notice"><b>Köhnə:</b> #${d.old_scan.id} — ${fmtDateTime(d.old_scan.started_at)} &nbsp; | &nbsp; <b>Yeni:</b> #${d.new_scan.id} — ${fmtDateTime(d.new_scan.started_at)}</div>
    <div class="compareCards">
      <div class="compareCard">Problem fərqi<strong class="${cls}">${deltaTxt}</strong></div>
      <div class="compareCard">Həll olunan problem<strong class="pos">${d.solved_count}</strong></div>
      <div class="compareCard">Yeni problem<strong class="neg">${d.new_problem_count}</strong></div>
      <div class="compareCard">Yaxşılaşan ATM<strong class="pos">${d.improved_count}</strong></div>
      <div class="compareCard">Pisləşən ATM<strong class="neg">${d.worsened_count}</strong></div>
      <div class="compareCard">Dəyişməyən<strong class="neutral">${d.unchanged_count}</strong></div>
    </div>
    <div class="listBox"><b>Həll olunan problemli ATM-lər (${d.solved_count}):</b><br>${d.solved_atms.length?d.solved_atms.map(esc).join(', '):'-'}</div>
    <div class="listBox"><b>Yeni problem yaranan ATM-lər (${d.new_problem_count}):</b><br>${d.new_problem_atms.length?d.new_problem_atms.map(esc).join(', '):'-'}</div>`}
  catch(e){alert(e)}
}

function scanExcelHistory(){
  if(!selectedHistoryScan){alert('Əvvəlcə tarixçədən bir scan seçin.');return}
  window.location='/api/scan/excel?id='+selectedHistoryScan.id+'&t='+Date.now();
}
function scanExcelLive(){
  const id=(document.getElementById('currentScanId').textContent||'').trim();
  if(!id||id==='-'){alert('Hələ tamamlanmış scan yoxdur. Scan bitəndən sonra Excel yükləyin.');return}
  window.location='/api/scan/excel?id='+encodeURIComponent(id)+'&t='+Date.now();
}
function exportHistoryCSV(){
  if(!selectedHistoryScan)return;const rows=[["ATM ID","Kateqoriya","Dunen","Son etibarli backup","Gecikme gun","JPG","Video","TXT","Cemi","Son media vaxti","Son tarix folderi","Son jurnal fayli","Sebeb"]];historyResults.forEach(x=>rows.push([x.atm,x.category,x.yesterday_state,x.last_valid_backup,x.delay_days??'',x.images,x.videos,x.txt||0,x.total,x.last_media_time,x.latest_date_folder,x.latest_journal_filename||'',x.reason]));const csv='\ufeff'+rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(';')).join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='ATM_'+(selectedHistoryScan.scan_type||'D')+'_SCAN_'+selectedHistoryScan.id+'_'+selectedHistoryScan.started_at.replace(/[:T]/g,'-')+'.csv';document.body.appendChild(a);a.click();a.remove()
}

// ====== ATM INVENTORY / COORDINATES ======
let atmInventoryRows=[];
let atmInventoryLoadTimer=null;
function scheduleAtmInventoryLoad(){if(atmInventoryLoadTimer)clearTimeout(atmInventoryLoadTimer);atmInventoryLoadTimer=setTimeout(loadAtmInventory,280)}
function atmInvFmtDate(v){return v?String(v).replace('T',' '):'—'}
function atmInvFind(id){return atmInventoryRows.find(x=>Number(x.id)===Number(id))||null}
async function loadAtmInventory(){
 const q=(document.getElementById('atmInventorySearch')?.value||'').trim();
 const state=document.getElementById('atmInventoryState')?.value||'visible';
 const tbody=document.getElementById('atmInventoryTable');if(!tbody)return;
 tbody.innerHTML='<tr><td colspan="9">Məlumatlar yüklənir...</td></tr>';
 try{
  const r=await fetch('/api/atms?'+new URLSearchParams({q,state,t:Date.now()}).toString(),{cache:'no-store'});
  const d=await r.json();if(!r.ok||!d.success)throw Error(d.error||'ATM siyahısı oxunmadı');
  atmInventoryRows=d.rows||[];renderAtmInventory();
  const s=d.stats||{};document.getElementById('atmStatTotal').textContent=s.total||0;document.getElementById('atmStatActive').textContent=s.active||0;document.getElementById('atmStatInactive').textContent=s.inactive||0;document.getElementById('atmStatDeleted').textContent=s.deleted||0;document.getElementById('atmStatPassword').textContent=s.password_found||0;
 }catch(e){tbody.innerHTML='<tr><td colspan="9" class="ds-field-error">'+esc(String(e.message||e))+'</td></tr>'}
}
function renderAtmInventory(){
 const tb=document.getElementById('atmInventoryTable');tb.replaceChildren();document.getElementById('atmInventoryCount').textContent=atmInventoryRows.length+' ATM';
 if(!atmInventoryRows.length){const tr=document.createElement('tr');tr.innerHTML='<td colspan="9">Uyğun ATM tapılmadı.</td>';tb.appendChild(tr);return}
 atmInventoryRows.forEach((x,i)=>{
  const tr=document.createElement('tr');if(Number(x.is_deleted))tr.className='deletedRow';
  const state=Number(x.is_deleted)?['deleted','SİLİNİB']:Number(x.status)?['active','AKTİV']:['inactive','DEAKTİV'];
  const env=x.password_env?'<span class="atmInvEnv found">'+esc(x.password_env)+'</span>':'<span class="atmInvEnv">Tapılmayıb</span>';
  let conn='<span class="atmInvConn">Yoxlanmayıb</span>';
  if(x.last_connection_ok===1)conn='<span class="atmInvConn ok">UĞURLU · '+esc(atmInvFmtDate(x.last_connection_at))+'</span>';
  else if(x.last_connection_ok===0)conn='<span class="atmInvConn fail">XƏTA · '+esc(x.last_connection_error||'Qoşulma alınmadı')+'</span>';
  let actions='';
  if(Number(x.is_deleted))actions='<button class="atmInvRestore" onclick="restoreAtmInventory('+x.id+')">↺ Bərpa et</button>';
  else actions='<button class="atmInvConnect" onclick="connectAtmInventory('+x.id+',this)">⌁ Qoşulma</button><button class="atmInvEdit" onclick="openAtmInventoryModal('+x.id+')">✎ Update</button><button class="atmInvDelete" onclick="deleteAtmInventory('+x.id+')">⌫ Delete</button>';
  tr.innerHTML='<td>'+(i+1)+'</td><td class="atmBlue">'+esc(x.atm_id)+'</td><td class="atmInvCoord">'+Number(x.latitude).toFixed(6)+'</td><td class="atmInvCoord">'+Number(x.longitude).toFixed(6)+'</td><td><span class="atmInvStatus '+state[0]+'">'+state[1]+'</span></td><td>'+env+'</td><td>'+conn+'</td><td>'+esc(atmInvFmtDate(x.updated_at))+'</td><td><div class="atmInvActions">'+actions+'</div></td>';
  tb.appendChild(tr);
 });
}
function openAtmInventoryModal(id=null){
 const row=id?atmInvFind(id):null;document.getElementById('atmEditId').value=row?row.id:'';document.getElementById('atmEditATM').value=row?row.atm_id:'';document.getElementById('atmEditLat').value=row?row.latitude:'';document.getElementById('atmEditLong').value=row?row.longitude:'';document.getElementById('atmEditStatus').checked=row?!!Number(row.status):true;document.getElementById('atmEditPassword').textContent=row?(row.password_env||'Tapılmayıb — “Qoşulma” düyməsi ilə avtomatik tapılır'):'Yeni ATM yaradıldıqdan sonra “Qoşulma” düyməsi ilə avtomatik tapılır';document.getElementById('atmInventoryModalTitle').textContent=row?'ATM Update — '+row.atm_id:'Yeni ATM əlavə et';document.getElementById('atmInventoryFormError').classList.add('hidden');document.getElementById('atmInventoryModal').classList.remove('hidden');setTimeout(()=>document.getElementById('atmEditATM').focus(),50)
}
function closeAtmInventoryModal(){document.getElementById('atmInventoryModal').classList.add('hidden')}
async function atmInvPost(url,payload){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});let d={};try{d=await r.json()}catch(e){}if(!r.ok||!d.success)throw Error(d.error||('HTTP '+r.status));return d}
async function saveAtmInventory(){
 const err=document.getElementById('atmInventoryFormError'),btn=document.getElementById('atmInventorySaveButton');err.classList.add('hidden');btn.disabled=true;btn.textContent='Yadda saxlanılır...';
 try{await atmInvPost('/api/atms/save',{id:Number(document.getElementById('atmEditId').value)||0,atm_id:document.getElementById('atmEditATM').value.trim().toUpperCase(),latitude:document.getElementById('atmEditLat').value,longitude:document.getElementById('atmEditLong').value,status:document.getElementById('atmEditStatus').checked});closeAtmInventoryModal();await loadAtmInventory()}
 catch(e){err.textContent=String(e.message||e);err.classList.remove('hidden')}
 finally{btn.disabled=false;btn.textContent='Yadda saxla'}
}
async function deleteAtmInventory(id){const row=atmInvFind(id);if(!row||!confirm(row.atm_id+' soft delete edilsin? Məlumat bazadan fiziki silinməyəcək.'))return;try{await atmInvPost('/api/atms/delete',{id});await loadAtmInventory()}catch(e){alert(e.message||e)}}
async function restoreAtmInventory(id){try{await atmInvPost('/api/atms/restore',{id});await loadAtmInventory()}catch(e){alert(e.message||e)}}
async function connectAtmInventory(id,button){
 const row=atmInvFind(id);if(!row)return;const old=button.textContent;button.disabled=true;button.textContent='Yoxlanılır...';
 try{const d=await atmInvPost('/api/atms/connect',{id});button.textContent='✓ '+(d.password_env||'Tapıldı');await loadAtmInventory()}
 catch(e){alert(row.atm_id+' qoşulma alınmadı:\n'+String(e.message||e));await loadAtmInventory()}
 finally{button.disabled=false;button.textContent=old}
}


// ====== ATM INVENTORY BULK CONNECTION ======
let atmBulkPollTimer=null,atmBulkLastProcessed=-1,atmBulkLastRefresh=0;
function atmBulkElapsed(started,finished){if(!started)return '—';const a=new Date(started),b=finished?new Date(finished):new Date();const sec=Math.max(0,Math.floor((b-a)/1000));const m=Math.floor(sec/60),s=sec%60;return m?`${m} dəq ${s} san`:`${s} san`}
function renderAtmBulkState(d){
 document.getElementById('atmBulkTotal').textContent=d.total||0;document.getElementById('atmBulkProcessed').textContent=d.processed||0;document.getElementById('atmBulkSuccess').textContent=d.success_count||0;document.getElementById('atmBulkFailed').textContent=d.failed_count||0;document.getElementById('atmBulkCurrent').textContent=d.current_atm||'—';
 const pct=Number(d.percent||0);document.getElementById('atmBulkFill').style.width=Math.max(0,Math.min(100,pct))+'%';document.getElementById('atmBulkPercent').textContent=pct.toFixed(1)+'%';document.getElementById('atmBulkTime').textContent=atmBulkElapsed(d.started_at,d.finished_at);
 const state=document.getElementById('atmBulkState');state.textContent=d.running?'İŞLƏYİR':d.finished?(d.cancel_requested?'DAYANDIRILIB':'TAMAMLANIB'):'Gözləyir';
 const log=document.getElementById('atmBulkLog');log.textContent=(d.logs||[]).join('\n')||'Toplu yoxlama başlamayıb.';log.scrollTop=log.scrollHeight;
 document.getElementById('atmBulkStart').disabled=!!d.running;document.getElementById('atmBulkStop').classList.toggle('hidden',!d.running);
}
async function pollAtmBulkProgress(startLoop=false){
 try{const r=await fetch('/api/atms/bulk_progress?t='+Date.now(),{cache:'no-store'});const d=await r.json();if(!r.ok||!d.success)return;renderAtmBulkState(d);
  if(Number(d.processed)!==atmBulkLastProcessed && (Date.now()-atmBulkLastRefresh>2500||d.finished)){atmBulkLastProcessed=Number(d.processed);atmBulkLastRefresh=Date.now();if(!document.getElementById('atmInventoryModule').classList.contains('hidden'))loadAtmInventory();}
  if(d.running&&startLoop&&!atmBulkPollTimer)atmBulkPollTimer=setInterval(()=>pollAtmBulkProgress(false),900);
  if(!d.running&&atmBulkPollTimer){clearInterval(atmBulkPollTimer);atmBulkPollTimer=null;}
 }catch(e){console.log(e)}
}
async function startAtmBulkConnection(){
 if(!confirm('Aktiv və silinməmiş BÜTÜN ATM-lərdə PASSWORD environment slotları yenidən sıfırdan yoxlanacaq. Bu əməliyyat uzun çəkə bilər. Başlayaq?'))return;
 try{const r=await fetch('/api/atms/bulk_start',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});const d=await r.json();if(!r.ok||!d.success)throw Error(d.error||'Toplu qoşulma başlamadı');atmBulkLastProcessed=-1;await pollAtmBulkProgress(true);if(!atmBulkPollTimer)atmBulkPollTimer=setInterval(()=>pollAtmBulkProgress(false),900)}catch(e){alert(String(e.message||e))}
}
async function stopAtmBulkConnection(){
 if(!confirm('Toplu qoşulma dayandırılsın? Hazırda işləyən bir neçə ATM yoxlaması timeout-a qədər davam edə bilər.'))return;
 try{const r=await fetch('/api/atms/bulk_cancel',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});const d=await r.json();if(!r.ok||!d.success)throw Error(d.error||'Dayandırılmadı');pollAtmBulkProgress(true)}catch(e){alert(String(e.message||e))}
}


// ====== SELECTED ATM DISK REPORT ======
let diskReportActiveAtms=[];
let diskReportSelected=new Map();
let diskReportRows=[];
let diskReportLastIndex=0;
let diskReportPollTimer=null;
let diskReportPollBusy=false;
let diskReportCurrentRun=null;
let diskReportHistoryRows=[];

function diskRptFmtBytes(v){if(v===null||v===undefined||!Number.isFinite(Number(v)))return '—';return (Number(v)/1073741824).toLocaleString('az-AZ',{minimumFractionDigits:1,maximumFractionDigits:1})+' GB'}
function diskRptFmtPct(v){return v===null||v===undefined||!Number.isFinite(Number(v))?'—':Number(v).toFixed(1)+'%'}
function diskRptAccessClass(s){s=String(s||'');return s==='UĞURLU'?'ok':s==='QİSMƏN'?'partial':'fail'}
function diskRptEscapeAttr(v){return esc(String(v??''))}

async function openDiskReportSelector(preselect=[]){
 const modal=document.getElementById('diskRptSelector');if(!modal)return;
 diskReportSelected=new Map();
 document.getElementById('diskRptLeftSearch').value='';document.getElementById('diskRptRightSearch').value='';
 document.getElementById('diskRptAvailable').innerHTML='<div class="diskRptPickEmpty">Aktiv ATM-lər yüklənir...</div>';
 modal.classList.remove('hidden');
 try{
  const r=await fetch('/api/atms?state=active&t='+Date.now(),{cache:'no-store'}),d=await r.json();
  if(!r.ok||!d.success)throw Error(d.error||'ATM siyahısı oxunmadı');
  diskReportActiveAtms=(d.rows||[]).filter(x=>Number(x.status)===1&&!Number(x.is_deleted));
  const want=new Set((preselect||[]).map(x=>String(x).toUpperCase()));
  diskReportActiveAtms.forEach(x=>{if(want.has(String(x.atm_id).toUpperCase()))diskReportSelected.set(String(x.atm_id).toUpperCase(),x)});
  renderDiskReportSelector();
 }catch(e){document.getElementById('diskRptAvailable').innerHTML='<div class="diskRptPickEmpty">'+esc(String(e.message||e))+'</div>'}
}
function closeDiskReportSelector(){document.getElementById('diskRptSelector')?.classList.add('hidden')}
function diskReportMoveOneRight(atm){const row=diskReportActiveAtms.find(x=>String(x.atm_id).toUpperCase()===String(atm).toUpperCase());if(row){diskReportSelected.set(String(row.atm_id).toUpperCase(),row);renderDiskReportSelector()}}
function diskReportMoveOneLeft(atm){diskReportSelected.delete(String(atm).toUpperCase());renderDiskReportSelector()}
function diskReportMoveAllRight(){
 const q=(document.getElementById('diskRptLeftSearch')?.value||'').trim().toUpperCase();
 diskReportActiveAtms.forEach(x=>{const id=String(x.atm_id).toUpperCase();if(!q||id.includes(q))diskReportSelected.set(id,x)});renderDiskReportSelector();
}
function diskReportMoveAllLeft(){
 const q=(document.getElementById('diskRptRightSearch')?.value||'').trim().toUpperCase();
 if(!q)diskReportSelected.clear();else [...diskReportSelected.keys()].forEach(id=>{if(id.includes(q))diskReportSelected.delete(id)});renderDiskReportSelector();
}
function renderDiskReportSelector(){
 const lq=(document.getElementById('diskRptLeftSearch')?.value||'').trim().toUpperCase(),rq=(document.getElementById('diskRptRightSearch')?.value||'').trim().toUpperCase();
 const left=diskReportActiveAtms.filter(x=>{const id=String(x.atm_id).toUpperCase();return !diskReportSelected.has(id)&&(!lq||id.includes(lq))});
 const right=[...diskReportSelected.values()].filter(x=>!rq||String(x.atm_id).toUpperCase().includes(rq));
 const l=document.getElementById('diskRptAvailable'),r=document.getElementById('diskRptSelected');
 l.innerHTML=left.length?left.map(x=>`<div class="diskRptPickRow" ondblclick="diskReportMoveOneRight('${diskRptEscapeAttr(x.atm_id)}')" title="İki dəfə kliklə → sağa"><b>${esc(x.atm_id)}</b><small>${esc(x.password_env||'PASSWORD ?')}</small></div>`).join(''):'<div class="diskRptPickEmpty">Solda uyğun ATM qalmadı.</div>';
 r.innerHTML=right.length?right.map(x=>`<div class="diskRptPickRow" ondblclick="diskReportMoveOneLeft('${diskRptEscapeAttr(x.atm_id)}')" title="İki dəfə kliklə → sola"><b>${esc(x.atm_id)}</b><small>${esc(x.password_env||'PASSWORD ?')}</small></div>`).join(''):'<div class="diskRptPickEmpty">Hələ ATM seçilməyib.</div>';
 document.getElementById('diskRptAvailableCount').textContent=left.length+' / '+diskReportActiveAtms.length;
 document.getElementById('diskRptSelectedCount').textContent=diskReportSelected.size;
 document.getElementById('diskRptStartBtn').disabled=diskReportSelected.size===0;
}
async function startSelectedDiskReport(){
 const ids=[...diskReportSelected.values()].map(x=>x.atm_id);if(!ids.length){alert('Ən azı bir ATM seç.');return}
 const btn=document.getElementById('diskRptStartBtn');btn.disabled=true;btn.textContent='Başladılır...';
 try{
  const r=await fetch('/api/disk-report/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({atm_ids:ids})}),d=await r.json();
  if(!r.ok||!d.success)throw Error(d.error||'Disk Report başlamadı');
  closeDiskReportSelector();diskReportRows=[];diskReportLastIndex=0;diskReportCurrentRun=d.run_id||null;renderDiskReportTable();openModule('diskreport');pollDiskReport(true);
 }catch(e){alert(String(e.message||e))}
 finally{btn.disabled=false;btn.textContent='▶ Başlat'}
}
async function stopDiskReport(){
 if(!confirm('Aktiv Disk Report dayandırılsın? Tamamlanan nəticələr tarixçədə qalacaq.'))return;
 try{const r=await fetch('/api/disk-report/cancel',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}),d=await r.json();if(!r.ok||!d.success)throw Error(d.error||'Dayandırılmadı');pollDiskReport(true)}catch(e){alert(String(e.message||e))}
}
function diskRptRenderState(d){
 document.getElementById('diskRptTotal').textContent=d.total||0;document.getElementById('diskRptProcessed').textContent=d.processed||0;document.getElementById('diskRptSuccess').textContent=d.success_count||0;document.getElementById('diskRptPartial').textContent=d.partial_count||0;document.getElementById('diskRptFailed').textContent=d.failed_count||0;
 document.getElementById('diskRptFill').style.width=Math.max(0,Math.min(100,Number(d.percent)||0))+'%';document.getElementById('diskRptPercent').textContent=(Number(d.percent)||0).toFixed(1)+'%';document.getElementById('diskRptCurrent').textContent=d.current_atm||'—';document.getElementById('diskRptRunBadge').textContent=d.run_id?'Run #'+d.run_id:'Run —';
 document.getElementById('diskRptStopBtn').classList.toggle('hidden',!d.running);document.getElementById('diskRptState').textContent=d.running?'Report işləyir':d.finished?(d.cancel_requested?'Report dayandırılıb':d.error?'Report xətalı bitib':'Report tamamlanıb'):'Report başlamayıb';
 document.getElementById('diskRptMeta').textContent=d.started_at?('Başlama: '+atmInvFmtDate(d.started_at)+(d.finished_at?' · Bitmə: '+atmInvFmtDate(d.finished_at):'')):'ATM seç düyməsi ilə siyahını hazırla.';
 document.getElementById('diskRptLog').textContent=(d.logs||[]).join('\n')||'Report gözləyir.';document.getElementById('diskRptLog').scrollTop=document.getElementById('diskRptLog').scrollHeight;
}
async function pollDiskReport(force=false){
 if(diskReportPollBusy&&!force)return;diskReportPollBusy=true;
 try{
  const r=await fetch('/api/disk-report/progress?'+new URLSearchParams({since:diskReportLastIndex,t:Date.now()}),{cache:'no-store'}),d=await r.json();if(!r.ok||!d.success)throw Error(d.error||'Disk Report status alınmadı');
  diskRptRenderState(d);diskReportCurrentRun=d.run_id||diskReportCurrentRun;
  if(d.new_results?.length){diskReportRows.push(...d.new_results);diskReportLastIndex=Number(d.next_index)||diskReportRows.length;renderDiskReportTable()}
  if(d.running){if(!diskReportPollTimer)diskReportPollTimer=setInterval(()=>pollDiskReport(false),900)}else{if(diskReportPollTimer){clearInterval(diskReportPollTimer);diskReportPollTimer=null}if(d.finished)loadDiskReportHistory()}
 }catch(e){console.log('disk report poll',e)}finally{diskReportPollBusy=false}
}
function diskRptDiskHtml(pct){if(pct===null||pct===undefined||!Number.isFinite(Number(pct)))return '<span class="diskRptMuted">—</span>';const n=Math.max(0,Math.min(100,Number(pct)));return `<div class="diskRptDiskCell"><div class="diskRptDiskLine"><b>${n.toFixed(1)}%</b><div class="diskRptDiskBar"><i class="${n>=85?'hot':''}" style="width:${n}%"></i></div></div></div>`}
function renderDiskReportTable(){
 const q=(document.getElementById('diskRptSearch')?.value||'').trim().toUpperCase(),tb=document.getElementById('diskRptTable');if(!tb)return;const rows=diskReportRows.filter(x=>!q||String(x.atm_id).toUpperCase().includes(q));
 tb.innerHTML=rows.length?rows.map((x,i)=>`<tr><td>${i+1}</td><td class="atmBlue">${esc(x.atm_id)}</td><td><span class="diskRptAccess ${diskRptAccessClass(x.access_status)}">${esc(x.access_status||'—')}</span></td><td>${x.password_env?`<span class="atmInvEnv found">${esc(x.password_env)}</span>`:'—'}</td><td>${diskRptDiskHtml(x.c_used_percent)}</td><td>${esc(diskRptFmtBytes(x.c_total_bytes))}</td><td>${esc(diskRptFmtBytes(x.c_free_bytes))}</td><td>${diskRptDiskHtml(x.d_used_percent)}</td><td>${esc(diskRptFmtBytes(x.d_total_bytes))}</td><td>${esc(diskRptFmtBytes(x.d_free_bytes))}</td><td>${esc(atmInvFmtDate(x.checked_at))}</td><td class="ds-cell-wrap">${esc(x.error||'—')}</td></tr>`).join(''):'<tr><td colspan="12" class="diskRptMuted">Hələ nəticə yoxdur.</td></tr>';
}
function exportDiskReportCSV(){
 if(!diskReportRows.length){alert('CSV üçün nəticə yoxdur.');return}
 const rows=[['ATM ID','Giriş statusu','PASSWORD','C doluluq %','C ümumi GB','C istifadə GB','C boş GB','D doluluq %','D ümumi GB','D istifadə GB','D boş GB','Yoxlanma vaxtı','Səbəb / qeyd']];
 diskReportRows.forEach(x=>rows.push([x.atm_id,x.access_status||'',x.password_env||'',x.c_used_percent??'',x.c_total_bytes==null?'':(x.c_total_bytes/1073741824).toFixed(2),x.c_used_bytes==null?'':(x.c_used_bytes/1073741824).toFixed(2),x.c_free_bytes==null?'':(x.c_free_bytes/1073741824).toFixed(2),x.d_used_percent??'',x.d_total_bytes==null?'':(x.d_total_bytes/1073741824).toFixed(2),x.d_used_bytes==null?'':(x.d_used_bytes/1073741824).toFixed(2),x.d_free_bytes==null?'':(x.d_free_bytes/1073741824).toFixed(2),x.checked_at||'',x.error||'']));
 const csv='\ufeff'+rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(';')).join('\r\n'),blob=new Blob([csv],{type:'text/csv;charset=utf-8;'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='ATM_DISK_REPORT_'+(diskReportCurrentRun?'RUN_'+diskReportCurrentRun+'_':'')+new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')+'.csv';document.body.appendChild(a);a.click();URL.revokeObjectURL(a.href);a.remove();
}
async function loadDiskReportHistory(){
 const tb=document.getElementById('diskRptHistoryTable');if(!tb)return;
 try{const r=await fetch('/api/disk-report/history?limit=100&t='+Date.now(),{cache:'no-store'}),d=await r.json();if(!r.ok||!d.success)throw Error(d.error||'Tarixçə alınmadı');diskReportHistoryRows=d.runs||[];tb.innerHTML=diskReportHistoryRows.length?diskReportHistoryRows.map(x=>`<tr><td>#${x.id}</td><td>${esc(atmInvFmtDate(x.started_at))}</td><td>${esc(x.status)}</td><td>${x.selected_count}</td><td>${x.checked_count}</td><td>${x.success_count}</td><td>${x.partial_count}</td><td>${x.failed_count}</td><td>${Number(x.duration_seconds||0).toFixed(1)} san</td><td><button class="mini" onclick="openDiskReportHistory(${x.id})">Aç</button></td></tr>`).join(''):'<tr><td colspan="10">Hələ Disk Report tarixçəsi yoxdur.</td></tr>'}catch(e){tb.innerHTML='<tr><td colspan="10">'+esc(String(e.message||e))+'</td></tr>'}
}
async function openDiskReportHistory(id){
 try{const r=await fetch('/api/disk-report/detail?id='+encodeURIComponent(id)+'&t='+Date.now(),{cache:'no-store'}),d=await r.json();if(!r.ok||!d.success)throw Error(d.error||'Report tapılmadı');diskReportCurrentRun=d.run.id;diskReportRows=d.results||[];diskReportLastIndex=0;renderDiskReportTable();diskRptRenderState({total:d.run.selected_count,processed:d.run.checked_count,success_count:d.run.success_count,partial_count:d.run.partial_count,failed_count:d.run.failed_count,percent:d.run.selected_count?Math.round(d.run.checked_count*1000/d.run.selected_count)/10:0,current_atm:'',run_id:d.run.id,running:false,finished:true,cancel_requested:d.run.status==='CANCELLED',error:d.run.error,started_at:d.run.started_at,finished_at:d.run.finished_at,logs:['Tarixçədən Disk Report #'+d.run.id+' açıldı.']});window.scrollTo({top:0,behavior:'smooth'})}catch(e){alert(String(e.message||e))}
}

// ====== AZERBAIJAN ATM MAP: 100% OFFLINE LEAFLET (street / satellite / hybrid, local tiles) ======
const ATM_MAP_BOUNDS={minLon:44.45,minLat:38.05,maxLon:50.75,maxLat:42.15};
const ATM_AZ_CENTER={lat:40.35,lng:47.75};
const ATM_AZ_OUTLINE=[[[41.963,46.360],[41.928,46.653],[41.298,47.371],[41.227,47.832],[41.491,48.011],[41.909,48.634],[41.363,49.183],[40.627,49.713],[40.578,50.199],[40.299,50.521],[40.215,49.661],[39.409,49.480],[39.045,49.300],[38.803,48.918],[38.288,48.946],[38.237,48.686],[38.780,48.035],[39.294,48.395],[39.598,48.087],[39.522,47.696],[38.756,46.465],[39.476,46.442],[39.646,45.974],[39.928,45.531],[40.259,45.825],[40.615,45.269],[40.875,45.479],[41.055,45.082],[41.327,44.866],[41.497,45.121],[41.199,45.898],[41.137,46.461],[41.258,46.603],[41.820,46.089],[41.963,46.360]],[[38.725,46.087],[38.864,45.372],[39.343,44.845],[39.734,44.679],[39.762,44.897],[39.484,45.205],[39.486,45.667],[39.326,45.661],[38.725,46.087]]];
const ATM_RAYON_LABELS=[
 ['Bakı',40.4093,49.8671],['Abşeron',40.49,49.73],['Sumqayıt',40.59,49.67],['Xızı',40.91,49.07],['Siyəzən',41.08,49.11],['Şabran',41.20,48.99],['Xaçmaz',41.47,48.81],['Quba',41.36,48.51],['Qusar',41.43,48.43],
 ['Qobustan',40.53,48.93],['Şamaxı',40.63,48.64],['Ağsu',40.57,48.40],['İsmayıllı',40.79,48.15],['Qəbələ',40.98,47.85],['Oğuz',41.07,47.47],['Şəki',41.20,47.17],['Qax',41.42,46.92],['Zaqatala',41.63,46.64],['Balakən',41.73,46.41],
 ['Ağdaş',40.65,47.48],['Göyçay',40.65,47.74],['Ucar',40.52,47.65],['Kürdəmir',40.34,48.16],['Hacıqabul',40.04,48.94],['Şirvan',39.93,48.92],['Salyan',39.60,48.98],['Neftçala',39.38,49.25],['Sabirabad',40.01,48.48],['Saatlı',39.93,48.37],['İmişli',39.87,48.06],['Biləsuvar',39.46,48.55],
 ['Cəlilabad',39.21,48.50],['Masallı',39.03,48.67],['Lənkəran',38.75,48.85],['Astara',38.46,48.88],['Lerik',38.77,48.42],['Yardımlı',38.91,48.24],
 ['Gəncə',40.68,46.36],['Samux',40.77,46.41],['Göygöl',40.59,46.32],['Daşkəsən',40.52,46.08],['Gədəbəy',40.57,45.81],['Şəmkir',40.83,46.02],['Tovuz',40.99,45.63],['Ağstafa',41.12,45.45],['Qazax',41.09,45.37],['Goranboy',40.61,46.79],['Naftalan',40.51,46.82],
 ['Mingəçevir',40.77,47.05],['Yevlax',40.62,47.15],['Bərdə',40.37,47.13],['Tərtər',40.34,46.93],['Ağcabədi',40.05,47.46],['Beyləqan',39.78,47.62],['Ağdam',39.99,46.93],['Xocalı',39.91,46.79],['Xankəndi',39.82,46.75],['Şuşa',39.76,46.75],['Xocavənd',39.79,47.11],
 ['Kəlbəcər',40.11,46.04],['Laçın',39.64,46.55],['Qubadlı',39.34,46.58],['Zəngilan',39.09,46.65],['Cəbrayıl',39.40,47.03],['Füzuli',39.60,47.15],
 ['Naxçıvan',39.21,45.41],['Şərur',39.55,44.98],['Sədərək',39.71,44.89],['Kəngərli',39.40,45.16],['Şahbuz',39.41,45.57],['Babək',39.15,45.45],['Culfa',38.96,45.63],['Ordubad',38.91,46.02]
];
let atmMapRows=[],atmMapSelectedId=null,atmMapEngine='offline';
let atmLMap=null,atmLMarkers=null,atmLMarkerIndex=new Map(),atmMapInfo=null,atmMapBase='street',atmLLayers={},atmLFallback=null;

function atmMapValid(x){const lat=Number(x.latitude),lon=Number(x.longitude),b=ATM_MAP_BOUNDS;return Number.isFinite(lat)&&Number.isFinite(lon)&&lat!==0&&lon!==0&&lat>=b.minLat&&lat<=b.maxLat&&lon>=b.minLon&&lon<=b.maxLon}
const ATM_MAP_COLORS={inactive:'#7d8898',ok:'#2a9a72',fail:'#b81c36',unknown:'#3d6796'}; // DS tokens: --c-neutral/--c-success/--c-danger/--c-info (canvas CSS var oxuya bilmir)
function atmMapColor(x){if(!Number(x.status))return ATM_MAP_COLORS.inactive;if(x.last_connection_ok===1)return ATM_MAP_COLORS.ok;if(x.last_connection_ok===0)return ATM_MAP_COLORS.fail;return ATM_MAP_COLORS.unknown}
function atmMapConnFilter(x,f){if(f==='ok')return x.last_connection_ok===1;if(f==='fail')return x.last_connection_ok===0;if(f==='unknown')return x.last_connection_ok===null||x.last_connection_ok===undefined;return true}
function atmMapFiltered(){const q=(document.getElementById('atmMapSearch')?.value||'').trim().toUpperCase(),cf=document.getElementById('atmMapConn')?.value||'all';return atmMapRows.filter(x=>atmMapValid(x)&&(!q||String(x.atm_id).toUpperCase().includes(q))&&atmMapConnFilter(x,cf))}

/* Lokal tile qatı: tile yoxdursa (məs. endirilməyən zoom), ən yaxın yüklənmiş valideyn tile-ı
   kəsib böyüdür — boz boşluq əvəzinə bulanıq, amma düzgün xəritə görünür. */
const ATM_TILE_CACHE=new Map();
function atmLoadImg(url){
 if(ATM_TILE_CACHE.has(url))return ATM_TILE_CACHE.get(url);
 const p=new Promise((res,rej)=>{const im=new Image();im.decoding='async';im.onload=()=>res(im);im.onerror=()=>rej(new Error('404'));im.src=url});
 ATM_TILE_CACHE.set(url,p);
 if(ATM_TILE_CACHE.size>600){const k=ATM_TILE_CACHE.keys().next().value;ATM_TILE_CACHE.delete(k)}
 p.catch(()=>{});return p;
}
const AtmOfflineTiles=L.GridLayer.extend({
 options:{layerName:'street',nativeMin:5,nativeMax:12,maxFallback:10,bg:null},
 createTile(coords,done){
  const t=document.createElement('canvas'),size=this.getTileSize();t.width=size.x;t.height=size.y;
  const ctx=t.getContext('2d'),o=this.options;
  let z=coords.z,x=coords.x,y=coords.y;
  // endirilmiş maksimumdan yuxarıdırsa birbaşa valideynə keç (lazımsız 404 yoxdur)
  while(z>o.nativeMax){x=Math.floor(x/2);y=Math.floor(y/2);z--}
  const tryLevel=(lz,lx,ly,depth)=>{
   if(lz<o.nativeMin||depth>o.maxFallback){if(o.bg){ctx.fillStyle=o.bg;ctx.fillRect(0,0,size.x,size.y)}done(null,t);return}
   atmLoadImg(`/tiles/${o.layerName}/${lz}/${lx}/${ly}.png`).then(im=>{
    const d=coords.z-lz,n=2**d,sw=im.width/n,sh=im.height/n,sx=(coords.x-lx*n)*sw,sy=(coords.y-ly*n)*sh;
    ctx.imageSmoothingEnabled=true;ctx.drawImage(im,sx,sy,sw,sh,0,0,size.x,size.y);done(null,t);
   }).catch(()=>tryLevel(lz-1,Math.floor(lx/2),Math.floor(ly/2),depth+1));
  };
  tryLevel(z,x,y,0);
  return t;
 }
});

var atmMapInfoPromise=null;
/* Tile-lar yalnız endirilmiş ərazi (manifest bbox) daxilində istənir — kənarda boz boşluq yox, xəritə fonu görünür */
function atmTileBounds(info){const b=info?.manifest?.bbox;return b?L.latLngBounds([[b[1],b[0]],[b[3],b[2]]]):undefined}
function atmFetchMapInfo(){if(!atmMapInfoPromise)atmMapInfoPromise=fetch('/node/map-info?t='+Date.now(),{cache:'no-store'}).then(r=>r.json()).catch(()=>({available:false}));return atmMapInfoPromise}
function atmMakeBaseLayers(info){const layers=info?.manifest?.layers||{},out={};const mk=(name,extra)=>{const l=layers[name];return l?new AtmOfflineTiles({layerName:name,nativeMin:l.minZoom,nativeMax:l.maxZoom,bounds:atmTileBounds(info),...extra}):null};
 out.street=mk('street',{bg:'#d9d6cf',attribution:'© OpenStreetMap contributors / © Esri'});out.satellite=mk('satellite',{bg:'#141b24',attribution:'© Esri, Maxar, Earthstar Geographics'});out.labels=mk('labels',{pane:'overlayPane',attribution:''});
 Object.keys(out).forEach(k=>{if(!out[k])delete out[k]});return out}
function atmMapSetNotice(text,warn){const n=document.getElementById('atmMapModeNotice');if(!n)return;n.textContent=text;n.classList.toggle('warn',!!warn)}
function atmMapSetProvider(){
 const badge=document.getElementById('atmMapProviderBadge'),text=document.getElementById('atmMapProviderText');
 const L_=atmMapInfo?.manifest?.layers||{};
 const desc=Object.entries(L_).map(([k,v])=>`${k==='street'?'Küçə':k==='satellite'?'Peyk':'Adlar'} z${v.minZoom}-${v.maxZoom}`).join(' • ');
 if(atmMapInfo?.available){
  if(badge)badge.querySelector('span').textContent='100% OFFLINE • '+(atmMapBase==='street'?'Küçə xəritəsi':atmMapBase==='satellite'?'Peyk görüntüsü':'Peyk + adlar');
  if(text)text.textContent='Lokal tile-lar: '+desc+' • © OpenStreetMap contributors / © Esri, Maxar, Earthstar Geographics';
  atmMapSetNotice('100% OFFLINE • LOKAL TILE • API KEY YOXDUR',false);
 }else{
  if(badge)badge.querySelector('span').textContent='Tile-lar tapılmadı • sadə kontur rejimi';
  if(text)text.textContent='map_tiles boşdur. İnternetli kompüterdə PREPARE_OFFLINE_MAP.bat işlədin, sonra ATM_WEB qovluğunu köçürün.';
  atmMapSetNotice('XƏRİTƏ TILE-LARI YÜKLƏNMƏYİB • PREPARE_OFFLINE_MAP.bat',true);
 }
}
function atmMapBuildFallback(){
 const g=L.layerGroup();
 ATM_AZ_OUTLINE.forEach(ring=>L.polygon(ring,{color:'#9aa0ad',weight:2,fillColor:'#9aa0ad',fillOpacity:.18}).addTo(g));
 ATM_RAYON_LABELS.forEach(([name,lat,lon])=>L.circleMarker([lat,lon],{radius:2,color:'#6b717e',weight:0,fillOpacity:.7,interactive:false}).bindTooltip(name,{permanent:true,direction:'right',className:'atmFallbackLabel',offset:[3,0]}).addTo(g));
 return g;
}
function atmMapUpdateLayerButtons(){
 const has=k=>!!atmMapInfo?.manifest?.layers?.[k];
 document.querySelectorAll('#atmMapLayerSwitch button').forEach(b=>{
  const k=b.dataset.layer,ok=k==='hybrid'?has('satellite'):has(k);
  b.disabled=!ok;b.classList.toggle('active',k===atmMapBase);
  b.title=ok?'':'Bu qat üçün tile yüklənməyib';
 });
}
function atmMapSetBase(kind){
 if(!atmLMap)return;
 const avail=atmMapInfo?.manifest?.layers||{};
 if(kind==='hybrid'&&!avail.satellite)return;
 if(kind!=='hybrid'&&!avail[kind])return;
 atmMapBase=kind;
 Object.values(atmLLayers).forEach(l=>{if(atmLMap.hasLayer(l))atmLMap.removeLayer(l)});
 if(kind==='street')atmLLayers.street.addTo(atmLMap);
 if(kind==='satellite'||kind==='hybrid')atmLLayers.satellite.addTo(atmLMap);
 if(kind==='hybrid'&&atmLLayers.labels)atmLLayers.labels.addTo(atmLMap);
 try{localStorage.setItem('atmMapBase',kind)}catch{}
 atmMapUpdateLayerButtons();atmMapSetProvider();
}
async function atmMapInitEngine(){
 if(atmLMap){setTimeout(()=>atmLMap.invalidateSize(),50);return}
 if(typeof L==='undefined')throw Error('Leaflet yüklənmədi (assets/vendor/leaflet/leaflet.js).');
 atmMapInfo=await atmFetchMapInfo();
 const layers=atmMapInfo?.manifest?.layers||{};
 const maxNative=Math.max(12,...Object.values(layers).map(l=>Number(l.maxZoom)||0));
 atmLMap=L.map('atmLeafletMap',{zoomControl:false,minZoom:6,maxZoom:Math.min(19,maxNative+2),preferCanvas:true,attributionControl:true,
  maxBounds:[[36.5,42.5],[43.8,52.8]],maxBoundsViscosity:.8,worldCopyJump:false});
 atmLMap.attributionControl.setPrefix('Leaflet');
 L.control.scale({imperial:false,position:'bottomright'}).addTo(atmLMap);
 const mk=(name,extra)=>{const l=layers[name];return l?new AtmOfflineTiles({layerName:name,nativeMin:l.minZoom,nativeMax:l.maxZoom,bounds:atmTileBounds(atmMapInfo),...extra}):null};
 atmLLayers.street=mk('street',{bg:'#d9d6cf',className:'atmStreetTiles',attribution:'© OpenStreetMap contributors'});
 atmLLayers.satellite=mk('satellite',{bg:'#141b24',attribution:'© Esri, Maxar, Earthstar Geographics'});
 atmLLayers.labels=mk('labels',{pane:'overlayPane',attribution:''});
 Object.keys(atmLLayers).forEach(k=>{if(!atmLLayers[k])delete atmLLayers[k]});
 if(!atmMapInfo?.available){atmLFallback=atmMapBuildFallback().addTo(atmLMap)}
 else{
  let pref='street';try{pref=localStorage.getItem('atmMapBase')||'street'}catch{}
  if(!layers[pref==='hybrid'?'satellite':pref])pref=layers.street?'street':'satellite';
  atmMapSetBase(pref);
 }
 atmLMarkers=L.layerGroup().addTo(atmLMap);
 atmMapUpdateLayerButtons();atmMapSetProvider();atmMapResetView();
 setTimeout(()=>atmLMap.invalidateSize(),60);
}
async function loadAtmMap(){const state=document.getElementById('atmMapState')?.value||'visible',badge=document.getElementById('atmMapCountBadge');badge.textContent='Yüklənir...';try{await atmMapInitEngine();const r=await fetch('/api/atms/map?'+new URLSearchParams({state,t:Date.now()}).toString(),{cache:'no-store'}),d=await r.json();if(!r.ok||!d.success)throw Error(d.error||'Xəritə məlumatı oxunmadı');atmMapRows=d.rows||[];renderAtmMapMarkers()}catch(e){badge.textContent='Xəta';document.getElementById('atmMapInfo').innerHTML='<span class="atmMapInfoLabel">XƏTA</span><div class="atmMapEmpty">'+esc(String(e.message||e))+'</div>'}}
function atmMapUpdateStats(candidates){let invalid=0,active=0,pwd=0;atmMapRows.forEach(x=>{if(x.last_info_ok===1)active++;if(x.password_env)pwd++;if(!atmMapValid(x))invalid++});document.getElementById('atmMapCountBadge').textContent=candidates.length+' marker';document.getElementById('atmMapVisibleCount').textContent=candidates.length;document.getElementById('atmMapInvalidCount').textContent=invalid;document.getElementById('atmMapActiveCount').textContent=active;document.getElementById('atmMapPasswordCount').textContent=pwd}
function renderAtmMapMarkers(suppressAuto=false){const rows=atmMapFiltered();atmMapUpdateStats(rows);atmMapRenderLeaflet(rows);const q=(document.getElementById('atmMapSearch')?.value||'').trim().toUpperCase();if(!suppressAuto&&q){const exact=rows.find(x=>String(x.atm_id).toUpperCase()===q);if(exact&&Number(exact.id)!==Number(atmMapSelectedId))atmMapSelect(exact.id,true)}}
function atmMapRenderLeaflet(rows){
 if(!atmLMarkers)return;
 atmLMarkers.clearLayers();atmLMarkerIndex.clear();
 rows.forEach(x=>{
  const sel=Number(x.id)===Number(atmMapSelectedId);
  const col=atmMapColor(x);
  // Seçilmiş ATM üçün rəngli halo (status rəngi) — müasir, diqqətçəkən görünüş
  if(sel){L.circleMarker([Number(x.latitude),Number(x.longitude)],{radius:19,color:col,weight:0,fillColor:col,fillOpacity:.16,interactive:false,bubblingMouseEvents:false}).addTo(atmLMarkers);}
  // Ağ kənar markeri tile üzərində aydın göstərir; status rəngi fill-dədir
  const m=L.circleMarker([Number(x.latitude),Number(x.longitude)],{radius:sel?9:7,color:'#ffffff',weight:sel?3:2,fillColor:col,fillOpacity:1,bubblingMouseEvents:false});
  m.bindTooltip(esc(x.atm_id),{direction:'top',offset:[0,-6],className:'atmMapTip'});
  m.on('click',()=>atmMapSelect(x.id,false));
  m.addTo(atmLMarkers);atmLMarkerIndex.set(Number(x.id),m);
  if(sel)m.bringToFront();
 });
}
function atmActionLabel(type){return({RESTART:'ATM Restart',VIDEO_ARCHIVE:'Video Archive',SYSTEM_MONITOR:'Sistem Monitoru',DISK_REPORT:'Disk Report'})[type]||type||'—'}
function atmMapWinLabel(t){t=String(t||'').toUpperCase();return t==='XP'?'Windows XP':t==='WIN7'?'Windows 7':t==='WIN10'?'Windows 10':''}
function atmMapTelemetryHtml(row){
  // "Qoşulma edib CPU/RAM çəkilmiş" ATM-lər AKTİV (canlı) kimi göstərilir.
  var hasLive=row.last_info_ok===1&&(row.last_cpu_percent!=null||row.last_ram_percent!=null);
  var cpu=row.last_cpu_percent==null?'—':Number(row.last_cpu_percent).toFixed(0)+'%';
  var ram=row.last_ram_percent==null?'—':Number(row.last_ram_percent).toFixed(0)+'%';
  var win=atmMapWinLabel(row.windows_type||row.effective_type);
  var chip=hasLive?'<span class="atmMapChip ok">● AKTİV (CANLI)</span>':(row.last_info_ok===0?'<span class="atmMapChip fail">İnfo: oflayn</span>':'');
  if(!hasLive&&!win&&row.last_info_ok==null)return chip;
  return chip+'<div class="atmMapInfoRow wide"><span>Canlı sistem</span><b>CPU: '+esc(cpu)+' · RAM: '+esc(ram)+(win?' · '+esc(win):'')+(row.last_os_name?' · '+esc(row.last_os_name):'')+(row.last_info_at?' · '+esc(atmInvFmtDate(row.last_info_at)):'')+'</b></div>';
}
function atmMapDiskReportHtml(row){if(!row.last_disk_report_at)return '';const c=row.last_disk_c_percent===null||row.last_disk_c_percent===undefined?'—':Number(row.last_disk_c_percent).toFixed(1)+'%',d=row.last_disk_d_percent===null||row.last_disk_d_percent===undefined?'—':Number(row.last_disk_d_percent).toFixed(1)+'%',st=row.last_disk_report_status||'—';return `<div class="atmMapInfoRow wide atmMapDiskReport"><span>Son Disk Report</span><b>${esc(st)} · C: ${esc(c)} · D: ${esc(d)} · ${esc(atmInvFmtDate(row.last_disk_report_at))}</b>${row.last_disk_report_error?`<small class="ds-cell-note ds-cell-note--warning">${esc(row.last_disk_report_error)}</small>`:''}</div>`}
function atmMapLastActionHtml(row){if(!row.last_action_type)return '<div class="atmMapInfoRow wide"><span>Son əməliyyat</span><b>Hələ əməliyyat qeydə alınmayıb</b></div>';const state=row.last_action_ok===1?'UĞURLU':row.last_action_ok===0?'XƏTA':'—';return `<div class="atmMapInfoRow wide"><span>Son əməliyyat</span><b>${esc(atmActionLabel(row.last_action_type))} · ${esc(state)} · ${esc(atmInvFmtDate(row.last_action_at))}</b>${row.last_action_detail?`<small class="ds-cell-note">${esc(row.last_action_detail)}</small>`:''}</div>`}
async function atmMapSelect(id,focus){atmMapSelectedId=Number(id);const row=atmMapRows.find(x=>Number(x.id)===Number(id));if(!row)return;renderAtmMapMarkers(true);const conn=row.last_connection_ok===1?'UĞURLU':row.last_connection_ok===0?'XƏTA':'Yoxlanmayıb',connClass=row.last_connection_ok===1?'ok':row.last_connection_ok===0?'fail':'';document.getElementById('atmMapInfo').innerHTML=`<span class="atmMapInfoLabel">ATM DETALI</span><h3>${esc(row.atm_id)}</h3><div class="atmMapStatusLine"><span class="atmMapChip ${Number(row.status)?'ok':'fail'}">${Number(row.status)?'● AKTİV':'● DEAKTİV'}</span><span class="atmMapChip ${connClass}">Qoşulma: ${esc(conn)}</span><span class="atmMapChip">${esc(row.password_env||'PASSWORD tapılmayıb')}</span></div><div class="atmMapInfoGrid"><div class="atmMapInfoRow"><span>Ad</span><b>${esc(row.name||'—')}</b></div><div class="atmMapInfoRow"><span>Region</span><b>${esc(row.region||'—')}</b></div><div class="atmMapInfoRow"><span>RİM</span><b>${esc(row.rim||'—')}</b></div><div class="atmMapInfoRow"><span>IP ünvanı</span><b id="atmMapSelIp" class="mono">…</b></div><div class="atmMapInfoRow wide"><span>Sistemdəki ünvan</span><b>${esc(row.sys_address||'—')}</b></div><div class="atmMapInfoRow wide"><span>Yerləşdiyi ünvan</span><b>${esc(row.phys_address||'—')}</b></div><div class="atmMapInfoRow"><span>Latitude</span><b>${Number(row.latitude).toFixed(6)}</b></div><div class="atmMapInfoRow"><span>Longitude</span><b>${Number(row.longitude).toFixed(6)}</b></div><div class="atmMapInfoRow wide"><span>Son qoşulma</span><b>${esc(atmInvFmtDate(row.last_connection_at))}</b></div>${atmMapTelemetryHtml(row)}${atmMapDiskReportHtml(row)}${atmMapLastActionHtml(row)}</div><div class="atmMapQuick atmMapQuickIcons"><button class="restart" title="ATM Restart" aria-label="ATM Restart" onclick="atmMapGoModule('restart',${row.id})"><svg class="ds-icon" aria-hidden="true"><use href="#i-power"/></svg></button><button class="system" title="Sistem Monitoru" aria-label="Sistem Monitoru" onclick="atmMapGoModule('system',${row.id})"><svg class="ds-icon" aria-hidden="true"><use href="#i-monitor-cog"/></svg></button><button title="Disk Report" aria-label="Disk Report" onclick="atmMapOpenDiskReport(${row.id})"><svg class="ds-icon" aria-hidden="true"><use href="#i-hard-drive"/></svg></button><button class="btnGray" title="Bankomatlar modulunda aç" aria-label="Bankomatlar modulunda aç" onclick="atmMapOpenInventory(${row.id})"><svg class="ds-icon" aria-hidden="true"><use href="#i-server"/></svg></button><button class="btnGray" title="Fokus" aria-label="Fokus" onclick="atmMapFocus(${row.id})"><svg class="ds-icon" aria-hidden="true"><use href="#i-locate-fixed"/></svg></button></div>`;atmMapLoadActivity(row.atm_id);atmMapLoadAtmInfo(row.atm_id);atmMapResolveIp(row.atm_id);if(focus)atmMapFocus(id)}
async function atmMapResolveIp(atm){const el=document.getElementById('atmMapSelIp');if(!el)return;try{const r=await fetch('/api/atms/resolve-ips?atms='+encodeURIComponent(atm)+'&t='+Date.now(),{cache:'no-store'});const d=await r.json();const ip=d&&d.ips&&d.ips[String(atm).toUpperCase()];const cur=document.getElementById('atmMapSelIp');if(cur)cur.textContent=ip||'—'}catch(e){const cur=document.getElementById('atmMapSelIp');if(cur)cur.textContent='—'}}
async function atmMapLoadAtmInfo(atm){const box=document.getElementById('atmMapInfo');if(!box)return;let host=box.querySelector('.atmMapLiveInfo');if(!host){host=document.createElement('div');host.className='atmMapLiveInfo';box.appendChild(host)}host.innerHTML='<div class="atmMapInfoRow wide"><span>Canlı məlumat</span><b>yüklənir...</b></div>';try{const r=await fetch('/api/atminfo/latest?atm='+encodeURIComponent(atm)+'&t='+Date.now(),{cache:'no-store'});const d=await r.json();if(!d.success){host.innerHTML='';return}const x=d.snapshot;if(!x){host.innerHTML='<div class="atmMapInfoRow wide"><span>CPU / RAM</span><b>Hələ qoşulma olmayıb</b></div>';return}const cpu=x.cpu_percent==null?'—':Number(x.cpu_percent).toFixed(0)+'%',ram=x.ram_percent==null?'—':Number(x.ram_percent).toFixed(0)+'%';let disk='';try{const ds=JSON.parse(x.disks_json||'[]');disk=ds.map(z=>esc(z.name)+' '+(z.used_percent==null?'—':Number(z.used_percent).toFixed(0)+'%')).join(' · ')}catch(e){}host.innerHTML=`<div class="atmMapInfoRow"><span>CPU</span><b>${cpu}</b></div><div class="atmMapInfoRow"><span>RAM</span><b>${ram}</b></div><div class="atmMapInfoRow wide"><span>OS</span><b>${esc(x.os_name||'—')}</b></div><div class="atmMapInfoRow wide"><span>Disk</span><b>${disk||'—'}</b></div><div class="atmMapInfoRow wide"><span>Ölçmə</span><b>${esc(x.collected_at||'—')} · port ${esc(x.method||'')}</b></div>`}catch(e){host.innerHTML=''}}
async function atmMapLoadActivity(atm){const box=document.getElementById('atmMapActivity');box.innerHTML='<div class="atmMapEmpty">Tarixçə oxunur...</div>';try{const r=await fetch('/api/atms/activity?'+new URLSearchParams({atm_id:atm,limit:7,t:Date.now()}).toString(),{cache:'no-store'}),d=await r.json();if(!r.ok||!d.success)throw Error(d.error||'Tarixçə alınmadı');if(!d.rows?.length){box.innerHTML='<div class="atmMapEmpty">Bu ATM üçün hələ əməliyyat qeydi yoxdur.</div>';return}box.innerHTML=d.rows.map(a=>`<div class="atmActivityItem"><i class="atmActivityDot ${a.success===1?'ok':a.success===0?'fail':''}"></i><div class="atmActivityText"><strong>${esc(a.action_label||atmActionLabel(a.action_type))} · ${a.success===1?'UĞURLU':a.success===0?'XƏTA':'DAVAM EDİR'}</strong><small>${esc(atmInvFmtDate(a.finished_at||a.started_at))}${a.detail?' · '+esc(a.detail):''}</small></div></div>`).join('')}catch(e){box.innerHTML='<div class="atmMapEmpty">'+esc(String(e.message||e))+'</div>'}}
function atmMapGoModule(module,id){const row=atmMapRows.find(x=>Number(x.id)===Number(id));if(!row)return;const top=document.getElementById('topATM');if(top)top.value=row.atm_id;if(module==='atminfo'||module==='inventory'||module==='system'||module==='diskreport'){openModule('atminfo');const s=document.getElementById('aiSearch');if(s){s.value=row.atm_id;}if(typeof atmInfoLoadList==='function')atmInfoLoadList();return}openModule(module);const input=document.getElementById(module==='restart'?'restartATM':module==='archive'?'archiveATM':'sysATM');if(input){input.value=row.atm_id;input.focus()}}
function atmMapOpenInventory(id){const row=atmMapRows.find(x=>Number(x.id)===Number(id));openModule('inventory');if(row){document.getElementById('atmInventorySearch').value=row.atm_id;loadAtmInventory()}}
function atmMapOpenDiskReport(id){const row=atmMapRows.find(x=>Number(x.id)===Number(id));if(row)openDiskReportSelector([row.atm_id])}
function atmMapFocus(id){const row=atmMapRows.find(x=>Number(x.id)===Number(id));if(!row||!atmMapValid(row)||!atmLMap)return;const maxN=Math.max(...Object.values(atmMapInfo?.manifest?.layers||{}).map(l=>Number(l.maxZoom)||12),12);atmLMap.flyTo([Number(row.latitude),Number(row.longitude)],Math.min(17,Math.max(15,maxN)),{duration:.8})}
function atmMapResetView(){if(atmLMap)atmLMap.fitBounds([[38.38,44.75],[41.95,50.9]],{padding:[10,10]})}
function atmMapZoomIn(){atmLMap?.zoomIn()}
function atmMapZoomOut(){atmLMap?.zoomOut()}

// ====== ATM SYSTEM MONITOR (independent from Archive/Restart/Scan) ======
let sysPollTimer=null;
let sysPollBusy=false;
let sysPollFailures=0;
let sysLastTarget='';
function sysEl(id){return document.getElementById(id)}
function sysText(id,text){sysEl(id).textContent=text??'—'}
function sysFmtBytes(raw){
  if(raw===null||raw===undefined||!Number.isFinite(Number(raw)))return '—';
  const x=Number(raw);
  return (x/1073741824).toLocaleString('az-AZ',{maximumFractionDigits:2,minimumFractionDigits:2})+' GB';
}
function sysPercentage(value){return value===null||value===undefined?'—':Number(value).toFixed(1)+'%'}
function sysFmtUptime(seconds){const n=Number(seconds);if(!Number.isFinite(n)||n<0)return '—';const d=Math.floor(n/86400),h=Math.floor((n%86400)/3600),m=Math.floor((n%3600)/60);return (d?d+' gün ':'')+h+' saat '+m+' dəq';}
function sysJoin(value){if(Array.isArray(value))return value.filter(Boolean).join(', ')||'—';return value||'—';}
function sysFill(id,pct){
  const n=Number(pct);
  const el=sysEl(id);el.style.width=Number.isFinite(n)?Math.min(100,Math.max(0,n))+'%':'0%';
  el.classList.toggle('high',Number.isFinite(n)&&n>=85);
}
function sysShowError(message){const el=sysEl('sysError');el.textContent=message;el.classList.remove('hidden')}
function sysDiagClass(status){const x=String(status||'').toUpperCase();if(x.includes('UĞURLU')||x==='AÇIQ')return 'good';if(x.includes('XƏTA')||x.includes('DENIED')||x.includes('BAĞLI')||x.includes('ƏLÇATMAZ'))return 'bad';if(x.includes('MÖVCUD')||x.includes('QİSMƏN')||x.includes('TAPILMADI')||x.includes('MÜƏYYƏN'))return 'warn';return 'info'}
function sysSetDiag(boxId,valueId,detailId,status,detail){const box=sysEl(boxId);if(!box)return;box.className='sysDiagItem '+(boxId==='sysDiagFinalBox'?'sysDiagFinal ':'')+sysDiagClass(status);sysText(valueId,status||'—');sysText(detailId,detail||'—')}
function sysRenderDiagnostics(state){
 const holder=sysEl('sysDiag');if(!holder)return;holder.classList.remove('hidden');
 const d=state?.diagnostics||{};sysText('sysBackendVersion','backend: '+(state?.backend_version||'KÖHNƏ / NAMƏLUM'));
 sysSetDiag('sysDiag135Box','sysDiag135','sysDiag135Detail',d.tcp135,d.tcp135_detail);
 sysSetDiag('sysDiagCredBox','sysDiagCred','sysDiagCredDetail',d.credential,d.credential_detail);
 sysSetDiag('sysDiagWmiBox','sysDiagWmi','sysDiagWmiDetail',d.wmi,d.wmi_detail);
 sysSetDiag('sysDiagSmbBox','sysDiagSmb','sysDiagSmbDetail',d.smb,d.smb_detail);
 sysSetDiag('sysDiagPsBox','sysDiagPs','sysDiagPsDetail',d.psexec,d.psexec_detail);
 sysSetDiag('sysDiagFinalBox','sysDiagFinal','sysDiagFinalDetail',d.final,d.final_detail||state?.error||'—');
}
function sysStopPolling(){if(sysPollTimer){clearInterval(sysPollTimer);sysPollTimer=null;}sysPollBusy=false;sysPollFailures=0;}
async function startSystemCheck(){
  const atm=sysEl('sysATM').value.trim().toUpperCase();
  if(!atm){sysShowError('ATM ID-ni daxil et.');return}
  if(sysPollTimer)clearInterval(sysPollTimer);
  sysPollTimer=null;sysPollBusy=false;sysPollFailures=0;
  sysEl('sysError').classList.add('hidden');sysEl('sysMetrics').classList.add('hidden');sysEl('sysDiag').classList.remove('hidden');sysRenderDiagnostics({backend_version:'WMI135-DIAG-v3',diagnostics:{tcp135:'YOXLANILIR',credential:'GÖZLƏYİR',wmi:'GÖZLƏYİR',smb:'GÖZLƏYİR',psexec:'GÖZLƏYİR',final:'YOXLANILIR'}});
  sysEl('sysStart').disabled=true;sysText('sysStart','Yoxlanılır...');
  sysText('sysStatus',atm+' — hazırlanır');sysText('sysAction','Aktiv sistem yoxlaması yoxlanılır...');
  sysText('sysLog','ATM: '+atm+'\nWMI/RPC (TCP 135) yoxlaması hazırlanır...');
  try{
    // Refresh və ya əvvəlki klikdən qalan aktiv yoxlama varsa 409 yaratmadan ona qoşul.
    try{
      const activeRes=await fetch('/api/system/progress?t='+Date.now(),{cache:'no-store'});
      const active=await activeRes.json();
      if(active.request_ok&&active.running){
        const activeTarget=String(active.target||'').trim().toUpperCase();
        if(activeTarget===atm){
          sysLastTarget=atm;
          sysText('sysStatus',atm+' — yoxlanılır');
          sysText('sysAction','Mövcud yoxlamaya qoşuldu...');
          sysPollTimer=setInterval(pollSystem,1100);await pollSystem();return;
        }
        throw new Error('Hazırda '+(activeTarget||'başqa ATM')+' üçün sistem yoxlaması davam edir. Bitdikdən sonra '+atm+' yoxla.');
      }
    }catch(e){
      if(String(e.message||e).startsWith('Hazırda '))throw e;
      // Progress endpoint müvəqqəti cavab verməsə POST yenə sınaqdan keçirilir.
    }

    sysText('sysStatus',atm+' — qoşulur');sysText('sysAction','Sorğu serverə göndərilir...');
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),9000);
    let r;
    try{r=await fetch('/api/system/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({atm}),signal:controller.signal})}
    finally{clearTimeout(timer)}
    const d=await r.json();
    if(!r.ok||!d.success){throw new Error(d.error||'Yoxlama başlanmadı')}
    sysLastTarget=atm;
    sysPollTimer=setInterval(pollSystem,1100);await pollSystem();
  }catch(e){
    sysText('sysStart','Sistemi yoxla');sysEl('sysStart').disabled=false;
    sysText('sysStatus','Xəta');sysShowError('Yoxlama başlanmadı: '+String(e.message||e));
  }
}
async function pollSystem(){
  if(document.hidden||sysPollBusy)return;
  sysPollBusy=true;
  try{
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),7500);
    let r;
    try{r=await fetch('/api/system/progress?t='+Date.now(),{signal:controller.signal})}
    finally{clearTimeout(timer)}
    if(!r.ok)throw new Error('HTTP '+r.status);
    const d=await r.json();if(!d.request_ok)throw new Error(d.error||'Status oxunmadı');
    sysRenderDiagnostics(d);
    sysPollFailures=0;
    if(!d.target||(!d.started_at&&!d.running))return;
    sysText('sysStatus',d.target+' — '+(d.running?'yoxlanılır':d.success?(d.metrics?.partial?'qismən hazır':'hazırdır'):'alınmadı'));
    sysText('sysAction',(d.current_action||'—')+' · '+(d.elapsed_seconds||0)+' saniyə');
    const log=sysEl('sysLog');log.textContent=(d.logs||[]).join('\n')||'Yoxlama başlayır...';log.scrollTop=log.scrollHeight;
    sysEl('sysStart').disabled=!!d.running;sysText('sysStart',d.running?'Yoxlanılır...':'Sistemi yoxla');
    if(d.finished){
      if(d.success&&d.metrics){
        sysRender(d.metrics,d);
        if(d.metrics.partial){sysShowError((d.error||'Tam WMI/PsExec məlumatı alınmadı.')+' Səbəb yuxarıdakı “Qoşulma diaqnostikası” blokunda mərhələ-mərhələ göstərilir.');}
        else{sysEl('sysError').classList.add('hidden');}
      }else{sysEl('sysMetrics').classList.add('hidden');sysShowError(d.error||'Məlumat alınmadı.');}
      if(sysPollTimer){clearInterval(sysPollTimer);sysPollTimer=null;}
    }
  }catch(e){
    sysPollFailures++;
    if(sysPollFailures>=3){
      if(sysPollTimer){clearInterval(sysPollTimer);sysPollTimer=null;}
      sysEl('sysStart').disabled=false;sysText('sysStart','Sistemi yoxla');
      sysShowError('Serverdən cavab gəlmir. Yenidən cəhd et: '+String(e.message||e));
    }
  }finally{sysPollBusy=false;}
}
function sysRender(m,state){
  sysEl('sysMetrics').classList.remove('hidden');
  sysText('sysTarget',state.target||'—');const method=m.collection_method||m.disk_source||'—';
  sysText('sysMeta',(m.hostname||m.computer_name||'—')+' · '+method+' · '+fmtDateTime(state.finished_at)+' · '+(state.matched_password_slot?'PASSWORD'+state.matched_password_slot:'—'));
  sysText('sysCPU',sysPercentage(m.cpu_percent));sysFill('sysCPUFill',m.cpu_percent);sysText('sysCPUInfo',m.cpu_percent===null||m.cpu_percent===undefined?'CPU məlumatı alınmadı':(m.cpu_name||'CPU adı oxunmadı')+' · '+(m.cpu_cores??'—')+' nüvə · '+(m.cpu_logical??'—')+' məntiqi prosessor');
  sysText('sysRAM',sysPercentage(m.ram_percent));sysFill('sysRAMFill',m.ram_percent);sysText('sysRAMInfo',m.ram_percent===null||m.ram_percent===undefined?'RAM məlumatı alınmadı':sysFmtBytes(m.ram_used_bytes)+' istifadə / '+sysFmtBytes(m.ram_total_bytes)+' ümumi · '+sysFmtBytes(m.ram_free_bytes)+' boş');
  sysText('sysDiskCount',m.disk_count??0);sysText('sysDiskMethod',m.disk_source||method);sysText('sysHostname',m.hostname||m.computer_name||'—');sysText('sysPrimaryIP',m.primary_ip?('IP: '+m.primary_ip):'IP alınmadı');
  sysText('sysInfoHostname',m.hostname||m.computer_name||'—');sysText('sysOSName',m.os_name||'—');sysText('sysOSVersion',[m.os_version,m.os_build?('Build '+m.os_build):''].filter(Boolean).join(' · ')||'—');sysText('sysOSArch',m.os_architecture||'—');sysText('sysManufacturer',m.manufacturer||'—');sysText('sysModel',m.model||'—');sysText('sysSerial',m.bios_serial||'—');sysText('sysDomain',m.domain||'—');sysText('sysLastBoot',m.last_boot||'—');sysText('sysUptime',sysFmtUptime(m.uptime_seconds));sysText('sysInfoIP',m.primary_ip||'—');sysText('sysAdapterCount',m.network_adapter_count??((m.network_adapters||[]).length));sysText('sysCollectionMethod',method);sysText('sysCredentialSlot',state.matched_password_slot?'PASSWORD'+state.matched_password_slot:'—');
  const container=sysEl('sysDisks');container.replaceChildren();if(!m.disks?.length){const msg=document.createElement('div');msg.className='exNotice';msg.textContent='Disk məlumatı alınmadı.';container.appendChild(msg)}
  [...(m.disks||[])].sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''))).forEach(d=>{const box=document.createElement('div');box.className='sysDisk';const title=document.createElement('div');title.className='sysDiskTitle';const name=document.createElement('span');name.textContent=(d.name||'Disk')+(d.label?' · '+d.label:'');title.appendChild(name);const pct=document.createElement('div');pct.className='sysBig';pct.textContent=sysPercentage(d.used_percent);const pctLabel=document.createElement('div');pctLabel.className='sysSmall';pctLabel.textContent='Doluluq faizi';const bar=document.createElement('div');bar.className='sysBar';const fill=document.createElement('div');fill.className='sysFill';const n=Number(d.used_percent);fill.style.width=Number.isFinite(n)?Math.min(100,Math.max(0,n))+'%':'0%';fill.classList.toggle('high',n>=85);bar.appendChild(fill);const text=document.createElement('div');text.className='sysSmall';text.textContent='Ümumi: '+sysFmtBytes(d.total_bytes)+' · Dolu: '+sysFmtBytes(d.used_bytes)+' · Boş: '+sysFmtBytes(d.free_bytes)+(d.filesystem?' · '+d.filesystem:'');box.append(title,pctLabel,pct,bar,text);container.appendChild(box)});
  const nets=sysEl('sysNetworks');nets.replaceChildren();const adapters=Array.isArray(m.network_adapters)?m.network_adapters:[];if(!adapters.length){const msg=document.createElement('div');msg.className='exNotice';msg.textContent='Network adapter məlumatı alınmadı.';nets.appendChild(msg)}
  adapters.forEach((n,i)=>{const card=document.createElement('div');card.className='sysNetCard';const title=document.createElement('div');title.className='sysNetTitle';const left=document.createElement('strong');left.textContent=n.name||n.description||('Adapter '+(i+1));const mac=document.createElement('span');mac.className='sysNetMac';mac.textContent=n.mac_address||'MAC —';title.append(left,mac);const rows=document.createElement('div');rows.className='sysNetRows';const add=(label,value)=>{const a=document.createElement('span');a.textContent=label;const b=document.createElement('b');b.textContent=value||'—';rows.append(a,b)};add('Description',n.description||'—');add('IPv4',sysJoin(n.ipv4));add('IPv6',sysJoin(n.ipv6));add('Subnet',sysJoin(n.subnets));add('Gateway',sysJoin(n.gateways));add('DNS',sysJoin(n.dns_servers));add('DHCP',n.dhcp_enabled?('Aktiv'+(n.dhcp_server?' · '+n.dhcp_server:'')):'Deaktiv');card.append(title,rows);nets.appendChild(card)});
  const warnings=sysEl('sysWarnings');if(state.warnings?.length){warnings.textContent=state.warnings.join('\n');warnings.classList.remove('hidden')}else{warnings.textContent='';warnings.classList.add('hidden')}
}

// ====== HOME · ATM ŞƏBƏKƏ XƏRİTƏSİ (əsas xəritə ilə eyni offline tile qatı) ======
var homeLMap=null,homeLLayers={},homeLMarkers=null,homeMapBase="street",homeMapLoading=false,homeMapInfo=null;
function homeMapSetBase(kind){
 if(!homeLMap)return;const avail=homeMapInfo?.manifest?.layers||{};
 if(kind==='hybrid'?!avail.satellite:!avail[kind])return;
 homeMapBase=kind;Object.values(homeLLayers).forEach(l=>{if(homeLMap.hasLayer(l))homeLMap.removeLayer(l)});
 if(kind==='street')homeLLayers.street.addTo(homeLMap);
 if(kind==='satellite'||kind==='hybrid')homeLLayers.satellite.addTo(homeLMap);
 if(kind==='hybrid'&&homeLLayers.labels)homeLLayers.labels.addTo(homeLMap);
 document.querySelectorAll('#homeMapLayerSwitch button').forEach(b=>{const k=b.dataset.layer,ok=k==='hybrid'?!!avail.satellite:!!avail[k];b.disabled=!ok;b.classList.toggle('active',k===kind)});
}
function homeMapPct(n,t){return t?Math.round(n/t*100)+'%':'0%'}
async function homeMapInit(){
 const el=document.getElementById('homeLeafletMap');if(!el||typeof L==='undefined'||homeMapLoading)return;
 homeMapLoading=true;
 try{
  if(!homeLMap){
   homeMapInfo=await atmFetchMapInfo();
   homeLMap=L.map(el,{zoomControl:true,minZoom:6,maxZoom:18,preferCanvas:true,scrollWheelZoom:false,maxBounds:[[36.5,42.5],[43.8,52.8]],maxBoundsViscosity:.8});
   homeLMap.attributionControl.setPrefix('Leaflet');
   el.addEventListener('click',()=>homeLMap.scrollWheelZoom.enable(),{once:true});
   homeLLayers=atmMakeBaseLayers(homeMapInfo);
   const info=document.getElementById('homeMapTilesInfo');
   if(homeMapInfo?.available){let pref='street';try{pref=localStorage.getItem('atmMapBase')||'street'}catch{};const av=homeMapInfo.manifest.layers;if(!av[pref==='hybrid'?'satellite':pref])pref=av.street?'street':'satellite';homeMapSetBase(pref);
    if(info)info.textContent='100% offline • '+Object.entries(av).map(([k,v])=>(k==='street'?'Küçə':k==='satellite'?'Peyk':'Adlar')+' z'+v.minZoom+'–'+v.maxZoom).join(' • ')+' • Xəritəyə klikləyib təkərlə zoom et.';}
   else{atmMapBuildFallback().addTo(homeLMap);document.querySelectorAll('#homeMapLayerSwitch button').forEach(b=>b.disabled=true);if(info)info.textContent='Tile-lar yüklənməyib — sadə kontur rejimi. PREPARE_OFFLINE_MAP.bat işlədin.';}
   homeLMarkers=L.layerGroup().addTo(homeLMap);
   homeLMap.fitBounds([[38.38,44.75],[41.95,50.9]],{padding:[8,8]});
  }
  setTimeout(()=>homeLMap.invalidateSize(),60);
  const r=await fetch('/api/atms/map?'+new URLSearchParams({state:'visible',t:Date.now()}),{cache:'no-store'}),d=await r.json();
  if(!r.ok||!d.success)throw Error(d.error||'ATM koordinatları oxunmadı');
  const rows=d.rows||[],valid=rows.filter(atmMapValid);
  let ok=0,fail=0,unk=0,inactive=0;
  homeLMarkers.clearLayers();
  valid.forEach(x=>{
   if(!Number(x.status))inactive++;else if(x.last_connection_ok===1)ok++;else if(x.last_connection_ok===0)fail++;else unk++;
   L.circleMarker([Number(x.latitude),Number(x.longitude)],{radius:5,color:'#0b1b30',weight:1.2,fillColor:atmMapColor(x),fillOpacity:.95,bubblingMouseEvents:false})
    .bindTooltip(esc(x.atm_id),{direction:'top',offset:[0,-5]})
    .on('click',()=>homeMapOpenAtm(x.atm_id)).addTo(homeLMarkers);
  });
  const act=ok+fail+unk,set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v};
  set('homeMapTotal',valid.length);set('homeMapOk',ok);set('homeMapFail',fail);set('homeMapUnknown',unk);set('homeMapInactive',inactive);
  set('homeMapInvalid',rows.length-valid.length?`${rows.length-valid.length} ATM koordinatsız`:'Hamısının koordinatı var');
  const bar=(id,n)=>{const e=document.getElementById(id);if(e)e.style.width=homeMapPct(n,act)};
  bar('homeMapOkBar',ok);bar('homeMapFailBar',fail);bar('homeMapUnknownBar',unk);
 }catch(e){const info=document.getElementById('homeMapTilesInfo');if(info)info.textContent='Xəta: '+(e.message||e)}
 finally{homeMapLoading=false}
}
async function homeMapOpenAtm(atmId){
 openModule('map');
 const s=document.getElementById('atmMapSearch');if(s){s.value=atmId}
 const wait=()=>new Promise(r=>setTimeout(r,120));
 for(let i=0;i<40&&!atmMapRows.length;i++)await wait();
 renderAtmMapMarkers();
}
/* ---- Home: DB statistikası (xəritəsiz) + son görülən işlər ---- */
let homeActivityRows=[];
async function homeLoadStats(){
 const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v};
 try{
  const r=await fetch('/api/atms/map?'+new URLSearchParams({state:'visible',t:Date.now()}),{cache:'no-store'});
  const d=await r.json();if(!r.ok||!d.success)throw Error(d.error||'DB oxunmadı');
  const rows=d.rows||[];let ok=0,fail=0,unk=0,inactive=0,pw=0;
  rows.forEach(x=>{if(x.password_env)pw++;if(!Number(x.status))inactive++;else if(x.last_connection_ok===1)ok++;else if(x.last_connection_ok===0)fail++;else unk++;});
  const act=ok+fail+unk||1;
  set('homeMapTotal',rows.length);set('homeMapOk',ok);set('homeMapFail',fail);set('homeMapUnknown',unk);set('homeMapInactive',inactive);
  set('homeStatPw',pw+' password tapılıb');set('homeMapInvalid','deaktiv = status 0');
  const bar=(id,n)=>{const e=document.getElementById(id);if(e)e.style.width=Math.round(100*n/act)+'%'};
  bar('homeMapOkBar',ok);bar('homeMapFailBar',fail);bar('homeMapUnknownBar',unk);
  if(typeof homeCCRing==='function')homeCCRing(rows.length,ok,fail,unk,inactive);
  window.homeNetStats={ok:ok,fail:fail,unk:unk,inactive:inactive,total:rows.length};
  if(typeof homeCharts==='function')homeCharts();
 }catch(e){set('homeMapTotal','—');if(typeof homeCCRing==='function')homeCCRing(0,0,0,0,0)}
}
/* ---- Ana səhifə diaqramları (canlı: şəbəkə / xəbərdarlıq / server backup) ---- */
function homeDrawDonut(svgId,legId,segs,centerLabel){
  const svg=document.getElementById(svgId);if(!svg)return;
  const NS='http://www.w3.org/2000/svg',cx=75,cy=75,R=56,SW=18,C=2*Math.PI*R;
  const el=(n,a)=>{const e=document.createElementNS(NS,n);for(const k in a)e.setAttribute(k,a[k]);return e};
  svg.replaceChildren();
  const total=segs.reduce((s,x)=>s+(x.value||0),0);
  svg.appendChild(el('circle',{cx,cy,r:R,fill:'none',stroke:'var(--c-border-subtle,#2a3a52)','stroke-width':SW}));
  let off=0;
  if(total>0){segs.forEach(sg=>{const v=sg.value||0;if(v<=0)return;const frac=v/total;
    svg.appendChild(el('circle',{cx,cy,r:R,fill:'none',stroke:sg.color,'stroke-width':SW,
      'stroke-dasharray':(C*frac)+' '+C,'stroke-dashoffset':(-off*C),transform:`rotate(-90 ${cx} ${cy})`}));
    off+=frac;});}
  const t=el('text',{x:cx,y:cy-2,'text-anchor':'middle','class':'ccDonutMid'});t.textContent=(centerLabel!=null?centerLabel:total);
  svg.appendChild(t);
  const sub=el('text',{x:cx,y:cy+16,'text-anchor':'middle','font-size':'9','fill':'var(--c-text-muted,#8aa0bd)','letter-spacing':'.08em'});sub.textContent='CƏMİ';
  svg.appendChild(sub);
  const leg=document.getElementById(legId);
  if(leg)leg.innerHTML=segs.map(sg=>`<span class="lg"><i style="background:${sg.color}"></i>${esc(sg.label)} <b>${(sg.value||0).toLocaleString('az')}</b></span>`).join('');
}
async function homeCharts(){
  // 1) Şəbəkə: işləyən/işləməyən (homeLoadStats-dən)
  const n=window.homeNetStats;
  if(n){homeDrawDonut('homeChartNet','homeChartNetLeg',[
    {label:'Qoşulma OK',value:n.ok,color:'#46c08a'},
    {label:'Xəta',value:n.fail,color:'#e8705f'},
    {label:'Yoxlanmayıb',value:n.unk,color:'#eab968'},
    {label:'Deaktiv',value:n.inactive,color:'#8aa0bd'}],n.total);}
  // 2) Xəbərdarlıq növləri
  try{const r=await fetch('/api/alerts/summary?t='+Date.now(),{cache:'no-store'});const d=await r.json();
    if(d&&d.success){const b=d.by_kind||{};
      homeDrawDonut('homeChartAlerts','homeChartAlertsLeg',[
        {label:'Şəkil yox',value:(b.IMAGE||0)+(b.IMAGE_OLD||0),color:'#e8705f'},
        {label:'Jurnal yox',value:(b.JOURNAL||0)+(b.JOURNAL_OLD||0),color:'#eab968'},
        {label:'Backup yox',value:b.BACKUP||0,color:'#9b6fe0'},
        {label:'Qoşulmayan',value:b.CONN||0,color:'#8aa0bd'}],d.active_total||0);}
  }catch(e){}
  // 3) Server (77) backup: yeni/problem
  try{const r=await fetch('/api/srvalert/summary?t='+Date.now(),{cache:'no-store'});const d=await r.json();
    if(d&&d.success){const s=d.last_summary||{};
      homeDrawDonut('homeChartSrv','homeChartSrvLeg',[
        {label:'Yeni (qaydasında)',value:s.ok||0,color:'#46c08a'},
        {label:'Problemli',value:s.problem||0,color:'#e8705f'}],s.total!=null?s.total:'—');}
  }catch(e){}
}
function homeActLabel(t){return (window.atmActionLabel?atmActionLabel(t):t)||t||'—'}
async function homeLoadActivity(){
 const box=document.getElementById('homeActivity');if(!box)return;
 box.innerHTML='<div class="homeEmpty">Yüklənir...</div>';
 try{
  const r=await fetch('/api/activity/recent?limit=20&t='+Date.now(),{cache:'no-store'});
  const d=await r.json();if(!d.success)throw Error(d.error);
  homeActivityRows=d.rows||[];
  if(!homeActivityRows.length){box.innerHTML='<div class="homeEmpty">Hələ əməliyyat qeydə alınmayıb.</div>';return}
  box.innerHTML=homeActivityRows.map(x=>{
   const okCls=x.success===1?'ds-badge--success':x.success===0?'ds-badge--danger':'ds-badge--neutral';
   const st=x.success===1?'UĞURLU':x.success===0?'XƏTA':'—';
   const when=(window.atmInvFmtDate?atmInvFmtDate(x.finished_at||x.started_at):(x.finished_at||x.started_at||''));
   return '<div class="homeRecentRow"><div><b class="mono">'+esc(x.atm_id)+'</b> <span class="ds-caption">'+esc(homeActLabel(x.action_type))+'</span></div>'+
    '<div style="display:flex;align-items:center;gap:8px"><span class="ds-badge ds-badge--dot '+okCls+'">'+st+'</span><span class="ds-caption">'+esc(when)+'</span></div></div>';
  }).join('');
 }catch(e){box.innerHTML='<div class="homeEmpty">Xəta: '+esc(e.message||e)+'</div>'}
}
function homeDownloadCSV(name,head,rows){
 const csv='﻿'+[head].concat(rows).map(r=>r.map(v=>'"'+String(v==null?'':v).replace(/"/g,'""')+'"').join(';')).join('\r\n');
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'}));
 a.download=name+'_'+new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')+'.csv';document.body.appendChild(a);a.click();URL.revokeObjectURL(a.href);a.remove();
}
function homeExportActivityCSV(){
 if(!homeActivityRows.length){alert('Fəaliyyət yoxdur.');return}
 homeDownloadCSV('SON_EMELIYYATLAR',['ATM ID','Əməliyyat','Mənbə','Başladı','Bitdi','Nəticə','Detal'],
  homeActivityRows.map(x=>[x.atm_id,homeActLabel(x.action_type),x.source_module||'',x.started_at||'',x.finished_at||'',x.success===1?'UĞURLU':x.success===0?'XƏTA':'',x.detail||'']));
}
function homeExportRecentCSV(){
 const rows=(window.homeHistoryRows||[]);
 if(!rows.length){alert('Scan nəticəsi yoxdur.');return}
 homeDownloadCSV('SON_SCAN',['Mənbə','Scan ID','Status','Başladı','Yoxlanıb','Ümumi ATM'],
  rows.map(x=>[x.source||'',x.id??'',x.status||'',x.started_at||'',x.checked??'',x.total_atm??'']));
}
function toggleBackupSub(e){
 const sub=document.getElementById('backupSub'),btn=document.getElementById('menuBackup');
 if(!sub){openModule('backup','live');return}
 const collapsed=sub.classList.toggle('collapsed');
 if(btn)btn.classList.toggle('is-open',!collapsed);
 if(!collapsed)openModule('backup','live');
}
window.toggleBackupSub=toggleBackupSub;

// ====== AGENT MONİTORU (push rejimli ATM agent hesabatları) ======
var agentAutoTimer=null,agentBusy=false,agentDetailId=null;
function agentStartAuto(){agentRefresh();agentToggleAuto();}
function agentStopAuto(){if(agentAutoTimer){clearInterval(agentAutoTimer);agentAutoTimer=null;}}
function agentToggleAuto(){
  agentStopAuto();
  const on=document.getElementById('agAuto')?.checked;
  if(on)agentAutoTimer=setInterval(agentRefresh,10000);
}
function agMiniBar(pct){
  const n=Number(pct);const w=Number.isFinite(n)?Math.min(100,Math.max(0,n)):0;
  return `<span class="agMiniBar"><span class="${n>=85?'high':''}" style="width:${w}%"></span></span>`;
}
async function agentRefresh(){
  if(document.hidden||agentBusy)return;agentBusy=true;
  try{
    const r=await fetch('/api/agent/list?t='+Date.now(),{cache:'no-store'});
    const d=await r.json();
    if(!r.ok||!d.success)throw new Error(d.error||'Siyahı oxunmadı');
    const items=d.items||[];
    let online=0;items.forEach(x=>{if(x.online)online++;});
    sysText('agTotal',items.length);sysText('agOnline',online);sysText('agOffline',items.length-online);
    sysText('agStatus',items.length?('Son yeniləmə: '+new Date().toLocaleTimeString('az-AZ')):'Hələ heç bir agent hesabat göndərməyib');
    const tb=document.getElementById('agRows');tb.replaceChildren();
    if(!items.length){tb.innerHTML='<tr><td colspan="10" class="agEmpty">Hələ heç bir ATM hesabat göndərməyib. Agent işə düşəndə burada görünəcək.</td></tr>';return;}
    items.forEach(x=>{
      const tr=document.createElement('tr');
      tr.onclick=()=>agentOpenDetail(x.atm_id);
      const diskPct=x.disk_total_bytes?Math.round(100*x.disk_used_bytes/x.disk_total_bytes):null;
      tr.innerHTML=
        `<td><span class="agBadge ${x.online?'on':'off'}">${x.online?'Online':'Offline'}</span></td>`+
        `<td><b>${esc(x.atm_id)}</b></td>`+
        `<td>${esc(x.hostname||'—')}</td>`+
        `<td>${esc(x.os_name||'—')}</td>`+
        `<td>${esc(x.os_architecture||'—')}</td>`+
        `<td>${sysPercentage(x.cpu_percent)}${agMiniBar(x.cpu_percent)}</td>`+
        `<td>${sysPercentage(x.ram_percent)}${agMiniBar(x.ram_percent)}</td>`+
        `<td>${diskPct==null?'—':diskPct+'%'} <span class="sysSmall">${sysFmtBytes(x.disk_used_bytes)}/${sysFmtBytes(x.disk_total_bytes)}</span></td>`+
        `<td>${esc(x.source_ip||'—')}</td>`+
        `<td>${esc(fmtDateTime(x.received_at))}</td>`;
      tb.appendChild(tr);
    });
    if(agentDetailId)agentOpenDetail(agentDetailId,true);
  }catch(e){
    sysText('agStatus','Xəta: '+String(e.message||e));
  }finally{agentBusy=false;}
}
async function agentOpenDetail(atmId,silent){
  agentDetailId=atmId;
  try{
    const r=await fetch('/api/agent/detail?atm='+encodeURIComponent(atmId)+'&t='+Date.now(),{cache:'no-store'});
    const d=await r.json();
    if(!r.ok||!d.success)throw new Error(d.error||'Detal oxunmadı');
    const m=d.report||{};
    document.getElementById('agDetail').classList.remove('hidden');
    sysText('agdTarget',m.atm_id||atmId);
    sysText('agdMeta',(m.hostname||'—')+' · '+(m.source_ip||'—')+' · '+fmtDateTime(m.received_at));
    sysText('agdCPU',sysPercentage(m.cpu_percent));sysFill('agdCPUFill',m.cpu_percent);
    sysText('agdCPUInfo',(m.cpu_name||'CPU')+' · '+(m.cpu_cores??'—')+' nüvə · '+(m.cpu_logical??'—')+' məntiqi');
    sysText('agdRAM',sysPercentage(m.ram_percent));sysFill('agdRAMFill',m.ram_percent);
    sysText('agdRAMInfo',sysFmtBytes(m.ram_used_bytes)+' / '+sysFmtBytes(m.ram_total_bytes)+' · '+sysFmtBytes(m.ram_free_bytes)+' boş');
    sysText('agdDiskCount',m.disk_count??0);
    sysText('agdDiskSum','Ümumi: '+sysFmtBytes(m.disk_total_bytes)+' · Dolu: '+sysFmtBytes(m.disk_used_bytes));
    sysText('agdHostname',m.hostname||'—');sysText('agdIP',m.source_ip?('IP: '+m.source_ip):'—');
    sysText('agdInfoHost',m.hostname||'—');sysText('agdOSName',m.os_name||'—');
    sysText('agdOSVer',[m.os_version,m.os_build?('Build '+m.os_build):''].filter(Boolean).join(' · ')||'—');
    sysText('agdOSArch',m.os_architecture||'—');sysText('agdCPUName',m.cpu_name||'—');
    sysText('agdUptime',sysFmtUptime(m.uptime_seconds));sysText('agdBoot',m.boot_time||'—');
    sysText('agdAgentVer',m.agent_version||'—');sysText('agdSrcIP',m.source_ip||'—');
    sysText('agdReceived',fmtDateTime(m.received_at));
    const c=document.getElementById('agdDisks');c.replaceChildren();
    const disks=Array.isArray(m.disks)?m.disks:[];
    if(!disks.length){const e=document.createElement('div');e.className='exNotice';e.textContent='Disk məlumatı yoxdur.';c.appendChild(e);}
    disks.slice().sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''))).forEach(dd=>{
      const box=document.createElement('div');box.className='sysDisk';
      const title=document.createElement('div');title.className='sysDiskTitle';
      const name=document.createElement('span');name.textContent=(dd.name||'Disk')+(dd.label?' · '+dd.label:'');title.appendChild(name);
      const pct=document.createElement('div');pct.className='sysBig';pct.textContent=sysPercentage(dd.used_percent);
      const pl=document.createElement('div');pl.className='sysSmall';pl.textContent='Doluluq faizi';
      const bar=document.createElement('div');bar.className='sysBar';const fill=document.createElement('div');fill.className='sysFill';
      const n=Number(dd.used_percent);fill.style.width=Number.isFinite(n)?Math.min(100,Math.max(0,n))+'%':'0%';fill.classList.toggle('high',n>=85);bar.appendChild(fill);
      const text=document.createElement('div');text.className='sysSmall';
      text.textContent='Ümumi: '+sysFmtBytes(dd.total_bytes)+' · Dolu: '+sysFmtBytes(dd.used_bytes)+' · Boş: '+sysFmtBytes(dd.free_bytes)+(dd.filesystem?' · '+dd.filesystem:'');
      box.append(title,pl,pct,bar,text);c.appendChild(box);
    });
    if(!silent)document.getElementById('agDetail').scrollIntoView({behavior:'smooth',block:'start'});
  }catch(e){
    if(!silent)sysText('agStatus','Detal xətası: '+String(e.message||e));
  }
}
function agentCloseDetail(){agentDetailId=null;document.getElementById('agDetail').classList.add('hidden');}
