/* Cihaz İdarəetmə Sistemi — ATM-ə Folder Göndər.
   Seçilmiş mənbə qovluğunu siyahıdakı ATM-lərin təyinat yoluna köçürür.
   Backend: /api/deploy/start|cancel|progress|history|detail|excel|browse|check-source */
(function () {
'use strict';
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = id => document.getElementById(id);
const toast = (m, t) => { if (window.DS && DS.toast) DS.toast(m, t || 'info'); };
const can = key => { try { return !window.AtmAuth || typeof AtmAuth.can !== 'function' || AtmAuth.can(key); } catch (e) { return true; } };

const CATS = ['GÖNDƏRİLDİ', 'ARTIQ VAR (ötürüldü)', 'QOŞULMADI', 'XƏTA', 'DAYANDIRILDI'];
const BADGE = { 'GÖNDƏRİLDİ': 'success', 'ARTIQ VAR (ötürüldü)': 'neutral', 'QOŞULMADI': 'neutral', 'XƏTA': 'danger', 'DAYANDIRILDI': 'neutral' };

const S = { inited: false, runId: null, running: false, results: [], since: 0, timer: null,
  filter: 'ALL', viewingHistory: false, polling: false, browsePath: '', browseParent: null };

async function api(url, opts) {
  const r = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), Object.assign({ cache: 'no-store' }, opts || {}));
  let d = null;
  try { d = await r.json(); } catch (e) {}
  if (!r.ok || !d || d.success === false) throw new Error((d && d.error) || ('HTTP ' + r.status));
  return d;
}
function fmtDT(iso) {
  if (!iso) return '—';
  const m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})/.exec(iso);
  return m ? `${m[3]}.${m[2]}.${m[1]} ${m[4]}:${m[5]}` : esc(iso);
}
function fmtBytes(n) {
  n = Number(n || 0); const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return (i === 0 ? n : n.toFixed(1)) + ' ' + u[i];
}
function fmtDur(sec) {
  sec = Number(sec || 0);
  if (sec < 60) return Math.round(sec) + ' san';
  const m = Math.floor(sec / 60), s = Math.round(sec % 60);
  return m < 60 ? `${m} dəq ${s} san` : `${Math.floor(m / 60)} saat ${m % 60} dəq`;
}

/* ---------- preview ---------- */
function folderName(p) { return String(p || '').replace(/[\\/]+$/, '').split(/[\\/]/).pop() || ''; }
function updatePreview() {
  const name = folderName($('dpSource').value) || '<folder>';
  const dest = ($('dpDest').value || 'C$\\...').replace(/^\\+/, '');
  const contents = $('dpContents').checked;
  $('dpPreview').textContent = 'Təyinat nümunəsi: \\\\<ATM>\\' + dest + (contents ? '\\ (içindəkilər)' : '\\' + name);
}

/* ---------- render ---------- */
function counts(list) { const c = {}; list.forEach(r => { c[r.status] = (c[r.status] || 0) + 1; }); return c; }
function renderStats(snap) {
  const c = counts(S.results);
  $('dpProcessed').textContent = (snap ? snap.processed : S.results.length) + ' / ' + (snap ? snap.total : S.results.length);
  $('dpOk').textContent = snap ? snap.ok_total : (c['GÖNDƏRİLDİ'] || 0);
  $('dpSkip').textContent = snap ? snap.skip_total : (c['ARTIQ VAR (ötürüldü)'] || 0);
  $('dpFail').textContent = (c['XƏTA'] || 0);
  $('dpNoConn').textContent = (c['QOŞULMADI'] || 0);
  const files = snap ? snap.files_total : S.results.reduce((a, r) => a + (r.files_copied || 0), 0);
  const bytes = snap ? snap.bytes_total : S.results.reduce((a, r) => a + (r.bytes_copied || 0), 0);
  $('dpFiles').textContent = (files || 0) + ' / ' + fmtBytes(bytes);
}
function renderChips() {
  const c = counts(S.results);
  const items = [['ALL', 'Hamısı', S.results.length]].concat(CATS.filter(k => c[k]).map(k => [k, k, c[k]]));
  if (S.filter !== 'ALL' && !c[S.filter]) S.filter = 'ALL';
  $('dpChips').innerHTML = items.map(([k, label, n]) =>
    `<button type="button" class="vaChip${S.filter === k ? ' is-active' : ''}" data-k="${esc(k)}">${esc(label)} <b>${n}</b></button>`).join('');
  $('dpChips').querySelectorAll('.vaChip').forEach(b => b.onclick = () => { S.filter = b.dataset.k; renderChips(); renderTable(); });
}
function renderTable() {
  const rows = S.results.filter(r => S.filter === 'ALL' || r.status === S.filter);
  const tb = $('dpTable');
  if (!rows.length) {
    tb.innerHTML = `<tr><td colspan="9" class="vaEmpty">${S.results.length ? 'Filtrə uyğun yoxdur.' : (S.running ? 'Nəticələr gəldikcə görünəcək...' : 'Hələ nəticə yoxdur.')}</td></tr>`;
  } else {
    tb.innerHTML = rows.map((r, i) => `<tr class="vaRow vaRow--${BADGE[r.status] || 'neutral'}">
      <td>${i + 1}</td>
      <td><b class="vaAtm">${esc(r.atm_id)}</b></td>
      <td class="vaName" title="${esc(r.name)}">${esc(r.name || '—')}</td>
      <td>${esc(r.region || '—')}</td>
      <td><span class="ds-badge ds-badge--${BADGE[r.status] || 'neutral'}">${esc(r.status)}</span></td>
      <td>${r.files_copied || 0}</td>
      <td class="vaMono">${fmtBytes(r.bytes_copied)}</td>
      <td class="vaNote" title="${esc(r.target_path || '')}">${esc(r.target_path || '—')}</td>
      <td class="vaNote" title="${esc(r.error || '')}">${esc(r.error || '')}</td></tr>`).join('');
  }
  $('dpTableFoot').textContent = rows.length === S.results.length ? `${rows.length} ATM` : `${rows.length} / ${S.results.length} ATM`;
}
function renderAll(snap) { renderStats(snap); renderChips(); renderTable(); }
function setRunning(running) {
  S.running = running;
  const may = can('deploy.run');
  $('dpStartBtn').classList.toggle('hidden', running || !may);
  $('dpStopBtn').classList.toggle('hidden', !running || !may);
  $('dpStopBtn').disabled = false;
  $('dpExcelBtn').disabled = !S.runId || running || !S.results.length;
  $('dpExcelBtn').classList.toggle('hidden', !can('deploy.export'));
}

/* ---------- progress ---------- */
function applySnapshot(d) {
  if (!d.run_id) return false;
  if (S.runId !== d.run_id || S.viewingHistory) {
    if (!d.running && S.viewingHistory) return false;
    S.runId = d.run_id; S.results = []; S.since = 0; S.viewingHistory = false;
  }
  (d.new_results || []).forEach(r => S.results.push(r));
  S.since = d.next_index || S.since;
  const pct = Math.max(0, Math.min(100, Number(d.percent || 0)));
  $('dpFill').style.width = pct + '%';
  $('dpPercent').textContent = pct.toFixed(1).replace('.0', '') + '%';
  $('dpRunBadge').textContent = 'Deploy #' + d.run_id;
  $('dpCurrent').textContent = (d.current_atms || []).slice(0, 6).join(', ') + ((d.current_atms || []).length > 6 ? ' …' : '') || '—';
  const logBox = $('dpLog');
  const stick = logBox.scrollTop + logBox.clientHeight >= logBox.scrollHeight - 20;
  logBox.textContent = (d.logs || []).join('\n') || '—';
  if (stick) logBox.scrollTop = logBox.scrollHeight;
  if (d.running) {
    $('dpState').textContent = d.cancel_requested ? 'Dayandırılır...' : 'Göndərilir...';
    $('dpMeta').textContent = `${d.processed} / ${d.total} ATM · ${esc(d.folder_name || '')} → \\\\<ATM>\\${esc(d.dest || '')}`;
  } else {
    $('dpState').textContent = d.error ? 'Xəta ilə bitdi' : d.cancel_requested ? 'Dayandırıldı' : 'Tamamlandı';
    $('dpMeta').textContent = d.error ? d.error : `${d.ok_total} göndərildi · ${d.skip_total} ötürüldü · ${fmtDT(d.started_at)} → ${fmtDT(d.finished_at)}`;
  }
  setRunning(!!d.running);
  renderAll(d);
  return !!d.running;
}
async function poll() {
  if (S.polling) return;
  S.polling = true;
  try {
    const d = await api('/api/deploy/progress?since=' + (S.viewingHistory ? 0 : S.since));
    const running = applySnapshot(d);
    if (!running && S.timer) {
      clearInterval(S.timer); S.timer = null;
      deployLoadHistory();
      if (!S.viewingHistory && S.results.length) toast('Folder göndərmə bitdi.', 'success');
    }
    if (running && !S.timer) S.timer = setInterval(poll, 1500);
    return d;
  } catch (e) {} finally { S.polling = false; }
}

/* ---------- source check + browse ---------- */
async function checkSource() {
  const p = $('dpSource').value.trim();
  if (!p) { toast('Əvvəl mənbə yolu yaz.', 'warning'); return; }
  $('dpSourceInfo').textContent = 'Yoxlanılır...';
  try {
    const d = await api('/api/deploy/check-source?path=' + encodeURIComponent(p));
    $('dpSourceInfo').textContent = `✓ "${d.name}" — ${d.files} fayl · ${fmtBytes(d.bytes)}`;
    $('dpSourceInfo').style.color = 'var(--c-success)';
    updatePreview();
  } catch (e) { $('dpSourceInfo').textContent = '✗ ' + e.message; $('dpSourceInfo').style.color = 'var(--c-danger)'; }
}
async function browse(path) {
  $('dpBrowse').classList.remove('hidden');
  const list = $('dpBrowseList'); list.innerHTML = '<div class="dpBrowseItem">Yüklənir...</div>';
  try {
    const d = await api('/api/deploy/browse?path=' + encodeURIComponent(path || ''));
    S.browsePath = d.path || ''; S.browseParent = d.parent || null;
    $('dpBrowsePath').textContent = S.browsePath || '(kök — disk seç)';
    $('dpUpBtn').disabled = !S.browsePath;
    $('dpPickBtn').disabled = !S.browsePath;
    const dirs = d.dirs || [];
    if (!dirs.length) { list.innerHTML = '<div class="dpBrowseItem">Alt qovluq yoxdur.</div>'; return; }
    list.innerHTML = dirs.map((x, i) =>
      `<div class="dpBrowseItem" data-i="${i}"><svg class="ds-icon" aria-hidden="true"><use href="#i-folder"/></svg>${esc(x.name)}</div>`).join('');
    list.querySelectorAll('.dpBrowseItem[data-i]').forEach(el => el.onclick = () => browse(dirs[+el.dataset.i].path));
  } catch (e) { list.innerHTML = `<div class="dpBrowseItem">Xəta: ${esc(e.message)}</div>`; }
}
function browseUp() { if (S.browseParent != null) browse(S.browseParent); else browse(''); }
function browseClose() { $('dpBrowse').classList.add('hidden'); }
function pick() {
  if (!S.browsePath) { toast('Əvvəl bir qovluğa gir.', 'warning'); return; }
  $('dpSource').value = S.browsePath;
  browseClose();
  checkSource();
}

/* ---------- actions ---------- */
function parseList(text) {
  const seen = new Set(), out = [];
  String(text || '').split(/[\s,;]+/).forEach(x => {
    const a = x.trim().toUpperCase();
    if (/^[A-Z0-9._-]{1,64}$/.test(a) && !seen.has(a)) { seen.add(a); out.push(a); }
  });
  return out;
}
async function start() {
  const ids = parseList($('dpList').value);
  if (!ids.length) { toast('Ən azı bir ATM ID yaz.', 'warning'); $('dpList').focus(); return; }
  const source = $('dpSource').value.trim();
  if (!source) { toast('Mənbə yolunu yaz / seç.', 'warning'); $('dpSource').focus(); return; }
  const dest = $('dpDest').value.trim();
  if (!dest) { toast('Təyinat yolunu yaz.', 'warning'); $('dpDest').focus(); return; }
  const contents = $('dpContents').checked;
  const overwrite = $('dpOverwrite').checked;
  const name = folderName(source) || '(folder)';
  const what = contents ? `"${name}" qovluğunun İÇİNDƏKİLƏRİ` : `"${name}" qovluğu`;
  if (!confirm(`${ids.length} ATM-ə ${what} göndəriləcək.\nTəyinat: \\\\<ATM>\\${dest}\nÜzərinə yaz: ${overwrite ? 'bəli' : 'xeyr'}\n\nDavam edilsin?`)) return;
  const btn = $('dpStartBtn'); btn.disabled = true;
  try {
    const d = await api('/api/deploy/start', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ atm_ids: ids, source, dest, contents_only: contents, overwrite }) });
    S.runId = d.run_id; S.results = []; S.since = 0; S.viewingHistory = false; S.filter = 'ALL';
    renderAll(null);
    toast('Göndərmə #' + d.run_id + ' başladı.', 'success');
    await poll();
    if (!S.timer) S.timer = setInterval(poll, 1500);
  } catch (e) { toast('Başlamadı: ' + e.message, 'danger'); } finally { btn.disabled = false; }
}
async function stop() {
  $('dpStopBtn').disabled = true;
  try { await api('/api/deploy/cancel', { method: 'POST' }); toast('Dayandırılır...', 'info'); }
  catch (e) { toast(e.message, 'warning'); $('dpStopBtn').disabled = false; }
}
async function excel(runId) {
  if (!can('deploy.export')) { toast('Excel üçün icazən yoxdur.', 'warning'); return; }
  runId = runId || S.runId;
  if (!runId) { toast('Əvvəl göndərmə et və ya tarixçədən seç.', 'warning'); return; }
  try {
    const r = await fetch('/api/deploy/excel?id=' + encodeURIComponent(runId) + '&t=' + Date.now(), { cache: 'no-store' });
    const type = r.headers.get('Content-Type') || '';
    if (!r.ok || type.includes('json')) { let m = 'HTTP ' + r.status; try { m = (await r.json()).error || m; } catch (e) {} throw new Error(m); }
    const blob = await r.blob();
    const cd = r.headers.get('Content-Disposition') || '';
    const mm = /filename="?([^";]+)"?/i.exec(cd);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = mm ? mm[1] : `Folder_Gonderme_${runId}.xlsx`;
    document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
    toast('Excel hazırdır: ' + a.download, 'success');
  } catch (e) { toast('Excel yüklənmədi: ' + e.message, 'danger'); }
}
async function openRun(runId) {
  try {
    const d = await api('/api/deploy/detail?id=' + encodeURIComponent(runId));
    const run = d.run || {};
    S.viewingHistory = true; S.runId = run.id; S.filter = 'ALL';
    S.results = d.results || [];
    $('dpState').textContent = 'Tarixçə — #' + run.id;
    $('dpMeta').textContent = `${esc(run.folder_name || '')} → \\\\<ATM>\\${esc(run.dest || '')} · ${fmtDT(run.started_at)}`;
    $('dpFill').style.width = '100%'; $('dpPercent').textContent = '100%'; $('dpCurrent').textContent = '—';
    renderAll({ total: run.checked_count, processed: run.checked_count, ok_total: run.ok_total, skip_total: run.skip_total, files_total: run.files_total, bytes_total: run.bytes_total });
    setRunning(false);
    $('dpExcelBtn').disabled = !S.results.length;
  } catch (e) { toast('Açılmadı: ' + e.message, 'danger'); }
}
async function loadHistory() {
  const tb = $('dpHistory');
  try {
    const d = await api('/api/deploy/history?limit=50');
    const runs = d.runs || [];
    if (!runs.length) { tb.innerHTML = '<tr><td colspan="9" class="vaEmpty">Hələ göndərmə yoxdur.</td></tr>'; return; }
    const stAz = { COMPLETED: ['TAMAMLANDI', 'success'], CANCELLED: ['DAYANDIRILDI', 'warning'], FAILED: ['XƏTA', 'danger'] };
    tb.innerHTML = runs.map(r => {
      const [t, c] = stAz[r.status] || [r.status, 'neutral'];
      return `<tr class="${r.id === S.runId ? 'selected' : ''}">
        <td><b>#${r.id}</b></td><td>${fmtDT(r.started_at)}</td><td title="${esc(r.source || '')}">${esc(r.folder_name || '')}</td>
        <td>${r.checked_count || 0} / ${r.selected_count || 0}</td><td>${r.ok_total || 0}</td><td>${r.skip_total || 0}</td><td>${r.fail_total || 0}</td>
        <td><span class="ds-badge ds-badge--${c}">${esc(t)}</span></td>
        <td class="vaHistActs"><button type="button" class="btnGray ds-btn--sm" data-open="${r.id}">Bax</button>
          ${can('deploy.export') ? `<button type="button" class="btnGreen ds-btn--sm" data-xl="${r.id}" ${!r.checked_count ? 'disabled' : ''}>Excel</button>` : ''}</td></tr>`;
    }).join('');
    tb.querySelectorAll('[data-open]').forEach(b => b.onclick = () => openRun(Number(b.dataset.open)));
    tb.querySelectorAll('[data-xl]').forEach(b => b.onclick = () => excel(Number(b.dataset.xl)));
  } catch (e) { tb.innerHTML = `<tr><td colspan="9" class="vaEmpty">Alınmadı: ${esc(e.message)}</td></tr>`; }
}

function init() {
  if (!S.inited) {
    S.inited = true;
    ['dpSource', 'dpDest'].forEach(id => $(id).addEventListener('input', updatePreview));
    $('dpContents').addEventListener('change', updatePreview);
  }
  updatePreview();
  poll();
  loadHistory();
  if (!S.timer) S.timer = setInterval(poll, 2000);
}

window.deployInit = init;
window.deployStart = start;
window.deployStop = stop;
window.deployExcel = () => excel();
window.deployCheckSource = checkSource;
window.deployBrowse = browse;
window.deployBrowseUp = browseUp;
window.deployBrowseClose = browseClose;
window.deployPick = pick;
window.deployLoadHistory = loadHistory;
})();
