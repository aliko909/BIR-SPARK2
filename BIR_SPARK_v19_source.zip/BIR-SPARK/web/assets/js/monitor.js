/* Cihaz İdarəetmə Sistemi — ATM Foto Monitorinq.
   Hər ATM üçün maksimum saat həddi → avtomatik VIDEOARCHIVE yoxlaması →
   işləməyən (vaxtında şəkil çəkməyən) ATM-lər üçün mail.
   Backend: /api/monitor/status|config|thresholds|history|detail|excel
            |config/save|thresholds/import|thresholds/clear|start|stop|run-now|test-mail */
(function () {
'use strict';
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = id => document.getElementById(id);
const toast = (m, t) => { if (window.DS && DS.toast) DS.toast(m, t || 'info'); };
const can = key => { try { return !window.AtmAuth || typeof AtmAuth.can !== 'function' || AtmAuth.can(key); } catch (e) { return true; } };

const BADGE = { 'İŞLƏMİR': 'danger', 'ŞƏKİL YOXDUR': 'danger', 'QOŞULMADI': 'neutral', 'NORMAL': 'success' };
const CATS = ['İŞLƏMİR', 'ŞƏKİL YOXDUR', 'QOŞULMADI', 'NORMAL'];

const S = { inited: false, cfgLoaded: false, timer: null, results: [], filter: 'ALL', runId: null, viewingHistory: false, polling: false };

async function api(url, opts) {
  const r = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), Object.assign({ cache: 'no-store' }, opts || {}));
  let d = null;
  try { d = await r.json(); } catch (e) { /* */ }
  if (!r.ok || !d || d.success === false) throw new Error((d && d.error) || ('HTTP ' + r.status));
  return d;
}
function fmtDT(iso) {
  if (!iso) return '—';
  const m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})/.exec(iso);
  return m ? `${m[3]}.${m[2]}.${m[1]} ${m[4]}:${m[5]}` : esc(iso);
}
function fmtH(h) { return h == null ? '—' : (Math.round(h * 10) / 10) + ' s'; }

/* ---------- config form ---------- */
function fillConfig(c) {
  if (!c) return;
  $('cfInterval').value = c.interval_hours != null ? c.interval_hours : 1;
  $('cfDefault').value = c.default_threshold != null ? c.default_threshold : 0;
  $('cfGrace').value = c.grace_minutes != null ? c.grace_minutes : 0;
  $('cfOnlyProblem').checked = !!c.only_on_problem;
  $('cfInclOffline').checked = !!c.include_offline;
  $('cfHost').value = c.smtp_host || '';
  $('cfPort').value = c.smtp_port != null ? c.smtp_port : 25;
  $('cfSec').value = c.smtp_security || 'none';
  $('cfUser').value = c.smtp_user || '';
  $('cfFrom').value = c.mail_from || '';
  $('cfTo').value = c.mail_to || '';
  $('cfPassHint').textContent = c.has_pass ? '(yazılıb — dəyişmək üçün yenisini yaz)' : '(hələ yazılmayıb)';
  $('monThrCount').textContent = c.threshold_count || 0;
}
function readConfig() {
  const o = {
    interval_hours: parseFloat($('cfInterval').value) || 1,
    default_threshold: parseFloat($('cfDefault').value) || 0,
    grace_minutes: parseInt($('cfGrace').value) || 0,
    only_on_problem: $('cfOnlyProblem').checked ? 1 : 0,
    include_offline: $('cfInclOffline').checked ? 1 : 0,
    smtp_host: $('cfHost').value.trim(),
    smtp_port: parseInt($('cfPort').value) || 25,
    smtp_security: $('cfSec').value,
    smtp_user: $('cfUser').value.trim(),
    mail_from: $('cfFrom').value.trim(),
    mail_to: $('cfTo').value.trim(),
  };
  const p = $('cfPass').value;
  if (p) o.smtp_pass = p;
  return o;
}

/* ---------- render ---------- */
function setSchedUI(on) {
  $('monStartBtn').classList.toggle('hidden', on || !can('monitor.run'));
  $('monStopBtn').classList.toggle('hidden', !on || !can('monitor.run'));
  $('monSched').textContent = on ? 'İŞLƏYİR' : 'DAYANIB';
  $('monSched').style.color = on ? 'var(--c-success)' : 'var(--c-text-muted)';
}
function counts(list) { const c = {}; list.forEach(r => { c[r.status] = (c[r.status] || 0) + 1; }); return c; }
function renderChips() {
  const c = counts(S.results);
  const items = [['ALL', 'Hamısı', S.results.length]].concat(CATS.filter(k => c[k]).map(k => [k, k, c[k]]));
  if (S.filter !== 'ALL' && !c[S.filter]) S.filter = 'ALL';
  $('monChips').innerHTML = items.map(([k, label, n]) =>
    `<button type="button" class="vaChip${S.filter === k ? ' is-active' : ''}" data-k="${esc(k)}">${esc(label)} <b>${n}</b></button>`).join('');
  $('monChips').querySelectorAll('.vaChip').forEach(b => b.onclick = () => { S.filter = b.dataset.k; renderChips(); renderTable(); });
}
function renderTable() {
  const rows = S.results.filter(r => S.filter === 'ALL' || r.status === S.filter);
  const tb = $('monTable');
  if (!rows.length) {
    tb.innerHTML = `<tr><td colspan="10" class="vaEmpty">${S.results.length ? 'Filtrə uyğun yoxdur.' : 'Hələ yoxlama edilməyib.'}</td></tr>`;
  } else {
    tb.innerHTML = rows.map((r, i) => `<tr class="vaRow vaRow--${BADGE[r.status] || 'neutral'}">
      <td>${i + 1}</td>
      <td><b class="vaAtm">${esc(r.atm_id)}</b></td>
      <td class="vaName" title="${esc(r.name)}">${esc(r.name || '—')}</td>
      <td>${esc(r.region || '—')}</td>
      <td><span class="ds-badge ds-badge--${BADGE[r.status] || 'neutral'}">${esc(r.status)}</span></td>
      <td>${r.threshold == null ? '—' : r.threshold}</td>
      <td class="vaMono">${fmtH(r.hours_since)}</td>
      <td class="vaMono">${fmtDT(r.last_image_at)}</td>
      <td>${r.image_count == null ? '—' : r.image_count}</td>
      <td class="vaNote" title="${esc(r.error || '')}">${esc(r.error || '')}</td></tr>`).join('');
  }
  $('monTableFoot').textContent = rows.length === S.results.length ? `${rows.length} ATM` : `${rows.length} / ${S.results.length} ATM`;
}
function renderStats(st) {
  const c = counts(S.results);
  $('monChecked').textContent = (st ? st.checked : S.results.length) + ' / ' + (st ? st.total : S.results.length);
  $('monNotWorking').textContent = c['İŞLƏMİR'] || 0;
  $('monNoImage').textContent = c['ŞƏKİL YOXDUR'] || 0;
  $('monOffline').textContent = c['QOŞULMADI'] || 0;
  $('monNormal').textContent = c['NORMAL'] || 0;
}

/* ---------- status poll ---------- */
async function pollStatus() {
  if (document.hidden || S.polling) return;
  S.polling = true;
  try {
    const d = await api('/api/monitor/status');
    if (!S.cfgLoaded && d.config) { fillConfig(d.config); S.cfgLoaded = true; }
    else if (d.config) { $('monThrCount').textContent = d.config.threshold_count || 0; $('cfPassHint').textContent = d.config.has_pass ? '(yazılıb — dəyişmək üçün yenisini yaz)' : '(hələ yazılmayıb)'; }
    setSchedUI(!!d.scheduler_on);
    $('monRunBadge').textContent = d.busy ? 'Yoxlanır...' : 'Monitorinq';
    $('monState').textContent = d.busy ? 'Yoxlama gedir...' : (d.scheduler_on ? 'Planlaşdırıcı aktiv' : 'Monitorinq hazırdır');
    $('monMeta').textContent = d.last_run_at
      ? `Son yoxlama: ${fmtDT(d.last_run_at)} · ${d.last_status || ''}`
      : 'Parametrləri doldur, Excel həddini import et, sonra başlat.';
    $('monNext').textContent = 'Növbəti: ' + (d.scheduler_on && d.next_run_at ? fmtDT(d.next_run_at) : '—');
    $('monMail').textContent = d.mail_sent ? 'göndərildi ✓' : (d.mail_error ? 'XƏTA' : '—');
    $('monMail').style.color = d.mail_error ? 'var(--c-danger)' : (d.mail_sent ? 'var(--c-success)' : '');
    const logBox = $('monLog');
    if (logBox) { const stick = logBox.scrollTop + logBox.clientHeight >= logBox.scrollHeight - 20; logBox.textContent = (d.logs || []).join('\n') || '—'; if (stick) logBox.scrollTop = logBox.scrollHeight; }
    if (!S.viewingHistory && Array.isArray(d.last_results)) {
      S.results = d.last_results;
      S.runId = d.last_run_id;
      renderStats(d); renderChips(); renderTable();
      $('monExcelBtn').disabled = !S.runId || !S.results.length;
    }
  } catch (e) { /* */ } finally { S.polling = false; }
}

/* ---------- thresholds ---------- */
async function loadThresholds() {
  const tb = $('monThrTable');
  try {
    const d = await api('/api/monitor/thresholds');
    const rows = d.rows || [];
    if (!rows.length) { tb.innerHTML = '<tr><td colspan="4" class="vaEmpty">Hələ hədd yüklənməyib.</td></tr>'; return; }
    tb.innerHTML = rows.map(r => `<tr><td><b>${esc(r.atm_id)}</b></td><td>${esc(r.name || '—')}</td><td>${esc(r.region || '—')}</td><td><b>${r.max_hours}</b> saat</td></tr>`).join('');
  } catch (e) { tb.innerHTML = `<tr><td colspan="4" class="vaEmpty">Alınmadı: ${esc(e.message)}</td></tr>`; }
}
async function doImport(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  try {
    const buf = await file.arrayBuffer();
    const r = await fetch('/api/monitor/thresholds/import?t=' + Date.now(), {
      method: 'POST', cache: 'no-store',
      headers: { 'Content-Type': 'application/octet-stream' }, body: buf
    });
    const d = await r.json();
    if (!r.ok || !d.success) throw new Error(d.error || ('HTTP ' + r.status));
    toast(`Import: ${d.imported} ATM həddi yüklendi (${d.skipped} ötürüldü). Cəmi: ${d.total}.`, 'success');
    loadThresholds(); pollStatus();
  } catch (e) { toast('Import alınmadı: ' + e.message, 'danger'); }
  finally { input.value = ''; }
}
async function clearThr() {
  if (!confirm('Bütün ATM hədd cədvəli silinsin?')) return;
  try { await api('/api/monitor/thresholds/clear', { method: 'POST' }); toast('Hədd cədvəli təmizləndi.', 'info'); loadThresholds(); pollStatus(); }
  catch (e) { toast(e.message, 'danger'); }
}

/* ---------- actions ---------- */
async function saveConfig() {
  try {
    await api('/api/monitor/config/save', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(readConfig()) });
    $('cfPass').value = '';
    toast('Parametrlər yadda saxlanıldı.', 'success');
    S.cfgLoaded = false; pollStatus();
  } catch (e) { toast('Saxlanmadı: ' + e.message, 'danger'); }
}
async function testMail() {
  toast('Test mail göndərilir...', 'info');
  try {
    await api('/api/monitor/test-mail', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(readConfig()) });
    toast('Test mail göndərildi ✓ — gələnlər qutusunu yoxla.', 'success');
  } catch (e) { toast('Test mail getmədi: ' + e.message, 'danger'); }
}
async function start() {
  try { await api('/api/monitor/start', { method: 'POST' }); toast('Planlaşdırıcı başladı — indi ilk yoxlama gedir.', 'success'); setTimeout(pollStatus, 500); }
  catch (e) { toast(e.message, 'warning'); }
}
async function stop() {
  try { await api('/api/monitor/stop', { method: 'POST' }); toast('Planlaşdırıcı dayandırıldı.', 'info'); setTimeout(pollStatus, 300); }
  catch (e) { toast(e.message, 'warning'); }
}
async function runNow() {
  try { await api('/api/monitor/run-now', { method: 'POST' }); toast('Yoxlama başladı...', 'info'); S.viewingHistory = false; setTimeout(pollStatus, 500); }
  catch (e) { toast(e.message, 'warning'); }
}
async function excel(runId) {
  if (!can('monitor.export')) { toast('Excel üçün icazən yoxdur.', 'warning'); return; }
  runId = runId || S.runId;
  if (!runId) { toast('Əvvəl yoxlama et və ya tarixçədən seç.', 'warning'); return; }
  try {
    const r = await fetch('/api/monitor/excel?id=' + encodeURIComponent(runId) + '&t=' + Date.now(), { cache: 'no-store' });
    const type = r.headers.get('Content-Type') || '';
    if (!r.ok || type.includes('json')) { let m = 'HTTP ' + r.status; try { m = (await r.json()).error || m; } catch (e) {} throw new Error(m); }
    const blob = await r.blob();
    const cd = r.headers.get('Content-Disposition') || '';
    const mm = /filename="?([^";]+)"?/i.exec(cd);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = mm ? mm[1] : `ATM_Foto_Monitorinq_${runId}.xlsx`;
    document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
    toast('Excel hazırdır: ' + a.download, 'success');
  } catch (e) { toast('Excel yüklənmədi: ' + e.message, 'danger'); }
}
async function openRun(runId) {
  try {
    const d = await api('/api/monitor/detail?id=' + encodeURIComponent(runId));
    const run = d.run || {};
    S.viewingHistory = true; S.runId = run.id; S.filter = 'ALL';
    S.results = d.results || [];
    $('monState').textContent = 'Tarixçə — #' + run.id;
    $('monMeta').textContent = `${fmtDT(run.run_at)} · tətik: ${run.trigger || ''} · mail ${run.mail_sent ? 'göndərildi' : (run.mail_error ? 'XƏTA' : 'yox')}`;
    renderStats({ checked: run.checked, total: run.checked }); renderChips(); renderTable();
    $('monExcelBtn').disabled = !S.results.length;
    toast('Tarixçə #' + run.id + ' açıldı. (Canlıya qayıtmaq üçün "İndi yoxla" və ya yenilə)', 'info');
  } catch (e) { toast('Açılmadı: ' + e.message, 'danger'); }
}
async function loadHistory() {
  const tb = $('monHistory');
  try {
    const d = await api('/api/monitor/history?limit=50');
    const runs = d.runs || [];
    if (!runs.length) { tb.innerHTML = '<tr><td colspan="9" class="vaEmpty">Hələ yoxlama yoxdur.</td></tr>'; return; }
    tb.innerHTML = runs.map(r => `<tr class="${r.id === S.runId ? 'selected' : ''}">
      <td><b>#${r.id}</b></td><td>${fmtDT(r.run_at)}</td><td>${esc(r.trigger || '')}</td>
      <td>${r.checked || 0}</td><td>${r.not_working || 0}</td><td>${r.no_image || 0}</td><td>${r.offline || 0}</td>
      <td>${r.mail_sent ? '<span class="ds-badge ds-badge--success">göndərildi</span>' : (r.mail_error ? '<span class="ds-badge ds-badge--danger">xəta</span>' : '—')}</td>
      <td class="vaHistActs"><button type="button" class="btnGray ds-btn--sm" data-open="${r.id}">Bax</button>
        ${can('monitor.export') ? `<button type="button" class="btnGreen ds-btn--sm" data-xl="${r.id}" ${!r.checked ? 'disabled' : ''}>Excel</button>` : ''}</td></tr>`).join('');
    tb.querySelectorAll('[data-open]').forEach(b => b.onclick = () => openRun(Number(b.dataset.open)));
    tb.querySelectorAll('[data-xl]').forEach(b => b.onclick = () => excel(Number(b.dataset.xl)));
  } catch (e) { tb.innerHTML = `<tr><td colspan="9" class="vaEmpty">Alınmadı: ${esc(e.message)}</td></tr>`; }
}

function init() {
  if (!S.inited) { S.inited = true; }
  S.cfgLoaded = false;
  pollStatus();
  loadThresholds();
  loadHistory();
  if (!S.timer) S.timer = setInterval(pollStatus, 3000);
}

window.monitorInit = init;
window.monitorStart = start;
window.monitorStop = stop;
window.monitorRunNow = runNow;
window.monitorExcel = () => excel();
window.monitorSaveConfig = saveConfig;
window.monitorTestMail = testMail;
window.monitorImport = doImport;
window.monitorClearThr = clearThr;
window.monitorLoadHistory = loadHistory;
})();
