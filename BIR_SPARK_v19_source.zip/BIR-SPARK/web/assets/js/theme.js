/* Cihaz İdarəetmə Sistemi — Ağ / Qaranlıq rejim.
   Seçim brauzerdə yadda saxlanılır (localStorage: atm_theme = light | dark).
   Səhifə açılarkən "yanıb-sönmə" olmasın deyə <head>-də kiçik inline skript rejimi əvvəlcədən qoyur. */
(function () {
  'use strict';
  const KEY = 'atm_theme';
  const root = document.documentElement;
  const get = () => root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  function paint() {
    const dark = get() === 'dark';
    document.querySelectorAll('[data-theme-toggle]').forEach(b => {
      b.setAttribute('aria-pressed', String(dark));
      const label = dark ? 'Ağ rejimə keç' : 'Qaranlıq rejimə keç';
      b.title = label; b.setAttribute('aria-label', label);
      const use = b.querySelector('use'); if (use) use.setAttribute('href', dark ? '#i-sun' : '#i-moon');
      const txt = b.querySelector('[data-theme-label]'); if (txt) txt.textContent = dark ? 'Ağ rejim' : 'Qaranlıq rejim';
    });
  }
  function set(mode) {
    mode = mode === 'dark' ? 'dark' : 'light';
    if (mode === 'dark') root.setAttribute('data-theme', 'dark'); else root.removeAttribute('data-theme');
    try { localStorage.setItem(KEY, mode); } catch (e) { /* gizli rejim və s. */ }
    paint();
    try { window.dispatchEvent(new CustomEvent('atm-theme', { detail: mode })); } catch (e) { /* */ }
  }
  window.AtmTheme = { get, set, toggle: () => set(get() === 'dark' ? 'light' : 'dark') };
  // Başqa tab-da dəyişəndə bu tab da dəyişsin
  window.addEventListener('storage', e => { if (e.key === KEY) set(e.newValue); });
  document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('[data-theme-toggle]'); if (b) { e.preventDefault(); window.AtmTheme.toggle(); } });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', paint); else paint();
})();
