/* Cihaz İdarəetmə Sistemi — çoxdilli dəstək (AZ / RU / EN).
   Mərhələli tam tərcümə, 1-ci faza: menyu, başlıqlar, login, ümumi düymələr.
   Yanaşma: lüğət açarı = Azərbaycan mətni. Düyünün orijinal AZ mətni
   data-i18n-orig-də saxlanır, "az"-a qayıdanda bərpa olunur. Yalnız lüğətdə
   DƏQİQ uyğun gələn mətnlər dəyişir — ATM ID, rəqəm və data toxunulmur. */
(function () {
'use strict';

// === LÜĞƏT (AZ -> {ru, en}). Yeni mətnlər bura əlavə olunur (növbəti fazalar). ===
const DICT = {
  // Menyu / bölmələr
  "İdarəetmə": { ru: "Управление", en: "Management" },
  "Modullar": { ru: "Модули", en: "Modules" },
  "Administrasiya": { ru: "Администрирование", en: "Administration" },
  "Ana səhifə": { ru: "Главная", en: "Home" },
  "ATM Xəritəsi": { ru: "Карта устройств", en: "Device Map" },
  "Backup Monitor": { ru: "Монитор резервных копий", en: "Backup Monitor" },
  "Scan Tarixçəsi": { ru: "История сканирований", en: "Scan History" },
  "ATM Restart": { ru: "Перезагрузка", en: "Restart" },
  "Video Archive": { ru: "Видеоархив", en: "Video Archive" },
  "ATM Info": { ru: "Информация", en: "Info" },
  "Hadisə jurnalı": { ru: "Журнал событий", en: "Event Log" },
  "İstifadəçilər": { ru: "Пользователи", en: "Users" },
  "100% offline rejim": { ru: "100% офлайн режим", en: "100% offline mode" },
  "Sistem hazırdır": { ru: "Система готова", en: "System ready" },
  // Login
  "XOŞ GƏLMİSİNİZ": { ru: "ДОБРО ПОЖАЛОВАТЬ", en: "WELCOME" },
  "Sistemə giriş": { ru: "Вход в систему", en: "Sign in" },
  "İstifadəçi adı": { ru: "Имя пользователя", en: "Username" },
  "Şifrə": { ru: "Пароль", en: "Password" },
  "Daxil ol": { ru: "Войти", en: "Log in" },
  "Yeni şifrə təyin edin": { ru: "Задайте новый пароль", en: "Set a new password" },
  "Cari (müvəqqəti) şifrə": { ru: "Текущий (временный) пароль", en: "Current (temporary) password" },
  "Yeni şifrə": { ru: "Новый пароль", en: "New password" },
  "Yeni şifrə (təkrar)": { ru: "Новый пароль (повтор)", en: "New password (repeat)" },
  "Yadda saxla və davam et": { ru: "Сохранить и продолжить", en: "Save and continue" },
  "Başqa hesabla daxil ol": { ru: "Войти под другим аккаунтом", en: "Sign in with another account" },
  "Sessiya yoxlanılır...": { ru: "Проверка сессии...", en: "Checking session..." },
  // Ümumi düymələr / etiketlər
  "Yenilə": { ru: "Обновить", en: "Refresh" },
  "Yeni ATM": { ru: "Новое устройство", en: "New device" },
  "Toplu qoşulma": { ru: "Групповое подключение", en: "Bulk connect" },
  "Windows idarəetmə": { ru: "Управление Windows", en: "Windows management" },
  "Qoşul və yoxla": { ru: "Подключить и проверить", en: "Connect and check" },
  "Düzəliş": { ru: "Изменить", en: "Edit" },
  "Sil": { ru: "Удалить", en: "Delete" },
  "Bərpa et": { ru: "Восстановить", en: "Restore" },
  "Ləğv et": { ru: "Отмена", en: "Cancel" },
  "Yadda saxla": { ru: "Сохранить", en: "Save" },
  "Status": { ru: "Статус", en: "Status" },
  "Aktiv": { ru: "Активен", en: "Active" },
  "Deaktiv": { ru: "Неактивен", en: "Inactive" },
  "Hamısı": { ru: "Все", en: "All" },
  "Region": { ru: "Регион", en: "Region" },
  "Ad": { ru: "Название", en: "Name" },
  "Məlumat": { ru: "Данные", en: "Info" },
  // Səhifə başlıqları / modul adları
  "Backup Monitor — ATM Monitor": { ru: "Монитор резервных копий", en: "Backup Monitor" },
  "Agent Monitoru": { ru: "Монитор агентов", en: "Agent Monitor" },
  "Sistem Monitoru": { ru: "Системный монитор", en: "System Monitor" },
  "ATM Sistem Monitoru": { ru: "Системный монитор устройств", en: "Device System Monitor" },
  "Bankomatlar": { ru: "Устройства", en: "Devices" },
  "Disk Report": { ru: "Отчёт по дискам", en: "Disk Report" },
  "Disk Yaddaş Reportu": { ru: "Отчёт по дисковой памяти", en: "Disk Usage Report" },
  "ATM File Explorer / Video Archive": { ru: "Файлы / Видеоархив", en: "File Explorer / Video Archive" },
  "Coğrafiya": { ru: "География", en: "Geography" },
  "Diaqnostika": { ru: "Диагностика", en: "Diagnostics" },
  // ATM Info / cədvəl başlıqları
  "ATM siyahısı": { ru: "Список устройств", en: "Device list" },
  "Tip": { ru: "Тип", en: "Type" },
  "RİM": { ru: "РИМ", en: "RIM" },
  "Sistemdəki ünvan": { ru: "Адрес в системе", en: "System address" },
  "Yerləşdiyi ünvan": { ru: "Физический адрес", en: "Physical address" },
  "Son CPU": { ru: "CPU (посл.)", en: "Last CPU" },
  "Son RAM": { ru: "RAM (посл.)", en: "Last RAM" },
  "Son yoxlama": { ru: "Последняя проверка", en: "Last check" },
  "Son qoşulma": { ru: "Последнее подключение", en: "Last connection" },
  "Son info yoxlaması": { ru: "Последняя проверка инфо", en: "Last info check" },
  "Silinməyənlər": { ru: "Не удалённые", en: "Not deleted" },
  "Silinənlər": { ru: "Удалённые", en: "Deleted" },
  "Silinib": { ru: "Удалено", en: "Deleted" },
  "Excel/CSV": { ru: "Excel/CSV", en: "Excel/CSV" },
  "Ümumi": { ru: "Всего", en: "Total" },
  "Son yoxlama: online": { ru: "Проверка: онлайн", en: "Check: online" },
  "Son yoxlama: oflayn": { ru: "Проверка: офлайн", en: "Check: offline" },
  "Password tapılıb": { ru: "Пароль найден", en: "Password found" },
  "Məlumat": { ru: "Данные", en: "Info" },
  "Tarixçə / report": { ru: "История / отчёт", en: "History / report" },
  "Statik məlumat": { ru: "Статические данные", en: "Static data" },
  "Sistem məlumatı": { ru: "Системные данные", en: "System data" },
  "Disklərin yaddaşı": { ru: "Память дисков", en: "Disk memory" },
  "Qoşulma tarixçəsi": { ru: "История подключений", en: "Connection history" },
  "Hostname": { ru: "Имя хоста", en: "Hostname" },
  "Əməliyyat sistemi": { ru: "Операционная система", en: "Operating system" },
  "Versiya / build": { ru: "Версия / сборка", en: "Version / build" },
  "Arxitektura": { ru: "Архитектура", en: "Architecture" },
  "Nüvə sayı": { ru: "Число ядер", en: "Core count" },
  "Uptime": { ru: "Время работы", en: "Uptime" },
  "Boot vaxtı": { ru: "Время загрузки", en: "Boot time" },
  "PASSWORD slotu": { ru: "Слот PASSWORD", en: "PASSWORD slot" },
  "Windows növü": { ru: "Версия Windows", en: "Windows type" },
  "Latitude": { ru: "Широта", en: "Latitude" },
  "Longitude": { ru: "Долгота", en: "Longitude" },
  "Vaxt": { ru: "Время", en: "Time" },
  "Port": { ru: "Порт", en: "Port" },
  "Nəticə": { ru: "Результат", en: "Result" },
  "Online": { ru: "Онлайн", en: "Online" },
  "Oflayn": { ru: "Офлайн", en: "Offline" },
  "Disk": { ru: "Диск", en: "Disk" },
  "Label": { ru: "Метка", en: "Label" },
  "FS": { ru: "ФС", en: "FS" },
  "Dolu": { ru: "Занято", en: "Used" },
  "Boş": { ru: "Свободно", en: "Free" },
  // Xəritə
  "Marker": { ru: "Маркер", en: "Marker" },
  "Koordinatsız": { ru: "Без координат", en: "No coords" },
  "Aktiv (canlı)": { ru: "Активные (онлайн)", en: "Active (live)" },
  "Qoşulma OK": { ru: "Подключение OK", en: "Connection OK" },
  "Yoxlanmayıb": { ru: "Не проверено", en: "Not checked" },
  "Xəta": { ru: "Ошибка", en: "Error" },
  "ATM DETALI": { ru: "ДЕТАЛИ УСТРОЙСТВА", en: "DEVICE DETAILS" },
  "Son əməliyyatlar": { ru: "Последние операции", en: "Recent operations" },
  "Fokus": { ru: "Фокус", en: "Focus" },
  // Ümumi düymələr
  "Başlat": { ru: "Запустить", en: "Start" },
  "Dayandır": { ru: "Остановить", en: "Stop" },
  "Seçilmişlərə qoşul": { ru: "Подключить выбранные", en: "Connect selected" },
  "Mövcud ATM-lər": { ru: "Доступные устройства", en: "Available devices" },
  "Seçilmiş (qoşulacaq)": { ru: "Выбранные", en: "Selected" },
  "Bağla": { ru: "Закрыть", en: "Close" },
  "Hamısını sağa": { ru: "Все вправо", en: "All right" },
  "Hamısını sola": { ru: "Все влево", en: "All left" },
  "Avto-yenilə (10 san)": { ru: "Автообновление (10 с)", en: "Auto-refresh (10s)" },
  "CSV": { ru: "CSV", en: "CSV" },
  // Home
  "İdarəetmə paneli": { ru: "Панель управления", en: "Dashboard" },
  "Son scan nəticələri": { ru: "Последние результаты сканирования", en: "Recent scan results" },
  "Son görülən işlər": { ru: "Последние действия", en: "Recent activity" },
  "Scan mənbələri": { ru: "Источники сканирования", en: "Scan sources" },
  "Ümumi ATM": { ru: "Всего устройств", en: "Total devices" },
  "Qoşulma OK": { ru: "Подключение OK", en: "Connection OK" },
  "Qoşulma xətası": { ru: "Ошибка подключения", en: "Connection error" },
  "Backup": { ru: "Резервные копии", en: "Backup" },
  "Fəaliyyət": { ru: "Активность", en: "Activity" },
  // Backup alt-modulları
  "Jurnal": { ru: "Журнал", en: "Journal" },
  "Video / şəkil": { ru: "Видео / фото", en: "Video / image" },
  "Video / Şəkil Server": { ru: "Видео / фото на сервере", en: "Video / Image Server" },
  "ATM nömrəsi": { ru: "Номер ATM", en: "ATM number" },
  "Tarix (istəyə bağlı)": { ru: "Дата (необязательно)", en: "Date (optional)" },
  "Yoxla": { ru: "Проверить", en: "Check" },
  "Siyahı": { ru: "Список", en: "List" },
  "Qalereya": { ru: "Галерея", en: "Gallery" },
  "Qaranlıq rejim": { ru: "Тёмный режим", en: "Dark mode" },
  "Ağ rejim": { ru: "Светлый режим", en: "Light mode" },
  "Video / şəkil modulu": { ru: "Модуль видео / фото", en: "Video / image module" },
  "Qoşul": { ru: "Подключить", en: "Connect" },
  "Qoşulmayıb": { ru: "Не подключено", en: "Not connected" },
  "Önizləmə": { ru: "Предпросмотр", en: "Preview" },
  "Fayla kliklə.": { ru: "Нажмите на файл.", en: "Click a file." },
  "Scan Tarixçəsi": { ru: "История сканирований", en: "Scan history" },
  "Scan başlat": { ru: "Запустить сканирование", en: "Start scan" },
  "Dayandır": { ru: "Остановить", en: "Stop" }
};

const LANGS = ["az", "ru", "en"];
const ATTRS = ["placeholder", "title", "aria-label", "value"];

function getLang() {
  try { const l = localStorage.getItem("ui_lang"); if (LANGS.includes(l)) return l; } catch (e) {}
  return "az";
}
function tr(text, lang) {
  const key = (text || "").trim();
  if (!key || lang === "az") return null;
  const e = DICT[key];
  return e && e[lang] ? e[lang] : null;
}

function translateTextNodes(root, lang) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode: n => {
      const t = (n.nodeValue || "").trim();
      if (!t) return NodeFilter.FILTER_REJECT;
      const p = n.parentNode && n.parentNode.nodeName;
      if (p === "SCRIPT" || p === "STYLE") return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  });
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  nodes.forEach(n => {
    const el = n.parentElement; if (!el) return;
    // orijinal AZ mətni saxla
    if (el.dataset && el.dataset.i18nOrig === undefined && el.childNodes.length === 1) {
      // sadə element — tam mətni açar kimi işlədə bilərik
    }
    const raw = n.nodeValue;
    const trimmed = raw.trim();
    // orijinalı node-da saxla
    if (!n.__i18nOrig) n.__i18nOrig = raw;
    if (lang === "az") { n.nodeValue = n.__i18nOrig; return; }
    const t = tr(trimmed, lang);
    if (t != null) n.nodeValue = raw.replace(trimmed, t);
    else n.nodeValue = n.__i18nOrig;
  });
}

function translateAttrs(root, lang) {
  ATTRS.forEach(attr => {
    root.querySelectorAll("[" + attr + "]").forEach(el => {
      const key = "__i18n_" + attr;
      if (!el[key]) el[key] = el.getAttribute(attr);
      if (lang === "az") { el.setAttribute(attr, el[key]); return; }
      const t = tr(el[key], lang);
      el.setAttribute(attr, t != null ? t : el[key]);
    });
  });
}

function applyLang(lang) {
  if (!LANGS.includes(lang)) lang = "az";
  try { localStorage.setItem("ui_lang", lang); } catch (e) {}
  document.documentElement.setAttribute("lang", lang);
  translateTextNodes(document.body, lang);
  translateAttrs(document, lang);
  // seçicini uyğunlaşdır
  document.querySelectorAll(".i18nLangSel").forEach(s => { s.value = lang; });
}

// Dinamik yüklənən modullar üçün: #moduleHost-a yeni node gələndə yenidən tərcümə et
function observe() {
  const host = document.getElementById("moduleHost") || document.body;
  if (!host || host.__i18nObs) return;
  const obs = new MutationObserver(muts => {
    const lang = getLang(); if (lang === "az") return;
    let need = false;
    muts.forEach(m => { if (m.addedNodes && m.addedNodes.length) need = true; });
    if (need) { translateTextNodes(host, lang); translateAttrs(host, lang); }
  });
  obs.observe(host, { childList: true, subtree: true });
  host.__i18nObs = obs;
}

window.I18N = {
  apply: applyLang,
  get: getLang,
  t: (az) => { const l = getLang(); return tr(az, l) || az; },
  dict: DICT
};

// Dinamik dəyişən başlıq (app.js pageTitle-ı modul açılanda yenidən AZ təyin edir) —
// hər klikdən sonra başlığı/alt-başlığı irəli tərcümə et.
function retranslateHeader(lang) {
  if (lang === "az") return;
  ["pageTitle", "pageSubtitle"].forEach(id => {
    const el = document.getElementById(id); if (!el) return;
    const cur = (el.textContent || "").trim();
    const t = tr(cur, lang);
    if (t != null) el.textContent = t;
  });
}
document.addEventListener("click", () => {
  const lang = getLang(); if (lang === "az") return;
  setTimeout(() => retranslateHeader(lang), 120);
});

document.addEventListener("DOMContentLoaded", () => {
  observe();
  const lang = getLang();
  if (lang !== "az") setTimeout(() => applyLang(lang), 60);
});
})();
