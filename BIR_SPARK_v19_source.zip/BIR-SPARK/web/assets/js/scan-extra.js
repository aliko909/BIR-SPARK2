/* Cihaz İdarəetmə Sistemi — SCAN əlavələri:
   1) Müqayisə (cmp)  — ATM görüntü/jurnal faylları ↔ 172.21.12.77 server backup
   2) ATM Jurnal Scan (ajscan) — C$\JOURNAL + C$\Mobilpay\LOG (sonuncu tarix)
   Backend: /api/cmp/* , /api/ajscan/* */
(function () {
'use strict';
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = id => document.getElementById(id);
const toast = (m, t) => { if (window.DS && DS.toast) DS.toast(m, t || 'info'); };

async function api(url, opts) {
  const r = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), Object.assign({ cache: 'no-store' }, opts || {}));
  let d = null;
  try { d = await r.json(); } catch (e) {}
  if (!r.ok || !d || d.success === false) throw new Error((d && d.error) || ('HTTP ' + r.status));
  return d;
}
function fmtDT(iso) {
  if (!iso) return '—';
  const m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})/.exec(iso);
  return m ? `${m[3]}.${m[2]}.${m[1]} ${m[4]}:${m[5]}` : esc(iso);
}
function fmtFolder(f) { return f && /^\d{8}$/.test(f) ? `${f.slice(6, 8)}.${f.slice(4, 6)}.${f.slice(0, 4)}` : (f || '—'); }
function fmtDur(sec) {
  sec = Number(sec || 0);
  if (sec < 60) return Math.round(sec) + ' san';
  const m = Math.floor(sec / 60), s = Math.round(sec % 60);
  return m < 60 ? `${m} dəq ${s} san` : `${Math.floor(m / 60)} saat ${m % 60} dəq`;
}
function parseList(txt) {
  return (txt || '').split(/[\s,;]+/).map(x => x.trim().toUpperCase()).filter(Boolean);
}
function statusAz(s) {
  return ({ COMPLETED: 'TAMAMLANDI', CANCELLED: 'DAYANDIRILDI', RUNNING: 'İŞLƏYİR',
    FAILED: 'XƏTA', INTERRUPTED: 'YARIMÇIQ' })[s] || s || '—';
}

/* ======================================================================
   MÜQAYİSƏ (cmp)
   ====================================================================== */
const C = { inited: false, runId: null, running: false, since: 0, timer: null, results: [] };

function cmpBindScope() {
  document.querySelectorAll('input[name="cmpScope"]').forEach(r => {
    r.onchange = () => { $('cmpList').classList.toggle('hidden', document.querySelector('input[name="cmpScope"]:checked').value !== 'list'); };
  });
}
window.cmpInit = function () {
  if (!C.inited) { C.inited = true; cmpBindScope(); cmpLoadHistory(); }
  cmpPoll(true);
};
window.cmpStart = async function () {
  const scope = (document.querySelector('input[name="cmpScope"]:checked') || {}).value || 'all';
  const body = {};
  if (scope === 'list') {
    const ids = parseList($('cmpList').value);
    if (!ids.length) { toast('ATM ID daxil edin.', 'warning'); return; }
    body.atm_ids = ids;
  }
  $('cmpStartBtn').disabled = true;
  try {
    const d = await api('/api/cmp/start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    C.runId = d.run_id; C.since = 0; C.results = [];
    toast('Müqayisə başladı.', 'success');
    cmpPoll(true);
  } catch (e) { toast(String(e.message || e), 'danger'); $('cmpStartBtn').disabled = false; }
};
window.cmpStop = async function () {
  try { await api('/api/cmp/cancel', { method: 'POST' }); toast('Dayandırılır...', 'info'); } catch (e) { toast(String(e.message || e), 'danger'); }
};
window.cmpExcel = function () {
  if (!C.runId) return;
  window.location = '/api/cmp/excel?id=' + encodeURIComponent(C.runId) + '&t=' + Date.now();
};
window.cmpLoadHistory = async function () {
  try {
    const d = await api('/api/cmp/history?limit=100');
    const tb = $('cmpHistory'); if (!tb) return;
    tb.innerHTML = (d.runs || []).length ? d.runs.map(r =>
      `<tr><td>#${r.id}</td><td>${fmtDT(r.started_at)}</td><td>${esc(statusAz(r.status))}</td><td>${r.checked_count || 0}</td><td>${r.ok_count || 0}</td><td>${r.diff_count || 0}</td><td>${r.missing_files || 0}</td><td>${fmtDur(r.duration_seconds)}</td><td><button type="button" class="ds-btn ds-btn--sm" onclick="cmpOpen(${r.id})">Aç</button></td></tr>`
    ).join('') : '<tr><td colspan="9" class="vaEmpty">Hələ müqayisə yoxdur.</td></tr>';
  } catch (e) {}
};
window.cmpOpen = async function (id) {
  try {
    const d = await api('/api/cmp/detail?id=' + id);
    C.runId = id; C.results = d.results || [];
    cmpRenderTable(); cmpRenderStats(null, d.run);
    $('cmpExcelBtn').disabled = false;
    $('cmpState').textContent = 'Tarixçə #' + id + ' — ' + statusAz(d.run.status);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } catch (e) { toast(String(e.message || e), 'danger'); }
};
function cmpRenderStats(snap, run) {
  if ($('cmpAllCount') && snap && snap.active_atm_count != null) $('cmpAllCount').textContent = '(' + snap.active_atm_count + ')';
  const total = snap ? snap.total : (run ? run.checked_count : C.results.length);
  const processed = snap ? snap.processed : C.results.length;
  $('cmpProcessed').textContent = processed + ' / ' + (total || 0);
  let ok = 0, diff = 0, none = 0, fail = 0;
  C.results.forEach(r => {
    if (r.category === 'TAM BACKUP') ok++;
    else if (r.category === 'FƏRQ VAR') diff++;
    else if (r.category === 'FAYL YOXDUR') none++;
    else fail++;
  });
  $('cmpCntOk').textContent = ok; $('cmpCntDiff').textContent = diff;
  $('cmpCntNone').textContent = none; $('cmpCntFailed').textContent = fail;
}
const CMP_BADGE = { 'TAM BACKUP': 'success', 'FƏRQ VAR': 'danger', 'FAYL YOXDUR': 'warning', 'QOŞULMADI': 'neutral', 'VAXT AŞIMI': 'neutral', 'XƏTA': 'neutral' };
function cmpRenderTable() {
  const tb = $('cmpTable'); if (!tb) return;
  if (!C.results.length) { tb.innerHTML = '<tr><td colspan="10" class="vaEmpty">Hələ nəticə yoxdur.</td></tr>'; $('cmpTableFoot').textContent = ''; return; }
  const rows = C.results.slice().sort((a, b) => {
    const rank = c => ({ 'FƏRQ VAR': 0, 'QOŞULMADI': 1, 'XƏTA': 2, 'VAXT AŞIMI': 3, 'FAYL YOXDUR': 4, 'TAM BACKUP': 5 }[c] ?? 6);
    if (rank(a.category) !== rank(b.category)) return rank(a.category) - rank(b.category);
    return ((b.img_missing || 0) + (b.jrn_missing || 0)) - ((a.img_missing || 0) + (a.jrn_missing || 0));
  });
  tb.innerHTML = rows.map((r, i) => {
    const im = Number(r.img_missing || 0), jm = Number(r.jrn_missing || 0);
    return `<tr><td>${i + 1}</td><td class="mono">${esc(r.atm_id)}</td><td>${esc(r.name || '')}</td><td>${esc(r.region || '')}</td>`
      + `<td><span class="ds-badge ds-badge--${CMP_BADGE[r.category] || 'neutral'}">${esc(r.category)}</span></td>`
      + `<td>${r.img_total == null ? '—' : r.img_total}</td><td${im ? ' style="color:var(--c-danger);font-weight:700"' : ''}>${im}</td>`
      + `<td>${r.jrn_total == null ? '—' : r.jrn_total}</td><td${jm ? ' style="color:var(--c-danger);font-weight:700"' : ''}>${jm}</td>`
      + `<td>${esc(r.error || '')}</td></tr>`;
  }).join('');
  const diff = rows.filter(r => r.category === 'FƏRQ VAR').length;
  $('cmpTableFoot').textContent = `${rows.length} ATM · fərqi olan: ${diff}`;
}
function cmpSetRunning(running) {
  C.running = running;
  $('cmpStartBtn').classList.toggle('hidden', running);
  $('cmpStopBtn').classList.toggle('hidden', !running);
  $('cmpStartBtn').disabled = running;
}
async function cmpTick() {
  try {
    const d = await api('/api/cmp/progress?since=' + C.since);
    if (Array.isArray(d.logs) && d.logs.length) {
      const box = $('cmpLog');
      if (box) { if (C.since === 0) box.textContent = ''; box.textContent += d.logs.join('\n') + '\n'; box.scrollTop = box.scrollHeight; }
      C.since = d.log_total;
    }
    $('cmpFill').style.width = (d.percent || 0) + '%';
    $('cmpPercent').textContent = (d.percent || 0) + '%';
    $('cmpPhase').textContent = d.phase || '—';
    $('cmpRunBadge').textContent = d.running ? 'İŞLƏYİR' : (d.finished ? 'HAZIR' : '—');
    if (d.running) $('cmpState').textContent = 'İşləyir — ' + (d.phase || '');
    $('cmpProcessed').textContent = (d.processed || 0) + ' / ' + (d.total || 0);
    if (d.active_atm_count != null && $('cmpAllCount')) $('cmpAllCount').textContent = '(' + d.active_atm_count + ')';
    cmpSetRunning(!!d.running);
    if (d.run_id) C.runId = d.run_id;
    const wasRunning = C.running;
    if (!d.running && d.finished) {
      if (C.timer) { clearInterval(C.timer); C.timer = null; }
      if (C.runId) { await cmpOpenSilent(C.runId); $('cmpExcelBtn').disabled = false; }
      $('cmpState').textContent = d.error ? ('XƏTA: ' + d.error) : 'Tamamlandı.';
      if (!d.error && wasRunning) toast('Müqayisə tamamlandı.', 'success');
    }
  } catch (e) {}
}
async function cmpOpenSilent(id) {
  try { const d = await api('/api/cmp/detail?id=' + id); C.results = d.results || []; cmpRenderTable(); cmpRenderStats(null, d.run); } catch (e) {}
}
function cmpPoll(immediate) {
  if (C.timer) { clearInterval(C.timer); C.timer = null; }
  if (immediate) cmpTick();
  C.timer = setInterval(cmpTick, 1500);
}

/* ======================================================================
   ATM JURNAL SCAN (ajscan)
   ====================================================================== */
const A = { inited: false, runId: null, running: false, since: 0, timer: null, results: [] };
function ajBindScope() {
  document.querySelectorAll('input[name="ajScope"]').forEach(r => {
    r.onchange = () => { $('ajList').classList.toggle('hidden', document.querySelector('input[name="ajScope"]:checked').value !== 'list'); };
  });
}
window.ajScanInit = function () {
  if (!A.inited) { A.inited = true; ajBindScope(); ajScanLoadHistory(); }
  ajPoll(true);
};
window.ajScanStart = async function () {
  const scope = (document.querySelector('input[name="ajScope"]:checked') || {}).value || 'all';
  const body = {};
  if (scope === 'list') {
    const ids = parseList($('ajList').value);
    if (!ids.length) { toast('ATM ID daxil edin.', 'warning'); return; }
    body.atm_ids = ids;
  }
  $('ajStartBtn').disabled = true;
  try {
    const d = await api('/api/ajscan/start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    A.runId = d.run_id; A.since = 0; A.results = [];
    toast('ATM Jurnal Scan başladı.', 'success');
    ajPoll(true);
  } catch (e) { toast(String(e.message || e), 'danger'); $('ajStartBtn').disabled = false; }
};
window.ajScanStop = async function () {
  try { await api('/api/ajscan/cancel', { method: 'POST' }); toast('Dayandırılır...', 'info'); } catch (e) { toast(String(e.message || e), 'danger'); }
};
window.ajScanExcel = function () {
  if (!A.runId) return;
  window.location = '/api/ajscan/excel?id=' + encodeURIComponent(A.runId) + '&t=' + Date.now();
};
window.ajScanLoadHistory = async function () {
  try {
    const d = await api('/api/ajscan/history?limit=100');
    const tb = $('ajHistory'); if (!tb) return;
    tb.innerHTML = (d.runs || []).length ? d.runs.map(r =>
      `<tr><td>#${r.id}</td><td>${fmtDT(r.started_at)}</td><td>${esc(statusAz(r.status))}</td><td>${r.checked_count || 0}</td><td>${r.ok_count || 0}</td><td>${r.empty_count || 0}</td><td>${r.failed_count || 0}</td><td>${fmtDur(r.duration_seconds)}</td><td><button type="button" class="ds-btn ds-btn--sm" onclick="ajOpen(${r.id})">Aç</button></td></tr>`
    ).join('') : '<tr><td colspan="9" class="vaEmpty">Hələ scan yoxdur.</td></tr>';
  } catch (e) {}
};
window.ajOpen = async function (id) {
  try {
    const d = await api('/api/ajscan/detail?id=' + id);
    A.runId = id; A.results = d.results || [];
    ajRenderTable(); ajRenderStats(null, d.run);
    $('ajExcelBtn').disabled = false;
    $('ajState').textContent = 'Tarixçə #' + id + ' — ' + statusAz(d.run.status);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } catch (e) { toast(String(e.message || e), 'danger'); }
};
function ajRenderStats(snap, run) {
  if ($('ajAllCount') && snap && snap.active_atm_count != null) $('ajAllCount').textContent = '(' + snap.active_atm_count + ')';
  const total = snap ? snap.total : (run ? run.checked_count : A.results.length);
  const processed = snap ? snap.processed : A.results.length;
  $('ajProcessed').textContent = processed + ' / ' + (total || 0);
  let ok = 0, empty = 0, fail = 0;
  A.results.forEach(r => {
    if (r.category === 'OK') ok++;
    else if (r.category === 'BOŞ' || r.category === 'YOXDUR') empty++;
    else fail++;
  });
  $('ajCntOk').textContent = ok; $('ajCntEmpty').textContent = empty; $('ajCntFailed').textContent = fail;
}
const AJ_BADGE = { 'OK': 'success', 'BOŞ': 'warning', 'YOXDUR': 'warning', 'QOŞULMADI': 'neutral', 'VAXT AŞIMI': 'neutral', 'XƏTA': 'neutral' };
function mb(b) { const n = Number(b || 0); return n ? (n / 1048576).toFixed(2) : '0'; }
function ajRenderTable() {
  const tb = $('ajTable'); if (!tb) return;
  if (!A.results.length) { tb.innerHTML = '<tr><td colspan="12" class="vaEmpty">Hələ nəticə yoxdur.</td></tr>'; $('ajTableFoot').textContent = ''; return; }
  const rows = A.results.slice();
  tb.innerHTML = rows.map((r, i) =>
    `<tr><td>${i + 1}</td><td class="mono">${esc(r.atm_id)}</td><td>${esc(r.name || '')}</td><td>${esc(r.region || '')}</td>`
    + `<td><span class="ds-badge ds-badge--${AJ_BADGE[r.category] || 'neutral'}">${esc(r.category)}</span></td>`
    + `<td>${fmtFolder(r.j_date)}</td><td>${r.j_files == null ? '—' : r.j_files}</td><td>${mb(r.j_bytes)}</td>`
    + `<td>${fmtFolder(r.m_date)}</td><td>${r.m_files == null ? '—' : r.m_files}</td><td>${mb(r.m_bytes)}</td>`
    + `<td>${esc(r.error || [r.j_error, r.m_error].filter(Boolean).join(' · '))}</td></tr>`
  ).join('');
  $('ajTableFoot').textContent = `${rows.length} ATM`;
}
function ajSetRunning(running) {
  A.running = running;
  $('ajStartBtn').classList.toggle('hidden', running);
  $('ajStopBtn').classList.toggle('hidden', !running);
  $('ajStartBtn').disabled = running;
}
async function ajTick() {
  try {
    const d = await api('/api/ajscan/progress?since=' + A.since);
    if (Array.isArray(d.logs) && d.logs.length) {
      const box = $('ajLog');
      if (box) { if (A.since === 0) box.textContent = ''; box.textContent += d.logs.join('\n') + '\n'; box.scrollTop = box.scrollHeight; }
      A.since = d.log_total;
    }
    $('ajFill').style.width = (d.percent || 0) + '%';
    $('ajPercent').textContent = (d.percent || 0) + '%';
    $('ajRunBadge').textContent = d.running ? 'İŞLƏYİR' : (d.finished ? 'HAZIR' : 'Scan —');
    if (d.running) $('ajState').textContent = 'Scan işləyir...';
    $('ajProcessed').textContent = (d.processed || 0) + ' / ' + (d.total || 0);
    if (d.active_atm_count != null && $('ajAllCount')) $('ajAllCount').textContent = '(' + d.active_atm_count + ')';
    ajSetRunning(!!d.running);
    if (d.run_id) A.runId = d.run_id;
    const wasRunning = A.running;
    if (!d.running && d.finished) {
      if (A.timer) { clearInterval(A.timer); A.timer = null; }
      if (A.runId) { await ajOpenSilent(A.runId); $('ajExcelBtn').disabled = false; }
      $('ajState').textContent = d.error ? ('XƏTA: ' + d.error) : 'Tamamlandı.';
      if (!d.error && wasRunning) toast('ATM Jurnal Scan tamamlandı.', 'success');
    }
  } catch (e) {}
}
async function ajOpenSilent(id) {
  try { const d = await api('/api/ajscan/detail?id=' + id); A.results = d.results || []; ajRenderTable(); ajRenderStats(null, d.run); } catch (e) {}
}
function ajPoll(immediate) {
  if (A.timer) { clearInterval(A.timer); A.timer = null; }
  if (immediate) ajTick();
  A.timer = setInterval(ajTick, 1500);
}
})();
