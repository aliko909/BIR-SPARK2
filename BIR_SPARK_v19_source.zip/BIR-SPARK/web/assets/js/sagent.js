/* ATM Agent (sadə, müvəqqəti) — agentlərin göndərdiyi CPU/RAM/C/D disk/IP. Backend: /api/sagent/list */
(function () {
'use strict';
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = id => document.getElementById(id);
const S = { rows: [], serverTime: null, timer: null };

function gb(b) { b = Number(b || 0); if (!b) return '—'; const g = b / 1073741824; return (g >= 100 ? g.toFixed(0) : g.toFixed(1)) + ' GB'; }
function diskCell(total, free, pct) {
  total = Number(total || 0); free = Number(free || 0);
  if (!total) return '—';
  const used = total - free;
  const p = pct != null ? pct : Math.round(100 * used / total);
  const col = p >= 90 ? 'var(--c-danger)' : p >= 75 ? 'var(--c-warning)' : 'var(--c-text-primary)';
  return `<span style="color:${col};font-weight:700">${p}%</span> <span class="ds-caption">(${gb(used)}/${gb(total)})</span>`;
}
function pctCell(p) {
  if (p == null) return '—';
  const col = p >= 90 ? 'var(--c-danger)' : p >= 75 ? 'var(--c-warning)' : 'var(--c-text-primary)';
  return `<b style="color:${col}">${p}%</b>`;
}
function ago(iso, now) {
  if (!iso) return { txt: '—', stale: true };
  const t = Date.parse(iso), n = now ? Date.parse(now) : Date.now();
  if (!isFinite(t)) return { txt: esc(iso), stale: true };
  const sec = Math.max(0, Math.round((n - t) / 1000));
  const stale = sec > 300;
  let txt;
  if (sec < 60) txt = sec + ' san əvvəl';
  else if (sec < 3600) txt = Math.floor(sec / 60) + ' dəq əvvəl';
  else txt = Math.floor(sec / 3600) + ' saat əvvəl';
  return { txt, stale };
}

window.sAgentInit = function () {
  sAgentLoad();
  if (S.timer) clearInterval(S.timer);
  const tick = () => {
    if (!$('sAgentModule') || $('sAgentModule').classList.contains('hidden')) { clearInterval(S.timer); S.timer = null; return; }
    sAgentLoad();
  };
  S.timer = setInterval(tick, 5000);
};
window.sAgentLoad = async function () {
  if (document.hidden) return;
  try {
    const r = await fetch('/api/sagent/list?t=' + Date.now(), { cache: 'no-store' });
    const d = await r.json();
    if (!d || d.success === false) throw new Error((d && d.error) || 'HTTP ' + r.status);
    S.rows = d.rows || []; S.serverTime = d.server_time;
    sAgentRender();
  } catch (e) {}
};
window.sAgentRender = function () {
  const tb = $('saTable'); if (!tb) return;
  const q = (($('saSearch') && $('saSearch').value) || '').trim().toLowerCase();
  let rows = S.rows;
  if (q) rows = rows.filter(r => String(r.atm_id).toLowerCase().includes(q) || String(r.ip || '').toLowerCase().includes(q));
  let active = 0, stale = 0;
  S.rows.forEach(r => { const a = ago(r.received_at, S.serverTime); if (a.stale) stale++; else active++; });
  if ($('saCount')) { $('saCount').textContent = S.rows.length; $('saActive').textContent = active; $('saStale').textContent = stale; }
  if (!rows.length) { tb.innerHTML = '<tr><td colspan="9" class="vaEmpty">Hələ agentdən məlumat gəlməyib.</td></tr>'; $('saFoot').textContent = ''; return; }
  tb.innerHTML = rows.map(r => {
    const a = ago(r.received_at, S.serverTime);
    return `<tr${a.stale ? ' style="opacity:.6"' : ''}><td class="mono"><b>${esc(r.atm_id)}</b></td>`
      + `<td class="mono">${esc(r.ip || '—')}</td><td>${esc(r.hostname || '—')}</td>`
      + `<td>${pctCell(r.cpu_percent)}</td><td>${pctCell(r.ram_percent)}</td>`
      + `<td>${diskCell(r.c_total_bytes, r.c_free_bytes, r.c_percent)}</td>`
      + `<td>${diskCell(r.d_total_bytes, r.d_free_bytes, r.d_percent)}</td>`
      + `<td>${r.interval_minutes != null ? r.interval_minutes + ' dəq' : '—'}</td>`
      + `<td>${esc(a.txt)}</td></tr>`;
  }).join('');
  $('saFoot').textContent = `${rows.length} ATM`;
};
})();
