/* Avtomatik Backup — serverdə olmayan backup-ı ATM-dən köçürür. Backend: /api/autobk/* */
(function () {
'use strict';
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = id => document.getElementById(id);
const A = { running: false, timer: null, logLen: 0 };

function parseList(txt) {
  return String(txt || '').split(/[\s,;]+/).map(s => s.trim().toUpperCase()).filter(Boolean);
}

window.autoBkInit = function () {
  // Mövcud işləyən əməliyyat varsa ona qoşul
  _poll();
  if (A.timer) clearInterval(A.timer);
  A.timer = setInterval(() => { if (document.hidden) return; _poll(); }, 1500);
};

window.autoBkStart = async function () {
  const body = {
    days_ago: Number($('abkDaysAgo') && $('abkDaysAgo').value || 6),
    date: ($('abkDate') && $('abkDate').value) || '',
    mode: ($('abkMode') && $('abkMode').value) || 'copy',
    atm_ids: parseList($('abkOnly') && $('abkOnly').value),
    skip: parseList($('abkSkip') && $('abkSkip').value)
  };
  if (!body.atm_ids.length) delete body.atm_ids;
  const panel = $('abkPanel'); if (panel) panel.style.display = '';
  const tb = $('abkTable'); if (tb) tb.innerHTML = '<tr><td colspan="7" class="vaEmpty">Başladılır...</td></tr>';
  A.logLen = 0;
  try {
    const r = await fetch('/api/autobk/start', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-requested-with': 'atm-web' }, body: JSON.stringify(body) });
    const d = await r.json();
    if (!r.ok || !d.success) throw new Error(d.error || ('HTTP ' + r.status));
    A.running = true;
    if ($('abkStartBtn')) $('abkStartBtn').disabled = true;
    if ($('abkStopBtn')) $('abkStopBtn').style.display = '';
    if ($('abkExcelBtn')) $('abkExcelBtn').style.display = 'none';
    _poll();
    if (A.timer) clearInterval(A.timer);
    A.timer = setInterval(() => { if (document.hidden) return; _poll(); }, 1500);
  } catch (e) { alert('Başlamadı: ' + (e.message || e)); }
};

window.autoBkCancel = async function () {
  try { await fetch('/api/autobk/cancel', { method: 'POST', headers: { 'x-requested-with': 'atm-web' } }); } catch (e) {}
};
window.autoBkExcel = function () { window.open('/api/autobk/excel?t=' + Date.now(), '_blank'); };

async function _poll() {
  try {
    const r = await fetch('/api/autobk/progress?since=' + A.logLen + '&t=' + Date.now(), { cache: 'no-store' });
    const d = await r.json();
    if (!d || d.success === false) return;
    _render(d);
    if (!d.running && d.finished) {
      A.running = false;
      if (A.timer) { clearInterval(A.timer); A.timer = null; }
      if ($('abkStartBtn')) $('abkStartBtn').disabled = false;
      if ($('abkStopBtn')) $('abkStopBtn').style.display = 'none';
      if ($('abkExcelBtn') && (d.results || []).length) $('abkExcelBtn').style.display = '';
    }
  } catch (e) {}
}

function _render(d) {
  if (d.server_root && $('abkRoot')) $('abkRoot').textContent = d.server_root;
  const pct = d.percent || 0;
  if ($('abkBar')) $('abkBar').style.width = pct + '%';
  if ($('abkPercent')) $('abkPercent').textContent = pct + '%';
  if ($('abkProgressText')) $('abkProgressText').textContent =
    (d.running ? 'İşləyir' : (d.finished ? 'Tamamlandı' : '—')) + ' · ' + (d.processed || 0) + ' / ' + (d.total || 0) +
    (d.target_date ? (' · tarix ' + d.target_date) : '') + (d.error ? (' · XƏTA: ' + d.error) : '');
  const c = d.counts || {};
  const set = (id, v) => { const el = $(id); if (el) el.textContent = v || 0; };
  set('abkCopied', c.copied); set('abkExists', c.exists); set('abkNodata', c.nodata); set('abkFailed', c.failed);

  const tb = $('abkTable');
  const rows = d.results || [];
  if (tb) {
    if (!rows.length) tb.innerHTML = '<tr><td colspan="7" class="vaEmpty">' + (d.running ? 'İşlənir...' : 'Nəticə yoxdur.') + '</td></tr>';
    else tb.innerHTML = rows.map(r => {
      const cat = r.category || '';
      const badge = cat === 'KÖÇÜRÜLDÜ' ? 'ds-badge--success' : ((cat === 'XƏTA' || cat === 'QOŞULMADI') ? 'ds-badge--danger' : (cat === 'ARTIQ VAR' ? 'ds-badge--neutral' : 'ds-badge--warning'));
      return '<tr><td class="mono"><b>' + esc(r.atm_id) + '</b></td><td>' + esc(r.name || '—') + '</td><td>' + esc(r.region || '—') + '</td>'
        + '<td class="mono">' + esc(r.date || '—') + '</td><td>' + esc(r.server_status || '—') + '</td><td>' + esc(r.atm_status || '—') + '</td>'
        + '<td><span class="ds-badge ds-badge--dot ' + badge + '">' + esc(r.backup_status || cat || '—') + '</span></td></tr>';
    }).join('');
  }
  // log (append)
  if (d.logs && d.logs.length) {
    const box = $('abkLog');
    if (box) { box.textContent += (box.textContent ? '\n' : '') + d.logs.join('\n'); box.scrollTop = box.scrollHeight; }
    A.logLen = d.log_total || (A.logLen + d.logs.length);
  } else if (typeof d.log_total === 'number') {
    A.logLen = d.log_total;
  }
}
})();
