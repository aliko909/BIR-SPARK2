(() => {
  const modules = ['home','backup','videosekil','videoserver','vascan','berpa','jberpa','monitor','deploy','server','backupmgr','srvmove','atmcopy','cmp','ajscan','alerts','notifications','sagent','autobk','jurnal','restart','inventory','diskreport','map','system','agent','atminfo','users','audit'];
  const host = document.getElementById('moduleHost');
  const boot = document.getElementById('modularBoot');
  const bootText = document.getElementById('modularBootText');
  const bootError = document.getElementById('modularBootError');

  async function loadFragment(name, index) {
    bootText.textContent = `Modullar yüklənir: ${index + 1}/${modules.length} — ${name}`;
    const response = await fetch(`/modules/${name}.html?v=41`, {cache: 'no-store'});
    if (!response.ok) throw new Error(`${name}.html yüklənmədi — HTTP ${response.status}`);
    return await response.text();
  }

  async function bootApp() {
    try {
      bootText.textContent = 'Sessiya yoxlanılır...';
      await window.AtmAuth.init();          // sessiya yoxdursa login səhifəsinə yönləndirir
      const htmlParts = [];
      for (let i = 0; i < modules.length; i++) htmlParts.push(await loadFragment(modules[i], i));
      host.insertAdjacentHTML('beforeend', htmlParts.join('\n'));
      boot.remove();
      await new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = '/assets/js/app.js?v=41';
        s.onload = resolve;
        s.onerror = () => reject(new Error('assets/js/app.js yüklənmədi.'));
        document.body.appendChild(s);
      });
      window.AtmAdmin.bind();
      window.AtmAuth.afterAppLoad();        // icazələri tətbiq et, naviqasiya qoruyucularını qur
    } catch (error) {
      bootText.textContent = 'ATM WEB başladılmadı.';
      bootError.textContent = String(error && error.message ? error.message : error);
      bootError.classList.remove('hidden');
    }
  }

  bootApp();
})();
