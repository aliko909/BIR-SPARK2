/* ATM Smart Backup Manager — frontend.
   Serverdəki disklərdən ATM şəkil/jurnal fayllarını tarixə görə hədəf qovluğa köçürür.
   Backend: /api/backup/* (discover, plan, start, status, pause, resume, cancel, config, history). */
(function () {
'use strict';
const $ = id => document.getElementById(id);
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const toast = (m, t) => { if (window.DS && DS.toast) DS.toast(m, t || 'info'); };

let inited = false, pollTimer = null;
const ST = { atms: [], selected: new Set(), drives: [], settings: null };

async function jget(url) {
  const r = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), { cache: 'no-store' });
  let d = {}; try { d = await r.json(); } catch (e) {}
  if (!r.ok && !d.error) throw new Error('HTTP ' + r.status);
  return d;
}
async function jpost(url, body) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}), cache: 'no-store' });
  let d = {}; try { d = await r.json(); } catch (e) {}
  return d;
}

function fmtSize(b) {
  if (b == null || isNaN(b)) return '—';
  b = Number(b);
  const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0;
  while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
  return (i < 2 ? Math.round(b) : b.toFixed(2)) + ' ' + u[i];
}
function fmtSpeed(bps) { return (bps == null || !bps) ? '—' : fmtSize(bps) + '/s'; }
function fmtEta(sec) {
  if (sec == null || !isFinite(sec)) return '—';
  sec = Math.round(sec);
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return (h ? h + 's ' : '') + (h || m ? m + 'd ' : '') + s + 'san';
}
function todayStr(off) {
  const d = new Date(); if (off) d.setDate(d.getDate() - off);
  return d.toISOString().slice(0, 10);
}

/* ---------- Config / drives / settings ---------- */
async function loadConfig() {
  const d = await jget('/api/backup/config');
  if (!d.success) return;
  ST.settings = d.settings;
  ST.drives = (d.detected_drives || []).slice();
  // UNC/əlavə mənbələri də əlavə et
  (d.settings.source_roots || []).forEach(r => { if (ST.drives.indexOf(r) < 0) ST.drives.push(r); });
  renderDrives(d.settings.source_roots || []);
  $('bmDateModeVal').textContent = ({ filename: 'Faylın adı', subfolder: 'Alt qovluğun adı', mtime: 'Son dəyişdirilmə tarixi' })[d.settings.date_mode] || d.settings.date_mode;
  fillSettings(d.settings);
}
function renderDrives(activeRoots) {
  const host = $('bmDrives');
  const active = (activeRoots && activeRoots.length) ? new Set(activeRoots) : null; // null → hamısı
  host.innerHTML = ST.drives.map(dr => {
    const on = active ? active.has(dr) : true;
    return '<label class="bmChip' + (on ? ' on' : '') + '"><input type="checkbox" data-dr="' + esc(dr) + '"' + (on ? ' checked' : '') + '> ' + esc(dr) + '</label>';
  }).join('') || '<span class="ds-caption">Disk tapılmadı.</span>';
  host.querySelectorAll('input[data-dr]').forEach(cb => {
    cb.onchange = () => {
      cb.closest('.bmChip').classList.toggle('on', cb.checked);
      const chosen = [...host.querySelectorAll('input[data-dr]:checked')].map(x => x.dataset.dr);
      // hamısı seçilibsə boş saxla (avtomatik aşkarlama)
      const roots = (chosen.length === ST.drives.length) ? [] : chosen;
      jpost('/api/backup/config', { source_roots: roots });
    };
  });
}

/* ---------- Discover ---------- */
async function discover() {
  const btn = $('bmDiscover'); btn.disabled = true;
  $('bmDiscoverInfo').textContent = 'Disklər skan edilir...';
  try {
    const d = await jpost('/api/backup/discover', {});
    if (!d.success) throw new Error(d.error || 'Aşkarlama alınmadı');
    ST.atms = d.atms || [];
    ST.selected.clear();
    $('bmTotalAtm').textContent = d.count;
    $('bmDiscoverInfo').textContent = d.count + ' ATM tapıldı · mənbə: ' + (d.sources || []).join(', ');
    if (d.errors && d.errors.length) $('bmDiscoverInfo').textContent += ' · xətalar: ' + d.errors.length;
    renderAtmList();
    await loadConfig();
  } catch (e) { toast(e.message || e, 'danger'); $('bmDiscoverInfo').textContent = 'Xəta: ' + (e.message || e); }
  finally { btn.disabled = false; }
}

function renderAtmList() {
  const host = $('bmAtmList');
  const q = ($('bmSearch').value || '').trim().toUpperCase();
  const list = ST.atms.filter(a => !q || a.id.indexOf(q) >= 0);
  if (!ST.atms.length) { host.innerHTML = '<div class="ds-caption" style="padding:10px">Əvvəlcə "Aşkarla" düyməsini basın.</div>'; updateSelCount(); return; }
  host.innerHTML = list.map(a =>
    '<label class="bmAtmItem"><input type="checkbox" data-id="' + esc(a.id) + '"' + (ST.selected.has(a.id) ? ' checked' : '') + '>'
    + '<b>' + esc(a.id) + '</b><small>' + a.path_count + ' qovluq</small></label>'
  ).join('') || '<div class="ds-caption" style="padding:10px">Uyğun ATM yoxdur.</div>';
  host.querySelectorAll('input[data-id]').forEach(cb => {
    cb.onchange = () => { cb.checked ? ST.selected.add(cb.dataset.id) : ST.selected.delete(cb.dataset.id); updateSelCount(); };
  });
  updateSelCount();
}
function updateSelCount() {
  $('bmSelCount').textContent = 'Seçilmiş: ' + ST.selected.size + ' / ' + ST.atms.length;
  $('bmSelAtm').textContent = selectedMode() === 'all' ? ST.atms.length : ST.selected.size;
}
function selectedMode() { const r = document.querySelector('input[name="bmMode"]:checked'); return r ? r.value : 'all'; }
function fileType() { const r = document.querySelector('input[name="bmFtype"]:checked'); return r ? r.value : 'both'; }

/* ---------- Dry Run ---------- */
function buildJob() {
  return {
    mode: selectedMode(),
    atm_ids: selectedMode() === 'selected' ? [...ST.selected] : null,
    date_from: $('bmDateFrom').value, date_to: $('bmDateTo').value,
    file_types: fileType(), dest: ($('bmDest').value || '').trim(),
  };
}
async function dryRun() {
  const job = buildJob();
  if (!job.date_from) { toast('Başlanğıc tarixi seçin.', 'warning'); return; }
  const box = $('bmDryResult'); box.classList.remove('hidden');
  box.innerHTML = '<div class="ds-caption"><span class="ds-spinner"></span> Hesablanır...</div>';
  const d = await jpost('/api/backup/plan', job);
  if (!d.success) { box.innerHTML = '<div class="ds-alert ds-alert--danger">' + esc(d.error || 'Xəta') + '</div>'; return; }
  $('bmFiles').textContent = d.files_total; $('bmSize').textContent = fmtSize(d.bytes_total);
  const rows = (d.per_atm || []).map(a => '<tr><td><b>' + esc(a.id) + '</b></td><td>' + a.files + '</td><td>' + fmtSize(a.bytes) + '</td></tr>').join('');
  box.innerHTML =
    '<div class="ds-title"><svg class="ds-icon"><use href="#i-file-text"/></svg> Dry Run nəticəsi (köçürmə edilmədi)</div>'
    + '<div class="bmDrySummary">'
    + '<div class="ds-inset"><span>ATM</span><b>' + d.atm_count + '</b></div>'
    + '<div class="ds-inset"><span>Fayl</span><b>' + d.files_total + '</b></div>'
    + '<div class="ds-inset"><span>Həcm</span><b>' + fmtSize(d.bytes_total) + '</b></div>'
    + '<div class="ds-inset"><span>Tarix</span><b>' + esc(d.date_from) + (d.date_to !== d.date_from ? ' – ' + esc(d.date_to) : '') + '</b></div>'
    + '</div>'
    + '<div class="ds-caption">Hədəf nümunəsi: <code>' + esc(d.target_example) + '</code></div>'
    + (rows ? '<table class="bmDryTable"><thead><tr><th>ATM ID</th><th>Fayl</th><th>Həcm</th></tr></thead><tbody>' + rows + '</tbody></table>'
            : '<div class="ds-alert" style="margin-top:10px">Seçimə uyğun fayl tapılmadı.</div>');
}

/* ---------- Start / control ---------- */
async function startBackup() {
  const job = buildJob();
  if (!job.date_from) { toast('Başlanğıc tarixi seçin.', 'warning'); return; }
  if (!job.dest) { toast('Hədəf qovluğu yazın.', 'warning'); $('bmDest').focus(); return; }
  if (job.mode === 'selected' && !ST.selected.size) { toast('Ən azı bir ATM seçin.', 'warning'); return; }
  if (!confirm('Backup başladılsın?\nHədəf: ' + job.dest + '\nRejim: ' + (job.mode === 'all' ? 'Bütün ATM' : ST.selected.size + ' ATM'))) return;
  $('bmStart').disabled = true; $('bmActionMsg').textContent = 'Başladılır...';
  const d = await jpost('/api/backup/start', job);
  $('bmStart').disabled = false;
  if (!d.success) { $('bmActionMsg').textContent = ''; toast(d.error || 'Başlamadı', 'danger'); return; }
  $('bmActionMsg').textContent = '';
  toast('Backup başladı: ' + (d.info ? d.info.files_total + ' fayl' : ''), 'success');
  switchPane('monitor');
  startPoll();
}
async function ctrl(op) { const d = await jpost('/api/backup/' + op, {}); if (!d.success) toast(d.error || 'Alınmadı', 'warning'); }

/* ---------- Status polling ---------- */
function startPoll() { if (pollTimer) return; poll(); pollTimer = setInterval(poll, 1200); }
function stopPoll() { if (pollTimer) { clearInterval(pollTimer); pollTimer = null; } }
async function poll() {
  let d; try { d = await jget('/api/backup/status'); } catch (e) { return; }
  if (!d.success) return;
  const s = d.state; renderMonitor(s);
  if (!s.running && s.finished) { stopPoll(); loadHistory(); }
}
function renderMonitor(s) {
  const pct = s.bytes_total ? Math.min(100, Math.round(s.bytes_done * 100 / s.bytes_total))
            : (s.files_total ? Math.round(s.files_done * 100 / s.files_total) : 0);
  $('bmProgBar').style.width = pct + '%'; $('bmProgPct').textContent = pct + '%';
  $('bmPhase').textContent = s.paused ? 'Pauzada' : (s.running ? 'İşləyir' : (s.status || 'Gözləyir'));
  $('bmCurAtm').textContent = s.current_atm || '—';
  $('bmCurFile').textContent = s.current_file || '—';
  $('bmSpeed').textContent = fmtSpeed(s.speed_bps);
  $('bmTransferred').textContent = fmtSize(s.bytes_done) + ' / ' + fmtSize(s.bytes_total);
  $('bmRemain').textContent = Math.max(0, (s.files_total || 0) - (s.files_done || 0) - (s.files_skipped || 0));
  $('bmEta').textContent = s.paused ? 'Pauzada' : fmtEta(s.eta_sec);
  $('bmWorkers').textContent = s.workers_active;
  $('bmAtmProg').textContent = (s.atm_done || 0) + ' / ' + (s.atm_total || 0);
  $('bmDone').textContent = s.files_done || 0;
  $('bmFailed').textContent = s.failed_atms || 0;
  $('bmLog').textContent = (s.logs || []).join('\n'); $('bmLog').scrollTop = $('bmLog').scrollHeight;
  $('bmPause').classList.toggle('hidden', !s.running || s.paused);
  $('bmResume').classList.toggle('hidden', !s.running || !s.paused);
  $('bmCancel').disabled = !s.running;
}

/* ---------- History ---------- */
async function loadHistory() {
  const body = $('bmHistBody');
  try {
    const d = await jget('/api/backup/history?limit=50');
    const jobs = d.jobs || [];
    if (!jobs.length) { body.innerHTML = '<tr><td colspan="13" style="text-align:center;color:var(--c-text-muted);padding:20px">Hələ backup yoxdur.</td></tr>'; return; }
    body.innerHTML = jobs.map(j => {
      const st = j.status === 'BİTDİ' ? 'ds-badge--success' : (j.status === 'XƏTA' ? 'ds-badge--danger' : 'ds-badge--neutral');
      return '<tr><td>' + esc((j.started_at || '').replace('T', ' ')) + '</td><td>' + esc((j.finished_at || '').replace('T', ' ')) + '</td>'
        + '<td><span class="ds-badge ' + st + '">' + esc(j.status || '') + '</span></td>'
        + '<td>' + esc(j.mode || '') + '</td><td>' + esc(j.date_from || '') + (j.date_to && j.date_to !== j.date_from ? '–' + esc(j.date_to) : '') + '</td>'
        + '<td>' + esc(j.file_types || '') + '</td><td>' + (j.atm_total || 0) + '</td><td>' + (j.files_copied || 0) + '</td>'
        + '<td>' + (j.files_skipped || 0) + '</td><td>' + fmtSize(j.bytes_copied) + '</td>'
        + '<td>' + (j.ok_atms || 0) + '</td><td>' + (j.failed_atms || 0) + '</td><td class="bmEllipsis" style="max-width:220px">' + esc(j.dest || '') + '</td></tr>';
    }).join('');
  } catch (e) { body.innerHTML = '<tr><td colspan="13" style="text-align:center;color:var(--c-danger);padding:20px">Tarixçə alınmadı.</td></tr>'; }
}

/* ---------- Settings ---------- */
function fillSettings(s) {
  $('stWorkers').value = s.workers; $('stRetries').value = s.retries; $('stDepth').value = s.scan_depth;
  $('stDateMode').value = s.date_mode; $('stVerify').value = s.verify;
  $('stIncremental').value = s.incremental ? '1' : '0';
  $('stRegex').value = s.atm_regex;
  $('stImgExt').value = (s.image_ext || []).join(',');
  $('stLogExt').value = (s.log_ext || []).join(',');
  $('stRoots').value = (s.source_roots || []).join('\n');
}
async function saveSettings() {
  const patch = {
    workers: parseInt($('stWorkers').value, 10) || 4,
    retries: parseInt($('stRetries').value, 10) || 0,
    scan_depth: parseInt($('stDepth').value, 10) || 3,
    date_mode: $('stDateMode').value, verify: $('stVerify').value,
    incremental: $('stIncremental').value === '1',
    atm_regex: ($('stRegex').value || '').trim(),
    image_ext: ($('stImgExt').value || '').split(',').map(x => x.trim()).filter(Boolean),
    log_ext: ($('stLogExt').value || '').split(',').map(x => x.trim()).filter(Boolean),
    source_roots: ($('stRoots').value || '').split('\n').map(x => x.trim()).filter(Boolean),
  };
  $('stMsg').textContent = 'Yadda saxlanılır...';
  const d = await jpost('/api/backup/config', patch);
  if (d.success) { $('stMsg').textContent = 'Yadda saxlanıldı ✓'; ST.settings = d.settings; await loadConfig(); }
  else $('stMsg').textContent = 'Xəta: ' + (d.error || '');
}

/* ---------- Import TXT/CSV ---------- */
function importFile(file) {
  const rd = new FileReader();
  rd.onload = () => {
    const ids = String(rd.result || '').toUpperCase().match(/[A-Z0-9._-]{3,64}/g) || [];
    const known = new Set(ST.atms.map(a => a.id));
    let n = 0;
    ids.forEach(id => { if (known.has(id)) { ST.selected.add(id); n++; } });
    document.querySelector('input[name="bmMode"][value="selected"]').checked = true;
    renderAtmList();
    toast(n + ' ATM seçildi (import).', n ? 'success' : 'warning');
  };
  rd.readAsText(file);
}

/* ---------- Panes ---------- */
function switchPane(name) {
  document.querySelectorAll('.bmTab').forEach(b => b.classList.toggle('is-active', b.dataset.pane === name));
  ['config', 'monitor', 'history', 'settings'].forEach(p => {
    const el = $('bmPane' + p.charAt(0).toUpperCase() + p.slice(1));
    if (el) el.classList.toggle('hidden', p !== name);
  });
  if (name === 'history') loadHistory();
}

/* ---------- Init ---------- */
window.backupMgrInit = function () {
  if (!inited) {
    inited = true;
    $('bmDiscover').onclick = discover;
    $('bmDryRun').onclick = dryRun;
    $('bmStart').onclick = startBackup;
    $('bmPause').onclick = () => ctrl('pause');
    $('bmResume').onclick = () => ctrl('resume');
    $('bmCancel').onclick = () => { if (confirm('Backup dayandırılsın?')) ctrl('cancel'); };
    $('bmHistRefresh').onclick = loadHistory;
    $('stSave').onclick = saveSettings;
    $('bmSearch').oninput = renderAtmList;
    $('bmSelAll').onclick = () => { const q = ($('bmSearch').value || '').trim().toUpperCase(); ST.atms.forEach(a => { if (!q || a.id.indexOf(q) >= 0) ST.selected.add(a.id); }); renderAtmList(); };
    $('bmSelNone').onclick = () => { ST.selected.clear(); renderAtmList(); };
    $('bmImport').onchange = e => { if (e.target.files[0]) importFile(e.target.files[0]); e.target.value = ''; };
    document.querySelectorAll('input[name="bmMode"]').forEach(r => r.onchange = updateSelCount);
    document.querySelectorAll('.bmTab').forEach(b => b.onclick = () => switchPane(b.dataset.pane));
    document.querySelectorAll('.bmDateQuick [data-range]').forEach(b => b.onclick = () => {
      const r = b.dataset.range;
      if (r === 'today') { $('bmDateFrom').value = todayStr(0); $('bmDateTo').value = todayStr(0); }
      else { $('bmDateFrom').value = todayStr(parseInt(r, 10) - 1); $('bmDateTo').value = todayStr(0); }
    });
    if (!$('bmDateFrom').value) { $('bmDateFrom').value = todayStr(0); $('bmDateTo').value = todayStr(0); }
  }
  switchPane('config');
  loadConfig().catch(() => {});
  // davam edən iş varsa monitoru canlandır
  jget('/api/backup/status').then(d => { if (d.success && d.state && d.state.running) { switchPane('monitor'); startPoll(); } }).catch(() => {});
};
})();
