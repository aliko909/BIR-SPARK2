/* Cihaz İdarəetmə Sistemi — VIDEOARCHIVE Scan.
   Bütün aktiv ATM-lərdə \\ATM_ID\D$\VIDEOARCHIVE\ATM_ID → şəkli olan son tarix və son şəklin vaxtı.
   Backend: /api/vascan/start|cancel|progress|history|detail|excel */
(function () {
'use strict';
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = id => document.getElementById(id);
const toast = (m, t) => { if (window.DS && DS.toast) DS.toast(m, t || 'info'); };
const can = key => { try { return !window.AtmAuth || typeof AtmAuth.can !== 'function' || AtmAuth.can(key); } catch (e) { return true; } };

const CATS = ['AKTİV', 'GECİKİR', 'PROBLEM', 'ŞƏKİL YOXDUR', 'VIDEOARCHIVE YOXDUR', 'QOŞULMADI', 'VAXT AŞIMI', 'XƏTA'];
const BADGE = { 'AKTİV': 'success', 'GECİKİR': 'warning', 'PROBLEM': 'danger', 'ŞƏKİL YOXDUR': 'danger',
  'VIDEOARCHIVE YOXDUR': 'danger', 'VIDEO YOXDUR': 'danger', 'QOŞULMADI': 'neutral', 'VAXT AŞIMI': 'neutral', 'XƏTA': 'neutral' };
const CAT_ORDER = { 'ŞƏKİL YOXDUR': 0, 'VIDEOARCHIVE YOXDUR': 1, 'XƏTA': 2, 'VAXT AŞIMI': 3 };

const S = {
  inited: false, runId: null, running: false, results: [], since: 0, timer: null,
  filter: 'ALL', query: '', lateDays: 5, polling: false, viewingHistory: false,
};

async function api(url, opts) {
  const r = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), Object.assign({ cache: 'no-store' }, opts || {}));
  let d = null;
  try { d = await r.json(); } catch (e) { /* */ }
  if (!r.ok || !d || d.success === false) throw new Error((d && d.error) || ('HTTP ' + r.status));
  return d;
}

/* ---------- format ---------- */
function fmtDT(iso) {
  if (!iso) return '—';
  const m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?/.exec(iso);
  return m ? `${m[3]}.${m[2]}.${m[1]} ${m[4]}:${m[5]}` : esc(iso);
}
function fmtFolder(f) { return f && /^\d{8}$/.test(f) ? `${f.slice(6, 8)}.${f.slice(4, 6)}.${f.slice(0, 4)}` : (f || '—'); }
function fmtAgo(days) {
  if (days == null) return '—';
  if (days === 0) return 'bu gün';
  if (days === 1) return 'dünən';
  return days + ' gün əvvəl';
}
function fmtDur(sec) {
  sec = Number(sec || 0);
  if (sec < 60) return Math.round(sec) + ' san';
  const m = Math.floor(sec / 60), s = Math.round(sec % 60);
  return m < 60 ? `${m} dəq ${s} san` : `${Math.floor(m / 60)} saat ${m % 60} dəq`;
}
function cmp(a, b) {
  // Server ilə eyni sıra: son şəkil vaxtı (yenisi yuxarıda); gələcək vaxtlılar sonra; şəkli olmayanlar ən sonda
  const ga = a.last_image_at ? (a._future ? 1 : 0) : 2, gb = b.last_image_at ? (b._future ? 1 : 0) : 2;
  if (ga !== gb) return ga - gb;
  if (a.last_image_at !== b.last_image_at) return (b.last_image_at || '') < (a.last_image_at || '') ? -1 : 1;
  const ca = CAT_ORDER[a.category] ?? 4, cb = CAT_ORDER[b.category] ?? 4;
  if (ca !== cb) return ca - cb;
  return String(a.atm_id).localeCompare(String(b.atm_id), undefined, { numeric: true, sensitivity: 'base' });
}
function markFuture(r) {
  // Fayl vaxtı yoxlama vaxtından 1 gündən çox irəlidədirsə (ATM saatı səhv)
  if (r.last_image_at && r.checked_at) {
    const a = Date.parse(r.last_image_at), b = Date.parse(r.checked_at);
    r._future = isFinite(a) && isFinite(b) && a - b > 86400000;
  } else r._future = false;
  return r;
}

/* ---------- render ---------- */
function counts(list) {
  const c = {}; list.forEach(r => { c[r.category] = (c[r.category] || 0) + 1; }); return c;
}
const NOT_VERIFIED = ['QOŞULMADI', 'VAXT AŞIMI', 'XƏTA'];
function media(r) {
  const imgD = Number(r.image_count || 0), imgE = Number(r.video_image_count || 0);
  const vidD = Number(r.video_count || 0), vidE = Number(r.video_video_count || 0);
  return { totImg: imgD + imgE, totVid: vidD + vidE, verified: !NOT_VERIFIED.includes(r.category) };
}
function laterISO(a, b) { if (!a) return b || null; if (!b) return a; return a >= b ? a : b; }
function renderStats(snap) {
  const total = snap ? snap.total : S.results.length;
  const processed = snap ? snap.processed : S.results.length;
  $('vaProcessed').textContent = processed + ' / ' + total;
  let imgYes = 0, imgNo = 0, vidYes = 0, vidNo = 0, failed = 0;
  S.results.forEach(r => {
    const m = media(r);
    if (!m.verified) { failed++; return; }
    if (m.totImg > 0) imgYes++; else imgNo++;
    if (m.totVid > 0) vidYes++; else vidNo++;
  });
  $('vaCntImgYes').textContent = imgYes;
  $('vaCntImgNo').textContent = imgNo;
  $('vaCntVidYes').textContent = vidYes;
  $('vaCntVidNo').textContent = vidNo;
  $('vaCntFailed').textContent = failed;
}
function matchFilter(r, f) {
  if (f === 'ALL') return true;
  if (f === 'IMG_NO') { const m = media(r); return m.verified && m.totImg === 0; }
  if (f === 'VID_NO') { const m = media(r); return m.verified && m.totVid === 0; }
  return r.category === f;
}
function renderChips() {
  const c = counts(S.results);
  let imgNo = 0, vidNo = 0;
  S.results.forEach(r => { const m = media(r); if (m.verified) { if (m.totImg === 0) imgNo++; if (m.totVid === 0) vidNo++; } });
  const items = [['ALL', 'Hamısı', S.results.length]];
  if (imgNo) items.push(['IMG_NO', 'Şəkil yox', imgNo]);
  if (vidNo) items.push(['VID_NO', 'Video yox', vidNo]);
  CATS.filter(k => c[k]).forEach(k => items.push([k, k, c[k]]));
  const valid = new Set(items.map(x => x[0]));
  if (!valid.has(S.filter)) S.filter = 'ALL';
  $('vaChips').innerHTML = items.map(([k, label, n]) =>
    `<button type="button" class="vaChip${S.filter === k ? ' is-active' : ''}" data-k="${esc(k)}">${esc(label)} <b>${n}</b></button>`).join('');
  $('vaChips').querySelectorAll('.vaChip').forEach(b => b.onclick = () => { S.filter = b.dataset.k; renderChips(); renderTable(); });
}
let renderQueued = false;
function renderTable() {
  if (renderQueued) return;
  renderQueued = true;
  requestAnimationFrame(() => {
    renderQueued = false;
    const q = S.query.trim().toLowerCase();
    const rows = S.results.filter(r => matchFilter(r, S.filter) &&
      (!q || [r.atm_id, r.name, r.region].some(v => String(v || '').toLowerCase().includes(q))));
    const tb = $('vaTable');
    if (!rows.length) {
      tb.innerHTML = `<tr><td colspan="12" class="vaEmpty">${S.results.length ? 'Filtrə uyğun ATM yoxdur.' : (S.running ? 'Nəticələr gəldikcə burada görünəcək...' : 'Hələ nəticə yoxdur.')}</td></tr>`;
    } else {
      const yesno = (verified, has) => !verified
        ? '<span class="ds-badge ds-badge--neutral">—</span>'
        : (has ? '<span class="ds-badge ds-badge--success">VAR</span>'
               : '<span class="ds-badge ds-badge--danger">YOXDUR</span>');
      tb.innerHTML = rows.map((r, i) => {
        const m = media(r);
        const note = [r.error, (r.video_error && r.video_error !== r.error) ? ('E$: ' + r.video_error) : '']
          .filter(Boolean).join(' · ');
        const son = laterISO(r.last_image_at, r.video_last_image_at);
        return `<tr class="vaRow vaRow--${BADGE[r.category] || 'neutral'}">
          <td>${i + 1}</td>
          <td><b class="vaAtm">${esc(r.atm_id)}</b></td>
          <td class="vaName" title="${esc(r.name)}">${esc(r.name || '—')}</td>
          <td>${esc(r.region || '—')}</td>
          <td>${yesno(m.verified, m.totImg > 0)}</td>
          <td>${yesno(m.verified, m.totVid > 0)}</td>
          <td>${m.verified ? m.totImg : '—'}</td>
          <td>${m.verified ? m.totVid : '—'}</td>
          <td class="vaMono">${fmtDT(son)}${r._future ? ' <span title="Fayl vaxtı gələcəkdədir — ATM saatı səhv ola bilər">⚠</span>' : ''}</td>
          <td><span class="ds-badge ds-badge--${BADGE[r.category] || 'neutral'}">${esc(r.category)}</span></td>
          <td>${esc(r.password_env || '—')}</td>
          <td class="vaNote" title="${esc(note)}">${esc(note || '')}</td></tr>`;
      }).join('');
    }
    $('vaTableFoot').textContent = rows.length === S.results.length ? `${rows.length} ATM` : `${rows.length} / ${S.results.length} ATM göstərilir`;
  });
}
function renderAll(snap) { renderStats(snap); renderChips(); renderTable(); }

function setRunning(running) {
  S.running = running;
  const mayStart = can('vascan.start');
  $('vaStartBtn').classList.toggle('hidden', running || !mayStart);
  $('vaStopBtn').classList.toggle('hidden', !running || !mayStart);
  $('vaStopBtn').disabled = false;
  $('vaExcelBtn').disabled = !S.runId || running || !S.results.length;
  $('vaExcelBtn').classList.toggle('hidden', !can('vascan.export'));
}

/* ---------- progress ---------- */
function applySnapshot(d) {
  if (d.active_atm_count != null) $('vaAllCount').textContent = '(' + d.active_atm_count + ')';
  if (d.late_days) {
    S.lateDays = d.late_days;
    $('vaRule').textContent = `AKTİV — son şəkil bu gün/dünən · GECİKİR — 2–${d.late_days} gün · PROBLEM — ${d.late_days} gündən çox`;
  }
  if (!d.run_id) return false;
  if (S.runId !== d.run_id || S.viewingHistory) {
    if (!d.running && S.viewingHistory) return false; // tarixçədən baxılan scan-i canlı vəziyyət əvəz etməsin
    S.runId = d.run_id; S.results = []; S.since = 0; S.viewingHistory = false;
  }
  (d.new_results || []).forEach(r => S.results.push(markFuture(r)));
  S.since = d.next_index || S.since;
  S.results.sort(cmp);
  const pct = Math.max(0, Math.min(100, Number(d.percent || 0)));
  $('vaFill').style.width = pct + '%';
  $('vaPercent').textContent = pct.toFixed(1).replace('.0', '') + '%';
  $('vaRunBadge').textContent = 'Scan #' + d.run_id;
  $('vaCurrent').textContent = (d.current_atms || []).slice(0, 6).join(', ') + ((d.current_atms || []).length > 6 ? ' …' : '') || '—';
  const logBox = $('vaLog');
  const stick = logBox.scrollTop + logBox.clientHeight >= logBox.scrollHeight - 20;
  logBox.textContent = (d.logs || []).join('\n') || '—';
  if (stick) logBox.scrollTop = logBox.scrollHeight;
  if (d.running) {
    $('vaState').textContent = d.cancel_requested ? 'Dayandırılır...' : 'Scan gedir...';
    $('vaMeta').textContent = `${d.processed} / ${d.total} ATM · paralel ${d.workers} · başlama ${fmtDT(d.started_at)}`;
  } else {
    $('vaState').textContent = d.error ? 'Scan xəta ilə bitdi' : d.cancel_requested ? 'Scan dayandırıldı' : 'Scan tamamlandı';
    $('vaMeta').textContent = d.error ? d.error : `${d.processed} / ${d.total} ATM yoxlanıldı · ${fmtDT(d.started_at)} → ${fmtDT(d.finished_at)}`;
  }
  setRunning(!!d.running);
  renderAll(d);
  return !!d.running;
}

async function poll() {
  if (S.polling) return;
  S.polling = true;
  try {
    const d = await api('/api/vascan/progress?since=' + (S.viewingHistory ? 0 : S.since));
    const running = applySnapshot(d);
    if (!running && S.timer) {
      clearInterval(S.timer); S.timer = null;
      vaScanLoadHistory();
      if (!S.viewingHistory && S.results.length) toast('VIDEOARCHIVE Scan bitdi — Excel hesabatını yükləyə bilərsən.', 'success');
    }
    if (running && !S.timer) S.timer = setInterval(poll, 1500);
    return d;
  } catch (e) {
    /* müvəqqəti şəbəkə xətası — növbəti tick */
  } finally {
    S.polling = false;
  }
}

/* ---------- actions ---------- */
function parseList(text) {
  const seen = new Set(), out = [];
  String(text || '').split(/[\s,;]+/).forEach(x => {
    const a = x.trim().toUpperCase();
    if (/^[A-Z0-9._-]{1,64}$/.test(a) && !seen.has(a)) { seen.add(a); out.push(a); }
  });
  return out;
}
async function start() {
  const scope = (document.querySelector('input[name="vaScope"]:checked') || {}).value;
  let ids = null;
  if (scope === 'list') {
    ids = parseList($('vaList').value);
    if (!ids.length) { toast('Siyahıya ən azı bir ATM ID yaz.', 'warning'); $('vaList').focus(); return; }
  }
  const btn = $('vaStartBtn'); btn.disabled = true;
  try {
    const d = await api('/api/vascan/start', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(ids ? { atm_ids: ids } : {}) });
    S.runId = d.run_id; S.results = []; S.since = 0; S.viewingHistory = false; S.filter = 'ALL';
    renderAll(null);
    toast('Scan #' + d.run_id + ' başladı.', 'success');
    await poll();
    if (!S.timer) S.timer = setInterval(poll, 1500);
  } catch (e) {
    toast('Scan başlamadı: ' + e.message, 'danger');
  } finally { btn.disabled = false; }
}
async function stop() {
  $('vaStopBtn').disabled = true;
  try { await api('/api/vascan/cancel', { method: 'POST' }); toast('Dayandırılır — işləyən ATM-lər bitən kimi scan dayanacaq.', 'info'); }
  catch (e) { toast(e.message, 'warning'); $('vaStopBtn').disabled = false; }
}
async function excel(runId) {
  if (!can('vascan.export')) { toast('Excel yükləmək üçün icazən yoxdur.', 'warning'); return; }
  runId = runId || S.runId;
  if (!runId) { toast('Əvvəl scan et və ya tarixçədən scan seç.', 'warning'); return; }
  try {
    const r = await fetch('/api/vascan/excel?id=' + encodeURIComponent(runId) + '&t=' + Date.now(), { cache: 'no-store' });
    const type = r.headers.get('Content-Type') || '';
    if (!r.ok || type.includes('json')) {
      let msg = 'HTTP ' + r.status; try { msg = (await r.json()).error || msg; } catch (e) { /* */ }
      throw new Error(msg);
    }
    const blob = await r.blob();
    const cd = r.headers.get('Content-Disposition') || '';
    const m = /filename="?([^";]+)"?/i.exec(cd);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = m ? m[1] : `VIDEOARCHIVE_Scan_${runId}.xlsx`;
    document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
    toast('Excel hazırdır: ' + a.download, 'success');
  } catch (e) { toast('Excel yüklənmədi: ' + e.message, 'danger'); }
}
async function openRun(runId) {
  try {
    const d = await api('/api/vascan/detail?id=' + encodeURIComponent(runId));
    S.runId = d.run.id; S.viewingHistory = true; S.filter = 'ALL';
    S.results = (d.results || []).map(markFuture).sort(cmp);
    const run = d.run;
    const st = { COMPLETED: 'Scan tamamlandı', CANCELLED: 'Scan dayandırılıb', INTERRUPTED: 'Scan yarımçıq qalıb (server dayandı)', FAILED: 'Scan xəta ilə bitdi', RUNNING: 'Scan gedir...' }[run.status] || run.status;
    $('vaState').textContent = st + ' · tarixçə';
    $('vaMeta').textContent = `${run.checked_count} / ${run.selected_count} ATM · ${fmtDT(run.started_at)} → ${fmtDT(run.finished_at)}`;
    $('vaRunBadge').textContent = 'Scan #' + run.id;
    const pct = run.selected_count ? Math.round(run.checked_count * 1000 / run.selected_count) / 10 : 0;
    $('vaFill').style.width = pct + '%'; $('vaPercent').textContent = pct + '%';
    $('vaCurrent').textContent = '—';
    renderAll({ total: run.selected_count, processed: run.checked_count });
    setRunning(S.running);
    $('vaExcelBtn').disabled = !S.results.length;
  } catch (e) { toast('Scan açılmadı: ' + e.message, 'danger'); }
}
async function loadHistory() {
  const tb = $('vaHistory');
  try {
    const d = await api('/api/vascan/history?limit=50');
    const runs = d.runs || [];
    if (!runs.length) { tb.innerHTML = '<tr><td colspan="11" class="vaEmpty">Hələ scan edilməyib.</td></tr>'; return runs; }
    const stAz = { COMPLETED: ['TAMAMLANDI', 'success'], CANCELLED: ['DAYANDIRILDI', 'warning'], RUNNING: ['İŞLƏYİR', 'info'], INTERRUPTED: ['YARIMÇIQ', 'warning'], FAILED: ['XƏTA', 'danger'] };
    tb.innerHTML = runs.map(r => {
      const [t, c] = stAz[r.status] || [r.status, 'neutral'];
      return `<tr class="${r.id === S.runId ? 'selected' : ''}">
        <td><b>#${r.id}</b></td><td>${fmtDT(r.started_at)}</td>
        <td><span class="ds-badge ds-badge--${c}">${esc(t)}</span></td>
        <td>${r.checked_count} / ${r.selected_count}</td><td>${r.active_count}</td><td>${r.late_count}</td><td>${r.problem_count}</td>
        <td>${r.nophoto_count}</td><td>${r.failed_count}</td><td>${r.status === 'RUNNING' ? '—' : esc(fmtDur(r.duration_seconds))}</td>
        <td class="vaHistActs"><button type="button" class="btnGray ds-btn--sm" data-open="${r.id}">Bax</button>
          ${can('vascan.export') ? `<button type="button" class="btnGreen ds-btn--sm" data-xl="${r.id}" ${r.status === 'RUNNING' || !r.checked_count ? 'disabled' : ''}>Excel</button>` : ''}</td></tr>`;
    }).join('');
    tb.querySelectorAll('[data-open]').forEach(b => b.onclick = () => openRun(Number(b.dataset.open)));
    tb.querySelectorAll('[data-xl]').forEach(b => b.onclick = () => excel(Number(b.dataset.xl)));
    return runs;
  } catch (e) {
    tb.innerHTML = `<tr><td colspan="11" class="vaEmpty">Tarixçə alınmadı: ${esc(e.message)}</td></tr>`;
    return [];
  }
}

async function init() {
  if (!S.inited) {
    S.inited = true;
    document.querySelectorAll('input[name="vaScope"]').forEach(r => r.onchange = () => {
      $('vaList').classList.toggle('hidden', r.value !== 'list' || !r.checked);
      if (r.value === 'list' && r.checked) $('vaList').focus();
    });
  }
  const d = await poll();
  const runs = await loadHistory();
  // Server yenidən başladılıbsa canlı vəziyyət boş olur — son saxlanmış scan-i göstər
  if (d && !d.run_id && !S.results.length && runs.length) {
    const last = runs.find(r => r.checked_count > 0);
    if (last) await openRun(last.id);
  }
}

window.vaScanInit = init;
window.vaScanStart = start;
window.vaScanStop = stop;
window.vaScanExcel = () => excel();
window.vaScanLoadHistory = loadHistory;
})();
