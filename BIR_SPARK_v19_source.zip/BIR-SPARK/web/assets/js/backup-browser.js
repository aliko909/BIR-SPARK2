/* Cihaz İdarəetmə Sistemi — Backup Monitor alt-modulları: Jurnal + Video-şəkil.
   ATM-ə qoşul (arxiv session) → DB-dəki diskləri göstər → diskə klik → içini gəz →
   fayla klik: önizləmə + yükləmə. Yalnız baxış/yükləmə, dəyişiklik yoxdur. */
(function () {
'use strict';
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const TEXT_EXT = ['.txt', '.jrn', '.log', '.csv'];
const IMG_EXT = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'];
const VID_EXT = ['.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm'];

function createBrowser(opts) {
  // opts: {root: elementId, journalChip, kind, mode:'atm'|'server', endpoint, forceDisks:[], onCopyFolder}
  const host = document.getElementById(opts.root);
  if (!host) return null;
  const EP = opts.endpoint || 'explorer';            // 'explorer' | 'srvexp'
  const SERVER = opts.mode === 'server';
  const mediaUrl = (root, rel) => '/api/' + EP + '/media?root=' + encodeURIComponent(root) + '&rel=' + encodeURIComponent(rel) + '&t=' + Date.now();
  const S = { atm: '', connected: false, root: '', rel: '', entries: [], polling: null };

  host.innerHTML = `
    <div class="bfConnect"${SERVER ? ' style="display:none"' : ''}>
      <span class="ds-input-icon"><svg class="ds-icon" aria-hidden="true"><use href="#i-search"/></svg></span>
      <input class="bfAtm" placeholder="ATM ID — məsələn A0100051" autocomplete="off">
      <button class="ds-btn ds-btn--primary bfConnectBtn" type="button"><svg class="ds-icon" aria-hidden="true"><use href="#i-plug-zap"/></svg>Qoşul</button>
      <span class="bfConnState ds-badge ds-badge--neutral">Qoşulmayıb</span>
    </div>
    <div class="bfLog" style="display:none"></div>
    <div class="bfWorkspace" style="display:none">
      <div class="bfDisks" aria-label="Disklər"></div>
      <div class="bfGrid">
        <div class="bfPanel">
          <div class="bfPanelHead"><b class="bfPath">—</b>
            <span>
              <button class="ds-btn ds-btn--secondary ds-btn--sm bfBack" type="button">← Geri</button>
              <button class="ds-btn ds-btn--secondary ds-btn--sm bfReload" type="button"><svg class="ds-icon" aria-hidden="true"><use href="#i-refresh-cw"/></svg></button>
            </span>
          </div>
          <input class="bfSearch" placeholder="Qovluq/fayl axtar..." style="width:100%;margin:8px 0;padding:7px 9px;border:1px solid var(--c-border,#ccc);border-radius:8px">
          <div class="bfCount ds-caption">—</div>
          <div class="bfList"></div>
        </div>
        <div class="bfPanel">
          <div class="bfPanelHead"><b class="bfPvTitle">Önizləmə</b></div>
          <div class="bfPvMeta ds-caption">Fayla kliklə.</div>
          <div class="bfPreview"></div>
        </div>
      </div>
    </div>`;

  const $ = sel => host.querySelector(sel);
  const atmInput = $('.bfAtm'), connBtn = $('.bfConnectBtn'), connState = $('.bfConnState'),
    logBox = $('.bfLog'), workspace = $('.bfWorkspace'), disksBox = $('.bfDisks'),
    pathEl = $('.bfPath'), listEl = $('.bfList'), countEl = $('.bfCount'), searchEl = $('.bfSearch'),
    backBtn = $('.bfBack'), reloadBtn = $('.bfReload'),
    pvTitle = $('.bfPvTitle'), pvMeta = $('.bfPvMeta'), pvBox = $('.bfPreview');

  function setState(txt, cls) { connState.textContent = txt; connState.className = 'bfConnState ds-badge ' + (cls || 'ds-badge--neutral'); }

  async function connect() {
    const atm = (atmInput.value || '').trim().toUpperCase();
    if (!/^[A-Z0-9._-]{1,64}$/.test(atm)) { if (window.DS) DS.toast('ATM ID düzgün deyil.', 'warning'); return; }
    stopPoll();
    S.connected = false; workspace.style.display = 'none';
    connBtn.disabled = true; connBtn.textContent = 'Qoşulur...';
    logBox.style.display = 'block'; logBox.textContent = atm + ' — qoşulma başladılır...';
    setState(atm + ' — yoxlanılır', 'ds-badge--info');
    try {
      const r = await fetch('/api/archive/start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ atm }) });
      const d = await r.json();
      if (!r.ok || !d.success) throw new Error(d.error || 'Bağlantı başlamadı');
      S.atm = atm;
      S.polling = setInterval(poll, 1200); poll();
    } catch (e) {
      connBtn.disabled = false; connBtn.textContent = 'Qoşul';
      setState('alınmadı', 'ds-badge--danger'); logBox.textContent = 'Xəta: ' + (e.message || e);
    }
  }
  function stopPoll() { if (S.polling) { clearInterval(S.polling); S.polling = null; } }
  async function poll() {
    try {
      const r = await fetch('/api/archive/progress?t=' + Date.now(), { cache: 'no-store' });
      const d = await r.json();
      logBox.textContent = (d.logs || []).join('\n') || 'gözlənilir...';
      logBox.scrollTop = logBox.scrollHeight;
      if (d.finished) {
        stopPoll(); connBtn.disabled = false; connBtn.textContent = 'Qoşul';
        if (!d.success) { setState('alınmadı', 'ds-badge--danger'); return; }
        S.connected = true;
        setState(d.target + ' — qoşuldu', 'ds-badge--success');
        workspace.style.display = 'block';
        await loadDisks();
      }
    } catch (e) { /* növbəti tick */ }
  }

  async function loadDisks() {
    disksBox.innerHTML = '<span class="ds-caption">Disklər yüklənir...</span>';
    const chips = [];
    if (SERVER) {
      // Server disklərini srvexp-dən al (D / H / M / F ...)
      let sd = [];
      try { const d = await (await fetch('/api/srvexp/disks?t=' + Date.now(), { cache: 'no-store' })).json(); sd = d.disks || []; } catch (e) {}
      sd.forEach(x => chips.push({ root: x.root, label: x.label, icon: 'i-hard-drive' }));
    } else if (opts.forceDisks && opts.forceDisks.length) {
      // Məcburi disklər (məs. ATM köçürmə üçün C$ və D$)
      opts.forceDisks.forEach(L => chips.push({ root: 'disk:' + L, label: L + '$ diski', icon: 'i-hard-drive' }));
    } else {
      let disks = [];
      try { const d = await (await fetch('/api/disks?t=' + Date.now(), { cache: 'no-store' })).json(); disks = d.disks || []; } catch (e) {}
      if (opts.journalChip) chips.push({ root: 'journal', label: 'C$ \\ JOURNAL', icon: 'i-file-text' });
      disks.forEach(x => chips.push({ root: 'disk:' + x.letter, label: x.letter + '$ diski', icon: 'i-hard-drive' }));
      if (opts.kind === 'media' && !disks.some(x => String(x.letter || '').toUpperCase() === 'E')) {
        chips.push({ root: 'disk:E', label: 'E$ diski', icon: 'i-hard-drive' });
      }
    }
    disksBox.innerHTML = chips.map(c =>
      `<button class="bfDiskChip" data-root="${esc(c.root)}"><svg class="ds-icon" aria-hidden="true"><use href="#${c.icon}"/></svg>${esc(c.label)}</button>`).join('')
      || '<span class="ds-caption">DB-də disk tapılmadı.</span>';
    disksBox.querySelectorAll('.bfDiskChip').forEach(b => b.onclick = () => {
      disksBox.querySelectorAll('.bfDiskChip').forEach(x => x.classList.remove('is-active'));
      b.classList.add('is-active');
      openDir(b.dataset.root, '');
    });
    // ilk diski avtomatik aç
    const first = disksBox.querySelector('.bfDiskChip'); if (first) first.click();
  }

  async function openDir(root, rel) {
    S.root = root; S.rel = rel;
    pathEl.textContent = 'Oxunur...'; listEl.innerHTML = '<div class="bfNote">Yüklənir...</div>';
    backBtn.disabled = !rel;
    try {
      const u = '/api/' + EP + '/list?root=' + encodeURIComponent(root) + '&rel=' + encodeURIComponent(rel) + '&t=' + Date.now();
      const d = await (await fetch(u, { cache: 'no-store' })).json();
      if (!d.success) throw new Error(d.error || 'Qovluq açılmadı');
      S.entries = d.entries || [];
      pathEl.textContent = d.path;
      countEl.textContent = d.folder_count + ' qovluq · ' + d.file_count + ' fayl' + (d.truncated ? ' · ilk 10000' : '');
      renderList();
    } catch (e) { pathEl.textContent = '—'; listEl.innerHTML = '<div class="bfNote">Xəta: ' + esc(e.message || e) + '</div>'; }
  }

  function kindOf(ext) {
    ext = (ext || '').toLowerCase();
    if (TEXT_EXT.includes(ext)) return 'text';
    if (IMG_EXT.includes(ext)) return 'img';
    if (VID_EXT.includes(ext)) return 'vid';
    return 'other';
  }
  function renderList() {
    const q = (searchEl.value || '').trim().toLowerCase();
    let items = S.entries.filter(e => !q || e.name.toLowerCase().includes(q));
    // Jurnal modulunda fayllar üçün mətn/jrn öncə; video modulunda şəkil/video öncə (qovluqlar həmişə görünür)
    const rows = items.map(e => {
      if (e.kind === 'folder') {
        const cp = opts.onCopyFolder ? `<button class="bfCopy ds-btn ds-btn--secondary ds-btn--sm" title="Bu qovluğu köçür" data-rel="${esc(e.rel)}" data-name="${esc(e.name)}"><svg class="ds-icon" aria-hidden="true"><use href="#i-arrow-up-right"/></svg>Köçür</button>` : '';
        return `<div class="bfRow bfFolder" data-rel="${esc(e.rel)}"><svg class="ds-icon" aria-hidden="true"><use href="#i-folder-open"/></svg><span class="bfName">${esc(e.name)}</span><span class="bfSize">${esc(e.size_display)}</span>${cp}</div>`;
      }
      const k = kindOf(e.ext), canDl = e.previewable;
      const dl = canDl ? `<button class="bfDl" title="Yüklə" data-rel="${esc(e.rel)}" data-name="${esc(e.name)}" data-ext="${esc(e.ext)}"><svg class="ds-icon" aria-hidden="true"><use href="#i-download"/></svg></button>` : '<span class="ds-caption" title="Web-də dəstəklənmir">—</span>';
      return `<div class="bfRow bfFile" data-rel="${esc(e.rel)}" data-name="${esc(e.name)}" data-ext="${esc(e.ext)}" data-kind="${k}"><svg class="ds-icon" aria-hidden="true"><use href="#${k === 'img' ? 'i-image' : k === 'vid' ? 'i-film' : 'i-file-text'}"/></svg><span class="bfName">${esc(e.name)}</span><span class="bfSize">${esc(e.size_display)}</span>${dl}</div>`;
    });
    listEl.innerHTML = rows.join('') || '<div class="bfNote">Bu qovluqda uyğun element yoxdur.</div>';
    listEl.querySelectorAll('.bfFolder').forEach(r => r.onclick = e => { if (e.target.closest('.bfCopy')) return; openDir(S.root, r.dataset.rel); });
    listEl.querySelectorAll('.bfFile').forEach(r => r.onclick = e => { if (e.target.closest('.bfDl')) return; preview(r.dataset); });
    listEl.querySelectorAll('.bfDl').forEach(b => b.onclick = e => { e.stopPropagation(); download(b.dataset); });
    if (opts.onCopyFolder) listEl.querySelectorAll('.bfCopy').forEach(b => b.onclick = e => { e.stopPropagation(); opts.onCopyFolder(S.root, b.dataset.rel, b.dataset.name); });
  }

  async function preview(d) {
    pvTitle.textContent = d.name; pvMeta.textContent = (S.root === 'journal' ? 'C$\\JOURNAL' : S.root) + ' · ' + d.ext;
    pvBox.innerHTML = '<div class="bfNote">Açılır...</div>';
    const k = d.kind;
    try {
      if (k === 'text') {
        const u = '/api/' + EP + '/text?root=' + encodeURIComponent(S.root) + '&rel=' + encodeURIComponent(d.rel) + '&t=' + Date.now();
        const r = await (await fetch(u, { cache: 'no-store' })).json();
        if (!r.success) throw new Error(r.error);
        pvBox.innerHTML = '<pre class="bfTextView">' + esc(r.text || '(boş)') + '</pre>' + (r.truncated ? '<div class="ds-caption">· ilk 1 MB göstərilir</div>' : '');
      } else if (k === 'img') {
        pvBox.innerHTML = '<img class="bfImg" src="' + mediaUrl(S.root, d.rel) + '" alt="">';
      } else if (k === 'vid') {
        const ext = (d.ext || '').toLowerCase();
        const native = ['.mp4', '.m4v', '.webm', '.ogg', '.ogv'].includes(ext);
        const vurl = native ? mediaUrl(S.root, d.rel)
          : '/api/' + EP + '/transcode?root=' + encodeURIComponent(S.root) + '&rel=' + encodeURIComponent(d.rel) + '&t=' + Date.now();
        pvBox.innerHTML = (native ? '' : '<div class="bfNote">AVI/WMV serverdə MP4-ə çevrilir (ffmpeg) — başlaması bir neçə saniyə çəkə bilər.</div>')
          + '<video class="bfVid" src="' + vurl + '" controls></video>';
      } else {
        pvBox.innerHTML = '<div class="bfNote">Bu fayl web-də önizlənmir. Yükləmə düyməsini işlət (varsa).</div>';
      }
    } catch (e) { pvBox.innerHTML = '<div class="bfNote">Xəta: ' + esc(e.message || e) + '</div>'; }
  }

  async function download(d) {
    const ext = (d.ext || '').toLowerCase();
    try {
      if (TEXT_EXT.includes(ext)) {
        const u = '/api/' + EP + '/text?root=' + encodeURIComponent(S.root) + '&rel=' + encodeURIComponent(d.rel) + '&t=' + Date.now();
        const r = await (await fetch(u, { cache: 'no-store' })).json();
        if (!r.success) throw new Error(r.error);
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([r.text || ''], { type: 'text/plain;charset=utf-8;' }));
        a.download = d.name; document.body.appendChild(a); a.click(); URL.revokeObjectURL(a.href); a.remove();
      } else {
        const a = document.createElement('a');
        a.href = mediaUrl(S.root, d.rel); a.download = d.name;
        document.body.appendChild(a); a.click(); a.remove();
      }
      if (window.DS) DS.toast(d.name + ' yüklənir...', 'success');
    } catch (e) { if (window.DS) DS.toast('Yüklənmədi: ' + (e.message || e), 'danger'); }
  }

  connBtn.onclick = connect;
  atmInput.addEventListener('keydown', e => { if (e.key === 'Enter') connect(); });
  backBtn.onclick = () => { const p = S.rel.split(/[\\/]/).filter(Boolean); p.pop(); openDir(S.root, p.join('\\')); };
  reloadBtn.onclick = () => openDir(S.root, S.rel);
  searchEl.oninput = renderList;

  if (SERVER) {
    // Server rejimi: qoşulma lazım deyil — disklər dərhal yüklənir
    S.connected = true; workspace.style.display = 'block';
    loadDisks();
  }
  return {
    focus: () => (SERVER ? null : (atmInput && atmInput.focus())),
    refresh: () => { if (SERVER) loadDisks(); },
    atm: () => S.atm,
    connected: () => S.connected,
  };
}

window.createBrowser = createBrowser;   // ana səhifə ATM drawer-i də istifadə edir
let jrInst = null, vsInst = null, srvInst = null, acInst = null;
window.jurnalInit = function () { if (!jrInst) jrInst = createBrowser({ root: 'jurnalRoot', journalChip: true, kind: 'journal' }); if (jrInst) jrInst.focus(); };
window.videosekilInit = function () { if (!vsInst) vsInst = createBrowser({ root: 'videosekilRoot', journalChip: false, kind: 'media' }); if (vsInst) vsInst.focus(); };

/* ---- Server diskləri: sxematik həcm diaqramı (donut + bar) ---- */
function srvFmtSize(bytes) {
  if (bytes == null || isNaN(bytes)) return '—';
  const gb = bytes / (1024 * 1024 * 1024);
  if (gb >= 1024) return (gb / 1024).toFixed(2) + ' TB';
  if (gb >= 100) return Math.round(gb) + ' GB';
  if (gb >= 10) return gb.toFixed(1) + ' GB';
  if (gb >= 1) return gb.toFixed(2) + ' GB';
  return Math.round(bytes / (1024 * 1024)) + ' MB';
}
function srvDiskLevel(pct) { return pct >= 90 ? 'danger' : pct >= 70 ? 'warn' : 'ok'; }
function srvDiskStateLabel(lvl) { return lvl === 'danger' ? 'Kritik' : lvl === 'warn' ? 'Dolur' : 'Normal'; }
let srvDiskBusy = false;
async function srvRenderDiskCharts() {
  const host = document.getElementById('serverDiskCharts');
  if (!host || srvDiskBusy) return;
  srvDiskBusy = true;
  host.innerHTML = '<div class="srvDiskLoading"><span class="ds-spinner"></span> Disklər oxunur...</div>';
  const R = 42, C = 2 * Math.PI * R;
  try {
    const r = await fetch('/api/srvexp/usage?t=' + Date.now(), { cache: 'no-store' });
    const d = await r.json();
    if (!d || !d.success || !Array.isArray(d.disks)) throw new Error((d && d.error) || 'Cavab alınmadı');
    const ipEl = document.getElementById('serverIpLabel');
    if (ipEl && d.server) ipEl.textContent = d.server;
    host.innerHTML = d.disks.map(dk => {
      const letter = esc(dk.letter || '?');
      if (!dk.ok) {
        return '<div class="srvDiskCard">'
          + '<div class="srvDiskCardTop"><span class="srvDiskLetter">' + letter + '$</span>'
          + '<span class="srvDiskName">' + esc(dk.label || '') + '</span>'
          + '<span class="srvDiskState off">Əlçatmaz</span></div>'
          + '<div class="srvDiskErr">' + esc(dk.error || 'Disk oxunmadı') + '</div></div>';
      }
      const pct = Math.max(0, Math.min(100, Math.round(dk.used_percent || 0)));
      const lvl = srvDiskLevel(pct);
      const off = (C * (1 - pct / 100)).toFixed(1);
      return '<div class="srvDiskCard">'
        + '<div class="srvDiskCardTop"><span class="srvDiskLetter">' + letter + '$</span>'
        + '<span class="srvDiskName">' + esc(dk.label || '') + '</span>'
        + '<span class="srvDiskState ' + lvl + '">' + srvDiskStateLabel(lvl) + '</span></div>'
        + '<div class="srvDonut"><svg width="132" height="132" viewBox="0 0 110 110">'
        + '<circle class="srvDonutTrack" cx="55" cy="55" r="' + R + '"/>'
        + '<circle class="srvDonutArc ' + lvl + '" cx="55" cy="55" r="' + R + '" stroke-dasharray="' + C.toFixed(1) + '" stroke-dashoffset="' + off + '"/>'
        + '</svg><div class="srvDonutMid"><span class="srvDonutPct">' + pct + '%</span><span class="srvDonutSub">dolu</span></div></div>'
        + '<div class="srvDiskBar"><i class="' + lvl + '" style="width:' + pct + '%"></i></div>'
        + '<div class="srvDiskKv">'
        + '<div><span>Ümumi</span><b>' + srvFmtSize(dk.total_bytes) + '</b></div>'
        + '<div><span>İstifadə</span><b>' + srvFmtSize(dk.used_bytes) + '</b></div>'
        + '<div><span>Boş</span><b class="free">' + srvFmtSize(dk.free_bytes) + '</b></div>'
        + '</div></div>';
    }).join('') || '<div class="srvDiskLoading">Disk tapılmadı.</div>';
  } catch (e) {
    host.innerHTML = '<div class="srvDiskErr" style="grid-column:1/-1">Disk məlumatı alınmadı: ' + esc(e.message || e) + '</div>';
  } finally {
    srvDiskBusy = false;
  }
}

/* ---- Server disk gəzgini (172.21.12.77 — D/H/M/F) ---- */
window.serverInit = function () {
  if (!srvInst) srvInst = createBrowser({ root: 'serverRoot', mode: 'server', endpoint: 'srvexp', kind: 'media' });
  else srvInst.refresh();
  srvRenderDiskCharts();
  const rb = document.getElementById('srvDiskRefresh');
  if (rb) rb.onclick = () => srvRenderDiskCharts();
};

/* ---- ATM Fayl Köçür (C$/D$ qovluğu → təyinata) ---- */
window.atmCopyInit = function () {
  const T = s => (window.DS && DS.toast ? DS.toast(s[0], s[1] || 'info') : null);
  if (!acInst) {
    acInst = createBrowser({
      root: 'atmCopyRoot', forceDisks: ['C', 'D'], kind: 'media',
      onCopyFolder: (root, rel, name) => {
        if (!acInst.connected()) { T(['Əvvəl ATM-ə qoşul.', 'warning']); return; }
        const dest = (document.getElementById('acDest').value || '').trim();
        if (!dest) { T(['Əvvəl təyinat yolunu yaz.', 'warning']); document.getElementById('acDest').focus(); return; }
        const letter = String(root).split(':')[1] || '';
        const atm = acInst.atm();
        if (!confirm(`${atm} → ${letter}$\\${rel}\nqovluğu bura köçürülsün?\n${dest}\\${name}`)) return;
        fetch('/api/atmcopy/start', { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ atm, disk: letter, source_rel: rel, dest }) })
          .then(r => r.json()).then(d => {
            if (!d.success) { T(['Başlamadı: ' + (d.error || ''), 'danger']); return; }
            T(['Köçürmə başladı...', 'success']); acPoll();
          }).catch(e => T(['Xəta: ' + e.message, 'danger']));
      }
    });
  }
};
let acTimer = null;
function acPoll() {
  const box = document.getElementById('acProgress'); if (!box) return;
  const tick = () => fetch('/api/atmcopy/progress?t=' + Date.now(), { cache: 'no-store' }).then(r => r.json()).then(d => {
    const fmt = n => { n = Number(n || 0); const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0; while (n >= 1024 && i < 4) { n /= 1024; i++; } return (i ? n.toFixed(1) : n) + ' ' + u[i]; };
    box.style.display = 'block';
    box.innerHTML = `<b>${esc(d.status || '')}</b> · ${esc(d.atm || '')} · ${d.files || 0} fayl · ${fmt(d.bytes)}`
      + (d.target_path ? `<div class="ds-caption">→ ${esc(d.target_path)}</div>` : '')
      + (d.error ? `<div class="ds-caption" style="color:var(--c-danger)">${esc(d.error)}</div>` : '')
      + ((d.logs && d.logs.length) ? `<div class="ds-caption">${esc(d.logs[d.logs.length - 1])}</div>` : '');
    if (d.running) { if (!acTimer) acTimer = setInterval(tick, 1200); }
    else { if (acTimer) { clearInterval(acTimer); acTimer = null; }
      if (d.finished && d.status === 'KÖÇÜRÜLDÜ' && window.DS) DS.toast('Köçürüldü: ' + (d.files || 0) + ' fayl', 'success'); }
  }).catch(() => {});
  tick();
}
})();
