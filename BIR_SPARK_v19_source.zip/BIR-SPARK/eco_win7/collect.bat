@echo off
REM ATM WEB - collect.bat  (ATM-in ozunde isleyir)
REM ===> Bu collector WINDOWS 7 ucundur (eco_win7)
REM Server bunu PsExec ile uzaqdan cagirir. Yaninda collect.ps1 olmalidir.
REM Netice: eyni qovluqda atminfo.json
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0collect.ps1"
exit /b %errorlevel%
