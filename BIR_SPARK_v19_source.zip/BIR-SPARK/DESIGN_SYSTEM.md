# ATM WEB — Design System

Bir tətbiq = bir dizayn sistemi. Səhifəyə xas tema, rəng və ya yeni stil yaradılmır.

## Fayllar (yüklənmə sırası `web/home.html`-də)
| Fayl | Rolu |
|---|---|
| `web/assets/ds/tokens.css` | **Tək mənbə**: rəng, tipoqrafiya, spacing, ölçü, radius, kölgə, breakpoint, motion, z-index |
| `web/assets/css/app.css` | Modul layout-ları. Bütün dəyərlər tokenlərə köçürülüb (1354 əvəzləmə) |
| `web/assets/ds/components.css` | Komponentlər + köhnə siniflərin vahid standarta gətirilməsi |
| `web/assets/ds/icons.js` | Offline SVG ikon dəsti (Lucide, ISC): `<svg class="ds-icon"><use href="#i-house"/></svg>` və ya `DS.icon("house")` |
| `web/assets/ds/ds.js` | `DS.toast()`, `alert()` → toast, **AppTable** (avtomatik cədvəl filtri) |

## Tokenlər (qısa)
- Rəng: `--c-bg`, `--c-surface`, `--c-surface-inset`, `--c-border`, `--c-text-primary/secondary/muted/disabled`,
  `--c-primary(-hover/-active/-light/-subtle)`, `--c-success|warning|danger|info` (+ `-bg`, `-border`, `-solid`).
- Tipoqrafiya: `--fs-2xs(10) xs(11) sm(12) md(13) base(14) lg(16) xl(18) 2xl(22) 3xl(28) 4xl(36) 5xl(44)`, `--fw-*`, `--lh-*`.
- Spacing: `--sp-2 … --sp-64` (4px şkala), aliaslar `--space-xs … --space-3xl`.
- Radius: `--radius-xs(4) sm(7) md(10) lg(15) xl(20) full`.
- Kölgə: `--shadow-xs/sm/md/lg`, `--shadow-focus`.
- Breakpoint: 1200 / 1024 / 760 px. Motion: `--dur-fast/base/slow`. Z-index: `--z-sticky … --z-tooltip`.

## Komponentlər
Düymə `ds-btn` (+`--secondary --tertiary --success --danger --warning --sm --lg --icon`, `.is-loading`) ·
Input/select/textarea (vahid hündürlük, focus, `aria-invalid` xəta) · `ds-switch` · Form: `ds-form ds-field ds-label ds-help ds-field-error ds-form-actions` ·
`ds-card`, `ds-inset`, `ds-log` · Səhifə başlığı `ds-hero` · `ds-toolbar` · KPI `ds-stats > ds-stat(--success/--danger/--warning/--accent)` ·
Badge `ds-badge(--success/--danger/--warning/--neutral/--dot)` · Modal `ds-modal-overlay > ds-modal > __head/__body/__foot` ·
Toast `DS.toast(msg,'success|danger|warning|info')`, `ds-alert` · Loader `ds-spinner`, `ds-skeleton` · `ds-empty`, `ds-error-state`.

## Cədvəl sistemi (AppTable) — avtomatik
Səhifəyə hər hansı `<table><thead>…</thead><tbody>…</tbody></table>` qoyulan kimi `ds.js` onu tapır və əlavə edir:
- **Sütun tipinə görə filtr sırası** (tip avtomatik təyin olunur):
  - mətn: `abc` (tərkibində), `^abc` (başlayır), `=abc` (tam)
  - rəqəm: `=5`, `>5`, `>=5`, `<5`, `<=5`, `5..20`
  - tarix: `2026-09-30` (həmin gün), `>2026-09-01`, `<…`, `2026-09-01..2026-09-30`
  - enum/status (≤12 dəyər): açılan siyahı
- Qlobal axtarış, **aktiv filtr sayı**, **"Hamısını təmizlə"**, sıralama (başlığa klik: ▲ ▼ söndür),
  səhifələmə (25/50/100/250/Hamısı), sütun görünüşü, sticky başlıq, üfüqi scroll, "nəticə tapılmadı" halı.
- Atributlar: `<table data-ds-table="off">` (söndür), `<th data-filter="none">`, `<th data-type="text|number|date|enum">`.
- Öz filtr sırası olan köhnə cədvəllər (`<tr class="filters">`, Backup Monitor) — məntiq toxunulmur; DS toolbar onlara qoşulur.

## Yeni səhifə şablonu
```html
<div id="xModule" class="hidden">
  <div class="ds-hero"><span class="ds-kicker">BÖLMƏ</span><h2>Başlıq</h2><p>İzah</p>
    <div class="ds-hero__actions"><button class="ds-btn">Əsas</button><button class="ds-btn ds-btn--secondary">İkinci</button></div></div>
  <div class="ds-stats"><div class="ds-stat ds-stat--success"><span class="ds-stat__label">Uğurlu</span><b class="ds-stat__value">0</b></div></div>
  <div class="ds-card"><div class="ds-table-box"><table><thead><tr><th>ATM ID</th><th>Status</th></tr></thead><tbody id="xBody"></tbody></table></div></div>
</div>
```
Filtr, sıralama, səhifələmə avtomatik gəlir — heç bir əlavə kod lazım deyil.

## v2 — vizual standart
- Palitra: az doymuş tünd boz-göy (göz yormur), bir əsas rəng `--c-primary`. Parıltı/gradient yoxdur.
- Maksimum məzmun eni `--content-max` (1600px) — geniş ekranda səhifə uzanmır, mərkəzdə qalır.
- Hər modul: `ds-page-head` (ikon + başlıq + izah + sağda əməliyyatlar) → lazım olsa `ds-command` (ATM ID / tarix + əsas düymə + status) → KPI → kartlar/cədvəl.
- Breakpoint-lər: 1200 (grid → 1 sütun), 1024 (sidebar gizlənir, ☰), 760 (mobil), 480.
- Düymədəki köhnə simvollar (⟳ ＋ ▥ ⇩ …) avtomatik SVG ikona çevrilir (`DS.iconize`); yeni kodda birbaşa `DS.icon()` istifadə et.
- Cədvəldə qlobal axtarışı söndürmək (modulun öz server-axtarışı varsa): `<table data-ds-search="off">`.
