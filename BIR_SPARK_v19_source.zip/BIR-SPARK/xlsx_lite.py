# -*- coding: utf-8 -*-
"""
xlsx_lite — xarici paket tələb etməyən sadə .xlsx (Office Open XML) yazıcı.

Dəstəklənir:
  * bir neçə vərəq (sheet)
  * mətn, tam/kəsr ədəd, datetime / date (həqiqi Excel tarixi — sıralama/filtr düzgün işləyir)
  * başlıq sətri (qalın, rəngli fon), sətir rəngləri (status üçün), qalın xana
  * sütun eni, başlığın dondurulması (freeze), avtomatik filtr

İstifadə:
    wb = Workbook()
    ws = wb.add_sheet("Hesabat", columns=[("ATM ID", 14), ("Tarix", 20)])
    ws.add_row(["A0100051", datetime.now()], fill="green")
    data = wb.to_bytes()
"""
import io
import re
import zipfile
from datetime import datetime, date, timezone
from xml.sax.saxutils import escape

__all__ = ["Workbook", "FILLS"]

# Fon rəngləri (ARGB). Ad -> rəng. "none" = fon yoxdur.
FILLS = {
    "none": None,
    "header": "FF2D6E7E",
    "green": "FFD3ECDF",
    "yellow": "FFF3E6C9",
    "red": "FFF3D0D6",
    "gray": "FFE2E5EC",
    "blue": "FFDDE6F1",
    "title": "FFE2EEF1",
}
_FILL_ORDER = list(FILLS.keys())

# Xana formatları (numFmt): 0=General, 164=tarix+saat, 165=tarix, 166=0.0
_FMT = {"general": 0, "datetime": 164, "date": 165, "dec1": 166}
_FONTS = {"normal": 0, "bold": 1, "header": 2}

_ILLEGAL_XML = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]")
_EPOCH = datetime(1899, 12, 30)


def _col_letter(index):
    """0 -> A, 25 -> Z, 26 -> AA"""
    index += 1
    out = ""
    while index:
        index, rem = divmod(index - 1, 26)
        out = chr(65 + rem) + out
    return out


def _clean_text(value):
    text = _ILLEGAL_XML.sub("", str(value))
    if len(text) > 32000:  # Excel xana limiti 32767
        text = text[:32000] + "…"
    return escape(text)


def _sheet_name(name, used):
    name = re.sub(r"[\[\]\:\*\?\/\\]", " ", str(name or "Sheet")).strip() or "Sheet"
    name = name[:31]
    base, n = name, 2
    while name.lower() in used:
        suffix = f" ({n})"
        name = base[:31 - len(suffix)] + suffix
        n += 1
    used.add(name.lower())
    return name


class _Style:
    """(font, fill, numfmt) üçlüyü -> cellXfs indeksi."""

    def __init__(self):
        self.combos = [("normal", "none", "general")]

    def index(self, font="normal", fill="none", fmt="general"):
        if fill not in FILLS:
            fill = "none"
        key = (font, fill, fmt)
        if key not in self.combos:
            self.combos.append(key)
        return self.combos.index(key)

    def xml(self):
        fonts = (
            '<fonts count="3">'
            '<font><sz val="11"/><name val="Calibri"/><family val="2"/></font>'
            '<font><b/><sz val="11"/><name val="Calibri"/><family val="2"/></font>'
            '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/><family val="2"/></font>'
            '</fonts>'
        )
        fill_xml = ['<fill><patternFill patternType="none"/></fill>',
                    '<fill><patternFill patternType="gray125"/></fill>']
        fill_index = {}
        for name in _FILL_ORDER:
            rgb = FILLS[name]
            if rgb is None:
                fill_index[name] = 0
                continue
            fill_index[name] = len(fill_xml)
            fill_xml.append(f'<fill><patternFill patternType="solid"><fgColor rgb="{rgb}"/>'
                            f'<bgColor indexed="64"/></patternFill></fill>')
        xfs = []
        for font, fill, fmt in self.combos:
            attrs = [f'numFmtId="{_FMT[fmt]}"', f'fontId="{_FONTS[font]}"',
                     f'fillId="{fill_index[fill]}"', 'borderId="0"', 'xfId="0"']
            if _FMT[fmt]:
                attrs.append('applyNumberFormat="1"')
            if font != "normal":
                attrs.append('applyFont="1"')
            if fill != "none":
                attrs.append('applyFill="1"')
            xfs.append("<xf " + " ".join(attrs) + "/>")
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            '<numFmts count="3">'
            '<numFmt numFmtId="164" formatCode="dd.mm.yyyy hh:mm:ss"/>'
            '<numFmt numFmtId="165" formatCode="dd.mm.yyyy"/>'
            '<numFmt numFmtId="166" formatCode="0.0"/>'
            '</numFmts>'
            + fonts
            + f'<fills count="{len(fill_xml)}">' + "".join(fill_xml) + '</fills>'
            '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            f'<cellXfs count="{len(xfs)}">' + "".join(xfs) + '</cellXfs>'
            '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            '</styleSheet>'
        )


class Sheet:
    def __init__(self, book, name, columns, freeze=True, autofilter=True):
        self.book = book
        self.name = name
        self.columns = list(columns or [])
        self.rows = []          # list[str] — hazır <row> XML-i
        self.freeze = freeze and bool(self.columns)
        self.autofilter = autofilter and bool(self.columns)
        self.header_rows = 0
        if self.columns:
            self._raw_row([c[0] for c in self.columns], font="header", fill="header")
            self.header_rows = 1

    def _cell(self, ref, value, font, fill, fmt=None):
        st = self.book.style
        if value is None or value == "":
            if fill == "none" and font == "normal":
                return ""
            return f'<c r="{ref}" s="{st.index(font, fill)}"/>'
        if isinstance(value, bool):
            return f'<c r="{ref}" s="{st.index(font, fill)}" t="b"><v>{1 if value else 0}</v></c>'
        if isinstance(value, datetime):
            serial = (value.replace(tzinfo=None) - _EPOCH).total_seconds() / 86400.0
            return f'<c r="{ref}" s="{st.index(font, fill, fmt or "datetime")}"><v>{serial:.8f}</v></c>'
        if isinstance(value, date):
            serial = (datetime(value.year, value.month, value.day) - _EPOCH).days
            return f'<c r="{ref}" s="{st.index(font, fill, fmt or "date")}"><v>{serial}</v></c>'
        if isinstance(value, int):
            return f'<c r="{ref}" s="{st.index(font, fill)}"><v>{value}</v></c>'
        if isinstance(value, float):
            if value != value or value in (float("inf"), float("-inf")):
                return f'<c r="{ref}" s="{st.index(font, fill)}"/>'
            return f'<c r="{ref}" s="{st.index(font, fill, fmt or "general")}"><v>{repr(value)}</v></c>'
        return (f'<c r="{ref}" s="{st.index(font, fill)}" t="inlineStr">'
                f'<is><t xml:space="preserve">{_clean_text(value)}</t></is></c>')

    def _raw_row(self, values, font="normal", fill="none", bold_cols=()):
        r = len(self.rows) + 1
        cells = []
        for i, v in enumerate(values):
            f = "bold" if (i in bold_cols and font == "normal") else font
            cells.append(self._cell(f"{_col_letter(i)}{r}", v, f, fill))
        self.rows.append(f'<row r="{r}">' + "".join(cells) + "</row>")

    def add_row(self, values, fill="none", bold=False, bold_cols=()):
        self._raw_row(list(values), font="bold" if bold else "normal", fill=fill, bold_cols=tuple(bold_cols))

    def add_blank(self):
        r = len(self.rows) + 1
        self.rows.append(f'<row r="{r}"/>')

    def xml(self):
        ncols = max([len(self.columns)] + [1])
        parts = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                 '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">']
        last = f"{_col_letter(ncols - 1)}{max(1, len(self.rows))}"
        parts.append(f'<dimension ref="A1:{last}"/>')
        if self.freeze and self.header_rows:
            parts.append('<sheetViews><sheetView workbookViewId="0">'
                         f'<pane ySplit="{self.header_rows}" topLeftCell="A{self.header_rows + 1}" '
                         'activePane="bottomLeft" state="frozen"/>'
                         f'<selection pane="bottomLeft" activeCell="A{self.header_rows + 1}" '
                         f'sqref="A{self.header_rows + 1}"/>'
                         '</sheetView></sheetViews>')
        else:
            parts.append('<sheetViews><sheetView workbookViewId="0"/></sheetViews>')
        parts.append('<sheetFormatPr defaultRowHeight="15"/>')
        if self.columns:
            parts.append("<cols>")
            for i, (_, width) in enumerate(self.columns):
                w = max(4, min(float(width or 12), 120))
                parts.append(f'<col min="{i + 1}" max="{i + 1}" width="{w}" customWidth="1"/>')
            parts.append("</cols>")
        parts.append("<sheetData>" + "".join(self.rows) + "</sheetData>")
        if self.autofilter and len(self.rows) >= 1:
            parts.append(f'<autoFilter ref="A1:{last}"/>')
        parts.append('<pageMargins left="0.5" right="0.5" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>')
        parts.append("</worksheet>")
        return "".join(parts)


class Workbook:
    def __init__(self):
        self.style = _Style()
        self.sheets = []
        self._names = set()

    def add_sheet(self, name, columns=None, freeze=True, autofilter=True):
        sheet = Sheet(self, _sheet_name(name, self._names), columns, freeze, autofilter)
        self.sheets.append(sheet)
        return sheet

    def to_bytes(self):
        if not self.sheets:
            self.add_sheet("Sheet1")
        n = len(self.sheets)
        # Vərəq XML-ləri əvvəl qurulur ki, bütün stil kombinasiyaları qeydə alınsın.
        sheet_xml = [s.xml() for s in self.sheets]
        content_types = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/xl/workbook.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            + "".join(
                f'<Override PartName="/xl/worksheets/sheet{i + 1}.xml" '
                'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                for i in range(n))
            + '<Override PartName="/xl/styles.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            '<Override PartName="/docProps/core.xml" '
            'ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
            '<Override PartName="/docProps/app.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
            '</Types>'
        )
        root_rels = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
            'Target="xl/workbook.xml"/>'
            '<Relationship Id="rId2" '
            'Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" '
            'Target="docProps/core.xml"/>'
            '<Relationship Id="rId3" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" '
            'Target="docProps/app.xml"/>'
            '</Relationships>'
        )
        defined = []
        for i, s in enumerate(self.sheets):
            if s.autofilter and s.rows:
                ncols = max(1, len(s.columns))
                last_col = _col_letter(ncols - 1)
                qname = "'" + s.name.replace("'", "''") + "'"
                defined.append(f'<definedName name="_xlnm._FilterDatabase" localSheetId="{i}" hidden="1">'
                               f'{escape(qname)}!$A$1:${last_col}${len(s.rows)}</definedName>')
        workbook = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<bookViews><workbookView xWindow="0" yWindow="0" windowWidth="28800" windowHeight="15000"/></bookViews>'
            '<sheets>'
            + "".join(f'<sheet name="{escape(s.name, {chr(34): "&quot;"})}" sheetId="{i + 1}" r:id="rId{i + 1}"/>'
                      for i, s in enumerate(self.sheets))
            + '</sheets>'
            + ('<definedNames>' + "".join(defined) + '</definedNames>' if defined else '')
            + '</workbook>'
        )
        wb_rels = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            + "".join(f'<Relationship Id="rId{i + 1}" '
                      'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
                      f'Target="worksheets/sheet{i + 1}.xml"/>' for i in range(n))
            + f'<Relationship Id="rId{n + 1}" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" '
            'Target="styles.xml"/>'
            '</Relationships>'
        )
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        core = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
            'xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            '<dc:creator>Cihaz İdarəetmə Sistemi</dc:creator>'
            f'<dcterms:created xsi:type="dcterms:W3CDTF">{now}</dcterms:created>'
            f'<dcterms:modified xsi:type="dcterms:W3CDTF">{now}</dcterms:modified>'
            '</cp:coreProperties>'
        )
        app = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">'
            '<Application>Microsoft Excel</Application></Properties>'
        )
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("[Content_Types].xml", content_types)
            z.writestr("_rels/.rels", root_rels)
            z.writestr("docProps/core.xml", core)
            z.writestr("docProps/app.xml", app)
            z.writestr("xl/workbook.xml", workbook)
            z.writestr("xl/_rels/workbook.xml.rels", wb_rels)
            for i, x in enumerate(sheet_xml):
                z.writestr(f"xl/worksheets/sheet{i + 1}.xml", x)
            z.writestr("xl/styles.xml", self.style.xml())
        return buf.getvalue()
