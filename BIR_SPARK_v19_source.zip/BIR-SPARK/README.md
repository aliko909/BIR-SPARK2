# BIR SPARK — ATM / ADM / Terminal idarəetmə platforması

İnternetsiz (offline) Windows serverdə işləyən veb tətbiq: ATM-lərin backup / jurnal yoxlaması, monitorinq,
disk hesabatları, uzaqdan restart, video arxiv, server disk gəzgini, Backup Manager, istifadəçi + icazə idarəetməsi,
iki mərhələli giriş (2FA / TOTP) və audit jurnalı.

> **Versiya:** v19 (Node.js gateway + Python mühərrik). Dəyişiklik tarixçəsi: [`DEYISIKLIKLER.md`](DEYISIKLIKLER.md)

## Arxitektura

```
Brauzer ──HTTP/HTTPS──► Node.js gateway  (server.js + auth.js, port 8080)
                          ├─ giriş, 2FA, sessiyalar, icazələr, audit  → atm_auth.db (node:sqlite)
                          ├─ statik frontend (web/), offline xəritə tile-ları (map_tiles/)
                          └─ icazə yoxlamasından sonra /api/* ──► Python mühərrik (server.py, yalnız 127.0.0.1:8081)
                                                                  ├─ ATM-lərə SMB (C$/D$/E$), WMI, PsExec
                                                                  ├─ scan / backup / restart / hesabatlar
                                                                  └─ atm_history.db (sqlite3)
ATM agent-ləri (agent/, agent_simple/) ──POST──► /api/agent/* (HMAC imzalı telemetriya)
```

Xarici asılılıq yoxdur: `npm install` / `pip install` tələb olunmur. Frontend kitabxanaları (`web/assets/vendor/`) lokaldır.

## Qovluq quruluşu

| Yol | Məzmun |
|---|---|
| `server.js` | Node gateway: statik fayllar, HTTPS, Python-a proxy, təhlükəsizlik başlıqları (CSP və s.) |
| `auth.js` | İstifadəçilər, scrypt şifrələr, JWT access + rotasiyalı refresh, 2FA (TOTP, AES-GCM), icazə kataloqu (`CATALOG`), API → icazə xəritəsi (`ROUTES`), audit |
| `server.py` | Python mühərrik — bütün ATM/server əməliyyatları (~126 endpoint) |
| `xlsx_lite.py` | Asılılıqsız Excel (.xlsx) yazıcı |
| `web/login.html`, `web/home.html` | Giriş (2FA daxil) və əsas səhifə |
| `web/modules/*.html` | Modullar (bootstrap.js tərəfindən yüklənir) |
| `web/assets/js/` | `app.js` (əsas), `auth-client.js` / `auth-admin.js` (sessiya, istifadəçilər), modul skriptləri |
| `web/assets/ds/`, `web/assets/css/` | Dizayn sistemi (tokenlər, komponentlər, Lucide ikonlar) — bax [`DESIGN_SYSTEM.md`](DESIGN_SYSTEM.md) |
| `web/assets/vendor/` | Leaflet 1.9.4, qrcode-generator 1.4.4 (MIT) |
| `agent/`, `agent_simple/` | ATM-də işləyən monitorinq agentləri |
| `eco*/` | Köhnə Windows versiyaları üçün məlumat toplama skriptləri |
| `tools/` | Offline xəritə yükləyici, ATM metadata importu, `reset_2fa.js` (break-glass) |

## Tələblər

* Windows Server (ATM-lərə SMB/WMI çıxışı olan şəbəkədə)
* Node.js **22.13+** (tövsiyə 24) — portable `runtime\node.exe` kimi
* Python 3.9+ (Anaconda: `C:\ProgramData\Anaconda3\python.exe`)
* `PsExec.exe` / `PsExec64.exe` (Sysinternals) — lisenziya səbəbi ilə repoda yoxdur, ayrıca yükləyib kök qovluğa qoyun

## İşə salma

1. `runtime\node.exe` və (lazımdırsa) PsExec fayllarını yerləşdirin.
2. `START.bat` → port və HTTP/HTTPS seçin.
3. İlk işə salınmada `admin` istifadəçisi yaradılır, müvəqqəti şifrə `ILK_ADMIN_SIFRE.txt` faylına yazılır
   (girişdən sonra silin). İlk girişdə şifrə dəyişmə və 2FA (QR) qeydiyyatı məcburidir.
4. Ünvan: `http://localhost:8080/home.html`

Yerli inkişaf (Linux/macOS): `ATM_NO_BROWSER=1 node server.js` (Python avtomatik başladılır).
Sintaksis yoxlaması: `npm run check`.

## Əsas mühit dəyişənləri

| Dəyişən | Standart | Mənası |
|---|---|---|
| `ATM_WEB_PORT` / `ATM_WEB_BIND` | 8080 / 0.0.0.0 | gateway portu / interfeys |
| `ATM_WEB_HTTPS=1` + `ATM_WEB_PFX` (`_PASS`) və ya `ATM_WEB_CERT` + `ATM_WEB_KEY` | — | HTTPS |
| `ATM_COOKIE_SECURE=1` | 0 | HTTPS arxasında cookie Secure |
| `ATM_PY_PORT`, `ATM_PYTHON` | 8081 | Python mühərrik |
| `ATM_ACCESS_TTL_MIN`, `ATM_REFRESH_TTL_DAYS` | 15, 7 | sessiya müddətləri |
| `ATM_2FA=0`, `ATM_2FA_WINDOW`, `ATM_2FA_ISSUER` | aktiv, 1, BIR SPARK | 2FA parametrləri |
| `ATM_AUDIT_DAYS` | 180 | audit saxlama |

ATM parolları kodda saxlanılmır — mühərrik onları mühit dəyişənlərindən oxuyur (bax `README.txt`).

## Repoda OLMAYAN fayllar (`.gitignore`)

* `atm_history.db`, `atm_auth.db` — işlək bazalar (ATM siyahısı, istifadəçilər, audit)
* `atm_auth.key` — 2FA sirlərinin şifrələmə açarı
* `ILK_ADMIN_SIFRE.txt`, `backup_mgr_settings.json`, sertifikatlar (`certs/`)
* `tools/atm_meta.json` — real ATM ünvanları/koordinatları (nümunə: `tools/atm_meta.example.json`)
* `runtime/` (Node.js), `map_tiles/` (offline xəritə), `PsExec*.exe`

Boş baza ilə başlamaq üçün sadəcə serveri işə salın — `atm_auth.db` avtomatik yaradılır.

## Təhlükəsizlik

Ətraflı audit: [`SECURITY_AUDIT.md`](SECURITY_AUDIT.md), giriş sistemi: [`README_AUTH.txt`](README_AUTH.txt).
Qısaca: scrypt şifrələr, HttpOnly + SameSite=Strict cookie-lər, CSRF başlığı, refresh token rotasiyası və təkrar
istifadə aşkarlanması, məcburi TOTP 2FA, hesab kilidi, fail-safe icazə xəritəsi (xəritədə olmayan API yalnız admin),
CSP və digər təhlükəsizlik başlıqları, audit jurnalı.

> ⚠️ Kodda bankın daxili şəbəkə ünvanları (`172.21.x.x`) var. Repozitoriyanı **Private** saxlayın.
