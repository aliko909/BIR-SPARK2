ATM WEB — GİRİŞ, İCAZƏ VƏ AUDİT SİSTEMİ
=======================================

İLK İŞƏ SALMA
-------------
1. START.bat ilə işə salın (Node.js 22.13+; tövsiyə olunan portable Node 24).
2. İlk açılışda "admin" hesabı yaradılır. Müvəqqəti şifrə konsolda göstərilir və
   ILK_ADMIN_SIFRE.txt faylına yazılır. Daxil olun, şifrəni dəyişin, FAYLI SİLİN.
3. Sol menyu → Administrasiya → İstifadəçilər: hesab yaradın, "İcazələr" düyməsi ilə
   modul / əməliyyat / blok / cədvəl sütunu icazələrini təyin edin.

FAYLLAR
-------
auth.js                      Server: istifadəçi, token, icazə, audit (Node gateway daxilində)
atm_auth.db                  İstifadəçi + sessiya + audit bazası (avtomatik yaranır). BACKUP EDİN.
web/login.html               Giriş və məcburi şifrə dəyişmə səhifəsi
web/assets/js/auth-client.js Token yeniləmə, icazələrin UI-a tətbiqi, klik/keçid izləmə
web/assets/js/auth-admin.js  İstifadəçilər / İcazələr / Audit log ekranları
web/modules/users.html, audit.html

TOKENLƏR
--------
Access token : HS256 JWT, HttpOnly cookie "atm_at", 15 dəqiqə (ATM_ACCESS_TTL_MIN)
Refresh token: təsadüfi 256 bit, bazada yalnız SHA-256 hash, HttpOnly cookie "atm_rt",
               7 gün, hər istifadədə uzanır (ATM_REFRESH_TTL_DAYS). Hər yeniləmədə rotasiya olunur;
               köhnə token təkrar istifadə edilərsə sessiya ləğv olunur və audit-ə yazılır.
Brauzeri bağlayıb açanda / yeni tab açanda: access token etibarlıdırsa birbaşa home;
bitibsə login səhifəsi refresh token ilə səssiz bərpa edib home-a atır; refresh də bitibsə login.

GİRİŞ QAYDALARI
---------------
status = false         → "Bu istifadəçi silinib." (soft delete, hesab bazada qalır)
login_allowed = false  → "Sistemə giriş icazəniz yoxdur."
Hər iki mesaj yalnız DÜZGÜN şifrədən sonra göstərilir. 5 səhv cəhd → 5 dəqiqə kilid.
Status/giriş icazəsi bağlananda, şifrə sıfırlananda istifadəçinin bütün sessiyaları dərhal bağlanır.

MÜHİT DƏYİŞƏNLƏRİ (istəyə görə)
-------------------------------
ATM_ACCESS_TTL_MIN=15   ATM_REFRESH_TTL_DAYS=7   ATM_AUDIT_DAYS=180   ATM_COOKIE_SECURE=1 (yalnız HTTPS arxasında)

ADMİN ŞİFRƏSİ UNUDULUBSA
------------------------
Proqramı dayandırın, atm_auth.db faylını silin (BÜTÜN istifadəçilər və audit silinir) və yenidən başladın —
yeni "admin" yaradılacaq. Yalnız şifrəni sıfırlamaq üçün başqa administrator hesabından istifadə edin.

MƏHDUDİYYƏTLƏR (bilmək vacibdir)
--------------------------------
* Trafik HTTP-dir: şifrə və cookie şəbəkədə şifrələnmir. Etibarsız şəbəkədə HTTPS reverse proxy qoyun.
* Sütun icazəsi yalnız UI-da gizlədir; həmin sahə API cavabında (və CSV exportda) qalır.
  Həssas sütunu gizlətdiyiniz istifadəçidə "CSV export" icazəsini də bağlayın.
* Python backend (127.0.0.1:8081) yalnız lokal dinləyir, amma server maşınının özündə
  localhost:8081 ünvanına birbaşa müraciət girişsiz işləyir. Server maşınına giriş məhdud olmalıdır.
* /api/agent/report (ATM agent-ləri) girişsiz qalır — əvvəlki kimi.
* Yeni düymə/endpoint əlavə edəndə auth.js-dəki CATALOG və ROUTES siyahısına yazın;
  ROUTES-da olmayan /api yolu yalnız administratora açıqdır.

2FA (OTP) — v19
* Hər istifadəçi girişdə şifrədən sonra Authenticator tətbiqindəki 6 rəqəmli kodu yazır.
  İlk girişdə QR kod göstərilir (bir dəfəlik qeydiyyat). İnternet tələb olunmur.
* Sıfırla / Yenidən qur / Kilidi aç — yalnız administrator (İstifadəçilər → 📱 düyməsi).
* atm_auth.key — 2FA sirlərinin şifrələmə açarı. atm_auth.db ilə BİRLİKDƏ backup edin, heç kimə verməyin.
* Admin telefonu itibsə: serverdə  node tools\reset_2fa.js admin
* Server saatı düzgün olmalıdır (NTP). Saat 1 dəqiqədən çox fərqlənsə kodlar qəbul edilməz.
* ATM_2FA=0 mühit dəyişəni 2FA-nı söndürür (yalnız fövqəladə hal üçün).
* ATM_2FA_WINDOW (0–2, standart 1) — saat fərqi tolerantlığı (×30 san).
