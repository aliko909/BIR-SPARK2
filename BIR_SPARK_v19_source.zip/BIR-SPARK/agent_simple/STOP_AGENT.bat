@echo off
REM Agenti dayandirir (hem exe, hem pythonw variantini).
taskkill /F /IM sagent.exe  >nul 2>&1
taskkill /F /IM pythonw.exe >nul 2>&1
echo Agent dayandirildi.
pause
