@echo off
REM sagent.py -> sagent.exe  (TEK fayl, KONSOLSUZ -> CMD acilmir, arxa fonda isleyir)
REM Interneti olan bir Windows masininda islenir. Hazir exe sonra ATM-lere kopyalanir.
setlocal
cd /d "%~dp0"
where python >nul 2>&1 || (echo [XETA] Python tapilmadi. python.org-dan Python 3.8+ qurun ("Add to PATH").& pause & exit /b 1)

python -c "import PyInstaller" 2>nul || (
  echo PyInstaller qurulur ^(internet lazimdir^)...
  python -m pip install pyinstaller || (echo [XETA] pip ile qurulmadi.& pause & exit /b 1)
)

python -m PyInstaller --onefile --noconsole --name sagent sagent.py
if not exist dist\sagent.exe (echo [XETA] build alinmadi.& pause & exit /b 1)

if exist paket rmdir /S /Q paket
mkdir paket
copy /Y dist\sagent.exe   paket\ >nul
copy /Y ATM_YOL.txt       paket\ >nul
copy /Y config.json       paket\ >nul
echo.
echo === HAZIRDIR ===
echo Paket:  %CD%\paket\
echo   sagent.exe   - agentin ozu (konsolsuz, cift-klik -> arxa fonda isleyir)
echo   ATM_YOL.txt  - server yolu
echo   config.json  - atm_id + interval
echo.
echo Bu 3 fayli her ATM-e kopyalayin. ATM_YOL.txt ve config.json-u ATM-e uygun doldurun.
echo sagent.exe-e cift-klik -> CMD ACILMIR, arxa fonda isleyir.
echo Avtomatik baslama: sagent.exe qisayolunu shell:startup qovluguna atin.
pause
endlocal
