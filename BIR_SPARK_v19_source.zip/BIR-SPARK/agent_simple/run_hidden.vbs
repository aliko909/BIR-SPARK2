' Sade ATM Agent-i GORUNMEDEN, arxa fonda ishe salir (CMD acilmir).
' 1) Yaninda sagent.exe varsa -> onu gizli ishe salir (Python LAZIM DEYIL).
' 2) Yoxdursa -> pythonw.exe ile sagent.py (Python qurulmalidir).
Set sh  = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = dir

exePath = dir & "\sagent.exe"
If fso.FileExists(exePath) Then
    sh.Run """" & exePath & """", 0, False
ElseIf fso.FileExists(dir & "\sagent.py") Then
    ' pythonw.exe PATH-da olmalidir; yoxdursa tam yolu asagida yazin:
    ' pyw = "C:\Python38\pythonw.exe"
    pyw = "pythonw.exe"
    On Error Resume Next
    sh.Run """" & pyw & """ """ & dir & "\sagent.py""", 0, False
    If Err.Number <> 0 Then
        MsgBox "Python (pythonw.exe) tapilmadi." & vbCrLf & _
               "Ya sagent.exe-ni bura qoyun, ya da Python 3 qurun.", 48, "ATM Agent"
    End If
    On Error GoTo 0
Else
    MsgBox "sagent.exe ve ya sagent.py tapilmadi.", 48, "ATM Agent"
End If
