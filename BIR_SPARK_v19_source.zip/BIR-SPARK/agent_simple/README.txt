SADE ATM AGENT (muveqqeti) — CPU / RAM / C: / D: disk / IP
==========================================================
Fayllar:
  sagent.py        - agent (Python stdlib, XP/7/10)
  ATM_YOL.txt      - SERVER YOLU (bir setir).  Numune: https://172.21.12.229/agent
  config.json      - { "atm_id":"A0100008", "interval_minutes":1 }
  run_hidden.vbs   - agenti GORUNMEDEN ishe salir (CMD acilmir)
  START_AGENT.bat  - klikle -> agent arxa fonda ishleyir
  STOP_AGENT.bat   - agenti dayandirir
  sagent.log       - qisa log (ozu-ozune temizlenir)

QURASDIRMA (ATM-de):
  1) Bu qovlugu ATM-e kocurun (ve ya C:\ATMAgent).
  2) ATM_YOL.txt-ni acin: serverin yolunu yazin (https://SERVER_IP/agent).
  3) config.json-u acin: bu ATM-in ID-sini ve intervali (deqiqe) yazin.
     Intervali sonradan deyise bilersiniz - agent restartsiz tetbiq edir.
  4) Python 3 qurulu olmalidir (pythonw.exe). PATH-da yoxdursa run_hidden.vbs-de tam yolu yazin
     (mes: pyw = "C:\Python38\pythonw.exe").
  5) START_AGENT.bat-a klik -> agent arxa fonda, GORUNMEDEN ishleyir, her interval melumat gonderir.

AVTOMATIK BASLAMA (ATM yeniden acilanda):
  run_hidden.vbs-in qisayolunu Startup qovluguna atin:
    Win+R -> shell:startup -> run_hidden.vbs qisayolunu bura qoyun.

QEYD:
  - Agent yungul: cash/yaddas doldurmur, her dovrde toplayib gonderir.
  - HTTPS self-signed sertifikat ucun sertifikat yoxlamasi sondurulub (daxili sebeke).
  - Nece ATM olsa, her birinde oz config.json (oz atm_id) ile.
  - Serverde "ATM Agent (sade)" bolmesinde butun ATM-ler oz melumatlari ile gorunur.

------------------------------------------------------------
EXE-YE CEVIRMEK (ATM-de Python lazim olmasin)
------------------------------------------------------------
Interneti olan bir Windows masininda:
  1) Python 3.8+ qurun ("Add to PATH").
  2) build_exe.bat islet -> sagent.exe (KONSOLSUZ) + paket\ qovlugu yaranir.
  3) paket\ icinde: sagent.exe + ATM_YOL.txt + config.json.
  4) Bu 3 fayli ATM-e kopyalayin, ATM_YOL.txt ve config.json-u doldurun.
  5) sagent.exe-e cift-klik -> CMD ACILMIR, arxa fonda isleyir (Python LAZIM DEYIL).

QEYD: exe fayllari OZ YANINDAN oxuyur (ATM_YOL.txt, config.json exe ile eyni qovluqda olmalidir).
