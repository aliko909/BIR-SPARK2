@echo off
REM Agenti GORUNMEDEN ishe salir (CMD baglanir, agent arxa fonda qalir).
cd /d "%~dp0"
wscript.exe "%~dp0run_hidden.vbs"
exit
