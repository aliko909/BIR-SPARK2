#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Sade ATM Agent (muveqqeti) — CPU / RAM / C: / D: disk / IP gonderir.
- Server yolu:  ATM_YOL.txt faylindan oxunur  (numune: https://172.21.12.229/agent)
- ATM ID + interval:  config.json faylindan  ({"atm_id":"A0100008","interval_minutes":1})
- Arxa fonda, gorunmeden isleyir (pythonw.exe + run_hidden.vbs ile).
- Yungul: cash yaratmir, yaddas doldurmur; her dovrde toplayib gonderir, atir.
- Yalniz Python standart kitabxanasi (XP/7/10 uyumlu, f-string yoxdur).
"""
import os
import sys
import time
import json
import socket

try:
    import urllib.request as urlreq
    from urllib.parse import urlparse
except ImportError:
    import urllib2 as urlreq
    from urlparse import urlparse

IS_WINDOWS = os.name == "nt"
if IS_WINDOWS:
    import ctypes
    from ctypes import wintypes

# EXE-ye cevrildikde (PyInstaller) fayllar exe-nin YANINDAN oxunur, temp qovlugdan yox.
if getattr(sys, "frozen", False):
    HERE = os.path.dirname(sys.executable)
else:
    HERE = os.path.dirname(os.path.abspath(__file__))
YOL_FILE = os.path.join(HERE, "ATM_YOL.txt")
CFG_FILE = os.path.join(HERE, "config.json")
LOG_FILE = os.path.join(HERE, "sagent.log")


def log(msg):
    line = time.strftime("%Y-%m-%d %H:%M:%S") + "  " + str(msg)
    try:
        f = open(LOG_FILE, "a")
        try:
            # kicik saxla: 200 KB-dan boyukse sifirla
            if os.path.getsize(LOG_FILE) > 200000:
                f.close()
                f = open(LOG_FILE, "w")
            f.write(line + "\n")
        finally:
            f.close()
    except Exception:
        pass


def read_url():
    try:
        f = open(YOL_FILE)
        try:
            for ln in f:
                ln = ln.strip()
                if ln and not ln.startswith("#"):
                    return ln
        finally:
            f.close()
    except Exception:
        pass
    return ""


def read_config():
    atm_id = ""
    interval = 1
    try:
        f = open(CFG_FILE)
        try:
            d = json.load(f)
        finally:
            f.close()
        atm_id = str(d.get("atm_id", "")).strip()
        interval = int(d.get("interval_minutes", 1))
    except Exception:
        pass
    if interval < 1:
        interval = 1
    return atm_id, interval


def primary_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
        finally:
            s.close()
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return ""


def cpu_percent(sample=0.5):
    if not IS_WINDOWS:
        return None

    class FT(ctypes.Structure):
        _fields_ = [("l", wintypes.DWORD), ("h", wintypes.DWORD)]

    def v(ft):
        return (ft.h << 32) | ft.l
    i1, k1, u1 = FT(), FT(), FT()
    i2, k2, u2 = FT(), FT(), FT()
    kr = ctypes.windll.kernel32
    if not kr.GetSystemTimes(ctypes.byref(i1), ctypes.byref(k1), ctypes.byref(u1)):
        return None
    time.sleep(sample)
    if not kr.GetSystemTimes(ctypes.byref(i2), ctypes.byref(k2), ctypes.byref(u2)):
        return None
    idle = v(i2) - v(i1)
    total = (v(k2) - v(k1)) + (v(u2) - v(u1))
    if total <= 0:
        return None
    return round(100.0 * (total - idle) / total, 1)


def ram_info():
    if not IS_WINDOWS:
        return 0, 0, None

    class MS(ctypes.Structure):
        _fields_ = [("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD),
                    ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
    m = MS()
    m.dwLength = ctypes.sizeof(MS)
    if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
        total = int(m.ullTotalPhys)
        avail = int(m.ullAvailPhys)
        pct = round(100.0 * (total - avail) / total, 1) if total else None
        return total, total - avail, pct
    return 0, 0, None


def disk_info(letter):
    """letter: 'C' ve ya 'D'. (total, free, used_percent) qaytarir."""
    if not IS_WINDOWS:
        return {"total_bytes": 0, "free_bytes": 0, "used_percent": None}
    root = letter + ":\\"
    free_b = ctypes.c_ulonglong(0)
    total_b = ctypes.c_ulonglong(0)
    tfree_b = ctypes.c_ulonglong(0)
    ok = ctypes.windll.kernel32.GetDiskFreeSpaceExW(
        ctypes.c_wchar_p(root), ctypes.byref(free_b), ctypes.byref(total_b), ctypes.byref(tfree_b))
    if not ok:
        return {"total_bytes": 0, "free_bytes": 0, "used_percent": None}
    total = int(total_b.value)
    free = int(tfree_b.value)
    pct = round(100.0 * (total - free) / total, 1) if total else None
    return {"total_bytes": total, "free_bytes": free, "used_percent": pct}


def collect(atm_id, interval):
    rt, ru, rp = ram_info()
    rec = {
        "atm_id": atm_id,
        "hostname": socket.gethostname(),
        "ip": primary_ip(),
        "cpu_percent": cpu_percent(),
        "ram_total_bytes": rt, "ram_used_bytes": ru, "ram_percent": rp,
        "c": disk_info("C"),
        "d": disk_info("D"),
        "interval_minutes": interval,
        "collected_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    return rec


def send(url, rec):
    body = json.dumps(rec).encode("utf-8")
    req = urlreq.Request(url, data=body)
    req.add_header("Content-Type", "application/json")
    is_https = (urlparse(url).scheme or "").lower() == "https"
    ctx = None
    if is_https:
        try:
            import ssl
            ctx = ssl.create_default_context()
            # Daxili sebeke / self-signed sertifikat ucun yoxlamani sondururuk
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        except Exception:
            ctx = None
    try:
        if ctx is not None:
            r = urlreq.urlopen(req, timeout=20, context=ctx)
        else:
            r = urlreq.urlopen(req, timeout=20)
        try:
            r.read()
        finally:
            r.close()
        return True, "OK"
    except Exception as exc:
        return False, str(exc)


def main():
    log("Sade ATM Agent basladi.")
    while True:
        try:
            url = read_url()
            atm_id, interval = read_config()
            if not url:
                log("ATM_YOL.txt bos / tapilmadi.")
            elif not atm_id:
                log("config.json: atm_id bos.")
            else:
                rec = collect(atm_id, interval)
                ok, msg = send(url, rec)
                if ok:
                    log("Gonderildi: ATM=" + atm_id + " CPU=" + str(rec["cpu_percent"]) +
                        " RAM=" + str(rec["ram_percent"]) + " -> " + url)
                else:
                    log("Gonderilmedi: " + msg)
        except Exception as exc:
            log("Xeta: " + str(exc))
        # interval her dovrde yeniden oxunur (deyisiklik restartsiz tetbiq olunur)
        _, interval = read_config()
        slept = 0
        target = interval * 60
        while slept < target:
            time.sleep(2)
            slept += 2


if __name__ == "__main__":
    main()
