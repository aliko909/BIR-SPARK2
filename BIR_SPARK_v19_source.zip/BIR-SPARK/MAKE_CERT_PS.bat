@echo off
REM ADMIN olaraq self-signed sertifikat yaradir -> certs\server.pfx (PowerShell, openssl LAZIM DEYIL)
REM Administrator kimi islat.
setlocal
cd /d "%~dp0"
if not exist certs mkdir certs

set /p CN=Server IP / ad [default 172.21.12.80]: 
if "%CN%"=="" set "CN=172.21.12.80"
set /p PFXPASS=PFX ucun parol teyin et [default atm123]: 
if "%PFXPASS%"=="" set "PFXPASS=atm123"

echo.
echo Sertifikat yaradilir (CN=%CN%)...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$c = New-SelfSignedCertificate -DnsName '%CN%','localhost' -CertStoreLocation Cert:\LocalMachine\My -NotAfter (Get-Date).AddYears(3) -KeyExportPolicy Exportable;" ^
  "$p = ConvertTo-SecureString -String '%PFXPASS%' -Force -AsPlainText;" ^
  "Export-PfxCertificate -Cert $c -FilePath '%~dp0certs\server.pfx' -Password $p | Out-Null;" ^
  "Write-Host 'OK'"

if exist "%~dp0certs\server.pfx" (
  echo.
  echo [OK] Hazir:  certs\server.pfx
  echo      Parol:  %PFXPASS%
  echo.
  echo      Indi START.bat -^> 2^) Sertifikatli -^> 1^) .pfx  secin.
  echo      PFX yolu: certs\server.pfx , parol: %PFXPASS%
) else (
  echo [XETA] Yaradilmadi. PowerShell-i Administrator kimi islatdiginizdan emin olun.
)
pause
endlocal
