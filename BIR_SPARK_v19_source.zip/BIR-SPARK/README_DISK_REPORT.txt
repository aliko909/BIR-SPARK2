ATM WEB — DISK REPORT UPDATE
=============================

Bu paket mövcud ATM_WEB qovluğunun üzərinə çıxarılmaq üçündür.

VACİB — saxla, silmə, overwrite etmə:
  - atm_history.db
  - runtime\node.exe və runtime qovluğu
  - PsExec64.exe
  - PASSWORD<n> Windows environment dəyişənləri

ZIP bunları qəsdən daxil etmir. Mövcud DB server.py start zamanı non-destructive şəkildə genişləndirilir.

YENİ MODUL: Disk Report
-----------------------
1. Bankomatlar -> "Disk Report" düyməsi və ya sol menyu -> Disk Report.
2. Seçim dialogunda solda yalnız status=True və soft-delete olmayan ATM-lər görünür.
3. ATM adına iki dəfə klik: soldan sağa. Sağdakına iki dəfə klik: geri sola.
4. Hər iki tərəfdə ayrıca search var.
5. Ortadakı ≫ soldakı görünən ATM-lərin hamısını sağa keçirir; ≪ geri qaytarır.
6. Başlat -> yalnız seçilmiş ATM-lərdə SMB 445 vasitəsilə C: və D: disk həcmləri oxunur.
7. Table: giriş statusu, PASSWORD environment etiketi, C/D doluluq %, total/free, vaxt, xəta.
8. CSV Export offline işləyir.
9. Hər run disk_report_runs / disk_report_results tarixçəsinə yazılır.
10. Xəritədə ATM detalında "Son Disk Report" C/D faizləri görünür; activity timeline-da Disk Report əməliyyatı qalır.

DB migration avtomatik yaradır:
  disk_report_runs
  disk_report_results
və atms cədvəlinə last_disk_report_* cache sütunları əlavə edir.

Real password DB/UI/log-da saxlanılmır. Yalnız PASSWORD3 kimi environment dəyişəninin adı saxlanıla bilər.

QURAŞDIRMA
----------
1. ATM_WEB qovluğunun backup-ını götür.
2. Bu ZIP-in içindəkiləri C:\Users\samadliaf\Desktop\ATM_WEB\ üzərinə çıxar və fayl overwrite-a YES de.
3. atm_history.db, runtime və PsExec64.exe olduğu kimi qalsın.
4. Köhnə START pəncərəsini bağla.
5. START.bat aç.
6. Browser Ctrl+F5.

Portable Node yolu dəyişməyib:
  ATM_WEB\runtime\node.exe

Internet tələb olunmur. Xəritə əvvəlki kimi tam offline qalır.
