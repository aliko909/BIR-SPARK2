"use strict";
/* =====================================================================
   ATM WEB — AUTH / İCAZƏ / AUDİT (Node gateway səviyyəsində)
   - İstifadəçilər, sessiyalar və audit: atm_auth.db (node:sqlite, xarici paket yoxdur)
   - Access token: HS256 JWT, HttpOnly cookie (atm_at), qısa ömürlü
   - Refresh token: təsadüfi, bazada yalnız SHA-256 hash-i, HttpOnly cookie (atm_rt),
     hər yeniləmədə rotasiya + təkrar istifadə aşkarlanması
   - Bütün /api/* sorğuları burada yoxlanılır, sonra Python-a ötürülür
   ===================================================================== */
const crypto = require("crypto");
const path = require("path");
const fs = require("fs");

const _emitWarning = process.emitWarning;
process.emitWarning = function (w, ...rest) {
  if (String((w && w.message) || w).includes("SQLite")) return;
  return _emitWarning.call(process, w, ...rest);
};
let DatabaseSync;
try { ({ DatabaseSync } = require("node:sqlite")); }
catch (e) {
  console.error("[AUTH] node:sqlite tapılmadı. Node.js 22.13+ (tövsiyə: 24) lazımdır. Cari:", process.version);
  process.exit(1);
}

const ACCESS_TTL = Math.max(1, Number(process.env.ATM_ACCESS_TTL_MIN || 15)) * 60;          // saniyə
const REFRESH_TTL = Math.max(1, Number(process.env.ATM_REFRESH_TTL_DAYS || 7)) * 86400;     // saniyə
const AUDIT_DAYS = Math.max(1, Number(process.env.ATM_AUDIT_DAYS || 180));
const ROTATE_GRACE = 30;          // eyni anda iki tab refresh edərsə köhnə token bu qədər saniyə qəbul olunur
const MAX_FAILS = 5, LOCK_SECONDS = 300;
const COOKIE_SECURE = process.env.ATM_COOKIE_SECURE === "1"; // yalnız HTTPS arxasında 1 et
/* İki mərhələli təsdiq (TOTP, RFC 6238 — Google/Microsoft Authenticator). Offline işləyir.
   ATM_2FA=0 → müvəqqəti söndürülür (yalnız fövqəladə hal üçün; server saatı pozulanda və s.) */
const MFA_ON = process.env.ATM_2FA !== "0";
const MFA_WINDOW = Math.min(2, Math.max(0, Number(process.env.ATM_2FA_WINDOW ?? 1)));   // ±addım (30 san)
const MFA_ISSUER = String(process.env.ATM_2FA_ISSUER || "BIR SPARK").slice(0, 40);
const MFA_TTL = 300, MFA_MAX_TRIES = 5;                                                 // challenge: 5 dəq, 5 cəhd

/* ---------------- İcazə kataloqu (server + UI üçün vahid mənbə) ----------------
   key      : icazə açarı. "modul" = modulu görmək; "modul.x" = modul daxili əməliyyat/blok
   menu     : sol menyudakı element id-ləri (icazə yoxdursa gizlənir)
   fns      : bu icazəyə bağlı düymə funksiyaları (onclick) — icazə yoxdursa düymə gizlənir və funksiya bloklanır
   sel      : icazə yoxdursa gizlənən CSS selektorları                                         */
const CATALOG = [
  { key: "home", label: "Ana səhifə", menu: ["menuHome"], items: [
    { key: "home.block.kpis", label: "KPI göstəriciləri", sel: ["#homeModule .homeKpis"] },
    { key: "home.block.tiles", label: "Tez keçid plitələri", sel: ["#homeModule .homeBlock"] },
    { key: "home.block.sources", label: "Scan mənbələri bloku", sel: ["#homeModule .homePane:has(#homeSources)"] },
    { key: "home.block.recent", label: "Scan xülasəsi bloku", sel: ["#homeModule .homePane:has(#homeRecent)"] },
    { key: "home.block.map", label: "Canlı xəritə bloku", sel: ["#homeModule .homeMain__right"] },
    { key: "home.search", label: "Yuxarı paneldə ATM axtarışı", sel: [".appHeader .topSearch"], fns: ["homeJump"] },
  ]},
  { key: "map", label: "ATM Xəritəsi", menu: ["menuMap"], items: [
    { key: "map.stats", label: "Statistika kartları", sel: ["#atmMapModule .atmMapStats"] },
    { key: "map.goto", label: "Xəritədən ATM Info-ya keçid", fns: ["atmMapGoModule"] },
  ]},
  { key: "backup", label: "Backup Monitor", menu: ["menuBackup", "ipTree"], items: [
    { key: "backup.start", label: "Scan başlat / dayandır", fns: ["startScan", "stopScan"] },
  ]},
  { key: "history", label: "Scan Tarixçəsi", menu: ["menuHistory"], items: [
    { key: "history.detail", label: "Scan detalına bax", fns: ["viewHistory"] },
    { key: "history.compare", label: "Scan-ləri müqayisə et", fns: ["compareSelected"] },
    { key: "history.export", label: "CSV export", fns: ["exportHistoryCSV"] },
  ]},
  { key: "restart", label: "ATM Restart", menu: ["menuRestart"], items: [
    { key: "restart.start", label: "ATM-i restart et", fns: ["startRestart"] },
  ]},
  { key: "archive", label: "Video Archive", menu: ["menuArchive"], items: [
    { key: "archive.connect", label: "ATM-ə qoşul", fns: ["startArchiveScan"] },
    { key: "archive.browse", label: "D$ qovluqlarını gəz", fns: ["openExplorer", "openLatestArchive"] },
    { key: "archive.journal", label: "C$ JOURNAL oxu", fns: ["openJournal"] },
    { key: "archive.media", label: "Şəkil / video önizləmə" },
  ]},
  { key: "videoserver", label: "Video / Şəkil Server", menu: ["menuVideoServer"], items: [
    { key: "videoserver.check", label: "Serverdə ATM qovluğunu yoxla", fns: ["videoServerCheck"] },
    { key: "videoserver.browse", label: "Server qovluqlarını gəz" },
    { key: "videoserver.media", label: "Şəkil / video önizləmə və yükləmə" },
  ]},
  { key: "vascan", label: "VIDEOARCHIVE Scan", menu: ["menuVaScan"], items: [
    { key: "vascan.start", label: "Scan başlat / dayandır", fns: ["vaScanStart", "vaScanStop"] },
    { key: "vascan.export", label: "Excel hesabatı yüklə", fns: ["vaScanExcel"] },
  ]},
  { key: "berpa", label: "Qovluq Bərpası", menu: ["menuBerpa"], items: [
    { key: "berpa.start", label: "Bərpa başlat / dayandır", fns: ["berpaStart", "berpaStop"] },
    { key: "berpa.export", label: "Excel hesabatı yüklə", fns: ["berpaExcel"] },
  ]},
  { key: "jberpa", label: "Journal Bərpası", menu: ["menuJberpa"], items: [
    { key: "jberpa.start", label: "Bərpa başlat / dayandır", fns: ["jberpaStart", "jberpaStop"] },
    { key: "jberpa.export", label: "Excel hesabatı yüklə", fns: ["jberpaExcel"] },
  ]},
  { key: "deploy", label: "ATM-ə Folder Göndər", menu: ["menuDeploy"], items: [
    { key: "deploy.run", label: "Folder göndər / dayandır", fns: ["deployStart", "deployStop"] },
    { key: "deploy.export", label: "Excel hesabatı yüklə", fns: ["deployExcel"] },
  ]},
  { key: "server", label: "Server (disk gəzgini)", menu: ["menuServer"], items: [
    { key: "server.browse", label: "Server disklərini gəz / aç" },
    { key: "server.backup", label: "ATM Backup Manager (köçürmə əməliyyatı)" },
    { key: "server.move", label: "Disklər arası köçür / yerini dəyiş" },
  ]},
  { key: "monitor", label: "Foto Monitorinq", menu: ["menuMonitor"], items: [
    { key: "monitor.run", label: "Planlaşdırıcı başlat/dayandır, indi yoxla", fns: ["monitorStart", "monitorStop", "monitorRunNow"] },
    { key: "monitor.config", label: "Parametrləri / mail ayarlarını dəyiş", fns: ["monitorSaveConfig", "monitorTestMail", "monitorImport"] },
    { key: "monitor.export", label: "Excel hesabatı yüklə", fns: ["monitorExcel"] },
  ]},
  { key: "atminfo", label: "ATM Info", menu: ["menuAtmInfo"], items: [
    { key: "atminfo.query", label: "ATM-ə qoşul və məlumat al (445/135)", fns: ["atmInfoConnect"] },
    { key: "atminfo.save", label: "ATM əlavə et / düzəliş et", fns: ["atmInfoOpenEdit", "atmInfoOpenNew"] },
    { key: "atminfo.delete", label: "ATM sil / bərpa et (status)", fns: ["atmInfoDelete", "atmInfoRestore"] },
    { key: "atminfo.history", label: "Tarixçə / report", fns: ["atmInfoLoadHistory", "atmInfoViewSnapshot"] },
    { key: "atminfo.stats", label: "Statistika kartları", sel: ["#atmInfoModule .atmInfoListStats"] },
    { key: "atminfo.disks", label: "Disk cədvəli", sel: ["#atmInfoDrawer .atmInfoDisksCard"] },
  ]},
  { key: "users", label: "İstifadəçilər", menu: ["menuUsers"], items: [
    { key: "users.create", label: "İstifadəçi əlavə et" },
    { key: "users.edit", label: "Məlumatları düzəlt / giriş icazəsini dəyiş" },
    { key: "users.delete", label: "İstifadəçini sil / bərpa et (status)" },
    { key: "users.reset", label: "Şifrəni sıfırla" },
    { key: "users.perms", label: "İcazələri idarə et" },
    { key: "users.sessions", label: "Sessiyaları bitir" },
  ]},
  { key: "audit", label: "Audit log", menu: ["menuAudit"], items: [
    { key: "audit.export", label: "CSV export" },
  ]},
];
const ALL_KEYS = new Set();
for (const m of CATALOG) { ALL_KEYS.add(m.key); for (const it of m.items) ALL_KEYS.add(it.key); }

/* Python API marşrutları → tələb olunan icazə (hər hansı biri kifayətdir). Siyahıda olmayan /api yolu yalnız adminə açıqdır. */
const ANY = "*";
const ROUTES = {
  "/api/config": [ANY],
  "/api/atms": ["atminfo", "map", "inventory"],
  "/api/atms/map": ["map", "home.block.map", "home.block.kpis"],
  "/api/atms/activity": ["map", "atminfo"],
  "/api/atms/bulk_progress": ["inventory"],
  "/api/atms/save": ["atminfo.save", "inventory.save"],
  "/api/atms/delete": ["atminfo.delete", "inventory.delete"],
  "/api/atms/restore": ["atminfo.delete", "inventory.restore"],
  "/api/atms/connect": ["atminfo.query", "inventory.connect"],
  "/api/atms/bulk_start": ["inventory.bulk"],
  "/api/atms/bulk_cancel": ["inventory.bulk"],
  "/api/disk-report/progress": ["diskreport"],
  "/api/disk-report/history": ["diskreport.history"],
  "/api/disk-report/detail": ["diskreport.history"],
  "/api/disk-report/start": ["diskreport.start"],
  "/api/disk-report/cancel": ["diskreport.start"],
  "/api/system/progress": ["system"],
  "/api/system/start": ["system.start"],
  "/api/atminfo/run": ["atminfo.query"],
  "/api/atminfo/history": ["atminfo.history", "atminfo"],
  "/api/atminfo/latest": ["atminfo", "map"],
  "/api/atminfo/snapshot": ["atminfo.history", "atminfo"],
  "/api/atms/resolve-ips": ["atminfo", "map", "inventory", "system"],
  "/api/srvexp/disks": ["server"],
  "/api/srvexp/usage": ["server"],
  "/api/srvexp/list": ["server"],
  "/api/srvexp/text": ["server"],
  "/api/srvexp/media": ["server"],
  "/api/srvexp/transcode": ["server"],
  "/api/backup/config": ["server"],
  "/api/backup/status": ["server"],
  "/api/backup/history": ["server"],
  "/api/backup/discover": ["server"],
  "/api/backup/plan": ["server"],
  "/api/backup/start": ["server.backup"],
  "/api/backup/pause": ["server.backup"],
  "/api/backup/resume": ["server.backup"],
  "/api/backup/cancel": ["server.backup"],
  "/api/srvmove/list": ["server"],
  "/api/srvmove/disks": ["server"],
  "/api/srvmove/progress": ["server"],
  "/api/srvmove/start": ["server.move"],
  "/api/srvmove/cancel": ["server.move"],
  "/api/atmcopy/start": ["archive.connect", "atminfo.query"],
  "/api/atmcopy/cancel": ["archive.connect", "atminfo.query"],
  "/api/atmcopy/progress": ["archive", "atminfo"],
  "/api/explorer/list": ["archive.browse"],
  "/api/explorer/latest": ["archive.browse"],
  "/api/explorer/journal": ["archive.journal"],
  "/api/explorer/text": ["archive.journal", "archive.browse"],
  "/api/explorer/media": ["archive.media"],
  "/api/srvmedia/sources": ["videoserver"],
  "/api/srvmedia/check": ["videoserver.check"],
  "/api/srvmedia/stats": ["videoserver.check", "videoserver.browse"],
  "/api/srvmedia/list": ["videoserver.browse"],
  "/api/srvmedia/text": ["videoserver.browse"],
  "/api/srvmedia/media": ["videoserver.media"],
  "/api/srvmedia/transcode": ["videoserver.media"],
  "/api/vascan/progress": ["vascan"],
  "/api/vascan/history": ["vascan"],
  "/api/vascan/detail": ["vascan"],
  "/api/vascan/excel": ["vascan.export"],
  "/api/vascan/start": ["vascan.start"],
  "/api/vascan/cancel": ["vascan.start"],
  "/api/cmp/progress": ["backup"],
  "/api/cmp/history": ["backup"],
  "/api/cmp/detail": ["backup"],
  "/api/cmp/excel": ["backup"],
  "/api/cmp/start": ["backup.start"],
  "/api/cmp/cancel": ["backup.start"],
  "/api/ajscan/progress": ["backup"],
  "/api/ajscan/history": ["backup"],
  "/api/ajscan/detail": ["backup"],
  "/api/ajscan/excel": ["backup"],
  "/api/ajscan/start": ["backup.start"],
  "/api/ajscan/cancel": ["backup.start"],
  "/api/missdate/progress": ["backup"],
  "/api/missdate/excel": ["backup"],
  "/api/missdate/start": ["backup.start"],
  "/api/missdate/cancel": ["backup.start"],
  "/api/autobk/progress": ["backup"],
  "/api/autobk/excel": ["backup"],
  "/api/autobk/start": ["backup.start"],
  "/api/autobk/cancel": ["backup.start"],
  "/api/berpa/maps": ["berpa"],
  "/api/berpa/progress": ["berpa"],
  "/api/berpa/history": ["berpa"],
  "/api/berpa/detail": ["berpa"],
  "/api/berpa/excel": ["berpa.export"],
  "/api/berpa/start": ["berpa.start"],
  "/api/berpa/cancel": ["berpa.start"],
  "/api/jberpa/config": ["jberpa"],
  "/api/jberpa/progress": ["jberpa"],
  "/api/jberpa/history": ["jberpa"],
  "/api/jberpa/detail": ["jberpa"],
  "/api/jberpa/excel": ["jberpa.export"],
  "/api/jberpa/start": ["jberpa.start"],
  "/api/jberpa/cancel": ["jberpa.start"],
  "/api/deploy/progress": ["deploy"],
  "/api/deploy/history": ["deploy"],
  "/api/deploy/detail": ["deploy"],
  "/api/deploy/browse": ["deploy.run"],
  "/api/deploy/check-source": ["deploy.run"],
  "/api/deploy/excel": ["deploy.export"],
  "/api/deploy/start": ["deploy.run"],
  "/api/deploy/cancel": ["deploy.run"],
  "/api/monitor/status": ["monitor"],
  "/api/monitor/config": ["monitor"],
  "/api/monitor/thresholds": ["monitor"],
  "/api/monitor/history": ["monitor"],
  "/api/monitor/detail": ["monitor"],
  "/api/monitor/excel": ["monitor.export"],
  "/api/alerts/summary": ["monitor", "backup", "agent"],
  "/api/alerts/progress": ["monitor", "backup", "agent"],
  "/api/alerts/list": ["monitor", "backup", "agent"],
  "/api/alerts/config": ["monitor", "monitor.config", "backup", "backup.start"],
  "/api/alerts/run": ["monitor.run", "backup.start", "monitor"],
  "/api/alerts/scheduler": ["monitor.run", "backup.start", "monitor"],
  "/api/alerts/excel": ["monitor", "backup", "agent"],
  "/api/srvalert/summary": ["monitor", "backup", "agent"],
  "/api/srvalert/progress": ["monitor", "backup", "agent"],
  "/api/srvalert/config": ["monitor", "monitor.config", "backup", "backup.start"],
  "/api/srvalert/run": ["monitor.run", "backup.start", "monitor"],
  "/api/reports/list": ["monitor", "backup", "agent", "vascan"],
  "/api/reports/download": ["monitor", "backup", "agent", "vascan"],
  "/api/reports/delete": ["monitor.run", "backup.start", "monitor"],
  "/api/monitor/config/save": ["monitor.config"],
  "/api/monitor/thresholds/import": ["monitor.config"],
  "/api/monitor/thresholds/clear": ["monitor.config"],
  "/api/monitor/test-mail": ["monitor.config"],
  "/api/monitor/start": ["monitor.run"],
  "/api/monitor/stop": ["monitor.run"],
  "/api/monitor/run-now": ["monitor.run"],
  "/api/archive/config": ["archive"],
  "/api/archive/progress": ["archive"],
  "/api/archive/start": ["archive.connect"],
  "/api/start": ["backup.start"],
  "/api/progress": ["backup"],
  "/api/scan/cancel": ["backup.start", "restart.start", "archive.connect", "system.start", "diskreport.start", "inventory.bulk"],
  "/api/history": ["history", "home.block.recent"],
  "/api/history_detail": ["history.detail"],
  "/api/scan/excel": ["history.detail", "history", "backup"],
  "/api/compare": ["history.compare"],
  "/api/restart/config": ["restart"],
  "/api/restart/progress": ["restart"],
  "/api/restart/start": ["restart.start"],
  "/api/agent/list": ["agent"],
  "/api/sagent/list": ["agent", "monitor", "backup"],
  "/api/agent/detail": ["agent.detail"],
};
/* Audit-ə yazılmayan (polling) GET-lər — əks halda log saniyədə bir dolardı */
const QUIET_GET = /progress$|atminfo\/(latest|history|snapshot)$|^\/api\/srvmedia\/(sources|stats|media)$|^\/api\/vascan\/(progress|history|detail)$|^\/api\/(cmp|ajscan)\/(progress|history|detail)$|^\/api\/alerts\/(summary|progress|list|config)$|^\/api\/srvalert\/(summary|progress|config)$|^\/api\/reports\/list$|^\/api\/sagent\/list$|^\/api\/berpa\/(progress|history|detail|maps)$|^\/api\/jberpa\/(progress|history|detail|config)$|^\/api\/monitor\/(status|config|thresholds|history|detail)$|^\/api\/deploy\/(progress|history|detail|browse)$|^\/api\/atmcopy\/progress$|^\/api\/atms\/resolve-ips$|^\/api\/srvexp\/(disks|list)$|^\/api\/(config|me|agent\/list|atms\/(map|activity)|history|restart\/config|archive\/config|audit|users)$/;

/* ---------------- DB ---------------- */
let db;
const now = () => Math.floor(Date.now() / 1000);
const sha256 = s => crypto.createHash("sha256").update(s).digest("hex");
const b64u = b => Buffer.from(b).toString("base64url");

/* ---------------- 2FA / TOTP (RFC 6238 + RFC 4226) ---------------- */
let MFA_KEY_FILE = "", mfaKey = null;
const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
function b32encode(buf) {
  let bits = 0, val = 0, out = "";
  for (const byte of buf) { val = (val << 8) | byte; bits += 8; while (bits >= 5) { out += B32[(val >>> (bits - 5)) & 31]; bits -= 5; } }
  if (bits > 0) out += B32[(val << (5 - bits)) & 31];
  return out;
}
function b32decode(str) {
  const s = String(str || "").toUpperCase().replace(/[^A-Z2-7]/g, "");
  let bits = 0, val = 0; const out = [];
  for (const ch of s) { val = (val << 5) | B32.indexOf(ch); bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } }
  return Buffer.from(out);
}
function hotp(key, counter) {
  const msg = Buffer.alloc(8);
  msg.writeUInt32BE(Math.floor(counter / 0x100000000), 0); msg.writeUInt32BE(counter >>> 0, 4);
  const h = crypto.createHmac("sha1", key).update(msg).digest();
  const off = h[h.length - 1] & 15;
  const bin = ((h[off] & 0x7f) << 24) | (h[off + 1] << 16) | (h[off + 2] << 8) | h[off + 3];
  return String(bin % 1000000).padStart(6, "0");
}
/* Kodu yoxla: ±MFA_WINDOW addım; təkrar istifadəyə qarşı lastStep-dən böyük addım tələb olunur.
   Uğurlu olarsa istifadə olunan addımı qaytarır, əks halda -1. */
function totpCheck(secretB32, code, lastStep) {
  code = String(code || "").replace(/\s+/g, "");
  if (!/^\d{6}$/.test(code)) return -1;
  const key = b32decode(secretB32); if (key.length < 10) return -1;
  const step = Math.floor(Date.now() / 1000 / 30);
  const want = Buffer.from(code);
  let found = -1;
  for (let w = -MFA_WINDOW; w <= MFA_WINDOW; w++) {
    const st = step + w;
    const got = Buffer.from(hotp(key, st));
    if (crypto.timingSafeEqual(got, want) && st > (lastStep || 0)) found = st;   // döngü tam fırlanır (sabit vaxt)
  }
  return found;
}
function encSecret(plain) {
  if (!mfaKey) throw new Error("2FA açarı (atm_auth.key) yoxdur.");
  const iv = crypto.randomBytes(12), c = crypto.createCipheriv("aes-256-gcm", mfaKey, iv);
  const ct = Buffer.concat([c.update(String(plain), "utf8"), c.final()]);
  return "v1:" + iv.toString("base64") + ":" + c.getAuthTag().toString("base64") + ":" + ct.toString("base64");
}
function decSecret(stored) {
  if (!mfaKey || !stored) return null;
  try {
    const [v, iv, tag, ct] = String(stored).split(":");
    if (v !== "v1") return null;
    const d = crypto.createDecipheriv("aes-256-gcm", mfaKey, Buffer.from(iv, "base64"));
    d.setAuthTag(Buffer.from(tag, "base64"));
    return Buffer.concat([d.update(Buffer.from(ct, "base64")), d.final()]).toString("utf8");
  } catch { return null; }
}
const otpauthUri = (secret, username) =>
  `otpauth://totp/${encodeURIComponent(MFA_ISSUER)}:${encodeURIComponent(username)}?secret=${secret}&issuer=${encodeURIComponent(MFA_ISSUER)}&algorithm=SHA1&digits=6&period=30`;
/* Şifrədən sonra, kod təsdiqlənənə qədər gözləyən "challenge"lar (yaddaşda, tək istifadəlik) */
const MFA_PENDING = new Map();
setInterval(() => { const t = now(); for (const [k, v] of MFA_PENDING) if (v.exp <= t) MFA_PENDING.delete(k); }, 60000).unref();
const mfaCookie = (v, age) => `atm_mfa=${v}; Path=/api/auth; Max-Age=${age}; HttpOnly; SameSite=Strict` + (COOKIE_SECURE ? "; Secure" : "");

function init(rootDir) {
  db = new DatabaseSync(path.join(rootDir, "atm_auth.db"));
  db.exec(`
    PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA foreign_keys=ON;
    CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      first_name TEXT NOT NULL DEFAULT '', last_name TEXT NOT NULL DEFAULT '',
      position TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '',
      status INTEGER NOT NULL DEFAULT 1,            -- 0 = silinib
      login_allowed INTEGER NOT NULL DEFAULT 1,     -- 0 = sistemə giriş icazəsi yoxdur
      is_admin INTEGER NOT NULL DEFAULT 0,
      must_change_password INTEGER NOT NULL DEFAULT 0,
      perms TEXT NOT NULL DEFAULT '{}',
      failed_attempts INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0,
      last_login_at INTEGER, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, created_by INTEGER);
    CREATE TABLE IF NOT EXISTS sessions(
      id TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
      token_hash TEXT NOT NULL, prev_hash TEXT, rotated_at INTEGER,
      created_at INTEGER NOT NULL, last_used_at INTEGER NOT NULL, expires_at INTEGER NOT NULL,
      revoked_at INTEGER, revoke_reason TEXT, ip TEXT, ua TEXT);
    CREATE INDEX IF NOT EXISTS ix_sessions_user ON sessions(user_id);
    CREATE TABLE IF NOT EXISTS audit(
      id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL,
      user_id INTEGER, username TEXT, type TEXT NOT NULL, module TEXT, action TEXT, detail TEXT,
      method TEXT, path TEXT, status INTEGER, ip TEXT, ua TEXT, session_id TEXT);
    CREATE INDEX IF NOT EXISTS ix_audit_ts ON audit(ts);
    CREATE INDEX IF NOT EXISTS ix_audit_user ON audit(user_id, ts);
  `);
  if (!db.prepare("SELECT value FROM meta WHERE key='jwt_secret'").get())
    db.prepare("INSERT INTO meta(key,value) VALUES('jwt_secret',?)").run(crypto.randomBytes(48).toString("hex"));
  // ---- 2FA miqrasiyası (köhnə bazalar üçün sütunlar əlavə olunur) ----
  const ucols = new Set(db.prepare("PRAGMA table_info(users)").all().map(c => c.name));
  if (!ucols.has("totp_secret")) db.exec("ALTER TABLE users ADD COLUMN totp_secret TEXT");
  if (!ucols.has("totp_enabled")) db.exec("ALTER TABLE users ADD COLUMN totp_enabled INTEGER NOT NULL DEFAULT 0");
  if (!ucols.has("totp_last_step")) db.exec("ALTER TABLE users ADD COLUMN totp_last_step INTEGER NOT NULL DEFAULT 0");
  if (!ucols.has("totp_enrolled_at")) db.exec("ALTER TABLE users ADD COLUMN totp_enrolled_at INTEGER");
  const scols = new Set(db.prepare("PRAGMA table_info(sessions)").all().map(c => c.name));
  if (!scols.has("mfa")) db.exec("ALTER TABLE sessions ADD COLUMN mfa INTEGER NOT NULL DEFAULT 0");
  // TOTP sirləri bazada AES-256-GCM ilə şifrələnir; açar ayrıca faylda saxlanılır (baza tək sızsa sirlər açılmasın)
  MFA_KEY_FILE = path.join(rootDir, "atm_auth.key");
  try {
    if (!fs.existsSync(MFA_KEY_FILE)) fs.writeFileSync(MFA_KEY_FILE, crypto.randomBytes(32).toString("hex"), { encoding: "utf8", mode: 0o600 });
    const hex = fs.readFileSync(MFA_KEY_FILE, "utf8").trim();
    if (!/^[0-9a-f]{64}$/i.test(hex)) throw new Error("atm_auth.key formatı yanlışdır");
    mfaKey = Buffer.from(hex, "hex");
  } catch (e) {
    console.error("[AUTH] 2FA açarı (atm_auth.key) oxunmadı:", e.message);
    mfaKey = null;
  }
  if (MFA_ON) console.log("[AUTH] İki mərhələli təsdiq (TOTP) AKTİVDİR.");
  else console.warn("[AUTH] DİQQƏT: İki mərhələli təsdiq SÖNDÜRÜLÜB (ATM_2FA=0).");
  const n = db.prepare("SELECT COUNT(*) c FROM users").get().c;
  if (!n) {
    const pw = genPassword();
    const t = now();
    db.prepare("INSERT INTO users(username,password_hash,first_name,last_name,position,is_admin,must_change_password,created_at,updated_at) VALUES('admin',?,?,?,?,1,1,?,?)")
      .run(hashPassword(pw), "Sistem", "Administratoru", "Administrator", t, t);
    const file = path.join(rootDir, "ILK_ADMIN_SIFRE.txt");
    try { fs.writeFileSync(file, `ATM WEB ilk giriş\r\nİstifadəçi adı: admin\r\nMüvəqqəti şifrə: ${pw}\r\n\r\nİlk girişdə şifrəni dəyişmək məcburidir. Girişdən sonra bu faylı SİLİN.\r\n`, "utf8"); } catch {}
    console.log("\n[AUTH] İlk administrator yaradıldı →  istifadəçi: admin   müvəqqəti şifrə: " + pw);
    console.log("[AUTH] Şifrə həmçinin ILK_ADMIN_SIFRE.txt faylına yazıldı (girişdən sonra silin).\n");
  }
  cleanup();
  setInterval(cleanup, 6 * 3600 * 1000).unref();
}
function cleanup() {
  try {
    db.prepare("DELETE FROM audit WHERE ts < ?").run(now() - AUDIT_DAYS * 86400);
    db.prepare("DELETE FROM sessions WHERE expires_at < ? OR (revoked_at IS NOT NULL AND revoked_at < ?)").run(now() - 86400, now() - 7 * 86400);
  } catch (e) { console.error("[AUTH] cleanup:", e.message); }
}
const jwtSecret = () => db.prepare("SELECT value FROM meta WHERE key='jwt_secret'").get().value;

/* ---------------- Şifrə ---------------- */
function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const N = 16384, r = 8, p = 1;
  const h = crypto.scryptSync(String(pw), salt, 64, { N, r, p });
  return `scrypt$${N}$${r}$${p}$${salt.toString("base64")}$${h.toString("base64")}`;
}
function verifyPassword(pw, stored) {
  try {
    const [alg, N, r, p, salt, hash] = String(stored).split("$");
    if (alg !== "scrypt") return false;
    const want = Buffer.from(hash, "base64");
    const got = crypto.scryptSync(String(pw), Buffer.from(salt, "base64"), want.length, { N: +N, r: +r, p: +p });
    return crypto.timingSafeEqual(want, got);
  } catch { return false; }
}
const DUMMY_HASH = hashPassword(crypto.randomBytes(8).toString("hex"));
function genPassword() {
  const A = "ABCDEFGHJKMNPQRSTUVWXYZ", a = "abcdefghjkmnpqrstuvwxyz", d = "23456789";
  const pick = s => s[crypto.randomInt(s.length)];
  const out = [pick(A), pick(a), pick(d)];
  const all = A + a + d;
  while (out.length < 12) out.push(pick(all));
  for (let i = out.length - 1; i > 0; i--) { const j = crypto.randomInt(i + 1); [out[i], out[j]] = [out[j], out[i]]; }
  return out.join("");
}
function passwordProblem(pw, username) {
  pw = String(pw || "");
  if (pw.length < 8) return "Şifrə ən azı 8 simvol olmalıdır.";
  if (pw.length > 128) return "Şifrə çox uzundur.";
  if (!/[A-Za-zƏəÖöÜüĞğÇçŞşİı]/.test(pw) || !/\d/.test(pw)) return "Şifrədə ən azı bir hərf və bir rəqəm olmalıdır.";
  if (username && pw.toLowerCase() === String(username).toLowerCase()) return "Şifrə istifadəçi adı ilə eyni ola bilməz.";
  return null;
}

/* ---------------- JWT + cookie ---------------- */
function signAccess(uid, sid) {
  const iat = now(), exp = iat + ACCESS_TTL;
  const body = b64u(JSON.stringify({ alg: "HS256", typ: "JWT" })) + "." + b64u(JSON.stringify({ uid, sid, iat, exp }));
  const sig = crypto.createHmac("sha256", jwtSecret()).update(body).digest("base64url");
  return { token: body + "." + sig, exp };
}
function verifyAccess(token) {
  const parts = String(token || "").split(".");
  if (parts.length !== 3) return null;
  const want = crypto.createHmac("sha256", jwtSecret()).update(parts[0] + "." + parts[1]).digest();
  let got; try { got = Buffer.from(parts[2], "base64url"); } catch { return null; }
  if (got.length !== want.length || !crypto.timingSafeEqual(got, want)) return null;
  let p; try { p = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8")); } catch { return null; }
  if (!p || typeof p.exp !== "number" || p.exp <= now()) return null;
  return p;
}
function parseCookies(req) {
  const out = {};
  String(req.headers.cookie || "").split(";").forEach(part => {
    const i = part.indexOf("="); if (i < 0) return;
    out[part.slice(0, i).trim()] = part.slice(i + 1).trim();
  });
  return out;
}
const cookieAttrs = () => "; HttpOnly; SameSite=Strict" + (COOKIE_SECURE ? "; Secure" : "");
const accessCookie = t => `atm_at=${t}; Path=/; Max-Age=${ACCESS_TTL}${cookieAttrs()}`;
const refreshCookie = t => `atm_rt=${t}; Path=/api/auth; Max-Age=${REFRESH_TTL}${cookieAttrs()}`;
const clearCookies = () => [`atm_at=; Path=/; Max-Age=0${cookieAttrs()}`, `atm_rt=; Path=/api/auth; Max-Age=0${cookieAttrs()}`];

/* ---------------- Yardımçılar ---------------- */
function clientIp(req) { return String(req.socket.remoteAddress || "").replace(/^::ffff:/, ""); }
function sendJson(res, status, obj, cookies) {
  const headers = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };
  if (cookies && cookies.length) headers["Set-Cookie"] = cookies;
  res.writeHead(status, headers);
  res.end(JSON.stringify(obj));
}
function readBody(req, limit = 262144) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on("data", c => { size += c.length; if (size > limit) { reject(new Error("Sorğu çox böyükdür.")); req.destroy(); } else chunks.push(c); });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}
async function readJson(req) {
  const buf = await readBody(req);
  if (!buf.length) return {};
  try { const v = JSON.parse(buf.toString("utf8")); return v && typeof v === "object" ? v : {}; } catch { throw new Error("JSON formatı yanlışdır."); }
}
const clip = (s, n) => { s = s == null ? "" : String(s); return s.length > n ? s.slice(0, n) + "…" : s; };
function audit(e) {
  try {
    db.prepare("INSERT INTO audit(ts,user_id,username,type,module,action,detail,method,path,status,ip,ua,session_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)")
      .run(now(), e.user_id ?? null, e.username ?? null, e.type, e.module ?? null, clip(e.action, 120) || null, clip(e.detail, 600) || null,
        e.method ?? null, clip(e.path, 300) || null, e.status ?? null, e.ip ?? null, clip(e.ua, 200) || null, e.sid ?? null);
  } catch (err) { console.error("[AUTH] audit:", err.message); }
}
function auditCtx(req, ctx, e) {
  audit({ user_id: ctx && ctx.user.id, username: ctx && ctx.user.username, sid: ctx && ctx.sid, ip: clientIp(req), ua: req.headers["user-agent"], method: req.method, path: (req.url || "").split("?")[0], ...e });
}
function redact(obj) {
  if (!obj || typeof obj !== "object") return obj;
  const out = Array.isArray(obj) ? [] : {};
  for (const [k, v] of Object.entries(obj)) out[k] = /pass|secret|token|şifrə|sifre/i.test(k) ? "***" : (v && typeof v === "object" ? redact(v) : v);
  return out;
}

/* ---------------- İcazələr ---------------- */
function normPerms(raw) {
  let p = raw; if (typeof p === "string") { try { p = JSON.parse(p); } catch { p = {}; } }
  if (!p || typeof p !== "object") p = {};
  const allow = [...new Set((Array.isArray(p.allow) ? p.allow : []).filter(k => ALL_KEYS.has(k)))];
  const hideCols = {};
  if (p.hideCols && typeof p.hideCols === "object") {
    for (const [k, v] of Object.entries(p.hideCols).slice(0, 80)) {
      if (!Array.isArray(v) || !v.length) continue;
      hideCols[clip(k, 80)] = [...new Set(v.map(x => clip(x, 60)).filter(Boolean))].slice(0, 80);
    }
  }
  return { allow, hideCols };
}
function can(ctx, key) {
  if (!ctx) return false;
  if (ctx.user.is_admin) return true;
  if (key === ANY) return true;
  const set = ctx.allowSet;
  return set.has(key) && set.has(key.split(".")[0]);
}
const canAny = (ctx, keys) => keys.some(k => can(ctx, k));

/* ---------------- Sessiya ---------------- */
function authenticate(req) {
  const p = verifyAccess(parseCookies(req).atm_at);
  if (!p) return null;
  const s = db.prepare("SELECT id,user_id,revoked_at,expires_at,mfa FROM sessions WHERE id=?").get(String(p.sid));
  if (!s || s.revoked_at || s.expires_at <= now() || s.user_id !== p.uid) return null;
  if (MFA_ON && !s.mfa) return null;            // 2FA tətbiq olunmazdan əvvəlki sessiyalar etibarsızdır
  const u = db.prepare("SELECT * FROM users WHERE id=?").get(p.uid);
  if (!u || !u.status || !u.login_allowed) return null;
  const perms = normPerms(u.perms);
  return { user: u, sid: s.id, exp: p.exp, perms, allowSet: new Set(perms.allow) };
}
function createSession(req, user, mfa) {
  const sid = crypto.randomBytes(16).toString("hex");
  const secret = crypto.randomBytes(32).toString("base64url");
  const t = now();
  db.prepare("INSERT INTO sessions(id,user_id,token_hash,created_at,last_used_at,expires_at,ip,ua,mfa) VALUES(?,?,?,?,?,?,?,?,?)")
    .run(sid, user.id, sha256(secret), t, t, t + REFRESH_TTL, clientIp(req), clip(req.headers["user-agent"], 200), mfa ? 1 : 0);
  const a = signAccess(user.id, sid);
  return { sid, exp: a.exp, cookies: [accessCookie(a.token), refreshCookie(sid + "." + secret)] };
}
function revokeUserSessions(userId, reason, exceptSid) {
  db.prepare("UPDATE sessions SET revoked_at=?, revoke_reason=? WHERE user_id=? AND revoked_at IS NULL AND id<>?").run(now(), reason, userId, exceptSid || "");
}
function publicUser(u) {
  return { id: u.id, username: u.username, first_name: u.first_name, last_name: u.last_name, position: u.position, phone: u.phone,
    status: !!u.status, login_allowed: !!u.login_allowed, is_admin: !!u.is_admin, must_change_password: !!u.must_change_password,
    last_login_at: u.last_login_at, created_at: u.created_at, updated_at: u.updated_at, locked: u.locked_until > now(),
    mfa_enabled: !!u.totp_enabled, mfa_enrolled_at: u.totp_enrolled_at || null };
}
function mePayload(ctx) {
  return { success: true, user: publicUser(ctx.user), perms: ctx.perms, access_expires_at: ctx.exp, server_time: now(),
    access_ttl: ACCESS_TTL, refresh_ttl: REFRESH_TTL, mfa_on: MFA_ON, catalog: CATALOG };
}

/* ---------------- /api/auth/* ---------------- */
async function handleLogin(req, res) {
  const b = await readJson(req);
  const username = String(b.username || "").trim(), password = String(b.password || "");
  const fail = (status, error, action, user) => {
    audit({ type: "auth", action, detail: "istifadəçi adı: " + clip(username, 40), user_id: user && user.id, username: user ? user.username : clip(username, 40), status, ip: clientIp(req), ua: req.headers["user-agent"], method: "POST", path: "/api/auth/login" });
    sendJson(res, status, { success: false, error });
  };
  if (!username || !password) return sendJson(res, 400, { success: false, error: "İstifadəçi adı və şifrə daxil edin." });
  const u = db.prepare("SELECT * FROM users WHERE username=?").get(username);
  if (!u) { verifyPassword(password, DUMMY_HASH); return fail(401, "İstifadəçi adı və ya şifrə yanlışdır.", "login_fail_unknown_user"); }
  if (u.locked_until > now()) {
    const min = Math.ceil((u.locked_until - now()) / 60);
    return fail(429, `Çox sayda uğursuz cəhd. ${min} dəqiqə sonra yenidən cəhd edin.`, "login_locked", u);
  }
  if (!verifyPassword(password, u.password_hash)) {
    const fails = u.failed_attempts + 1;
    if (fails >= MAX_FAILS) db.prepare("UPDATE users SET failed_attempts=0, locked_until=? WHERE id=?").run(now() + LOCK_SECONDS, u.id);
    else db.prepare("UPDATE users SET failed_attempts=? WHERE id=?").run(fails, u.id);
    return fail(401, "İstifadəçi adı və ya şifrə yanlışdır.", "login_fail_bad_password", u);
  }
  // Hesabın vəziyyəti yalnız düzgün şifrədən sonra açıqlanır (kənar şəxs hesabın mövcudluğunu öyrənə bilməsin)
  if (!u.status) return fail(403, "Bu istifadəçi silinib.", "login_denied_deleted", u);
  if (!u.login_allowed) return fail(403, "Sistemə giriş icazəniz yoxdur.", "login_denied_no_access", u);
  if (MFA_ON) return startMfa(req, res, u);       // şifrə düzgündür → ikinci mərhələ (sessiya hələ YARANMIR)
  finishLogin(req, res, u, false, "");
}
function finishLogin(req, res, u, mfa, how) {
  db.prepare("UPDATE users SET failed_attempts=0, locked_until=0, last_login_at=? WHERE id=?").run(now(), u.id);
  const s = createSession(req, u, mfa);
  audit({ type: "auth", action: "login", detail: how || null, user_id: u.id, username: u.username, sid: s.sid, status: 200, ip: clientIp(req), ua: req.headers["user-agent"], method: "POST", path: "/api/auth/login" });
  const cookies = s.cookies.concat(mfa ? [mfaCookie("", 0)] : []);
  sendJson(res, 200, { success: true, must_change_password: !!u.must_change_password, access_expires_at: s.exp }, cookies);
}
/* Şifrədən sonra: qurulubsa kod istənilir, qurulmayıbsa QR ilə ilk qeydiyyat. */
function startMfa(req, res, u) {
  const id = crypto.randomBytes(32).toString("base64url");
  const setup = !u.totp_enabled || !u.totp_secret;
  if (!setup && !decSecret(u.totp_secret)) {
    audit({ type: "auth", action: "mfa_key_error", detail: "TOTP sirri açılmadı (atm_auth.key?)", user_id: u.id, username: u.username, status: 500, ip: clientIp(req), ua: req.headers["user-agent"], method: "POST", path: "/api/auth/login" });
    return sendJson(res, 500, { success: false, error: "İki mərhələli təsdiq açarı oxunmadı. Administrator 2FA-nı sıfırlamalıdır." });
  }
  if (setup && !mfaKey) return sendJson(res, 500, { success: false, error: "2FA açarı (atm_auth.key) yaradıla bilmədi. Administratorla əlaqə saxlayın." });
  const ch = { uid: u.id, exp: now() + MFA_TTL, tries: 0, ip: clientIp(req), setup };
  if (setup) ch.secret = b32encode(crypto.randomBytes(20));          // 160-bit sirr, yalnız təsdiqdən sonra bazaya yazılır
  MFA_PENDING.set(sha256(id), ch);
  audit({ type: "auth", action: setup ? "mfa_setup_start" : "mfa_challenge", user_id: u.id, username: u.username, status: 200, ip: clientIp(req), ua: req.headers["user-agent"], method: "POST", path: "/api/auth/login" });
  const out = { success: true, mfa_required: true, mfa_setup: setup, expires_in: MFA_TTL, issuer: MFA_ISSUER, account: u.username };
  if (setup) { out.secret = ch.secret; out.otpauth_uri = otpauthUri(ch.secret, u.username); }
  sendJson(res, 200, out, [mfaCookie(id, MFA_TTL)]);
}
async function handleMfa(req, res) {
  const b = await readJson(req);
  const raw = parseCookies(req).atm_mfa || "";
  const key = raw ? sha256(raw) : "";
  const ch = key && MFA_PENDING.get(key);
  const expired = () => sendJson(res, 401, { success: false, error: "Təsdiq vaxtı bitdi. Yenidən daxil olun.", code: "MFA_EXPIRED" }, [mfaCookie("", 0)]);
  if (!ch || ch.exp <= now()) { if (key) MFA_PENDING.delete(key); return expired(); }
  if (ch.ip !== clientIp(req)) { MFA_PENDING.delete(key); return expired(); }      // başqa ünvandan istifadə edilə bilməz
  const u = db.prepare("SELECT * FROM users WHERE id=?").get(ch.uid);
  if (!u || !u.status || !u.login_allowed) { MFA_PENDING.delete(key); return expired(); }
  const meta = { user_id: u.id, username: u.username, ip: clientIp(req), ua: req.headers["user-agent"], method: "POST", path: "/api/auth/mfa" };
  if (u.locked_until > now()) {
    MFA_PENDING.delete(key);
    const min = Math.ceil((u.locked_until - now()) / 60);
    audit({ type: "auth", action: "mfa_locked", status: 429, ...meta });
    return sendJson(res, 429, { success: false, error: `Çox sayda uğursuz cəhd. ${min} dəqiqə sonra yenidən cəhd edin.`, code: "MFA_EXPIRED" }, [mfaCookie("", 0)]);
  }
  const secret = ch.setup ? ch.secret : decSecret(u.totp_secret);
  const step = secret ? totpCheck(secret, b.code, ch.setup ? 0 : u.totp_last_step) : -1;
  if (step < 0) {
    ch.tries++;
    const fails = u.failed_attempts + 1;
    if (fails >= MAX_FAILS) db.prepare("UPDATE users SET failed_attempts=0, locked_until=? WHERE id=?").run(now() + LOCK_SECONDS, u.id);
    else db.prepare("UPDATE users SET failed_attempts=? WHERE id=?").run(fails, u.id);
    audit({ type: "auth", action: ch.setup ? "mfa_setup_fail" : "mfa_fail", detail: `cəhd ${ch.tries}/${MFA_MAX_TRIES}`, status: 401, ...meta });
    if (ch.tries >= MFA_MAX_TRIES || fails >= MAX_FAILS) {
      MFA_PENDING.delete(key);
      return sendJson(res, 401, { success: false, error: "Kod dəfələrlə yanlış daxil edildi. Yenidən daxil olun.", code: "MFA_EXPIRED" }, [mfaCookie("", 0)]);
    }
    return sendJson(res, 401, { success: false, error: "Kod yanlışdır və ya vaxtı keçib. Tətbiqdəki yeni kodu daxil edin.", tries_left: MFA_MAX_TRIES - ch.tries });
  }
  MFA_PENDING.delete(key);                           // tək istifadəlik
  if (ch.setup) {
    db.prepare("UPDATE users SET totp_secret=?, totp_enabled=1, totp_last_step=?, totp_enrolled_at=?, updated_at=? WHERE id=?")
      .run(encSecret(ch.secret), step, now(), now(), u.id);
    audit({ type: "auth", action: "mfa_enrolled", detail: "Authenticator qeydiyyatdan keçdi", status: 200, ...meta });
  } else {
    db.prepare("UPDATE users SET totp_last_step=? WHERE id=?").run(step, u.id);
  }
  finishLogin(req, res, db.prepare("SELECT * FROM users WHERE id=?").get(u.id), true, ch.setup ? "2FA qeydiyyat + giriş" : "2FA ilə giriş");
}
function handleRefresh(req, res) {
  const raw = parseCookies(req).atm_rt || "";
  const dot = raw.indexOf(".");
  const deny = () => sendJson(res, 401, { success: false, error: "Sessiya bitib. Yenidən daxil olun.", code: "SESSION_EXPIRED" }, clearCookies());
  if (dot < 1) return deny();
  const sid = raw.slice(0, dot), h = sha256(raw.slice(dot + 1));
  const s = db.prepare("SELECT * FROM sessions WHERE id=?").get(sid);
  if (!s || s.revoked_at || s.expires_at <= now()) return deny();
  if (MFA_ON && !s.mfa) return deny();
  const u = db.prepare("SELECT * FROM users WHERE id=?").get(s.user_id);
  if (!u || !u.status || !u.login_allowed) { revokeUserSessions(s.user_id, "user_disabled"); return deny(); }
  const t = now();
  if (h === s.token_hash) {
    const secret = crypto.randomBytes(32).toString("base64url");
    db.prepare("UPDATE sessions SET prev_hash=token_hash, token_hash=?, rotated_at=?, last_used_at=?, expires_at=? WHERE id=?").run(sha256(secret), t, t, t + REFRESH_TTL, sid);
    const a = signAccess(u.id, sid);
    return sendJson(res, 200, { success: true, access_expires_at: a.exp }, [accessCookie(a.token), refreshCookie(sid + "." + secret)]);
  }
  if (s.prev_hash && h === s.prev_hash) {
    if (t - (s.rotated_at || 0) <= ROTATE_GRACE) {           // paralel tab: yeni refresh cookie artıq digər cavabla yazılıb
      const a = signAccess(u.id, sid);
      return sendJson(res, 200, { success: true, access_expires_at: a.exp }, [accessCookie(a.token)]);
    }
    db.prepare("UPDATE sessions SET revoked_at=?, revoke_reason='refresh_reuse' WHERE id=?").run(t, sid);
    audit({ type: "auth", action: "refresh_token_reuse", detail: "Köhnə refresh token təkrar istifadə edildi — sessiya ləğv olundu", user_id: u.id, username: u.username, sid, status: 401, ip: clientIp(req), ua: req.headers["user-agent"], method: "POST", path: "/api/auth/refresh" });
  }
  return deny();
}
function handleLogout(req, res) {
  const ctx = authenticate(req);
  const raw = parseCookies(req).atm_rt || "";
  const sid = ctx ? ctx.sid : raw.slice(0, Math.max(0, raw.indexOf(".")));
  if (sid) db.prepare("UPDATE sessions SET revoked_at=?, revoke_reason='logout' WHERE id=? AND revoked_at IS NULL").run(now(), sid);
  if (ctx) auditCtx(req, ctx, { type: "auth", action: "logout", status: 200 });
  const mc = parseCookies(req).atm_mfa;                 // yarımçıq 2FA mərhələsini də ləğv et
  if (mc) MFA_PENDING.delete(sha256(String(mc)));
  sendJson(res, 200, { success: true }, clearCookies().concat([mfaCookie("", 0)]));
}
async function handleChangePassword(req, res, ctx) {
  const b = await readJson(req);
  if (!verifyPassword(String(b.current || ""), ctx.user.password_hash)) {
    auditCtx(req, ctx, { type: "auth", action: "password_change_fail", status: 400 });
    return sendJson(res, 400, { success: false, error: "Cari şifrə yanlışdır." });
  }
  const problem = passwordProblem(b.password, ctx.user.username);
  if (problem) return sendJson(res, 400, { success: false, error: problem });
  if (String(b.password) === String(b.current)) return sendJson(res, 400, { success: false, error: "Yeni şifrə köhnə ilə eyni ola bilməz." });
  db.prepare("UPDATE users SET password_hash=?, must_change_password=0, updated_at=? WHERE id=?").run(hashPassword(b.password), now(), ctx.user.id);
  revokeUserSessions(ctx.user.id, "password_change", ctx.sid);
  auditCtx(req, ctx, { type: "auth", action: "password_change", status: 200 });
  sendJson(res, 200, { success: true });
}

/* ---------------- /api/users/* ---------------- */
const activeAdmins = exceptId => db.prepare("SELECT COUNT(*) c FROM users WHERE is_admin=1 AND status=1 AND login_allowed=1 AND id<>?").get(exceptId || 0).c;
function getTarget(res, id) {
  const u = db.prepare("SELECT * FROM users WHERE id=?").get(Number(id) || 0);
  if (!u) { sendJson(res, 404, { success: false, error: "İstifadəçi tapılmadı." }); return null; }
  return u;
}
function guardAdminTarget(res, ctx, target) {
  if (target.is_admin && !ctx.user.is_admin) { sendJson(res, 403, { success: false, error: "Administrator hesabını yalnız administrator dəyişə bilər." }); return false; }
  return true;
}
function usersList(req, res) {
  const rows = db.prepare("SELECT * FROM users ORDER BY status DESC, username").all();
  const sess = Object.fromEntries(db.prepare("SELECT user_id, COUNT(*) c FROM sessions WHERE revoked_at IS NULL AND expires_at>? GROUP BY user_id").all(now()).map(r => [r.user_id, r.c]));
  sendJson(res, 200, { success: true, users: rows.map(u => ({ ...publicUser(u), perms: normPerms(u.perms), sessions: sess[u.id] || 0 })) });
}
async function usersSave(req, res, ctx) {
  const b = await readJson(req);
  const id = Number(b.id) || 0;
  const f = {
    username: String(b.username || "").trim(), first_name: clip(String(b.first_name || "").trim(), 60), last_name: clip(String(b.last_name || "").trim(), 60),
    position: clip(String(b.position || "").trim(), 80), phone: clip(String(b.phone || "").trim(), 30),
    login_allowed: b.login_allowed === false || b.login_allowed === 0 ? 0 : 1, is_admin: b.is_admin ? 1 : 0,
  };
  if (!/^[A-Za-z0-9._-]{3,32}$/.test(f.username)) return sendJson(res, 400, { success: false, error: "İstifadəçi adı 3–32 simvol olmalı, yalnız latın hərfi, rəqəm, nöqtə, _ və - ola bilər." });
  if (!f.first_name || !f.last_name) return sendJson(res, 400, { success: false, error: "Ad və soyad məcburidir." });
  if (f.phone && !/^[0-9+()\-\s]{5,30}$/.test(f.phone)) return sendJson(res, 400, { success: false, error: "Telefon nömrəsi yanlış formatdadır." });
  if (f.is_admin && !ctx.user.is_admin) return sendJson(res, 403, { success: false, error: "Administrator hüququnu yalnız administrator verə bilər." });
  const dup = db.prepare("SELECT id FROM users WHERE username=?").get(f.username);
  if (dup && dup.id !== id) return sendJson(res, 409, { success: false, error: "Bu istifadəçi adı artıq mövcuddur." });
  const t = now();
  if (!id) {
    if (!can(ctx, "users.create")) return forbid(req, res, ctx, "users.create");
    let pw = String(b.password || ""), generated = false;
    if (!pw) { pw = genPassword(); generated = true; }
    const problem = passwordProblem(pw, f.username);
    if (problem) return sendJson(res, 400, { success: false, error: problem });
    const r = db.prepare("INSERT INTO users(username,password_hash,first_name,last_name,position,phone,login_allowed,is_admin,must_change_password,perms,created_at,updated_at,created_by) VALUES(?,?,?,?,?,?,?,?,1,?,?,?,?)")
      .run(f.username, hashPassword(pw), f.first_name, f.last_name, f.position, f.phone, f.login_allowed, f.is_admin, JSON.stringify({ allow: ["home"], hideCols: {} }), t, t, ctx.user.id);
    auditCtx(req, ctx, { type: "admin", module: "users", action: "user_create", detail: `${f.username} (${f.first_name} ${f.last_name}, ${f.position || "-"})`, status: 200 });
    return sendJson(res, 200, { success: true, id: Number(r.lastInsertRowid), temp_password: generated ? pw : undefined });
  }
  if (!can(ctx, "users.edit")) return forbid(req, res, ctx, "users.edit");
  const target = getTarget(res, id); if (!target) return;
  if (!guardAdminTarget(res, ctx, target)) return;
  if (target.id === ctx.user.id && (!f.login_allowed || (target.is_admin && !f.is_admin)))
    return sendJson(res, 400, { success: false, error: "Öz giriş icazənizi və ya admin hüququnuzu ləğv edə bilməzsiniz." });
  if (target.is_admin && target.status && target.login_allowed && (!f.is_admin || !f.login_allowed) && !activeAdmins(target.id))
    return sendJson(res, 400, { success: false, error: "Sistemdə ən azı bir aktiv administrator qalmalıdır." });
  db.prepare("UPDATE users SET username=?,first_name=?,last_name=?,position=?,phone=?,login_allowed=?,is_admin=?,updated_at=? WHERE id=?")
    .run(f.username, f.first_name, f.last_name, f.position, f.phone, f.login_allowed, f.is_admin, t, id);
  if (!f.login_allowed) revokeUserSessions(id, "login_disabled");
  const changes = ["username", "first_name", "last_name", "position", "phone", "login_allowed", "is_admin"].filter(k => String(target[k]) !== String(f[k])).map(k => `${k}: ${target[k]} → ${f[k]}`);
  auditCtx(req, ctx, { type: "admin", module: "users", action: "user_edit", detail: `${target.username}: ${changes.join("; ") || "dəyişiklik yoxdur"}`, status: 200 });
  sendJson(res, 200, { success: true, id });
}
async function usersStatus(req, res, ctx) {
  const b = await readJson(req);
  const target = getTarget(res, b.id); if (!target) return;
  if (!guardAdminTarget(res, ctx, target)) return;
  const status = b.status ? 1 : 0;
  if (!status && target.id === ctx.user.id) return sendJson(res, 400, { success: false, error: "Öz hesabınızı silə bilməzsiniz." });
  if (!status && target.is_admin && target.login_allowed && !activeAdmins(target.id)) return sendJson(res, 400, { success: false, error: "Sistemdə ən azı bir aktiv administrator qalmalıdır." });
  db.prepare("UPDATE users SET status=?, updated_at=? WHERE id=?").run(status, now(), target.id);
  if (!status) revokeUserSessions(target.id, "user_deleted");
  auditCtx(req, ctx, { type: "admin", module: "users", action: status ? "user_restore" : "user_delete", detail: target.username, status: 200 });
  sendJson(res, 200, { success: true });
}
async function usersAccess(req, res, ctx) {
  const b = await readJson(req);
  const target = getTarget(res, b.id); if (!target) return;
  if (!guardAdminTarget(res, ctx, target)) return;
  const allowed = b.login_allowed ? 1 : 0;
  if (!allowed && target.id === ctx.user.id) return sendJson(res, 400, { success: false, error: "Öz giriş icazənizi ləğv edə bilməzsiniz." });
  if (!allowed && target.is_admin && target.status && !activeAdmins(target.id)) return sendJson(res, 400, { success: false, error: "Sistemdə ən azı bir aktiv administrator qalmalıdır." });
  db.prepare("UPDATE users SET login_allowed=?, updated_at=? WHERE id=?").run(allowed, now(), target.id);
  if (!allowed) revokeUserSessions(target.id, "login_disabled");
  auditCtx(req, ctx, { type: "admin", module: "users", action: allowed ? "login_allow" : "login_deny", detail: target.username, status: 200 });
  sendJson(res, 200, { success: true });
}
async function usersReset(req, res, ctx) {
  const b = await readJson(req);
  const target = getTarget(res, b.id); if (!target) return;
  if (!guardAdminTarget(res, ctx, target)) return;
  let pw = String(b.password || ""), generated = false;
  if (!pw) { pw = genPassword(); generated = true; }
  const problem = passwordProblem(pw, target.username);
  if (problem) return sendJson(res, 400, { success: false, error: problem });
  db.prepare("UPDATE users SET password_hash=?, must_change_password=1, failed_attempts=0, locked_until=0, updated_at=? WHERE id=?").run(hashPassword(pw), now(), target.id);
  revokeUserSessions(target.id, "password_reset", target.id === ctx.user.id ? ctx.sid : "");
  auditCtx(req, ctx, { type: "admin", module: "users", action: "password_reset", detail: target.username, status: 200 });
  sendJson(res, 200, { success: true, temp_password: generated ? pw : undefined });
}
async function usersPerms(req, res, ctx) {
  const b = await readJson(req);
  const target = getTarget(res, b.id); if (!target) return;
  if (!guardAdminTarget(res, ctx, target)) return;
  const next = normPerms(b.perms), prev = normPerms(target.perms);
  if (!ctx.user.is_admin) {
    if (target.id === ctx.user.id) return sendJson(res, 403, { success: false, error: "Öz icazələrinizi dəyişə bilməzsiniz." });
    const prevSet = new Set(prev.allow);
    const extra = next.allow.filter(k => !prevSet.has(k) && !can(ctx, k));
    if (extra.length) return sendJson(res, 403, { success: false, error: "Özünüzdə olmayan icazəni başqasına verə bilməzsiniz: " + extra.join(", ") });
  }
  db.prepare("UPDATE users SET perms=?, updated_at=? WHERE id=?").run(JSON.stringify(next), now(), target.id);
  const a = new Set(prev.allow), n = new Set(next.allow);
  const added = next.allow.filter(k => !a.has(k)), removed = prev.allow.filter(k => !n.has(k));
  const cols = Object.entries(next.hideCols).map(([k, v]) => `${k}: ${v.join("|")}`).join("; ");
  auditCtx(req, ctx, { type: "admin", module: "users", action: "perms_change", detail: `${target.username} +[${added.join(",")}] -[${removed.join(",")}] gizli sütunlar: ${cols || "yox"}`, status: 200 });
  sendJson(res, 200, { success: true });
}
async function usersRevoke(req, res, ctx) {
  const b = await readJson(req);
  const target = getTarget(res, b.id); if (!target) return;
  if (!guardAdminTarget(res, ctx, target)) return;
  revokeUserSessions(target.id, "admin_revoke", target.id === ctx.user.id ? ctx.sid : "");
  auditCtx(req, ctx, { type: "admin", module: "users", action: "sessions_revoke", detail: target.username, status: 200 });
  sendJson(res, 200, { success: true });
}

/* ---------------- 2FA idarəetməsi (YALNIZ administrator) ---------------- */
async function usersMfaReset(req, res, ctx) {
  const b = await readJson(req);
  const target = getTarget(res, b.id); if (!target) return;
  db.prepare("UPDATE users SET totp_secret=NULL, totp_enabled=0, totp_last_step=0, totp_enrolled_at=NULL, failed_attempts=0, locked_until=0, updated_at=? WHERE id=?").run(now(), target.id);
  revokeUserSessions(target.id, "mfa_reset", target.id === ctx.user.id ? ctx.sid : "");
  auditCtx(req, ctx, { type: "admin", module: "users", action: "mfa_reset", detail: `${target.username}: 2FA sıfırlandı — növbəti girişdə QR ilə yenidən qurulacaq`, status: 200 });
  sendJson(res, 200, { success: true });
}
async function usersMfaRebuild(req, res, ctx) {
  const b = await readJson(req);
  const target = getTarget(res, b.id); if (!target) return;
  if (!mfaKey) return sendJson(res, 500, { success: false, error: "2FA açarı (atm_auth.key) yoxdur." });
  const secret = b32encode(crypto.randomBytes(20));
  db.prepare("UPDATE users SET totp_secret=?, totp_enabled=1, totp_last_step=0, totp_enrolled_at=?, failed_attempts=0, locked_until=0, updated_at=? WHERE id=?")
    .run(encSecret(secret), now(), now(), target.id);
  revokeUserSessions(target.id, "mfa_rebuild", target.id === ctx.user.id ? ctx.sid : "");
  auditCtx(req, ctx, { type: "admin", module: "users", action: "mfa_rebuild", detail: `${target.username}: yeni 2FA açarı yaradıldı (administrator tərəfindən)`, status: 200 });
  sendJson(res, 200, { success: true, username: target.username, issuer: MFA_ISSUER, secret, otpauth_uri: otpauthUri(secret, target.username) });
}
async function usersUnlock(req, res, ctx) {
  const b = await readJson(req);
  const target = getTarget(res, b.id); if (!target) return;
  db.prepare("UPDATE users SET failed_attempts=0, locked_until=0, updated_at=? WHERE id=?").run(now(), target.id);
  auditCtx(req, ctx, { type: "admin", module: "users", action: "unlock", detail: target.username, status: 200 });
  sendJson(res, 200, { success: true });
}

/* ---------------- /api/audit ---------------- */
function auditWhere(q) {
  const w = [], a = [];
  if (q.get("user_id")) { w.push("user_id=?"); a.push(Number(q.get("user_id"))); }
  if (q.get("type")) { w.push("type=?"); a.push(q.get("type")); }
  if (q.get("module")) { w.push("module=?"); a.push(q.get("module")); }
  const ts = s => { const d = Date.parse(s); return Number.isFinite(d) ? Math.floor(d / 1000) : null; };
  if (q.get("from") && ts(q.get("from")) != null) { w.push("ts>=?"); a.push(ts(q.get("from"))); }
  if (q.get("to") && ts(q.get("to")) != null) { w.push("ts<=?"); a.push(ts(q.get("to"))); }
  if (q.get("q")) { const like = "%" + q.get("q").replace(/[%_\\]/g, m => "\\" + m) + "%"; w.push("(username LIKE ? ESCAPE '\\' OR action LIKE ? ESCAPE '\\' OR detail LIKE ? ESCAPE '\\' OR path LIKE ? ESCAPE '\\' OR ip LIKE ? ESCAPE '\\')"); a.push(like, like, like, like, like); }
  return { sql: w.length ? " WHERE " + w.join(" AND ") : "", args: a };
}
function auditList(req, res) {
  const q = new URL(req.url, "http://x").searchParams;
  const { sql, args } = auditWhere(q);
  const limit = Math.min(500, Math.max(1, Number(q.get("limit")) || 100)), offset = Math.max(0, Number(q.get("offset")) || 0);
  const total = db.prepare("SELECT COUNT(*) c FROM audit" + sql).get(...args).c;
  const rows = db.prepare("SELECT id,ts,user_id,username,type,module,action,detail,method,path,status,ip FROM audit" + sql + " ORDER BY id DESC LIMIT ? OFFSET ?").all(...args, limit, offset);
  const users = db.prepare("SELECT id,username,first_name,last_name FROM users ORDER BY username").all();
  sendJson(res, 200, { success: true, total, rows, users });
}
function auditExport(req, res, ctx) {
  const q = new URL(req.url, "http://x").searchParams;
  const { sql, args } = auditWhere(q);
  const rows = db.prepare("SELECT ts,username,type,module,action,detail,method,path,status,ip FROM audit" + sql + " ORDER BY id DESC LIMIT 50000").all(...args);
  const esc = v => { let s = v == null ? "" : String(v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };
  const lines = ["Vaxt;İstifadəçi;Tip;Modul;Əməliyyat;Detal;Metod;Yol;Status;IP"];
  for (const r of rows) lines.push([new Date(r.ts * 1000).toISOString().replace("T", " ").slice(0, 19), r.username, r.type, r.module, r.action, r.detail, r.method, r.path, r.status, r.ip].map(esc).join(";"));
  auditCtx(req, ctx, { type: "admin", module: "audit", action: "audit_export", detail: rows.length + " sətir", status: 200 });
  res.writeHead(200, { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": 'attachment; filename="atm_audit.csv"', "Cache-Control": "no-store" });
  res.end("﻿" + lines.join("\r\n"));
}
async function auditTrack(req, res, ctx) {
  const b = await readJson(req);
  const events = Array.isArray(b.events) ? b.events.slice(0, 60) : [];
  for (const e of events) {
    if (!e || (e.type !== "nav" && e.type !== "click")) continue;
    auditCtx(req, ctx, { type: e.type, module: clip(e.module, 30), action: clip(e.action, 120), detail: clip(e.detail, 200), path: null, method: null });
  }
  sendJson(res, 200, { success: true });
}

/* ---------------- Gateway ---------------- */
function forbid(req, res, ctx, need) {
  const pathname = (req.url || "").split("?")[0];
  if (!(req.method === "GET" && QUIET_GET.test(pathname)))
    auditCtx(req, ctx, { type: "denied", action: "icazə yoxdur", detail: "tələb olunan: " + need, status: 403 });
  sendJson(res, 403, { success: false, request_ok: false, error: "Bu əməliyyat üçün icazəniz yoxdur.", code: "FORBIDDEN", need });
}
const unauth = res => sendJson(res, 401, { success: false, request_ok: false, error: "Giriş tələb olunur.", code: "UNAUTHENTICATED" });

/* true qaytarırsa sorğu burada cavablandırılıb; {proxy:true, ctx, bodyLog} qaytarırsa Python-a ötürülməlidir */
async function handleApi(req, res) {
  const pathname = (req.url || "/").split("?")[0];
  const method = req.method || "GET";
  try {
    if (pathname === "/api/agent/report") {            // ATM agent-ləri (maşın → server), brauzer sessiyası yoxdur
      if (method !== "POST") return sendJson(res, 405, { success: false, error: "Yalnız POST." }), true;
      return { proxy: true, ctx: null };
    }
    if (pathname === "/api/agent/telemetry") {          // ATM Monitoring Agent → server; per-ATM HMAC imzası (sessiya yox)
      if (method !== "POST") return sendJson(res, 405, { success: false, error: "Yalnız POST." }), true;
      return { proxy: true, ctx: null };
    }
    if (method !== "GET" && method !== "HEAD" && req.headers["x-requested-with"] !== "atm-web")
      return sendJson(res, 403, { success: false, error: "Sorğu rədd edildi (CSRF qoruması)." }), true;

    if (pathname === "/api/auth/login") { if (method !== "POST") return unauth(res), true; await handleLogin(req, res); return true; }
    if (pathname === "/api/auth/mfa") { if (method !== "POST") return unauth(res), true; await handleMfa(req, res); return true; }
    if (pathname === "/api/auth/refresh") { if (method !== "POST") return unauth(res), true; handleRefresh(req, res); return true; }
    if (pathname === "/api/auth/logout") { if (method !== "POST") return unauth(res), true; handleLogout(req, res); return true; }

    const ctx = authenticate(req);
    if (!ctx) return unauth(res), true;
    if (pathname === "/api/me") return sendJson(res, 200, mePayload(ctx)), true;
    if (pathname === "/api/auth/change-password" && method === "POST") { await handleChangePassword(req, res, ctx); return true; }
    if (ctx.user.must_change_password)
      return sendJson(res, 403, { success: false, error: "Davam etmək üçün şifrənizi dəyişməlisiniz.", code: "PASSWORD_CHANGE_REQUIRED" }), true;

    if (pathname === "/api/audit/track" && method === "POST") { await auditTrack(req, res, ctx); return true; }
    if (pathname === "/api/audit") { if (!can(ctx, "audit")) return forbid(req, res, ctx, "audit"), true; auditList(req, res); return true; }
    if (pathname === "/api/audit/export") { if (!can(ctx, "audit.export")) return forbid(req, res, ctx, "audit.export"), true; auditExport(req, res, ctx); return true; }

    if (pathname === "/api/users") { if (!can(ctx, "users")) return forbid(req, res, ctx, "users"), true; usersList(req, res); return true; }
    if (pathname.startsWith("/api/users/")) {
      if (method !== "POST") return sendJson(res, 405, { success: false, error: "Yalnız POST." }), true;
      // 2FA sıfırla / yenidən qur / kilidi aç — icazə kataloqundan asılı olmayaraq YALNIZ administrator
      const adminOnly = { "/api/users/mfa/reset": usersMfaReset, "/api/users/mfa/rebuild": usersMfaRebuild, "/api/users/unlock": usersUnlock }[pathname];
      if (adminOnly) {
        if (!ctx.user.is_admin) return forbid(req, res, ctx, "admin"), true;
        await adminOnly(req, res, ctx); return true;
      }
      const table = { "/api/users/save": [null, usersSave], "/api/users/status": ["users.delete", usersStatus], "/api/users/access": ["users.edit", usersAccess],
        "/api/users/reset-password": ["users.reset", usersReset], "/api/users/perms": ["users.perms", usersPerms], "/api/users/sessions/revoke": ["users.sessions", usersRevoke] }[pathname];
      if (!table) return sendJson(res, 404, { success: false, error: "Tapılmadı." }), true;
      if (!can(ctx, "users") || (table[0] && !can(ctx, table[0]))) return forbid(req, res, ctx, table[0] || "users"), true;
      await table[1](req, res, ctx); return true;
    }

    const need = ROUTES[pathname];
    if (!need) { if (!ctx.user.is_admin) return forbid(req, res, ctx, "admin"), true; }
    else if (!canAny(ctx, need)) return forbid(req, res, ctx, need.join(" | ")), true;
    return { proxy: true, ctx };
  } catch (e) {
    if (!res.headersSent) sendJson(res, 400, { success: false, error: String(e.message || e) });
    return true;
  }
}
/* Python-a ötürülən sorğunun audit qeydi */
function logProxied(req, ctx, status, bodyBuf) {
  const [pathname, qs] = (req.url || "").split("?");
  if (!ctx) return;
  if (req.method === "GET" && QUIET_GET.test(pathname)) return;
  let detail = "";
  if (qs) detail = qs.replace(/(^|&)t=\d+/g, "").replace(/^&/, "");
  if (bodyBuf && bodyBuf.length) { try { detail = (detail ? detail + " " : "") + JSON.stringify(redact(JSON.parse(bodyBuf.toString("utf8")))); } catch {} }
  const key = (ROUTES[pathname] || [""])[0] || "";
  auditCtx(req, ctx, { type: "api", module: key === ANY ? null : key.split(".")[0] || null, action: pathname.replace(/^\/api\//, ""), detail, status });
}

module.exports = { init, authenticate, handleApi, logProxied, can, readBody, clearCookies };
