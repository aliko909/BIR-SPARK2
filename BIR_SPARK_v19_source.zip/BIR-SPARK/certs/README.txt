SERTIFIKAT QOVLUGU (HTTPS ucun)
================================
START.bat-da "2) Sertifikatli port (HTTPS)" secdikde bu fayllar lazimdir:

  certs\server.crt   <- sertifikat (PEM format: -----BEGIN CERTIFICATE-----)
  certs\server.key   <- gizli acar (PEM: -----BEGIN PRIVATE KEY-----)

Onlari ya bankin daxili CA-sindan alin, ya da TEST ucun MAKE_TEST_CERT.bat ile yaradin.
START.bat basqa yol da sorusacaq - istesеniz tam yol gosterin.

QEYD:
- Fayllar PEM formatinda olmalidir. .pfx varsa, once .crt + .key-e cevirin.
- Sertifikatsiz baslamaq ucun START.bat-da "1) Sertifikatsiz (HTTP)" secin - sertifikat lazim deyil.
