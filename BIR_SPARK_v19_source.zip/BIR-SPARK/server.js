"use strict";

const http = require("http");
const https = require("https");
const fs = require("fs");
const path = require("path");
const { spawn, exec } = require("child_process");
const auth = require("./auth");

const ROOT = __dirname;
const WEB_DIR = path.join(ROOT, "web");
const TILE_DIR = path.join(ROOT, "map_tiles");
const TILE_RE = /^\/tiles\/(street|satellite|labels)\/(\d{1,2})\/(\d{1,7})\/(\d{1,7})\.(png|jpg)$/;
const NODE_PORT = Number(process.env.ATM_WEB_PORT || 8080);
const PY_PORT = Number(process.env.ATM_PY_PORT || 8081);
const HOST = "127.0.0.1";
// LISTEN_HOST: Node frontend/gateway hansı interfeysdə dinləsin.
// Default 0.0.0.0 = bütün interfeyslər, yəni ATM agent-ləri 172.21.12.80:8080-ə
// sorğu göndərə bilir. Yalnız lokal istəsən: set ATM_WEB_BIND=127.0.0.1
const LISTEN_HOST = process.env.ATM_WEB_BIND || "0.0.0.0";
const IS_WIN = process.platform === "win32";
let pythonChild = null;
let shuttingDown = false;

function contentType(file) {
  const ext = path.extname(file).toLowerCase();
  return ({
    ".html":"text/html; charset=utf-8", ".css":"text/css; charset=utf-8",
    ".js":"application/javascript; charset=utf-8", ".json":"application/json; charset=utf-8",
    ".png":"image/png", ".jpg":"image/jpeg", ".jpeg":"image/jpeg", ".gif":"image/gif",
    ".svg":"image/svg+xml", ".ico":"image/x-icon", ".txt":"text/plain; charset=utf-8",
    ".woff2":"font/woff2", ".webp":"image/webp", ".map":"application/json; charset=utf-8"
  })[ext] || "application/octet-stream";
}

function safeJoin(base, requestPath) {
  let decoded;
  try { decoded = decodeURIComponent(requestPath.split("?")[0]); } catch { return null; }
  const normalized = path.posix.normalize(decoded).replace(/^\/+/, "");
  if (normalized.includes("..")) return null;
  const full = path.resolve(base, ...normalized.split("/"));
  const baseResolved = path.resolve(base) + path.sep;
  if (full !== path.resolve(base) && !full.startsWith(baseResolved)) return null;
  return full;
}

// Təhlükəsizlik başlıqları (offline tətbiq: bütün resurslar 'self'-dən gəlir).
// Inline script/style işlədildiyi üçün 'unsafe-inline' saxlanılır, amma xarici
// mənbələr və data sızması default-src/connect-src 'self' ilə bloklanır.
const CSP = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "media-src 'self' blob:",
  "font-src 'self' data:",
  "connect-src 'self'",
  "worker-src 'self' blob:",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'"
].join("; ");
function securityHeaders() {
  const h = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "same-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=(), usb=()",
    "Content-Security-Policy": CSP
  };
  if (USE_HTTPS) h["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains";
  return h;
}

function sendFile(req, res, filePath) {
  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) {
      res.writeHead(404, {"Content-Type":"text/plain; charset=utf-8"});
      res.end("Fayl tapılmadı.");
      return;
    }
    const headers = {
      "Content-Type": contentType(filePath),
      "Content-Length": st.size,
      "Cache-Control": /\.(html|js|css)$/i.test(filePath) ? "no-cache" : "public, max-age=3600",
      ...securityHeaders()
    };
    res.writeHead(200, headers);
    const stream = fs.createReadStream(filePath);
    stream.on("error", () => { if (!res.headersSent) res.writeHead(500); res.end(); });
    stream.pipe(res);
  });
}

function sendTile(res, filePath, st) {
  res.writeHead(200, {"Content-Type": contentType(filePath), "Content-Length": st.size, "Cache-Control": "public, max-age=604800"});
  const stream = fs.createReadStream(filePath);
  stream.on("error", () => { try { res.end(); } catch {} });
  stream.pipe(res);
}

function proxyApi(req, res, ctx, bodyBuf) {
  const headers = {...req.headers, host: `${HOST}:${PY_PORT}`};
  delete headers.cookie;                                   // token-lər Python-a ötürülmür
  if (ctx) headers["x-atm-user"] = encodeURIComponent(ctx.user.username);
  if (bodyBuf) { headers["content-length"] = String(bodyBuf.length); delete headers["transfer-encoding"]; }
  const proxy = http.request({host: HOST, port: PY_PORT, path: req.url, method: req.method, headers}, upstream => {
    auth.logProxied(req, ctx, upstream.statusCode || 502, bodyBuf);
    res.writeHead(upstream.statusCode || 502, upstream.headers);
    upstream.pipe(res);
  });
  proxy.on("error", err => {
    if (res.headersSent) { try { res.end(); } catch {} return; }
    res.writeHead(502, {"Content-Type":"application/json; charset=utf-8", "Cache-Control":"no-store"});
    res.end(JSON.stringify({success:false, request_ok:false, error:`Python backend cavab vermir: ${err.message}`}));
  });
  if (bodyBuf) proxy.end(bodyBuf); else req.pipe(proxy);
}

async function handleApi(req, res) {
  const r = await auth.handleApi(req, res);
  if (r === true || !r || !r.proxy) return;
  if (req.method === "GET" || req.method === "HEAD") return proxyApi(req, res, r.ctx, null);
  let body;
  try { body = await auth.readBody(req, 16 * 1024 * 1024); }
  catch (e) { res.writeHead(413, {"Content-Type":"application/json; charset=utf-8"}); return res.end(JSON.stringify({success:false, error:String(e.message||e)})); }
  proxyApi(req, res, r.ctx, body);
}

function redirect(res, to) { res.writeHead(302, {Location: to, "Cache-Control": "no-store"}); res.end(); }
function deny401(res) { res.writeHead(401, {"Content-Type":"text/plain; charset=utf-8", "Cache-Control":"no-store"}); res.end("Giriş tələb olunur."); }

function pythonExecutable() {
  if (process.env.ATM_PYTHON) return process.env.ATM_PYTHON;
  if (IS_WIN) {
    const known = "C:\\ProgramData\\Anaconda3\\python.exe";
    if (fs.existsSync(known)) return known;
    return "python.exe";
  }
  return process.env.PYTHON || "python3";
}

function startPython() {
  const exe = pythonExecutable();
  const env = {...process.env, ATM_PY_PORT: String(PY_PORT), ATM_NO_BROWSER: "1"};
  console.log(`[NODE] Python engine: ${exe} server.py -> http://${HOST}:${PY_PORT}`);
  pythonChild = spawn(exe, [path.join(ROOT, "server.py")], {cwd: ROOT, env, stdio: "inherit", windowsHide: true});
  pythonChild.on("error", err => console.error("[NODE] Python engine başlatma xətası:", err.message));
  pythonChild.on("exit", (code, signal) => {
    pythonChild = null;
    if (!shuttingDown) console.error(`[NODE] Python engine dayandı. code=${code} signal=${signal || "-"}`);
  });
}

function openBrowser() {
  const url = `${USE_HTTPS ? "https" : "http"}://localhost:${NODE_PORT}/`;
  if (!IS_WIN) return;
  exec(`start "" "${url}"`, {windowsHide:true}, () => {});
}

function backendReady(timeoutMs=20000) {
  return new Promise(resolve => {
    const started = Date.now();
    const tryOnce = () => {
      const r = http.get({host:HOST, port:PY_PORT, path:"/api/config", timeout:1200}, resp => {
        resp.resume();
        if ((resp.statusCode || 500) < 500) return resolve(true);
        setTimeout(tryOnce, 350);
      });
      r.on("timeout", () => r.destroy());
      r.on("error", () => {
        if (Date.now() - started >= timeoutMs) resolve(false);
        else setTimeout(tryOnce, 350);
      });
    };
    tryOnce();
  });
}

function stopPython() {
  if (!pythonChild || !pythonChild.pid) return;
  const pid = pythonChild.pid;
  if (IS_WIN) exec(`taskkill /PID ${pid} /T /F`, {windowsHide:true}, () => {});
  else { try { pythonChild.kill("SIGTERM"); } catch {} }
}

function requestHandler(req, res) {
  const pathname = (req.url || "/").split("?")[0];
  // Sadə ATM Agent endpoint-i (sessiya yox): POST /agent -> Python
  if (pathname === "/agent") {
    if ((req.method || "") !== "POST") { res.writeHead(405, {"Content-Type":"application/json; charset=utf-8"}); return res.end(JSON.stringify({success:false, error:"Yalnız POST."})); }
    return void auth.readBody(req, 512 * 1024).then(body => proxyApi(req, res, null, body))
      .catch(() => { if (!res.headersSent) res.writeHead(413); try { res.end(); } catch {} });
  }
  if (pathname.startsWith("/api/")) return void handleApi(req, res).catch(err => { console.error("[NODE] API xətası:", err); if (!res.headersSent) { res.writeHead(500); } try { res.end(); } catch {} });
  if (pathname === "/node/health") {
    res.writeHead(200, {"Content-Type":"application/json; charset=utf-8", "Cache-Control":"no-store"});
    return res.end(JSON.stringify({ok:true, node:process.version, frontend_port:NODE_PORT, python_port:PY_PORT, python_running:!!pythonChild}));
  }
  // Bu nöqtədən sonra: login səhifəsi və statik asset-lərdən başqa hər şey sessiya tələb edir
  const ctx = auth.authenticate(req);
  if (pathname === "/node/map-info" || pathname.startsWith("/tiles/") || pathname.startsWith("/modules/")) {
    if (!ctx || ctx.user.must_change_password) return deny401(res);
  }
  if (pathname === "/node/map-info") {
    let manifest = null;
    try { manifest = JSON.parse(fs.readFileSync(path.join(TILE_DIR, "manifest.json"), "utf8")); } catch {}
    res.writeHead(200, {"Content-Type":"application/json; charset=utf-8", "Cache-Control":"no-store"});
    return res.end(JSON.stringify({ok:true, available:!!(manifest && manifest.layers && Object.keys(manifest.layers).length), manifest}));
  }
  if (pathname.startsWith("/tiles/")) {
    const m = TILE_RE.exec(pathname);
    if (!m) { res.writeHead(400, {"Content-Type":"text/plain; charset=utf-8"}); return res.end("Yanlış tile path."); }
    const [, layer, z, x, y] = m;
    // Fayl diskdə hansı uzantı ilə saxlanıbsa onu ver (png/jpg provider-dən asılıdır)
    const base = path.join(TILE_DIR, layer, z, x, y);
    return fs.stat(base + ".png", (e1, s1) => {
      if (!e1 && s1.isFile()) return sendTile(res, base + ".png", s1);
      fs.stat(base + ".jpg", (e2, s2) => {
        if (!e2 && s2.isFile()) return sendTile(res, base + ".jpg", s2);
        res.writeHead(404, {"Content-Type":"text/plain; charset=utf-8", "Cache-Control":"no-store"});
        res.end("tile yoxdur");
      });
    });
  }
  if (pathname === "/" || pathname === "/index.html") return redirect(res, "/home.html");
  if (pathname === "/home.html") {
    // Etibarlı access token varsa birbaşa home; yoxdursa login səhifəsi refresh token ilə səssiz bərpa etməyə çalışır
    if (!ctx) return redirect(res, "/login.html" + (req.url.includes("?") ? "?next=" + encodeURIComponent(req.url) : ""));
    if (ctx.user.must_change_password) return redirect(res, "/login.html?change=1");
  }
  if (pathname === "/login.html" && ctx && !ctx.user.must_change_password) return redirect(res, "/home.html");
  const target = safeJoin(WEB_DIR, pathname);
  if (!target) { res.writeHead(400, {"Content-Type":"text/plain; charset=utf-8"}); res.end("Yanlış path."); return; }
  sendFile(req, res, target);
}

/* HTTP yoxsa HTTPS? ATM_WEB_HTTPS=1 və sertifikat/açar oxunursa HTTPS; əks halda HTTP. */
let USE_HTTPS = false;
let server;
(function buildServer() {
  const want = String(process.env.ATM_WEB_HTTPS || "").trim() === "1";
  if (want) {
    const pfxPath = process.env.ATM_WEB_PFX || "";
    const certPath = process.env.ATM_WEB_CERT || "";
    const keyPath = process.env.ATM_WEB_KEY || "";
    try {
      let opts;
      if (pfxPath) {
        // PowerShell ile yaradilan .pfx birbasa (PEM-e cevirmeye ehtiyac yoxdur)
        opts = { pfx: fs.readFileSync(pfxPath), passphrase: process.env.ATM_WEB_PFX_PASS || "" };
        console.log(`[NODE] HTTPS (sertifikatli) rejim: pfx=${pfxPath}`);
      } else {
        opts = { cert: fs.readFileSync(certPath), key: fs.readFileSync(keyPath) };
        if (process.env.ATM_WEB_CA) { try { opts.ca = fs.readFileSync(process.env.ATM_WEB_CA); } catch {} }
        console.log(`[NODE] HTTPS (sertifikatli) rejim: cert=${certPath}`);
      }
      server = https.createServer(opts, requestHandler);
      USE_HTTPS = true;
    } catch (e) {
      console.error(`[NODE] XEBERDARLIQ: Sertifikat/acar oxunmadi (${e.message}). HTTP rejimine kecilir.`);
      server = http.createServer(requestHandler);
    }
  } else {
    server = http.createServer(requestHandler);
  }
})();

server.on("error", err => {
  if (err.code === "EADDRINUSE") {
    console.error(`[NODE] ERROR: ${NODE_PORT} portu artıq istifadə olunur. Köhnə ATM WEB pəncərəsini bağla.`);
  } else console.error("[NODE] Server xətası:", err);
  stopPython();
  process.exit(1);
});

async function main() {
  auth.init(ROOT);
  startPython();
  server.listen(NODE_PORT, LISTEN_HOST, async () => {
    console.log("\n==========================================");
    console.log(" ATM WEB — NODE.JS MODULAR FRONTEND");
    console.log("==========================================");
    const scheme = USE_HTTPS ? "https" : "http";
    console.log(`WEB: ${scheme}://localhost:${NODE_PORT}/home.html`);
    console.log(`Listen host: ${LISTEN_HOST} (agent endpoint: ${scheme}://<server-ip>:${NODE_PORT}/api/agent/telemetry)`);
    console.log(`Python API engine: http://${HOST}:${PY_PORT}`);
    let tileInfo = "YOXDUR — PREPARE_OFFLINE_MAP.bat işlədin";
    try { const mf = JSON.parse(fs.readFileSync(path.join(TILE_DIR, "manifest.json"), "utf8")); tileInfo = Object.entries(mf.layers || {}).map(([k, v]) => `${k} z${v.minZoom}-${v.maxZoom} (${v.tiles})`).join(", ") || tileInfo; } catch {}
    console.log("Xəritə: Leaflet lokal • tile-lar: " + tileInfo);
    console.log("Internet: tələb olunmur • xarici tile/API/CDN yoxdur");
    console.log("Modullar: web/modules/*.html\n");
    const ready = await backendReady();
    console.log(ready ? "[NODE] Python API hazırdır." : "[NODE] XƏBƏRDARLIQ: Python API 20 saniyədə hazır olmadı.");
    openBrowser();
  });
}

function shutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log("\n[NODE] ATM WEB bağlanır...");
  server.close(() => process.exit(0));
  stopPython();
  setTimeout(() => process.exit(0), 1500).unref();
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
process.on("exit", () => { if (!shuttingDown) stopPython(); });

main();
