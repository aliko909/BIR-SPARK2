# ATM WEB - collect.ps1
# ATM-in ozunde (lokal) islenir, yaninda atminfo.json yaradir.
# collect.bat tefefinden cagirilir. Xarici modul yoxdur; kohne Windows (PS2) ucun JSON elle qurulur.
$ErrorActionPreference = "SilentlyContinue"
$out = Join-Path $PSScriptRoot "atminfo.json"

function JStr($v){ if($v -eq $null){return '""'}; $s=[string]$v; $s=$s -replace '\\','\\'; $s=$s -replace '"','\"'; $s=$s -replace "`r",''; $s=$s -replace "`n",' ' ; $s=$s -replace "`t",' '; return '"'+$s+'"' }
function JNum($v){ if($v -eq $null -or $v -eq ''){return 'null'}; return [string]([double]$v) }

$os  = Get-WmiObject Win32_OperatingSystem
$cpu = @(Get-WmiObject Win32_Processor)
$cs  = Get-WmiObject Win32_ComputerSystem

# CPU %
$load = $null
if($cpu.Count -gt 0){ $vals=@(); foreach($c in $cpu){ if($c.LoadPercentage -ne $null){$vals+=[int]$c.LoadPercentage} }; if($vals.Count -gt 0){ $load=[math]::Round(($vals | Measure-Object -Average).Average,1) } }
$cpuName = ($cpu[0].Name).Trim()
$cores = 0; foreach($c in $cpu){ if($c.NumberOfLogicalProcessors){$cores+=[int]$c.NumberOfLogicalProcessors} }
if($cores -eq 0){ $cores=[int]$env:NUMBER_OF_PROCESSORS }

# RAM (KB -> bytes)
$ramTotal = [int64]$os.TotalVisibleMemorySize * 1024
$ramFree  = [int64]$os.FreePhysicalMemory * 1024
$ramUsed  = $ramTotal - $ramFree
$ramPct   = $null; if($ramTotal -gt 0){ $ramPct=[math]::Round(100.0*$ramUsed/$ramTotal,1) }

# OS
$arch = $os.OSArchitecture; if(-not $arch){ if($env:PROCESSOR_ARCHITEW6432 -or $env:PROCESSOR_ARCHITECTURE -match '64'){$arch='64-bit'}else{$arch='32-bit'} }

# uptime
$upSec=$null; $boot=''
try{ $bt=[Management.ManagementDateTimeConverter]::ToDateTime($os.LastBootUpTime); $upSec=[int]((Get-Date)-$bt).TotalSeconds; $boot=$bt.ToString('yyyy-MM-dd HH:mm:ss') }catch{}

# disks (fixed = DriveType 3)
$diskJson=@()
foreach($d in (Get-WmiObject Win32_LogicalDisk -Filter "DriveType=3")){
  $t=[int64]$d.Size; $f=[int64]$d.FreeSpace; $u=$t-$f; $p=$null; if($t -gt 0){$p=[math]::Round(100.0*$u/$t,1)}
  $diskJson += "{""name"":"+(JStr $d.DeviceID)+",""label"":"+(JStr $d.VolumeName)+",""filesystem"":"+(JStr $d.FileSystem)+",""total_bytes"":"+(JNum $t)+",""used_bytes"":"+(JNum $u)+",""free_bytes"":"+(JNum $f)+",""used_percent"":"+(JNum $p)+"}"
}

$now = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ss')
$json = "{"+
 """status"":""online""," +
 """collector"":""collect.bat""," +
 """collected_at"":"+(JStr $now)+","+
 """hostname"":"+(JStr $env:COMPUTERNAME)+","+
 """os_name"":"+(JStr $os.Caption)+","+
 """os_version"":"+(JStr $os.Version)+","+
 """os_build"":"+(JStr $os.BuildNumber)+","+
 """os_architecture"":"+(JStr $arch)+","+
 """cpu_name"":"+(JStr $cpuName)+","+
 """cpu_cores"":"+(JNum $cores)+","+
 """cpu_percent"":"+(JNum $load)+","+
 """ram_total_bytes"":"+(JNum $ramTotal)+","+
 """ram_used_bytes"":"+(JNum $ramUsed)+","+
 """ram_free_bytes"":"+(JNum $ramFree)+","+
 """ram_percent"":"+(JNum $ramPct)+","+
 """uptime_seconds"":"+(JNum $upSec)+","+
 """boot_time"":"+(JStr $boot)+","+
 """disks"":["+ ($diskJson -join ",") +"]"+
 "}"

Set-Content -Path $out -Value $json -Encoding UTF8
