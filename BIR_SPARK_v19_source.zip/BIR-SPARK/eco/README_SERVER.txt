BU QOVLUGU SERVERDE  C:\eco  KIMI YERLESDIR.
Icindeki collect.bat ve collect.ps1 fayllari server terefinden her ATM-in
C:\Users\Administrator\Documents\.default_80 qovluguna avtomatik kopyalanir.
ATM-e el ile hec ne atmaq lazim deyil. (Yalniz 445 secimi ucun.)
